/* PILD — Leadership Assessment front-end wizard (dashboard tab)
   Markup/classnames match the original standalone assessment site 1:1
   (see assets/leadership-assessment.css) — this file only supplies the
   interactivity (card selection, AJAX, question stepping) that the
   original pages had spread across index/category-sector/goals/
   assessment/results.html, now driven from one embedded panel. */
(function ($) {
  'use strict';
  if (typeof PILD_LA === 'undefined') return;

  var LETTERS = (PILD_LA.i18n && PILD_LA.i18n.letters) || ['أ', 'ب', 'ج', 'د', 'هـ'];

  /* ---------- multi-type question engine (ported from the standalone
     assessment.html 1:1 — see that file's inline <script> for the
     original). Every question's underlying data is a text_ar/text_en +
     options_ar/options_en(1-5) pair; these constants only decide which
     *input widget* presents that same 1-5 choice for a given question
     position, purely for variety. The value the plugin scores and
     stores server-side is always a plain integer 1-5 per session_id,
     regardless of which widget produced it. Label TEXT for these tags
     comes from PILD_LA.i18n.qType (localized server-side); only the
     icon/dotColor — purely visual — live here. */
  var Q_TYPE_MAP = {
    situational: { icon: 'target',  dotColor: 'var(--purple)' },
    behavioral:  { icon: 'user',    dotColor: 'var(--plum, #8C6B78)' },
    ranking:     { icon: 'list',    dotColor: 'var(--cyan)' },
    slider:      { icon: 'sliders', dotColor: 'var(--amber)' },
    likert:      { icon: 'check',   dotColor: 'var(--green)' },
  };

  // Fixed 36-slot rotation (18 situational, 7 behavioral, 5 ranking,
  // 4 slider, 2 likert) applied by question *position* in the session,
  // reused via modulo if a session is ever a different length.
  var TYPE_SEQUENCE = [
    'situational', 'situational', 'situational', 'behavioral', 'situational',
    'situational', 'ranking',     'situational', 'slider',     'situational',
    'behavioral',  'situational', 'ranking',     'situational', 'likert',
    'situational', 'behavioral',  'ranking',     'situational', 'situational',
    'slider',      'behavioral',  'situational', 'ranking',     'situational',
    'slider',      'situational', 'behavioral',  'situational', 'ranking',
    'situational', 'slider',      'likert',      'situational', 'behavioral',
    'situational',
  ];

  // dotColor is the only visual-only part of this map now; label text
  // for each source badge comes from PILD_LA.i18n.srcMeta.
  var SRC_META = {
    general:     { dotColor: 'var(--purple)' },
    category:    { dotColor: 'var(--green)' },
    sector:      { dotColor: 'var(--cyan)' },
    consistency: { dotColor: 'var(--amber)' },
  };

  // Slider pole labels and ranking-item fallback labels are localized
  // server-side (PILD_LA.i18n.sliderPoles / rankingItems / *Fallback)
  // since they depend on the current site language.
  var SLIDER_POLES = (PILD_LA.i18n && PILD_LA.i18n.sliderPoles) || {};
  var RANKING_ITEMS = (PILD_LA.i18n && PILD_LA.i18n.rankingItems) || {};
  var RANKING_FALLBACK = (PILD_LA.i18n && PILD_LA.i18n.rankingFallback) || ['1', '2', '3', '4'];
  var SLIDER_FALLBACK = (PILD_LA.i18n && PILD_LA.i18n.sliderFallback) || { right: '1', left: '5' };

  var LIKERT_LABELS = (PILD_LA.i18n && PILD_LA.i18n.likert) || ['1', '2', '3', '4', '5'];
  var ICONS = PILD_LA.icons || {};
  function ico(n) { return ICONS[n] || ''; }

  var state = {
    categories: [],
    selectedCategory: null,
    selectedSector: null,
    selectedGoal: null,
    attemptId: null,
    questions: [],
    qTypes: [],
    idx: 0,
    answers: {},
    rankOrder: {},
    sliderVals: {},
    compMeta: {}, // built from PILD_LA.competencies: id -> {ar, color}
  };

  function ajax(action, data, onSuccess, onError) {
    data = data || {};
    data.action = action;
    data.nonce = PILD_LA.nonce;
    $.post(PILD_LA.ajaxUrl, data)
      .done(function (res) {
        if (res && res.success) onSuccess(res.data);
        else onError((res && res.data) || PILD_LA.i18n.error);
      })
      .fail(function () { onError(PILD_LA.i18n.error); });
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // Pick the _en or _ar variant of a data field based on the site language.
  function pick(obj, base) {
    if (!obj) return '';
    if (PILD_LA.isEn) return obj[base + '_en'] || obj[base + '_ar'] || '';
    return obj[base + '_ar'] || obj[base + '_en'] || '';
  }
  // Direction the decorative slider fill grows from (matches the native
  // range thumb, which browsers already flip for dir=ltr/rtl).
  var FILL_DIR = PILD_LA.isEn ? 'to right' : 'to left';

  function checkReady($root) {
    var ready = state.selectedCategory && state.selectedSector && state.selectedGoal;
    $root.find('#pild-la-start-btn').prop('disabled', !ready);
  }

  /* ---------- slide navigation (welcome -> category -> sector -> goal) ---------- */
  function showScreen($root, id) {
    $root.find('.screen').removeClass('active');
    $root.find('#' + id).addClass('active');
    var el = $root.get(0);
    if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- category / sector / goal card picker ---------- */
  function initPicker($root) {
    var dataEl = $root.find('#pild-la-categories-data');
    try { state.categories = JSON.parse(dataEl.text() || '[]'); } catch (e) { state.categories = []; }

    $root.on('click', '#pild-la-welcome-next-btn', function () {
      showScreen($root, 'pild-la-category-screen');
    });

    $root.on('click', '.pild-la-back-nav', function () {
      showScreen($root, $(this).data('target'));
    });

    $root.on('click', '.cat-card', function () {
      var catId = $(this).data('id');
      state.selectedCategory = catId;
      state.selectedSector = null;
      $root.find('.cat-card').removeClass('selected');
      $(this).addClass('selected');

      var cat = state.categories.find(function (c) { return c.id === catId; });
      renderSectors($root, cat ? (cat.sectors || []) : []);
      checkReady($root);

      // brief pause so the person sees their selection highlight before
      // the slide flips to the sub-sector screen.
      setTimeout(function () { showScreen($root, 'pild-la-sector-screen'); }, 280);
    });

    $root.on('click', '.sector-card', function () {
      state.selectedSector = $(this).data('id');
      $root.find('.sector-card').removeClass('selected');
      $(this).addClass('selected');
      checkReady($root);

      setTimeout(function () { showScreen($root, 'pild-la-goal-screen'); }, 280);
    });

    $root.on('click', '.goal-card', function () {
      state.selectedGoal = $(this).data('id');
      $root.find('.goal-card').removeClass('selected');
      $(this).addClass('selected');
      checkReady($root);
    });
  }

  // Spread N cards over even rows (max 5 per row) — mirrors
  // pild_la_grid_cols() in the PHP file.
  function gridCols(n) {
    if (n <= 5) return Math.max(n, 1);
    var best = 5, bestEmpty = (5 - n % 5) % 5;
    for (var k = 4; k >= 3; k--) {
      var e = (k - n % k) % k;
      if (e < bestEmpty) { best = k; bestEmpty = e; }
    }
    return best;
  }

  function renderSectors($root, sectors) {
    var grid = $root.find('#pild-la-sectors-grid');
    var html = '';
    sectors.forEach(function (s) {
      html += '<div class="sector-card" data-id="' + s.id + '">' +
        '<div class="sector-radio"></div>' +
        '<div class="sector-card-text">' +
        '<div class="sector-card-ar">' + escapeHtml(PILD_LA.isEn ? s.label_en : s.label_ar) + '</div>' +
        '</div></div>';
    });
    grid.css('--la-cols', gridCols(sectors.length)).html(html);
  }

  /* ---------- start ---------- */
  function startAssessment($root) {
    if (!state.selectedCategory || !state.selectedSector || !state.selectedGoal) {
      alert(PILD_LA.i18n.selectSector);
      return;
    }
    var $btn = $root.find('#pild-la-start-btn').prop('disabled', true);
    var originalHtml = $btn.html();
    $btn.html('<span>…</span>');

    ajax('pild_la_start', {
      category_id: state.selectedCategory,
      sector_id: state.selectedSector,
      goal_id: state.selectedGoal,
    }, function (data) {
      state.attemptId = data.attempt_id;
      state.questions = data.questions;
      state.qTypes = state.questions.map(function (q, i) {
        // Consistency-check questions always use the plain likert
        // widget (matches the original static site); everything else
        // follows the fixed rotation by position.
        if (q.questionType === 'consistency') return 'likert';
        return TYPE_SEQUENCE[i % TYPE_SEQUENCE.length];
      });
      state.idx = 0;
      state.answers = {};
      state.rankOrder = {};
      state.sliderVals = {};
      state.compMeta = {};
      (PILD_LA.competencies || []).forEach(function (c) {
        state.compMeta[c.id] = { ar: pick(c, 'label'), color: c.color };
      });
      $root.find('#pild-la-intro').hide();
      renderQuestion($root);
      $root.find('#pild-la-wizard').show();
    }, function (err) {
      alert(err);
      $btn.prop('disabled', false).html(originalHtml);
    });
  }

  /* ---------- dots progress ---------- */
  function dotsHtml() {
    var html = '<div class="dots">';
    state.questions.forEach(function (q, i) {
      var cls = i === state.idx ? 'current' : (state.answers[q.session_id] ? 'answered' : '');
      html += '<div class="dot ' + cls + '" data-idx="' + i + '"></div>';
    });
    html += '</div>';
    return html;
  }

  /* ---------- per-type body builders ---------- */
  function buildOptions(q, selected) {
    var html = '<div class="opts">';
    (((PILD_LA.isEn && q.options_en) ? q.options_en : q.options_ar) || []).forEach(function (o, i) {
      var sel = selected === o.value ? ' sel' : '';
      html += '<button class="opt' + sel + '" data-value="' + o.value + '">' +
        '<div class="opt-letter">' + (LETTERS[i] || o.value) + '</div>' +
        '<div class="opt-text">' + escapeHtml(o.text) + '</div>' +
        '<div class="opt-bar"></div></button>';
    });
    html += '</div>';
    return html;
  }

  function buildRanking(q) {
    var items = RANKING_ITEMS[q.competency] || RANKING_FALLBACK;
    var order = state.rankOrder[q.session_id];
    if (!order) {
      order = items.map(function (_, i) { return i; });
      state.rankOrder[q.session_id] = order;
    }
    var html = order.map(function (origIdx, pos) {
      return '<div class="rank-item" draggable="true" data-orig="' + origIdx + '" data-pos="' + pos + '">' +
        '<div class="rank-pos">' + (pos + 1) + '</div>' +
        '<div class="rank-txt">' + escapeHtml(items[origIdx]) + '</div>' +
        '<div class="rank-handle">' + ico('grip') + '</div></div>';
    }).join('');
    return '<div class="rank-intro"><span class="rank-intro-ico">' + ico('pin') + '</span><span>' + escapeHtml(PILD_LA.i18n.rankIntro) + '</span></div>' +
      '<div class="rank-list" id="rankList_' + q.session_id + '">' + html + '</div>';
  }

  function buildSlider(q) {
    var poles = SLIDER_POLES[q.competency] || SLIDER_FALLBACK;
    var val = state.sliderVals[q.session_id] || state.answers[q.session_id] || 3;
    var pct = ((val - 1) / 4) * 100;
    return '<div class="slider-wrap">' +
      '<div class="slider-poles"><div class="s-pole">' + escapeHtml(poles.right) + '</div><div class="s-pole r">' + escapeHtml(poles.left) + '</div></div>' +
      '<div class="slider-track"><input type="range" class="range-input" id="sliderInput_' + q.session_id + '" min="1" max="5" step="1" value="' + val + '" style="background:linear-gradient(' + FILL_DIR + ', var(--purple) 0%, var(--purple) ' + pct + '%, var(--line) ' + pct + '%, var(--line) 100%)"></div>' +
      '<div class="slider-ticks">' + [1, 2, 3, 4, 5].map(function (n) { return '<div class="slider-tick">' + n + '</div>'; }).join('') + '</div>' +
      '<div class="slider-val-display"><div class="slider-bubble" id="sliderBubble_' + q.session_id + '">' + val + '</div><div class="slider-val-label" id="sliderLbl_' + q.session_id + '">' + LIKERT_LABELS[val - 1] + '</div></div>' +
      '</div>';
  }

  function buildLikert(q, selected) {
    var btns = [1, 2, 3, 4, 5].map(function (n) {
      var sel = selected === n ? ' sel' : '';
      return '<button class="lk' + sel + '" data-value="' + n + '"><div class="lk-num">' + n + '</div></button>';
    }).join('');
    return '<div class="likert-wrap"><div class="likert-row">' + btns + '</div>' +
      '<div class="likert-endlabels"><span>' + escapeHtml(LIKERT_LABELS[0]) + '</span><span>' + escapeHtml(LIKERT_LABELS[4]) + '</span></div></div>';
  }

  function buildTypeTag(qt, q) {
    var tm = Q_TYPE_MAP[qt] || Q_TYPE_MAP.situational;
    var sm = SRC_META[q.questionType] || SRC_META.general;
    return '<div class="type-tag">' +
      '<div class="type-dot" style="background:' + tm.dotColor + '"></div>' + '<span class="type-ico">' + ico(tm.icon) + '</span>' + escapeHtml((PILD_LA.i18n.qType || {})[qt] || qt) +
      '<div class="type-dot" style="background:' + sm.dotColor + ';margin-inline-start:6px;opacity:.7"></div>' +
      '<span style="opacity:.7;font-size:9px">' + escapeHtml((PILD_LA.i18n.srcMeta || {})[q.questionType] || (PILD_LA.i18n.srcMeta || {}).general || '') + '</span></div>';
  }

  function buildCompLabel(q) {
    var cm = state.compMeta[q.competency];
    if (!cm) return '';
    return '<div class="comp-lbl"><div class="comp-dot" style="background:' + cm.color + '"></div>' + escapeHtml(cm.ar) + '</div>';
  }

  /* ---------- question card ---------- */
  function renderQuestion($root) {
    var q = state.questions[state.idx];
    var qt = state.qTypes[state.idx] || 'situational';
    var selected = state.answers[q.session_id];

    // Dragging isn't required to move past a ranking question (matches
    // the original static site) — count it answered as soon as it's
    // shown so it never blocks navigation or the final submit check.
    if (qt === 'ranking' && selected === undefined) {
      state.answers[q.session_id] = 5;
      selected = 5;
    }

    var bodyHtml;
    switch (qt) {
      case 'ranking': bodyHtml = buildRanking(q); break;
      case 'slider':  bodyHtml = buildSlider(q); break;
      case 'likert':  bodyHtml = buildLikert(q, selected); break;
      default:        bodyHtml = buildOptions(q, selected); // situational / behavioral
    }

    var isLast = state.idx === state.questions.length - 1;
    var html = dotsHtml() +
      '<div class="q-card" id="qCard">' +
      buildTypeTag(qt, q) +
      buildCompLabel(q) +
      '<div class="q-text">' + escapeHtml(pick(q, 'text')) + '</div>' +
      bodyHtml +
      '</div>' +
      '<div class="nav-bar"><div class="nav-inner">' +
      '<button class="btn btn-ghost" id="pild-la-back-btn"' + (state.idx === 0 ? ' disabled' : '') + '>' + (PILD_LA.isEn ? '&#x276E; ' : '&#x276F; ') + PILD_LA.i18n.prev + '</button>' +
      '<button class="btn btn-primary" id="pild-la-next-btn"' + (selected ? '' : ' disabled') + '>' + (isLast ? PILD_LA.i18n.submit : PILD_LA.i18n.next + (PILD_LA.isEn ? ' &#x276F;' : ' &#x276E;')) + '</button>' +
      '</div></div>';

    $root.find('#pild-la-wizard').html(html);

    if (qt === 'ranking') initDrag($root, q);
  }

  /* ---------- drag & drop (ranking) ---------- */
  function initDrag($root, q) {
    var list = $root.find('#rankList_' + q.session_id).get(0);
    if (!list) return;
    var dragEl = null;

    function persistOrder() {
      var order = Array.prototype.map.call(list.querySelectorAll('.rank-item'), function (el) {
        return parseInt(el.getAttribute('data-orig'), 10);
      });
      state.rankOrder[q.session_id] = order;
      // Value stays a flat "participated fully" score regardless of the
      // chosen order — there's no per-order scoring on the server side,
      // this widget is about engagement/variety, not a different metric.
      state.answers[q.session_id] = 5;
    }

    list.querySelectorAll('.rank-item').forEach(function (item) {
      item.addEventListener('dragstart', function (e) {
        dragEl = item; item.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      item.addEventListener('dragend', function () {
        item.classList.remove('dragging');
        list.querySelectorAll('.rank-item').forEach(function (i) { i.classList.remove('drag-over'); });
        persistOrder();
      });
      item.addEventListener('dragover', function (e) {
        e.preventDefault(); e.dataTransfer.dropEffect = 'move';
        if (item !== dragEl) item.classList.add('drag-over');
      });
      item.addEventListener('dragleave', function () { item.classList.remove('drag-over'); });
      item.addEventListener('drop', function (e) {
        e.preventDefault();
        if (dragEl && dragEl !== item) {
          var items = Array.prototype.slice.call(list.querySelectorAll('.rank-item'));
          var fromIdx = items.indexOf(dragEl), toIdx = items.indexOf(item);
          if (fromIdx < toIdx) list.insertBefore(dragEl, item.nextSibling);
          else list.insertBefore(dragEl, item);
          Array.prototype.forEach.call(list.querySelectorAll('.rank-item'), function (el, i) {
            el.querySelector('.rank-pos').textContent = i + 1;
            el.setAttribute('data-pos', i);
          });
        }
      });
    });

    // Touch support (mirrors the mouse drag-and-drop above).
    var touchDragEl = null, touchClone = null;
    list.querySelectorAll('.rank-item').forEach(function (item) {
      item.addEventListener('touchstart', function () {
        touchDragEl = item; item.classList.add('dragging');
        touchClone = item.cloneNode(true);
        touchClone.style.cssText = 'position:fixed;z-index:999;opacity:.85;pointer-events:none;width:' + item.offsetWidth + 'px;background:rgba(83,74,183,.3);border-radius:13px;';
        document.body.appendChild(touchClone);
      }, { passive: true });
      item.addEventListener('touchmove', function (e) {
        if (!touchClone) return;
        var t = e.touches[0];
        touchClone.style.top = (t.clientY - item.offsetHeight / 2) + 'px';
        touchClone.style.left = item.getBoundingClientRect().left + 'px';
        var els = Array.prototype.filter.call(list.querySelectorAll('.rank-item'), function (el) { return el !== touchDragEl; });
        els.forEach(function (el) { el.classList.remove('drag-over'); });
        var under = els.find(function (el) { var r = el.getBoundingClientRect(); return t.clientY >= r.top && t.clientY <= r.bottom; });
        if (under) under.classList.add('drag-over');
      }, { passive: true });
      item.addEventListener('touchend', function (e) {
        if (touchClone) { document.body.removeChild(touchClone); touchClone = null; }
        var t = e.changedTouches[0];
        var els = Array.prototype.filter.call(list.querySelectorAll('.rank-item'), function (el) { return el !== touchDragEl; });
        var target = els.find(function (el) { var r = el.getBoundingClientRect(); return t.clientY >= r.top && t.clientY <= r.bottom; });
        if (target && touchDragEl) {
          var items2 = Array.prototype.slice.call(list.querySelectorAll('.rank-item'));
          var fi = items2.indexOf(touchDragEl), ti = items2.indexOf(target);
          if (fi < ti) list.insertBefore(touchDragEl, target.nextSibling);
          else list.insertBefore(touchDragEl, target);
          Array.prototype.forEach.call(list.querySelectorAll('.rank-item'), function (el, i) {
            el.querySelector('.rank-pos').textContent = i + 1;
            el.setAttribute('data-pos', i);
          });
        }
        els.forEach(function (el) { el.classList.remove('drag-over'); });
        if (touchDragEl) touchDragEl.classList.remove('dragging');
        touchDragEl = null;
        persistOrder();
      }, { passive: true });
    });
  }

  function bindWizardEvents($root) {
    $root.on('click', '.opt', function () {
      var q = state.questions[state.idx];
      state.answers[q.session_id] = parseInt($(this).data('value'), 10);
      renderQuestion($root);
    });

    $root.on('click', '.lk', function () {
      var q = state.questions[state.idx];
      state.answers[q.session_id] = parseInt($(this).data('value'), 10);
      renderQuestion($root);
    });

    // Live visual feedback while dragging the slider (no re-render —
    // that would rebuild the <input> mid-drag and drop the pointer).
    $root.on('input', '.range-input', function () {
      var q = state.questions[state.idx];
      var val = parseInt(this.value, 10);
      var pct = ((val - 1) / 4) * 100;
      $(this).css('background', 'linear-gradient(' + FILL_DIR + ', var(--purple) 0%, var(--purple) ' + pct + '%, var(--line) ' + pct + '%, var(--line) 100%)');
      $root.find('#sliderBubble_' + q.session_id).text(val);
      $root.find('#sliderLbl_' + q.session_id).text(LIKERT_LABELS[val - 1]);
    });

    // Commit the value (and refresh dots/next-button) once the user
    // releases the slider.
    $root.on('change', '.range-input', function () {
      var q = state.questions[state.idx];
      var val = parseInt(this.value, 10);
      state.sliderVals[q.session_id] = val;
      state.answers[q.session_id] = val;
      renderQuestion($root);
    });

    $root.on('click', '#pild-la-back-btn', function () {
      if (state.idx > 0) { state.idx--; renderQuestion($root); }
    });

    $root.on('click', '#pild-la-next-btn', function () {
      if (state.idx < state.questions.length - 1) {
        state.idx++;
        renderQuestion($root);
      } else {
        submitAssessment($root);
      }
    });

    $root.on('click', '.dot.answered, .dot.current', function () {
      state.idx = parseInt($(this).data('idx'), 10);
      renderQuestion($root);
    });
  }

  function submitAssessment($root) {
    if (Object.keys(state.answers).length < state.questions.length) {
      alert(PILD_LA.i18n.answerAll);
      return;
    }
    $root.find('#pild-la-next-btn').prop('disabled', true).text('…');
    ajax('pild_la_submit', {
      attempt_id: state.attemptId,
      answers: JSON.stringify(state.answers),
    }, function (data) {
      $root.find('#pild-la-wizard').hide().empty();
      $root.find('#pild-la-result').html(data.html);
    }, function (err) {
      alert(err);
    });
  }

  /* ---------- retake ---------- */
  function bindRetake($root) {
    $root.on('click', '#pild-la-retake-btn', function () {
      if (!confirm(PILD_LA.i18n.confirmRetake)) return;
      state.selectedCategory = null;
      state.selectedSector = null;
      state.selectedGoal = null;
      $root.find('.cat-card, .sector-card, .goal-card').removeClass('selected');
      $root.find('#pild-la-sectors-grid').empty();
      $root.find('#pild-la-start-btn').prop('disabled', true);
      $root.find('#pild-la-result').empty();
      $root.find('#pild-la-intro').show();
      showScreen($root, 'pild-la-welcome');
    });
  }

  /* ---------- team invite tab ---------- */
  function bindTeamTab($root) {
    $root.on('click', '#pild-la-invite-btn', function () {
      var email = $root.find('#pild-la-invite-email').val().trim();
      if (!email) return;
      var $btn = $(this).prop('disabled', true);
      ajax('pild_la_invite', { email: email }, function (data) {
        $root.find('#pild-la-team-table').html(data.html);
        $root.find('#pild-la-invite-email').val('');
        $btn.prop('disabled', false);
      }, function (err) { alert(err); $btn.prop('disabled', false); });
    });

    $root.on('click', '.pild-la-remove-member', function () {
      var id = $(this).data('id');
      ajax('pild_la_remove_member', { member_id: id }, function (data) {
        $root.find('#pild-la-team-table').html(data.html);
      }, function (err) { alert(err); });
    });

    $root.on('click', '.pild-la-view-report', function () {
      var uid = $(this).data('user');
      ajax('pild_la_get_member_report', { user_id: uid }, function (data) {
        openReportWindow(data.html, false);
      }, function (err) { alert(err); });
    });
  }

  // Opens a clean window carrying just the report (with the tool's own
  // stylesheet) — used for "view member report" and for Print / Save PDF.
  function openReportWindow(html, autoPrint) {
    var w = window.open('', '_blank', 'width=1000,height=900');
    if (!w) { alert(PILD_LA.i18n.error); return; }
    w.document.write('<!DOCTYPE html><html dir="' + (PILD_LA.dir || 'rtl') + '" lang="' + (PILD_LA.isEn ? 'en' : 'ar') + '"><head><meta charset="utf-8"><title>PILD</title>' +
      '<link rel="stylesheet" href="' + (PILD_LA.cssUrl || '') + '"></head>' +
      '<body class="pild-la-site la-print-body" dir="' + (PILD_LA.dir || 'rtl') + '" style="margin:0;background:#fff">' + html + '</body></html>');
    w.document.close();
    if (autoPrint) {
      var go = function () { w.focus(); w.print(); };
      w.onload = function () { setTimeout(go, 400); };
    }
  }

  $(document).on('click', '.la-r-print', function () {
    var $doc = $(this).closest('.la-report').find('.la-r-doc').first();
    if ($doc.length) openReportWindow($doc.prop('outerHTML'), true);
  });

  $(function () {
    var $assessRoot = $('#pild-la-root');
    if ($assessRoot.length) {
      initPicker($assessRoot);
      bindWizardEvents($assessRoot);
      bindRetake($assessRoot);
      $assessRoot.on('click', '#pild-la-start-btn', function () { startAssessment($assessRoot); });
    }
    var $teamRoot = $('#pild-la-team-root');
    if ($teamRoot.length) bindTeamTab($teamRoot);
  });
})(jQuery);
