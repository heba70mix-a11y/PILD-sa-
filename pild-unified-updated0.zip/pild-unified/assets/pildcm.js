// NOTE: All Company Manager dashboard click handlers (sync team, invite member,
// assign/unassign track, save settings, etc.) are intentionally implemented via
// inline <script> blocks inside the dashboard templates themselves
// (04-dashboard-company.php, 05-dashboard-member.php, 06-dashboard-solo.php,
// 07-dashboard-customer.php).
// This file is kept only so that wp_enqueue_script('pildcm-js', ...) resolves to
// a real asset (avoiding a 404 request) and so that wp_localize_script() can
// attach the pildcm_ajax object (ajax_url + nonce) ahead of those inline scripts.
