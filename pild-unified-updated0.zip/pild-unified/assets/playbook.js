// NOTE: The playbook-complete button click handler is intentionally handled
// by the inline script inside pild_inject_playbook_footer() in pild-unified.php.
// This file is kept for wp_enqueue_scripts / wp_localize_script to run
// so that pild_ajax (ajax_url + nonce) is available as a JS global.
