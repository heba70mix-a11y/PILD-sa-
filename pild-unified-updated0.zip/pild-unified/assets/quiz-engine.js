/**
 * PILD Native Quiz Engine — front-end.
 *
 * Talks to includes/26-quiz-engine.php (pild_quiz_start / pild_quiz_submit /
 * pild_quiz_flag). The timer shown here is cosmetic — the server is the
 * source of truth for expiry (see pild_quiz_ajax_submit()). Correct answers
 * are never present in any response before submission.
 */
(function () {
    var root = document.getElementById('pild-quiz-root');
    if (!root || typeof pild_quiz_ajax === 'undefined') return;

    var state = {
        attemptId: null,
        questions: [],
        current: 0,
        secondsRemaining: 0,
        answers: {},   // question_id -> chosen choice index
        timerHandle: null,
        submitted: false,
    };

    function post(action, data) {
        var body = new URLSearchParams(Object.assign({
            action: action,
            nonce: pild_quiz_ajax.nonce,
        }, data || {}));
        return fetch(pild_quiz_ajax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
        }).then(function (r) { return r.json(); });
    }

    function render(html) { root.innerHTML = html; }
    function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML; }

    // ---------- Start screen ----------
    function renderStart() {
        var isArabicLike = /[\u0600-\u06FF]/;
        render(
            '<div class="pild-quiz-card pild-quiz-start">' +
            '<div class="pild-quiz-name-confirm">' +
            '<h3 class="pild-quiz-name-title">' + pild_quiz_ajax.i18n.name_confirm_title + '</h3>' +
            '<p class="pild-quiz-name-note">' + pild_quiz_ajax.i18n.name_confirm_note + '</p>' +
            '<div class="pild-quiz-field">' +
            '<label for="pild-quiz-fullname">' + pild_quiz_ajax.i18n.full_name + '</label>' +
            '<input type="text" id="pild-quiz-fullname" dir="ltr" value="' + esc(pild_quiz_ajax.display_name || '') + '">' +
            '<div class="pild-quiz-name-warning" id="pild-quiz-name-warning" style="display:none">⚠️ ' + pild_quiz_ajax.i18n.name_arabic_warning + '</div>' +
            '</div>' +
            '<div class="pild-quiz-field">' +
            '<label for="pild-quiz-email">' + pild_quiz_ajax.i18n.email + '</label>' +
            '<input type="email" id="pild-quiz-email" dir="ltr" value="' + esc(pild_quiz_ajax.user_email || '') + '" disabled>' +
            '</div>' +
            '<span id="pild-quiz-name-error" class="pild-quiz-name-error"></span>' +
            '</div>' +
            '<button id="pild-quiz-start-btn" class="pild-quiz-btn pild-quiz-btn-primary">' +
            pild_quiz_ajax.i18n.start + '</button></div>'
        );

        var nameInput = document.getElementById('pild-quiz-fullname');
        var warningEl = document.getElementById('pild-quiz-name-warning');
        nameInput.addEventListener('input', function () {
            warningEl.style.display = isArabicLike.test(nameInput.value) ? 'block' : 'none';
        });
        if (isArabicLike.test(nameInput.value)) warningEl.style.display = 'block';

        document.getElementById('pild-quiz-start-btn').addEventListener('click', function () {
            var name = nameInput.value.trim();
            var errEl = document.getElementById('pild-quiz-name-error');
            if (!name) {
                errEl.textContent = pild_quiz_ajax.i18n.name_required;
                return;
            }
            errEl.textContent = '';
            post('pild_quiz_confirm_name', { full_name: name }).then(function () {
                startAttempt();
            });
        });
    }

    function startAttempt() {
        render('<div class="pild-quiz-card">' + root.dataset.loading + '</div>');
        post('pild_quiz_start', { assessment_id: pild_quiz_ajax.assessment_id }).then(function (res) {
            if (!res.success) {
                var msg = (res.data && res.data.message) ? res.data.message : (res.data || 'Error');
                render('<div class="pild-quiz-card pild-quiz-error">' + msg + '</div>');
                return;
            }
            state.attemptId = res.data.attempt_id;
            state.questions = res.data.questions;
            state.secondsRemaining = res.data.seconds_remaining;
            state.current = 0;
            renderQuestion();
            startTimer();
            bindAntiCheat();
        });
    }

    // ---------- Timer (cosmetic; server enforces the real deadline) ----------
    function startTimer() {
        clearInterval(state.timerHandle);
        state.timerHandle = setInterval(function () {
            state.secondsRemaining--;
            var timerEl = document.getElementById('pild-quiz-timer');
            if (timerEl) timerEl.textContent = formatTime(state.secondsRemaining);
            if (state.secondsRemaining <= 0) {
                clearInterval(state.timerHandle);
                submitAttempt(true);
            }
        }, 1000);
    }

    function formatTime(sec) {
        sec = Math.max(0, sec);
        var m = Math.floor(sec / 60), s = sec % 60;
        return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    }

    // ---------- Question rendering ----------
    function renderQuestion() {
        var q = state.questions[state.current];
        var total = state.questions.length;
        var choicesHtml = q.choices.map(function (c) {
            var checked = state.answers[q.id] === c.index ? 'checked' : '';
            return '<label class="pild-quiz-choice">' +
                '<input type="radio" name="pild-q-' + q.id + '" value="' + c.index + '" ' + checked + '> ' +
                '<span>' + escapeHtml(c.text) + '</span></label>';
        }).join('');

        render(
            '<div class="pild-quiz-card">' +
            '<div class="pild-quiz-topbar">' +
            '<span id="pild-quiz-timer" class="pild-quiz-timer">' + formatTime(state.secondsRemaining) + '</span>' +
            '<span class="pild-quiz-progress-label">' + (state.current + 1) + ' / ' + total + '</span>' +
            '</div>' +
            '<div class="pild-quiz-progress-bar"><div style="width:' + (((state.current + 1) / total) * 100) + '%"></div></div>' +
            '<div class="pild-quiz-question">' + escapeHtml(q.text) + '</div>' +
            '<div class="pild-quiz-choices">' + choicesHtml + '</div>' +
            '<div class="pild-quiz-nav">' +
            (state.current > 0 ? '<button id="pild-quiz-prev" class="pild-quiz-btn">' + pild_quiz_ajax.i18n.prev + '</button>' : '<span></span>') +
            (state.current < total - 1
                ? '<button id="pild-quiz-next" class="pild-quiz-btn pild-quiz-btn-primary">' + pild_quiz_ajax.i18n.next + '</button>'
                : '<button id="pild-quiz-finish" class="pild-quiz-btn pild-quiz-btn-primary">' + pild_quiz_ajax.i18n.finish + '</button>') +
            '</div></div>'
        );

        root.querySelectorAll('input[type=radio]').forEach(function (input) {
            input.addEventListener('change', function () {
                state.answers[q.id] = parseInt(this.value, 10);
            });
        });
        var prevBtn = document.getElementById('pild-quiz-prev');
        if (prevBtn) prevBtn.addEventListener('click', function () { state.current--; renderQuestion(); });
        var nextBtn = document.getElementById('pild-quiz-next');
        if (nextBtn) nextBtn.addEventListener('click', function () { state.current++; renderQuestion(); });
        var finishBtn = document.getElementById('pild-quiz-finish');
        if (finishBtn) finishBtn.addEventListener('click', function () { submitAttempt(false); });
    }

    // ---------- Submission ----------
    function submitAttempt(auto) {
        if (state.submitted) return;
        state.submitted = true;
        clearInterval(state.timerHandle);
        render('<div class="pild-quiz-card">' + root.dataset.loading + '</div>');

        var payload = { attempt_id: state.attemptId, assessment_id: pild_quiz_ajax.assessment_id };
        Object.keys(state.answers).forEach(function (qid) {
            payload['answers[' + qid + ']'] = state.answers[qid];
        });

        post('pild_quiz_submit', payload).then(function (res) {
            if (!res.success) {
                render('<div class="pild-quiz-card pild-quiz-error">' + (res.data || 'Error') + '</div>');
                return;
            }
            renderResult(res.data, auto);
        });
    }

    // SVG ring geometry: r=64 -> circumference ~= 402.1
    var RING_R = 64;
    var RING_CIRC = 2 * Math.PI * RING_R;

    function renderResult(data, auto) {
        var passed = !!data.passed;
        var heading = passed ? pild_quiz_ajax.i18n.pass : pild_quiz_ajax.i18n.fail;
        var sub = passed ? '' : pild_quiz_ajax.i18n.try_again;
        var expiredNote = (auto || data.expired) ? '<p class="pild-quiz-expired-note">' + pild_quiz_ajax.i18n.expired + '</p>' : '';

        var pct = Math.max(0, Math.min(100, Number(data.score) || 0));
        var offset = RING_CIRC - (pct / 100) * RING_CIRC;

        var icon = passed
            ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>'
            : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="8" x2="12" y2="13"></line><circle cx="12" cy="16.5" r="0.6" fill="currentColor" stroke="none"></circle><circle cx="12" cy="12" r="9"></circle></svg>';

        var passMark = (data.pass_score !== undefined && data.pass_score !== null)
            ? '<p class="pild-quiz-result-passmark">' + pild_quiz_ajax.i18n.pass_mark + ': <b>' + Math.round(data.pass_score) + '%</b></p>'
            : '';

        var certBtn = data.certificate_url
            ? '<p><a href="' + data.certificate_url + '" target="_blank" rel="noopener" class="pild-quiz-cert-btn">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z"></path><path d="M8.5 13.5 7 22l5-3 5 3-1.5-8.5"></path></svg>' +
              '<span>' + pild_quiz_ajax.i18n.certificate + '</span>' +
              '</a></p>'
            : '';

        render(
            '<div class="pild-quiz-card pild-quiz-result ' + (passed ? 'pild-quiz-pass' : 'pild-quiz-fail') + '">' +
            expiredNote +
            '<div class="pild-quiz-result-icon">' + icon + '</div>' +
            '<div class="pild-quiz-result-ring-wrap">' +
            '<svg viewBox="0 0 148 148">' +
            '<circle class="pild-quiz-result-ring-track" cx="74" cy="74" r="' + RING_R + '"></circle>' +
            '<circle class="pild-quiz-result-ring-value" cx="74" cy="74" r="' + RING_R + '" ' +
            'stroke-dasharray="' + RING_CIRC + '" stroke-dashoffset="' + RING_CIRC + '"></circle>' +
            '</svg>' +
            '<div class="pild-quiz-result-ring-center">' +
            '<span class="pild-quiz-result-score">' + pct + '%</span>' +
            '<span class="pild-quiz-result-score-label">' + escapeHtml(pild_quiz_ajax.i18n.your_score) + '</span>' +
            '</div></div>' +
            '<h3><bdi>' + escapeHtml(heading) + '</bdi></h3>' +
            (sub ? '<p class="pild-quiz-result-sub">' + escapeHtml(sub) + '</p>' : '') +
            passMark +
            certBtn +
            '</div>'
        );

        // Animate the ring in on the next frame so the CSS transition runs.
        requestAnimationFrame(function () {
            var ring = root.querySelector('.pild-quiz-result-ring-value');
            if (ring) requestAnimationFrame(function () { ring.style.strokeDashoffset = offset; });
        });
    }

    // ---------- Anti-cheat (soft signal only — see 26-quiz-engine.php) ----------
    function bindAntiCheat() {
        document.addEventListener('visibilitychange', function () {
            if (document.hidden && !state.submitted && state.attemptId) {
                post('pild_quiz_flag', { attempt_id: state.attemptId });
            }
        });
        window.addEventListener('beforeunload', function (e) {
            if (!state.submitted && state.attemptId) {
                e.preventDefault();
                e.returnValue = pild_quiz_ajax.i18n.confirm;
            }
        });
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str == null ? '' : str;
        return div.innerHTML;
    }

    renderStart();
})();
