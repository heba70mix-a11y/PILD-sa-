/**
 * Multi-track direct checkout picker — talks to
 * includes/30-team-checkout.php's pild_mtc_checkout AJAX action.
 */
(function () {
    var root = document.getElementById('pild-mtc-root');
    if (!root || typeof pild_mtc_ajax === 'undefined') return;

    var checkboxes = root.querySelectorAll('.pild-mtc-check');
    var summaryEl  = document.getElementById('pild-mtc-summary');
    var btn        = document.getElementById('pild-mtc-checkout-btn');
    var errEl      = document.getElementById('pild-mtc-error');

    function refresh() {
        var count = 0, seats = 0;
        checkboxes.forEach(function (cb) {
            var row = cb.closest('.pild-mtc-row');
            var qty = row.querySelector('.pild-mtc-qty');
            qty.disabled = !cb.checked;
            if (cb.checked) {
                count++;
                var min = parseInt(cb.dataset.min, 10) || 1;
                var val = parseInt(qty.value, 10) || min;
                if (val < min) { val = min; qty.value = min; }
                seats += val;
            }
        });
        summaryEl.textContent = count
            ? pild_mtc_ajax.i18n.selected_count.replace('%d', count).replace('%d', seats)
            : pild_mtc_ajax.i18n.none_selected;
        btn.disabled = count === 0;
    }

    checkboxes.forEach(function (cb) { cb.addEventListener('change', refresh); });
    root.querySelectorAll('.pild-mtc-qty').forEach(function (q) { q.addEventListener('input', refresh); });
    refresh();

    btn.addEventListener('click', function () {
        errEl.style.display = 'none';
        var originalLabel = btn.textContent;
        var items = {};
        checkboxes.forEach(function (cb) {
            if (!cb.checked) return;
            var row = cb.closest('.pild-mtc-row');
            var qty = parseInt(row.querySelector('.pild-mtc-qty').value, 10) || parseInt(cb.dataset.min, 10);
            items['items[' + cb.dataset.product + ']'] = qty;
        });

        btn.disabled = true;
        btn.textContent = '...';

        var body = new URLSearchParams(Object.assign({
            action: 'pild_mtc_checkout',
            nonce: pild_mtc_ajax.nonce,
        }, items));

        fetch(pild_mtc_ajax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
        })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (res.success && res.data.checkout_url) {
                window.location.href = res.data.checkout_url;
            } else {
                errEl.textContent = (res.data && typeof res.data === 'string') ? res.data : pild_mtc_ajax.i18n.error_generic;
                errEl.style.display = 'block';
                btn.disabled = false;
                btn.textContent = originalLabel;
                refresh();
            }
        })
        .catch(function () {
            errEl.textContent = pild_mtc_ajax.i18n.error_generic;
            errEl.style.display = 'block';
            btn.disabled = false;
            btn.textContent = originalLabel;
            refresh();
        });
    });
})();
