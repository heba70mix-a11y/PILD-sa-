<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 2. POINTS SYSTEM CONFIG
// ============================================================
function pildcm_points_config() {
    return [
        'playbook_complete'  => 10,
        'program_complete' => 50,
        'track_complete'   => 200,
        'assessment_pass'        => 100,
        'first_login'      => 5,
        'streak_3day'      => 30,
    ];
}

// ============================================================
// 3. BADGES CONFIG
// ============================================================
function pildcm_badges_config() {
    return [
        'team_player'     => ['icon' => '🤝', 'label' => 'Team Player',     'desc' => 'Joined a team'],
        'first_playbook'    => ['icon' => '🌱', 'label' => 'First Step',      'desc' => 'Completed your first Playbook'],
        'track_finisher'  => ['icon' => '🏁', 'label' => 'Track Finisher',  'desc' => 'Completed an entire development track'],
        'streak_7'        => ['icon' => '🔥', 'label' => '7-Day Streak',    'desc' => 'Logged in 7 days in a row'],
        'streak_30'       => ['icon' => '⚡', 'label' => '30-Day Streak',   'desc' => 'Logged in 30 days in a row'],
        'top_scorer'      => ['icon' => '🎯', 'label' => 'Top Scorer',      'desc' => 'Scored 100% on an assessment'],
        'early_bird'      => ['icon' => '🌅', 'label' => 'Early Bird',      'desc' => 'Completed a playbook section before 8am'],
        'fast_learner'    => ['icon' => '⚡', 'label' => 'Fast Achiever',    'desc' => 'Completed 5 Playbooks in one day'],
        'certified'       => ['icon' => '🏅', 'label' => 'Professional Certificate',       'desc' => 'Earned your first professional certificate'],
    ];
}
