<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 4. CORE HELPER FUNCTIONS
// ============================================================
function pildcm_get_team_members($manager_id) {
    // PHASE 4: now backed by includes/23-teams-core.php's own pild_teams /
    // pild_team_members tables (created + populated by the purchase hook in
    // includes/24-team-purchase.php) instead of the WC Memberships for Teams
    // mirror tables. Same return shape as before: [user_id => WP_User].
    if (function_exists('pild_get_team_members_v2')) {
        return pild_get_team_members_v2($manager_id);
    }
    return [];
}

// PHASE 4: explicit "is this user actually a team manager" check, used by
// the AJAX handlers below to close the authorization gap flagged earlier
// (those handlers previously only checked is_user_logged_in(), relying on
// every DOWNSTREAM function happening to return empty for a non-manager —
// which worked, but wasn't a real access-control boundary).
function pildcm_is_team_manager($user_id) {
    return function_exists('pild_get_owner_teams') && !empty(pild_get_owner_teams($user_id));
}

function pildcm_get_manager_tracks($manager_id) {
    $track_ids = [];

    // Method 0: Direct DB enrollments — tracks the manager was auto-enrolled
    // into by pild_auto_enroll_tracks_from_purchase() on order completion, or
    // manually assigned. Completely independent of WooCommerce Memberships
    // being configured at all, so this always reflects what was actually
    // purchased even if the Memberships side (Methods 1/2 below) is missing
    // or misconfigured for a given product/track.
    global $wpdb;
    $db_track_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT track_id FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND status='active'", $manager_id
    ));
    foreach ((array) $db_track_ids as $tid) {
        $tid = (int) $tid;
        if ($tid) $track_ids[$tid] = get_post($tid);
    }

    // Method 0.5 (PHASE 4): tracks covered by any team this manager owns
    // (includes/23-teams-core.php's pild_team_tracks) — populated by the
    // purchase hook in includes/24-team-purchase.php when a Team product is
    // bought. Independent of WC Memberships plans, same as Method 0 above.
    // PHASE 6: only teams still inside their 1-year window count — same
    // condition as pild_get_covering_teams_for_track(), so a manager never
    // sees a track listed as assignable that would immediately fail the
    // seat check because the only team covering it has expired.
    if (function_exists('pild_get_owner_teams')) {
        foreach (pild_get_owner_teams($manager_id) as $team) {
            if (!$team->date_created || strtotime($team->date_created) <= strtotime('-1 year')) continue;
            $team_track_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT track_id FROM {$wpdb->prefix}pild_team_tracks WHERE team_id=%d", (int) $team->id
            ));
            foreach ($team_track_ids as $tid) {
                $tid = (int) $tid;
                if ($tid && !isset($track_ids[$tid]) && get_post_status($tid) === 'publish') {
                    $track_ids[$tid] = get_post($tid);
                }
            }
        }
    }

    // Method 1: Read content restriction rules from the manager's WC Memberships plans
    if (function_exists('wc_memberships_get_user_memberships')) {
        try {
            // FIX: filter to active memberships only — expired/cancelled plans must not grant track access.
            $memberships = wc_memberships_get_user_memberships($manager_id, ['status' => 'active']);
            if (!empty($memberships) && is_array($memberships)) {
                foreach ($memberships as $mem) {
                    if (!is_object($mem) || !method_exists($mem, 'get_plan')) continue;
                    $plan = $mem->get_plan();
                    if (!$plan || !method_exists($plan, 'get_content_restriction_rules')) continue;
                    $rules = $plan->get_content_restriction_rules();
                    if (empty($rules) || !is_array($rules)) continue;
                    foreach ($rules as $rule) {
                        if (!is_object($rule)) continue;
                        // FIX: WC_Memberships_Membership_Plan_Rule::get_content_type() only ever
                        // returns the generic string 'post_type' or 'taxonomy' — it never returns
                        // 'post_type:track' or 'track'. The actual post type slug lives in
                        // get_content_type_name(). The old comparison below could never be true,
                        // so this whole "Method 1" branch was silently dead code.
                        $type      = method_exists($rule, 'get_content_type')      ? $rule->get_content_type()      : '';
                        $type_name = method_exists($rule, 'get_content_type_name') ? $rule->get_content_type_name() : '';
                        $ids       = method_exists($rule, 'get_object_ids')        ? $rule->get_object_ids()        : [];
                        if ($type === 'post_type' && $type_name === 'track') {
                            foreach ((array) $ids as $tid) {
                                $tid = (int) $tid;
                                if ($tid && get_post_status($tid) === 'publish') {
                                    $track_ids[$tid] = get_post($tid);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) { /* silent */ }
    }

    // Method 2: Per-track capability check via wc_memberships_user_can (slower but reliable).
    // Runs regardless of whether Method 1 found anything, so a second/third purchased package
    // whose plan rules use a different content-type key is never silently dropped.
    // Skips tracks already found by Method 1 (isset guard) to avoid redundant DB calls.
    // Results are cached per-manager for 5 minutes to avoid N×track_count queries on every page load.
    $cache_key  = 'pild_manager_tracks_' . (int) $manager_id;
    $cached_ids = get_transient($cache_key);
    if ($cached_ids !== false) {
        // Merge cached Method-2 additions on top of fresh Method-1 results
        foreach ($cached_ids as $tid => $post_obj) {
            if (!isset($track_ids[$tid])) $track_ids[$tid] = $post_obj;
        }
    } elseif (function_exists('wc_memberships_user_can')) {
        $method2_ids = [];
        // Use 'ids' first to avoid loading full WP_Post objects for every track unnecessarily
        $all_track_ids = get_posts([
            'post_type'      => 'track',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'fields'         => 'ids',
        ]);
        foreach ($all_track_ids as $tid) {
            $tid = (int) $tid;
            if (isset($track_ids[$tid])) continue; // already found by Method 1
            if (function_exists('wc_memberships_is_post_content_restricted') &&
                !wc_memberships_is_post_content_restricted($tid)) continue; // not restricted = skip
            if (wc_memberships_user_can($manager_id, 'view', ['post' => $tid])) {
                $post_obj             = get_post($tid);
                $track_ids[$tid]      = $post_obj;
                $method2_ids[$tid]    = $post_obj;
            }
        }
        // Cache only Method-2 additions (Method-1 results are cheap and always fresh)
        set_transient($cache_key, $method2_ids, 5 * MINUTE_IN_SECONDS);
    }

    // NO generic fallback — only return what the manager actually paid for
    return $track_ids;
}

// Content access lasts exactly 1 year from the PURCHASE date — for an
// Individual purchase that's the enrollment's own creation moment (the
// default below, "now"), but for a Team-assigned member it's the team's
// original purchase date (the manager may add a member 6 months after
// buying the seats; that member's access still expires at the same time
// as everyone else's — 1 year after the team was bought, not 1 year from
// when they personally joined). Callers that need the team anchor pass
// $access_expires explicitly (see pildcm_ajax_assign_track() in 03-ajax.php).
function pildcm_enroll_user($user_id, $track_id, $program_id = 0, $enrolled_by = 0, $deadline = null, $access_expires = null) {
    global $wpdb;
    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT id, access_expires FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND track_id=%d AND program_id=%d",
        $user_id, $track_id, $program_id
    ));

    if (!$access_expires) $access_expires = date('Y-m-d H:i:s', strtotime('+1 year'));

    if ($existing) {
        // PHASE 6: a UNIQUE KEY on (user_id, track_id, program_id) means a
        // repurchase after the 1-year window lapsed would otherwise hit this
        // existing row and silently do nothing (the old INSERT-only version
        // of this function just returned false here) — access would never
        // actually be renewed even though the person just paid again. If the
        // existing row has genuinely expired, extend it instead of blocking.
        $is_expired = $existing->access_expires && strtotime($existing->access_expires) <= time();
        if (!$is_expired) return false; // still within their current window — nothing to do

        return $wpdb->update("{$wpdb->prefix}pild_enrollments", [
            'enrolled_by'    => $enrolled_by,
            'deadline'       => $deadline,
            'access_expires' => $access_expires,
            'status'         => 'active',
        ], ['id' => $existing->id]);
    }

    return $wpdb->insert("{$wpdb->prefix}pild_enrollments", [
        'user_id'        => $user_id,
        'track_id'       => $track_id,
        'program_id'     => $program_id,
        'enrolled_by'    => $enrolled_by,
        'deadline'       => $deadline,
        'access_expires' => $access_expires,
        'status'         => 'active',
    ]);
}

function pildcm_is_enrolled($user_id, $track_id) {
    global $wpdb;
    $ids = pild_bilingual_post_ids($track_id);
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $args = array_merge([$user_id], $ids);
    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_enrollments
         WHERE user_id=%d AND track_id IN ($placeholders) AND status='active'
           AND (access_expires IS NULL OR access_expires > NOW())",
        $args
    ));
}

// True only when the user WAS enrolled but their 1-year access window has
// passed — used to show "renew" instead of "purchase" messaging.
function pildcm_enrollment_expired($user_id, $track_id) {
    global $wpdb;
    $ids = pild_bilingual_post_ids($track_id);
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $args = array_merge([$user_id], $ids);
    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_enrollments
         WHERE user_id=%d AND track_id IN ($placeholders) AND status='active'
           AND access_expires IS NOT NULL AND access_expires <= NOW()",
        $args
    ));
}

// ============================================================
// BILINGUAL CONTENT — shared helper
// ------------------------------------------------------------
// Arabic/English editions of the same track, playbook or book are two
// separate WordPress posts linked via Polylang translations, but a member
// who bought/was-enrolled-in ONE edition must get access to BOTH. Every
// enrollment/ownership check in this file funnels through this helper to
// expand a single post ID into "this post + all of its translations".
// ============================================================
function pild_bilingual_post_ids($post_id) {
    $ids = [(int) $post_id];
    if (function_exists('pll_get_post_translations')) {
        $translations = pll_get_post_translations($post_id);
        if (is_array($translations)) {
            foreach ($translations as $tid) {
                $tid = (int) $tid;
                if ($tid) $ids[] = $tid;
            }
        }
    }
    return array_values(array_unique($ids));
}

// ============================================================
// SEAT-AWARE TRACK ASSIGNMENT (added 2026-07)
// ============================================================
// A manager can own several Teams (one per WooCommerce Memberships plan
// purchased): a single-track plan, a whole-domain plan (covers many tracks
// under one seat pool), or the full-platform plan. Each Team's seat count is
// exactly what was paid for (native WC Teams enforcement), and membership in
// a domain/platform-wide Team unlocks every track under it for one seat —
// this is intentional, not a bug (confirmed with the client 2026-07).
//
// Returns how many DISTINCT tracks a plan's content-restriction rules cover,
// or false if the plan does not cover $track_id at all. The count is used
// purely to rank "wider" plans (domain/platform) ahead of "narrower" ones
// (single track) when more than one of the manager's teams could serve a
// given assignment.
function pild_plan_track_scope_count($plan_id, $track_id) {
    if (!$plan_id || !function_exists('wc_memberships_get_membership_plan')) return false;
    $plan = wc_memberships_get_membership_plan($plan_id);
    if (!$plan || !method_exists($plan, 'get_content_restriction_rules')) return false;
    $rules = $plan->get_content_restriction_rules();
    if (empty($rules) || !is_array($rules)) return false;

    $covers = false;
    $total_tracks = 0;
    foreach ($rules as $rule) {
        if (!is_object($rule)) continue;
        $type      = method_exists($rule, 'get_content_type')      ? $rule->get_content_type()      : '';
        $type_name = method_exists($rule, 'get_content_type_name') ? $rule->get_content_type_name() : '';
        if ($type !== 'post_type' || $type_name !== 'track') continue;
        $ids = method_exists($rule, 'get_object_ids') ? array_map('intval', (array) $rule->get_object_ids()) : [];
        $total_tracks += count($ids);
        if (in_array((int) $track_id, $ids, true)) $covers = true;
    }
    return $covers ? $total_tracks : false;
}

// PHASE 4: rewritten to read from pild_teams / pild_team_tracks / pild_team_members
// (includes/23-teams-core.php) instead of the WC Memberships for Teams mirror
// tables + Content Restriction Rules. Return shape is UNCHANGED on purpose —
// pildcm_ajax_assign_track() in 03-ajax.php needs no edits at all.
// plan_id no longer applies (no Membership Plan involved) — kept as 0 for
// shape compatibility. scope = how many tracks this team covers in total,
// used only to prefer "wider" teams first, same as before.
function pild_get_covering_teams_for_track($manager_id, $track_id) {
    global $wpdb;
    // PHASE 6: only teams still within their 1-year purchase window are
    // usable for a NEW seat assignment — an expired team's leftover free
    // seats must NOT be assignable (that would hand out access that's
    // already expired the instant it's granted). This is also what makes
    // "buy a new team once the old one lapses" actually necessary rather
    // than optional: once a team crosses date_created + 1 year, it simply
    // stops appearing here, full or not.
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT t.id, t.seat_count,
                (SELECT COUNT(*) FROM {$wpdb->prefix}pild_team_tracks WHERE team_id = t.id) AS scope
         FROM {$wpdb->prefix}pild_teams t
         INNER JOIN {$wpdb->prefix}pild_team_tracks tt ON tt.team_id = t.id
         WHERE t.owner_id = %d AND tt.track_id = %d AND t.status = 'active'
           AND t.date_created > DATE_SUB(NOW(), INTERVAL 1 YEAR)",
        (int) $manager_id, (int) $track_id
    ));
    if (empty($rows)) return [];

    $candidates = [];
    foreach ($rows as $row) {
        $used = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pild_team_members WHERE team_id=%d AND role='member'",
            (int) $row->id
        ));
        $candidates[] = [
            'team_id'    => (int) $row->id,
            'plan_id'    => 0,
            'seat_count' => (int) $row->seat_count,
            'used'       => $used,
            'scope'      => (int) $row->scope,
        ];
    }
    usort($candidates, function ($a, $b) { return $b['scope'] <=> $a['scope']; });
    return $candidates;
}

// PHASE 4: rewritten on top of pild_team_add_member() (includes/23-teams-core.php),
// which already does the idempotency + seat-limit check against the SAME table
// used for counting seats — closing the double-bookkeeping class of bug the old
// version had (a local mirror table kept in sync with a separate real add_member()
// call, two sources of truth that could drift).
function pild_team_add_member_if_room($team_id, $user_id, $actor_id = null) {
    return function_exists('pild_team_add_member') ? pild_team_add_member($team_id, $user_id, 'member', false, $actor_id) : false;
}

// Maps a post to its bilingual "group key": the lowest post ID among itself
// and all its Polylang translations. Two posts that are translations of one
// another always resolve to the SAME key, regardless of which one is passed
// in — used to de-duplicate playbooks/tracks when a member has done work
// under one language's post ID and is now viewing the other.
function pild_bilingual_group_key($post_id) {
    $ids = pild_bilingual_post_ids($post_id);
    return $ids ? min($ids) : (int) $post_id;
}

function pildcm_get_track_progress($user_id, $track_id) {
    // PHASE 8: this used to be called from 8+ places within a single
    // company-dashboard page render, and each call independently ran a
    // nested get_posts() (WP_Query) chain to count total playbooks for
    // the track — expensive, and the SAME work for every member since
    // that total doesn't depend on user_id at all. Two-layer memoization:
    // (1) the track's total playbook count, cached once per track_id
    //     regardless of which user is being checked;
    // (2) the whole (user_id, track_id) result, so repeat calls across
    //     the page (KPI summary, member table, CSV export, modals...)
    //     reuse the same computed value instead of re-querying.
    static $result_cache = [];
    static $total_cache  = [];

    // A track and its Arabic/English translation are two separate posts, but
    // a member enrolled once can do the work in EITHER language — so progress
    // must be computed on the whole bilingual pair, not just the one post ID
    // the enrollment/current page happens to reference. Everything below is
    // grouped by pild_bilingual_group_key() so a playbook finished in Arabic
    // and its English translation both count as ONE completed item, and the
    // track's percentage/"done of total" is identical no matter which
    // language edition the member (or this function's caller) is looking at.
    $group_key = pild_bilingual_group_key($track_id);
    $cache_key = $user_id . ':' . $group_key;
    if (isset($result_cache[$cache_key])) return $result_cache[$cache_key];

    $track_ids = pild_bilingual_post_ids($track_id);

    if (!isset($total_cache[$group_key])) {
        global $wpdb;
        $playbook_groups = [];
        foreach ($track_ids as $tid) {
            $programs = get_posts(['post_type' => 'program', 'posts_per_page' => -1,
                'meta_key' => 'program_track', 'meta_value' => $tid]);
            foreach ($programs as $p) {
                $playbooks = get_posts(['post_type' => 'playbook', 'posts_per_page' => -1,
                    'meta_key' => 'playbook_program', 'meta_value' => $p->ID]);
                foreach ($playbooks as $pb) {
                    $playbook_groups[pild_bilingual_group_key($pb->ID)] = true;
                }
            }
        }
        $total_cache[$group_key] = count($playbook_groups) ?: 1;
    }
    $total = $total_cache[$group_key];

    global $wpdb;
    $placeholders = implode(',', array_fill(0, count($track_ids), '%d'));
    $completed_playbook_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT playbook_id FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND track_id IN ($placeholders)",
        array_merge([$user_id], $track_ids)
    ));
    $done_groups = [];
    foreach ($completed_playbook_ids as $pbid) {
        $done_groups[pild_bilingual_group_key($pbid)] = true;
    }
    $done = count($done_groups);

    return $result_cache[$cache_key] = ['done' => $done, 'total' => $total, 'pct' => min(100, round($done / $total * 100))];
}

function pildcm_get_user_points($user_id) {
    global $wpdb;
    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(points),0) FROM {$wpdb->prefix}pild_points WHERE user_id=%d", $user_id
    ));
}

function pildcm_get_user_badges($user_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_badges WHERE user_id=%d ORDER BY earned_at DESC", $user_id
    )) ?: [];
}

function pildcm_get_streak($user_id) {
    global $wpdb;
    $days = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT DATE(completed_at) as d FROM {$wpdb->prefix}pild_progress
         WHERE user_id=%d ORDER BY d DESC LIMIT 60", $user_id
    ));
    if (empty($days)) return 0;
    $streak = 0;
    $check  = date('Y-m-d');
    foreach ($days as $d) {
        if ($d === $check) { $streak++; $check = date('Y-m-d', strtotime($check . ' -1 day')); }
        else break;
    }
    return $streak;
}

function pildcm_get_user_enrollments($user_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND status='active'", $user_id
    )) ?: [];
}

function pildcm_get_solo_enrollments($user_id) {
    global $wpdb;
    $db_enrollments = $wpdb->get_results($wpdb->prepare(
        "SELECT track_id, deadline FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND status='active'", $user_id
    )) ?: [];
    $track_ids = [];
    $enrollment_map = [];
    foreach ($db_enrollments as $e) {
        $tid = (int)$e->track_id;
        $track_ids[$tid] = true;
        $enrollment_map[$tid] = $e->deadline ?? null;
    }
    if (function_exists('wc_memberships_get_user_memberships')) {
        try {
            $memberships = wc_memberships_get_user_memberships($user_id);
            if (!empty($memberships) && is_array($memberships)) {
                foreach ($memberships as $mem) {
                    if (!is_object($mem) || !method_exists($mem, 'get_plan')) continue;
                    $plan = $mem->get_plan();
                    if (!$plan || !method_exists($plan, 'get_content_restriction_rules')) continue;
                    $rules = $plan->get_content_restriction_rules();
                    if (empty($rules) || !is_array($rules)) continue;
                    foreach ($rules as $rule) {
                        if (!is_object($rule)) continue;
                        // FIX: same get_content_type()/get_content_type_name() mix-up as in
                        // pildcm_get_manager_tracks() above — see the comment there.
                        $type      = method_exists($rule, 'get_content_type')      ? $rule->get_content_type()      : '';
                        $type_name = method_exists($rule, 'get_content_type_name') ? $rule->get_content_type_name() : '';
                        $ids       = method_exists($rule, 'get_object_ids')        ? $rule->get_object_ids()        : [];
                        if ($type === 'post_type' && $type_name === 'track') {
                            foreach ((array)$ids as $tid) {
                                $tid = (int)$tid;
                                if ($tid && get_post_status($tid) === 'publish' && !isset($track_ids[$tid])) {
                                    $track_ids[$tid] = true;
                                    $enrollment_map[$tid] = null;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) { /* silent */ }
    }
    // Method 2: Per-track capability check — always runs to catch tracks from packages whose
    // plan rules weren't picked up by Method 1 (e.g. different content-type key).
    // Skips tracks already found (isset guard). Results cached per-user for 5 minutes.
    $cache_key_solo = 'pild_solo_tracks_' . (int) $user_id;
    $cached_solo    = get_transient($cache_key_solo);
    if ($cached_solo !== false) {
        foreach ($cached_solo as $tid) {
            if (!isset($track_ids[$tid])) {
                $track_ids[$tid]      = true;
                $enrollment_map[$tid] = null;
            }
        }
    } elseif (function_exists('wc_memberships_user_can')) {
        $method2_tids  = [];
        $all_track_ids = get_posts([
            'post_type'      => 'track',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'fields'         => 'ids',
        ]);
        foreach ($all_track_ids as $tid) {
            $tid = (int) $tid;
            if (isset($track_ids[$tid])) continue;
            if (function_exists('wc_memberships_is_post_content_restricted') &&
                !wc_memberships_is_post_content_restricted($tid)) continue;
            if (wc_memberships_user_can($user_id, 'view', ['post' => $tid])) {
                $track_ids[$tid]      = true;
                $enrollment_map[$tid] = null;
                $method2_tids[]       = $tid;
            }
        }
        set_transient($cache_key_solo, $method2_tids, 5 * MINUTE_IN_SECONDS);
    }
    // Dedupe: a member can end up with both the Arabic and English post IDs
    // in $track_ids at this point (DB row recorded for one language, a WC
    // Memberships rule/capability check picking up the other via the
    // bilingual access filters below) — collapse each translation pair down
    // to ONE entry so the same track never shows as two separate cards.
    // We deliberately keep whichever ID the enrollment/progress data is
    // actually recorded against (progress %, quiz results and certificates
    // are stored per-post, not per-translation-group) — see
    // pild_bilingual_track_display() below for how the card then shows the
    // title/link in the member's CURRENT browsing language without touching
    // which ID drives the progress numbers.
    if (function_exists('pll_get_post_translations')) {
        $seen_groups = [];
        foreach ($track_ids as $tid => $_) {
            $translations = pll_get_post_translations($tid);
            $group_key = (is_array($translations) && !empty($translations)) ? min($translations) : $tid;
            if (isset($seen_groups[$group_key])) {
                unset($track_ids[$tid]); // keep the first ID seen for this track, drop the duplicate
                continue;
            }
            $seen_groups[$group_key] = true;
        }
    }

    $results = [];
    foreach ($track_ids as $tid => $_) {
        $obj = new stdClass();
        $obj->track_id = $tid;
        $obj->deadline = $enrollment_map[$tid] ?? null;
        $results[] = $obj;
    }
    return $results;
}

// Bilingual display helper for a track/enrollment card: the progress %,
// "done" count and certificate must stay tied to the exact post ID they were
// actually recorded against ($tid) — but the TITLE and the "Review/Continue/
// Start Track" LINK should follow whichever language the member is
// currently browsing in, if a translation exists. Returns [$display_post,
// $display_permalink] — falls back to $tid's own post/permalink when no
// translation exists or Polylang isn't active.
function pild_bilingual_track_display($tid, $track) {
    if (function_exists('pll_get_post_translations') && function_exists('pll_current_language')) {
        $current_lang = pll_current_language();
        $translations = pll_get_post_translations($tid);
        if ($current_lang && is_array($translations) && !empty($translations[$current_lang])) {
            $other_id = (int) $translations[$current_lang];
            if ($other_id !== $tid) {
                $other_post = get_post($other_id);
                if ($other_post && $other_post->post_status === 'publish') {
                    return [$other_post, get_permalink($other_id)];
                }
            }
        }
    }
    return [$track, get_permalink($tid)];
}

// Same idea as pild_bilingual_track_display() above, but for callers that
// only need the TITLE string (not the full post object + permalink) — the
// Company Dashboard (includes/04-dashboard-company.php) stores/queries
// track and Practice-Area (domain) IDs that point at ONE specific language's
// post, then rendered get_the_title($id) directly regardless of which
// language the manager is currently viewing the dashboard in. That's why a
// manager browsing in English still saw Arabic track/Practice-Area names:
// get_the_title() has no idea about the current language, it just returns
// whatever that literal post ID's title is. This resolves to the current
// language's translation first (falling back to the original ID's own
// title when no translation exists or Polylang isn't active), the same
// fallback behavior as pild_bilingual_track_display().
function pild_bilingual_title($post_id) {
    $post_id = (int) $post_id;
    if (function_exists('pll_get_post_translations') && function_exists('pll_current_language')) {
        $current_lang = pll_current_language();
        $translations = pll_get_post_translations($post_id);
        if ($current_lang && is_array($translations) && !empty($translations[$current_lang])) {
            $other_id = (int) $translations[$current_lang];
            if ($other_id !== $post_id) {
                $other_post = get_post($other_id);
                if ($other_post && $other_post->post_status === 'publish') {
                    return get_the_title($other_id);
                }
            }
        }
    }
    return get_the_title($post_id);
}

function get_from_db_pildcm_enrollment($user_id, $track_id) {
    global $wpdb;
    $ids = pild_bilingual_post_ids($track_id);
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $args = array_merge([$user_id], $ids);
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND track_id IN ($placeholders) AND status='active' LIMIT 1",
        $args
    ));
}

// PHASE 11: shared HTML email template. Every customer-facing email in the
// plugin used to be plain text (wp_mail's default) while every dashboard
// the person actually logs into is carefully styled — the email was the
// worst-looking part of the whole experience, and often the FIRST thing a
// new employee sees before they've ever opened the platform. One function,
// used everywhere, so branding/styling can never drift between emails.
function pild_email_html($heading, $body_html, $cta_label = '', $cta_url = '') {
    $cta_block = '';
    if ($cta_label && $cta_url) {
        $cta_block = '
        <tr><td style="padding:28px 40px 8px;">
          <a href="' . esc_url($cta_url) . '" style="display:inline-block;background:#0E6655;color:#ffffff;text-decoration:none;font-weight:600;font-size:15px;padding:13px 28px;border-radius:8px;">' . esc_html($cta_label) . '</a>
        </td></tr>';
    }

    return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F3F4F6;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F3F4F6;padding:32px 16px;">
      <tr><td align="center">
        <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:14px;overflow:hidden;max-width:560px;width:100%;">
          <tr><td style="background:#0E6655;padding:22px 40px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;letter-spacing:.3px;">PILD</span>
          </td></tr>
          <tr><td style="padding:36px 40px 8px;">
            <h1 style="margin:0 0 18px;font-size:20px;color:#111827;">' . esc_html($heading) . '</h1>
            <div style="font-size:15px;line-height:1.6;color:#374151;">' . $body_html . '</div>
          </td></tr>
          ' . $cta_block . '
          <tr><td style="padding:32px 40px 28px;">
            <hr style="border:none;border-top:1px solid #E5E7EB;margin:0 0 20px;" />
            <p style="margin:0;font-size:13px;color:#9CA3AF;">PILD Learning Platform · <a href="https://pild.org" style="color:#9CA3AF;">pild.org</a></p>
          </td></tr>
        </table>
      </td></tr>
    </table>
    </body></html>';
}

function pild_email_headers() {
    return ['Content-Type: text/html; charset=UTF-8'];
}

function pildcm_get_member_manager($user_id) {
    // PHASE 4: was wc_memberships_teams/team_members — now pild_teams/pild_team_members.
    global $wpdb;
    $team_id = $wpdb->get_var($wpdb->prepare(
        "SELECT team_id FROM {$wpdb->prefix}pild_team_members WHERE user_id=%d AND role='member' LIMIT 1", $user_id
    ));
    if (!$team_id) return null;

    return $wpdb->get_var($wpdb->prepare(
        "SELECT owner_id FROM {$wpdb->prefix}pild_teams WHERE id=%d LIMIT 1", $team_id
    ));
}

function pildcm_get_member_avatar($user_id) {
    $avatar_id = get_user_meta($user_id, 'pild_avatar_id', true);
    return $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
}

if (!function_exists('pildcm_get_student_company_data')) {
    function pildcm_get_student_company_data($user_id) {
        $manager_id = pildcm_get_member_manager($user_id);
        if (!$manager_id) $manager_id = (int) $user_id;

        $company_name = (string) get_user_meta($manager_id, 'pild_company_name', true);
        $logo_id      = get_user_meta($manager_id, 'pild_company_logo_id', true);
        $logo_url     = $logo_id ? (string) wp_get_attachment_image_url($logo_id, 'medium') : '';

        if (!$company_name) {
            $mgr = get_userdata($manager_id);
            $company_name = $mgr ? $mgr->display_name : '';
        }
        return ['name' => $company_name, 'logo_url' => $logo_url, 'manager_id' => $manager_id];
    }
}

function pildcm_get_certificate_url($user_id, $track_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'pild_results';
    
    $code = $wpdb->get_var($wpdb->prepare(
        "SELECT certificate_code FROM `$table` WHERE user_id=%d AND track_id=%d AND passed='yes' ORDER BY completed_at DESC LIMIT 1",
        $user_id, $track_id
    ));
    
    if ($code) {
        return home_url('/certificate/' . $code);
    }
    
    // Fallback to old method
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT certificate_url FROM `$table` WHERE user_id=%d AND track_id=%d AND passed='yes' ORDER BY completed_at DESC LIMIT 1",
        $user_id, $track_id
    ));
    
    if ($row && !empty($row->certificate_url)) {
        return $row->certificate_url;
    }
    
    return '';
}

// ============================================================
// MEMBER ARTICLES — get posts (post_type=post) accessible
// to the user via their active WC Memberships plan rules.
// Returns array of WP_Post objects, or empty array.
// ============================================================
function pildcm_get_member_articles($user_id) {
    $article_ids = [];

    // Method 1: Read post content restriction rules from the user's WC Memberships plans
    if (function_exists('wc_memberships_get_user_memberships')) {
        try {
            $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
            if (!empty($memberships) && is_array($memberships)) {
                foreach ($memberships as $mem) {
                    if (!is_object($mem) || !method_exists($mem, 'get_plan')) continue;
                    $plan = $mem->get_plan();
                    if (!$plan || !method_exists($plan, 'get_content_restriction_rules')) continue;
                    $rules = $plan->get_content_restriction_rules();
                    if (empty($rules) || !is_array($rules)) continue;
                    foreach ($rules as $rule) {
                        if (!is_object($rule)) continue;
                        $type = method_exists($rule, 'get_content_type') ? $rule->get_content_type() : '';
                        $ids  = method_exists($rule, 'get_object_ids')   ? $rule->get_object_ids()   : [];
                        // Matches 'post', 'post_type:post', or category/taxonomy rules for posts
                        if (in_array($type, ['post', 'post_type:post'], true)) {
                            foreach ((array)$ids as $pid) {
                                $pid = (int)$pid;
                                if ($pid && get_post_status($pid) === 'publish') {
                                    $article_ids[$pid] = true;
                                }
                            }
                        }
                        // Category-level rules — include all published posts in that category
                        if ($type === 'taxonomy:category' || $type === 'post_category') {
                            $term_ids = (array)$ids;
                            if (!empty($term_ids)) {
                                $cat_posts = get_posts([
                                    'post_type'      => 'post',
                                    'post_status'    => 'publish',
                                    'posts_per_page' => -1,
                                    'tax_query'      => [[
                                        'taxonomy' => 'category',
                                        'field'    => 'term_id',
                                        'terms'    => $term_ids,
                                    ]],
                                    'fields' => 'ids',
                                ]);
                                foreach ($cat_posts as $pid) {
                                    $article_ids[(int)$pid] = true;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) { /* silent */ }
    }

    // Method 2: Per-post capability check — always runs (same fix as get_manager_tracks /
    // get_solo_enrollments) so articles from a second package are never silently dropped.
    // Skips posts already found by Method 1. Capped at 200 posts for performance.
    if (function_exists('wc_memberships_user_can')) {
        $all_pids = get_posts([
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ]);
        foreach ($all_pids as $pid) {
            $pid = (int) $pid;
            if (isset($article_ids[$pid])) continue; // already found by Method 1
            if (function_exists('wc_memberships_is_post_content_restricted') &&
                !wc_memberships_is_post_content_restricted($pid)) continue;
            if (wc_memberships_user_can($user_id, 'view', ['post' => $pid])) {
                $article_ids[$pid] = true;
            }
        }
    }

    if (empty($article_ids)) return [];

    return get_posts([
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'post__in'       => array_keys($article_ids),
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);
}

// ============================================================
// FREE PLAYBOOKS — playbooks (post_type=playbook) accessible to the
// user via their active WC Memberships plan rules (mirrors the
// pildcm_get_member_articles pattern above: content-restriction rules
// first, then a per-post capability check as a safety net).
//
// Playbooks that belong to a track the user already has a *paid*
// enrollment for are excluded via $exclude_track_ids — those already
// appear under "My Development Tracks" and shouldn't be duplicated
// under "Free Resources".
// ============================================================
function pildcm_get_playbook_track_id($playbook_id) {
    $program_id = (int) get_post_meta($playbook_id, 'playbook_program', true);
    return $program_id ? (int) get_post_meta($program_id, 'program_track', true) : 0;
}

function pildcm_get_member_free_playbooks($user_id, $exclude_track_ids = []) {
    $exclude_track_ids = array_map('intval', (array) $exclude_track_ids);
    $playbook_ids = [];

    // Method 1: content restriction rules on the user's active plans
    if (function_exists('wc_memberships_get_user_memberships')) {
        try {
            $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
            if (!empty($memberships) && is_array($memberships)) {
                foreach ($memberships as $mem) {
                    if (!is_object($mem) || !method_exists($mem, 'get_plan')) continue;
                    $plan = $mem->get_plan();
                    if (!$plan || !method_exists($plan, 'get_content_restriction_rules')) continue;
                    $rules = $plan->get_content_restriction_rules();
                    if (empty($rules) || !is_array($rules)) continue;
                    foreach ($rules as $rule) {
                        if (!is_object($rule)) continue;
                        $type      = method_exists($rule, 'get_content_type')      ? $rule->get_content_type()      : '';
                        $type_name = method_exists($rule, 'get_content_type_name') ? $rule->get_content_type_name() : '';
                        $ids       = method_exists($rule, 'get_object_ids')        ? $rule->get_object_ids()        : [];
                        if ($type === 'post_type' && $type_name === 'playbook') {
                            foreach ((array)$ids as $pid) {
                                $pid = (int)$pid;
                                if ($pid && get_post_status($pid) === 'publish') {
                                    $playbook_ids[$pid] = true;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) { /* silent */ }
    }

    // Method 2: per-post capability check — safety net, capped at 200 for performance
    if (function_exists('wc_memberships_user_can')) {
        $all_pbids = get_posts([
            'post_type'      => 'playbook',
            'post_status'    => 'publish',
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ]);
        foreach ($all_pbids as $pid) {
            $pid = (int) $pid;
            if (isset($playbook_ids[$pid])) continue; // already found by Method 1
            if (function_exists('wc_memberships_is_post_content_restricted') &&
                !wc_memberships_is_post_content_restricted($pid)) continue;
            if (wc_memberships_user_can($user_id, 'view', ['post' => $pid])) {
                $playbook_ids[$pid] = true;
            }
        }
    }

    if (empty($playbook_ids)) return [];

    // Drop playbooks whose track is already a paid enrollment (avoid duplicates with Tracks tab)
    if (!empty($exclude_track_ids)) {
        foreach ($playbook_ids as $pid => $_) {
            $tid = pildcm_get_playbook_track_id($pid);
            if ($tid && in_array($tid, $exclude_track_ids, true)) {
                unset($playbook_ids[$pid]);
            }
        }
    }

    if (empty($playbook_ids)) return [];

    return get_posts([
        'post_type'      => 'playbook',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'post__in'       => array_keys($playbook_ids),
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);
}

// ============================================================
// PURCHASED PRODUCTS — standalone paid books/assessments the member
// bought directly (a Playbook or Assessment product), NOT a package
// that unlocks a whole Track (those are driven by the ACF field
// `product_tracks` and already surface under "My Development Tracks").
// Free items (price = 0), such as the free plan's signup product, are
// excluded here — those live under "Free Resources & Articles".
// ============================================================
function pildcm_get_member_purchased_products($user_id) {
    if (!function_exists('wc_get_orders')) return [];

    $orders = wc_get_orders([
        'customer' => $user_id,
        'limit'    => 50,
        'orderby'  => 'date',
        'order'    => 'DESC',
        'status'   => ['completed', 'processing'],
    ]);
    if (empty($orders)) return [];

    $products = [];
    foreach ($orders as $order) {
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            if (!$product_id || isset($products[$product_id])) continue;

            $product = wc_get_product($product_id);
            if (!$product) continue;

            // Skip track-unlocking packages — those belong on the Tracks
            // tab instead. Covers both the legacy one-product-per-track
            // model (product_tracks field) AND the shared pricing-level
            // model (includes/22-registration-routing.php's 6 shared
            // products, tagged with _pild_level/_pild_variant instead of
            // a product_tracks list) — a level product is never itself
            // the content, so it must never show up here as a generic
            // "purchased product" with its own product page as the link.
            $track_ids = function_exists('get_field') ? get_field('product_tracks', $product_id) : '';
            $is_level_product = (bool) get_post_meta($product_id, '_pild_level', true);
            if (!empty($track_ids) || $is_level_product) continue;

            // Skip free items (e.g. the free-plan signup product).
            if ((float) $product->get_price() <= 0) continue;

            $book_url  = function_exists('get_field') ? get_field('product_book_url', $product_id) : '';
            $cats      = get_the_terms($product_id, 'product_cat');
            $cat_label = (!empty($cats) && !is_wp_error($cats)) ? $cats[0]->name : 'Product';

            // Is this a Book Store purchase (includes/34-book-store.php)? Primary
            // check: a direct SQL lookup for a published `store_book` whose ACF
            // `book_product` meta equals this product's ID — a raw query instead
            // of get_posts()/WP_Query so it can NEVER be affected by a caching
            // plugin's persistent object cache, a pre_get_posts hook, or any other
            // query filter silently altering the result on some hosting setups.
            $is_book  = false;
            $url_ar   = '';
            $url_en   = '';
            global $wpdb;
            $book_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT pm.post_id FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key = 'book_product' AND pm.meta_value = %s
                   AND p.post_type = 'store_book' AND p.post_status = 'publish'
                 LIMIT 1",
                (string) $product_id
            ));

            // Fallback: reverse-resolve the product's own `product_book_url` ACF
            // field, in case the direct lookup above ever misses (e.g. the field
            // was set manually instead of through the Excel importer).
            if (!$book_id && !empty($book_url)) {
                $maybe_id = url_to_postid($book_url);
                if ($maybe_id && get_post_type($maybe_id) === 'store_book') $book_id = $maybe_id;
            }

            if ($book_id) {
                $is_book = true;
                if (empty($book_url)) $book_url = get_permalink($book_id);

                // Buying one language edition unlocks both (see
                // pild_user_purchased_product_linked_to_post()) — so the "My
                // Library" card can offer direct links to read in either
                // language, instead of relying on the site's language switcher.
                if (function_exists('pll_get_post_translations')) {
                    $book_translations = pll_get_post_translations($book_id);
                    if (is_array($book_translations)) {
                        if (!empty($book_translations['ar'])) $url_ar = get_permalink($book_translations['ar']);
                        if (!empty($book_translations['en'])) $url_en = get_permalink($book_translations['en']);
                    }
                }
            }

            // The card's TEXT (name, category, blurb, cover) must follow the
            // member's CURRENT browsing language, exactly like track cards do
            // via pild_bilingual_track_display() — only the pair of "Read in
            // Arabic / Read in English" buttons stays fixed to url_ar/url_en so
            // both editions remain reachable regardless of which one was bought.
            //
            // IMPORTANT: Polylang's translation link lives on the BOOK posts
            // (pll_save_post_translations() is only ever called for the two
            // store_book posts — see pild_bookstore_execute()), never on the
            // two WooCommerce PRODUCT posts directly. So resolving language
            // must start from $book_id's translation, then read ITS OWN
            // linked product — asking pll_get_post_translations($product_id)
            // directly returns nothing, since the products were never linked
            // to each other as translations.
            $display_product = $product;
            $display_product_id = $product_id;
            if ($book_id && function_exists('pll_get_post_translations') && function_exists('pll_current_language')) {
                $current_lang = pll_current_language();
                $current_lang_book_id = 0;
                if ($current_lang) {
                    if (isset($book_translations) && is_array($book_translations) && !empty($book_translations[$current_lang])) {
                        $current_lang_book_id = (int) $book_translations[$current_lang];
                    } elseif (function_exists('pll_get_post_language') && pll_get_post_language($book_id) === $current_lang) {
                        $current_lang_book_id = $book_id; // already the right language
                    }
                }
                if ($current_lang_book_id) {
                    $translated_product_id = function_exists('get_field') ? (int) get_field('book_product', $current_lang_book_id) : 0;
                    if ($translated_product_id && $translated_product_id !== $product_id) {
                        $translated_product = wc_get_product($translated_product_id);
                        if ($translated_product) {
                            $display_product    = $translated_product;
                            $display_product_id = $translated_product_id;
                        }
                    }
                }
            }
            $display_cats = get_the_terms($display_product_id, 'product_cat');
            $display_cat_label = (!empty($display_cats) && !is_wp_error($display_cats)) ? $display_cats[0]->name : $cat_label;

            $products[$product_id] = (object) [
                'product_id' => $product_id,
                'name'       => $display_product->get_name(),
                'url'        => !empty($book_url) ? $book_url : get_permalink($product_id),
                'thumb'      => get_the_post_thumbnail_url($display_product_id, 'medium'),
                'short_desc' => wp_strip_all_tags($display_product->get_short_description()),
                'cat_label'  => $display_cat_label,
                'is_book'    => $is_book,
                'url_ar'     => $url_ar,
                'url_en'     => $url_en,
            ];
        }
    }
    return array_values($products);
}

// ============================================================
// COMPANY LOGO — SIZE STANDARDS & AUTO-NORMALIZATION
// ============================================================
/**
 * The fixed "box" every company logo gets normalized into.
 * Changing these numbers changes the standard for ALL future uploads.
 * (Existing already-uploaded logos are not retroactively resized.)
 */
function pildcm_company_logo_box() {
    return [
        'width'  => 400, // px — final canvas width
        'height' => 200, // px — final canvas height (2:1 box, logo is fit inside, never cropped)
    ];
}

/**
 * Human-readable recommendation shown in the admin/dashboard UI,
 * so company managers know what to upload even before normalization runs.
 */
function pildcm_company_logo_size_label() {
    $box = pildcm_company_logo_box();
    return sprintf(
        '%d × %d px (PNG with transparent background recommended)',
        $box['width'],
        $box['height']
    );
}

/**
 * Normalize an uploaded company logo attachment to a single standard size.
 *
 * Whatever dimensions/aspect-ratio the admin uploads, this:
 *  - Scales the image down/up so it fits inside the standard box
 *    (never upscaled beyond the box, never cropped/distorted),
 *  - Centers it on a transparent canvas of EXACTLY pildcm_company_logo_box(),
 *  - Overwrites the attachment file in place, so every company logo used
 *    on certificates ends up with identical, predictable dimensions.
 *
 * @param int $attachment_id The attachment ID returned by media_handle_upload().
 * @return bool True on success, false if the file couldn't be processed.
 */
function pildcm_normalize_company_logo($attachment_id) {
    $file_path = get_attached_file($attachment_id);
    if (!$file_path || !file_exists($file_path)) return false;

    $box = pildcm_company_logo_box();
    $editor = wp_get_image_editor($file_path);
    if (is_wp_error($editor)) return false;

    $size = $editor->get_size();
    if (!$size || empty($size['width']) || empty($size['height'])) return false;

    // Scale to FIT inside the box (preserve aspect ratio, no upscaling past the box)
    $scale = min($box['width'] / $size['width'], $box['height'] / $size['height'], 1);
    $new_w = max(1, (int) round($size['width']  * $scale));
    $new_h = max(1, (int) round($size['height'] * $scale));

    $editor->resize($new_w, $new_h, false);
    $resized_path = $editor->generate_filename('logo-fit');
    $saved = $editor->save($resized_path);
    if (is_wp_error($saved)) return false;

    // Composite the fitted logo onto a transparent canvas of the exact standard size
    if (function_exists('imagecreatetruecolor') && !empty($saved['path'])) {
        $canvas = imagecreatetruecolor($box['width'], $box['height']);
        imagesavealpha($canvas, true);
        $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
        imagefill($canvas, 0, 0, $transparent);

        $src_img = @imagecreatefromstring(file_get_contents($saved['path']));
        if ($src_img) {
            imagesavealpha($src_img, true);
            $dst_x = (int) round(($box['width']  - $new_w) / 2);
            $dst_y = (int) round(($box['height'] - $new_h) / 2);
            imagecopy($canvas, $src_img, $dst_x, $dst_y, 0, 0, $new_w, $new_h);
            imagedestroy($src_img);

            // Overwrite the ORIGINAL attachment file with the normalized canvas
            imagepng($canvas, $file_path);
            imagedestroy($canvas);

            // Clean up the temporary "fit" file and refresh WP's cached metadata
            @unlink($saved['path']);
            if (function_exists('wp_update_attachment_metadata') && function_exists('wp_generate_attachment_metadata')) {
                $metadata = wp_generate_attachment_metadata($attachment_id, $file_path);
                wp_update_attachment_metadata($attachment_id, $metadata);
            }
            return true;
        }
        imagedestroy($canvas);
    }

    return false;
}

// ============================================================
// CACHE INVALIDATION — clear per-user track/enrollment caches
// whenever a WC Memberships status changes so the user sees
// their updated access immediately without waiting 5 minutes.
// ============================================================

/**
 * Bust the Method-2 transient caches for a specific user.
 * Called on any membership status event (created, updated, deleted).
 *
 * @param int $user_id
 */
function pild_bust_track_cache( $user_id ) {
    $user_id = (int) $user_id;
    if ( ! $user_id ) return;
    delete_transient( 'pild_manager_tracks_' . $user_id );
    delete_transient( 'pild_solo_tracks_'    . $user_id );
}

// Fires when a user membership is created (new purchase / manual grant)
add_action( 'wc_memberships_user_membership_created',        function( $membership ) {
    if ( is_object( $membership ) && method_exists( $membership, 'get_user_id' ) ) {
        pild_bust_track_cache( $membership->get_user_id() );
    }
} );

// Fires when status changes (active → expired, paused → active, etc.)
add_action( 'wc_memberships_user_membership_status_changed', function( $membership ) {
    if ( is_object( $membership ) && method_exists( $membership, 'get_user_id' ) ) {
        pild_bust_track_cache( $membership->get_user_id() );
    }
} );

// Fires when a membership is permanently deleted
add_action( 'wc_memberships_user_membership_deleted',        function( $membership ) {
    if ( is_object( $membership ) && method_exists( $membership, 'get_user_id' ) ) {
        pild_bust_track_cache( $membership->get_user_id() );
    }
} );

// ============================================================
// STANDALONE BOOK/ASSESSMENT PURCHASE → CONTENT ACCESS BYPASS
//
// A post can end up gated by TWO independent systems at once:
//   1. "Page Restrict for WooCommerce" — locked to one exact product
//      via its own "Lock by Products" field (post meta `prwc_products`).
//   2. WooCommerce Memberships — the post is ALSO covered by a plan's
//      content-restriction rules (e.g. by category), gating it behind
//      a full membership plan (e.g. "Pild Knowledge Membership").
// A customer who buys the individual product (system 1) but doesn't
// own the full plan (system 2) still gets WC Memberships' own
// "you must purchase <plan-granting product>" message — even though
// they already paid for exactly this piece of content.
//
// Fix: whenever WordPress resolves the WC Memberships "can view this
// restricted post" capability, also allow it if the current user has
// purchased one of the products already listed in that post's own
// "Lock by Products" field (`prwc_products` — no extra setup needed,
// it's the same list the admin already configured), or a product whose
// ACF `product_book_url` field links straight to this post (used to
// build the dashboard's "Read Now" buttons) as a secondary check.
//
// Two hooks are used for safety: `map_meta_cap` catches the
// current_user_can('wc_memberships_view_restricted_post', ...) checks
// WC Memberships uses when it decides whether to render the real
// content vs. the restricted message; `wc_memberships_user_can` is an
// extra safety net for any other code path that calls the public
// wc_memberships_user_can() helper directly.
// ============================================================
add_filter('map_meta_cap', 'pild_bypass_wcm_meta_cap_for_purchased_book', 999, 4);
function pild_bypass_wcm_meta_cap_for_purchased_book($caps, $cap, $user_id, $args) {
    static $checking = [];
    $wcm_view_caps = [
        'wc_memberships_view_restricted_post_content', // posts/pages — the actual cap WC Memberships checks
        'wc_memberships_view_restricted_product',      // products
        'wc_memberships_view_delayed_post_content',    // delayed-access content
    ];
    if (!in_array($cap, $wcm_view_caps, true)) return $caps;

    $post_id = isset($args[0]) ? (int) $args[0] : 0;
    if (!$post_id) return $caps;

    if (pild_user_purchased_product_linked_to_post($user_id, $post_id)) {
        return ['read']; // a capability every logged-in customer already has — grants access
    }

    // Bilingual fallback: this exact post may be locked, but if the member
    // already has WC Memberships view access to its OTHER language edition
    // (a track/playbook they're enrolled in via a plan rule), extend that
    // same access to this translation too — see pild_bilingual_post_ids().
    $guard_key = $cap . ':' . $user_id . ':' . $post_id;
    if (isset($checking[$guard_key])) return $caps; // already resolving this post -> avoid recursion
    $checking[$guard_key] = true;

    $result = $caps;
    if (function_exists('wc_memberships_user_can')) {
        foreach (pild_bilingual_post_ids($post_id) as $other_id) {
            if ($other_id === $post_id) continue;
            if (wc_memberships_user_can($user_id, 'view', ['post' => $other_id])) {
                $result = ['read'];
                break;
            }
        }
    }

    unset($checking[$guard_key]);
    return $result;
}

add_filter('wc_memberships_user_can', 'pild_bypass_restriction_for_purchased_book', 20, 4);
function pild_bypass_restriction_for_purchased_book($can, $user_id, $action, $args) {
    if ($can) return $can; // already allowed, nothing to do
    if ($action !== 'view' || empty($user_id) || empty($args['post'])) return $can;

    $post_id = is_object($args['post']) ? $args['post']->ID : (int) $args['post'];
    if (!$post_id) return $can;

    if (pild_user_purchased_product_linked_to_post($user_id, $post_id)) {
        return true;
    }
    return $can;
}

// Bilingual fallback for the WC Memberships plan-rule route (tracks,
// playbooks, ...): if the member has 'view' access to the OTHER language
// edition of this exact post (enrolled/granted via a membership plan whose
// content-restriction rule only lists one language's post ID), grant the
// same access here. Runs after pild_bypass_restriction_for_purchased_book
// above so the single-product-purchase check is tried first.
add_filter('wc_memberships_user_can', 'pild_bilingual_membership_access', 25, 4);
function pild_bilingual_membership_access($can, $user_id, $action, $args) {
    static $checking = [];
    if ($can) return $can;
    if ($action !== 'view' || empty($user_id) || empty($args['post'])) return $can;
    if (!function_exists('wc_memberships_user_can')) return $can;

    $post_id = is_object($args['post']) ? $args['post']->ID : (int) $args['post'];
    if (!$post_id) return $can;

    $guard_key = $user_id . ':' . $post_id;
    if (isset($checking[$guard_key])) return $can; // already resolving this post -> avoid recursion
    $checking[$guard_key] = true;

    $result = $can;
    foreach (pild_bilingual_post_ids($post_id) as $other_id) {
        if ($other_id === $post_id) continue;
        if (wc_memberships_user_can($user_id, 'view', ['post' => $other_id])) {
            $result = true;
            break;
        }
    }

    unset($checking[$guard_key]);
    return $result;
}

function pild_user_purchased_product_linked_to_post($user_id, $post_id) {
    static $cache = [];
    $cache_key = $user_id . ':' . $post_id;
    if (isset($cache[$cache_key])) return $cache[$cache_key];

    $owns = false;

    if (function_exists('wc_get_orders') && $user_id && $post_id) {
        // Bilingual books are stored as TWO separate posts (Arabic + English),
        // each with its OWN WooCommerce product (includes/34-book-store.php).
        // Buying either language edition must unlock BOTH — so we collect the
        // "required product" / "book URL" link not just for $post_id, but for
        // every Polylang translation of it too, and match against any of them.
        $post_ids = [$post_id];
        if (function_exists('pll_get_post_translations')) {
            $translations = pll_get_post_translations($post_id);
            if (is_array($translations) && !empty($translations)) {
                $post_ids = array_values(array_unique(array_merge($post_ids, array_map('intval', array_values($translations)))));
            }
        }

        // Primary source: each post's own "Lock by Products" list from the
        // "Page Restrict for WooCommerce" plugin — already configured by
        // the admin for every restricted page, no extra setup required.
        $required_product_ids = [];
        // Secondary source: our own ACF `product_book_url` field on the
        // product (product -> post URL), used to build "Read Now" links.
        $target_permalinks = [];
        foreach ($post_ids as $pid) {
            $prwc_products = get_post_meta($pid, 'prwc_products', true);
            if ($prwc_products) {
                $required_product_ids = array_merge($required_product_ids, array_filter(array_map('intval', explode(',', $prwc_products))));
            }
            $target_permalinks[] = untrailingslashit(get_permalink($pid));
        }
        $required_product_ids = array_unique($required_product_ids);

        $orders = wc_get_orders([
            'customer' => $user_id,
            'limit'    => 50,
            'status'   => ['completed', 'processing'],
        ]);
        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                if (!$product_id) continue;

                if (!empty($required_product_ids) && in_array($product_id, $required_product_ids, true)) {
                    $owns = true;
                    break 2;
                }

                if (function_exists('get_field')) {
                    $book_url = get_field('product_book_url', $product_id);
                    if ($book_url && in_array(untrailingslashit($book_url), $target_permalinks, true)) {
                        $owns = true;
                        break 2;
                    }
                }
            }
        }
    }

    return $cache[$cache_key] = $owns;
}

// ============================================================
// LANGUAGE-AWARE DASHBOARD URLs
// ------------------------------------------------------------
// All the automatic redirects across this plugin (after login,
// after registration, after accepting a team invite, etc.) point
// to one of the three dashboard pages ('solo-dashboard',
// 'company-dashboard', 'member-dashboard'). On a bilingual
// (Polylang) site, a plain home_url('/solo-dashboard/') always
// resolves to that one page regardless of which language the
// visitor is currently using — so an Arabic-language visitor could
// get redirected straight back into the English version of their
// dashboard after logging in, even though everything else on the
// site stayed in Arabic.
//
// pild_dashboard_url( $slug ) fixes this: it finds whichever page
// currently carries that slug (in ANY language — Polylang allows
// the same slug across languages, or a fully different translated
// slug), then asks Polylang for that page's translation in the
// visitor's CURRENT language, and returns that page's real
// permalink. Falls back to the plain '/$slug/' URL on non-Polylang
// sites, or if no matching page exists yet, so nothing breaks on a
// site that hasn't set this plugin up yet.
// ============================================================
function pild_dashboard_url( $slug ) {
    static $cache = [];
    if ( isset( $cache[ $slug ] ) ) return $cache[ $slug ];

    $url = home_url( '/' . trim( $slug, '/' ) . '/' ); // sane fallback

    $page = get_page_by_path( $slug );
    if ( $page instanceof WP_Post ) {
        if ( function_exists( 'pll_current_language' ) && function_exists( 'pll_get_post' ) ) {
            $current_lang  = pll_current_language();
            $translated_id = $current_lang ? pll_get_post( $page->ID, $current_lang ) : 0;
            $target_id     = $translated_id ?: $page->ID; // no translation yet -> whatever we found
            $permalink     = get_permalink( $target_id );
        } else {
            $permalink = get_permalink( $page->ID );
        }
        if ( $permalink ) $url = $permalink;
    }

    return $cache[ $slug ] = $url;
}
