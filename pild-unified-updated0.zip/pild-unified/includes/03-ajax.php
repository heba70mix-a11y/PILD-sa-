<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 5–14. AJAX HANDLERS (unchanged logic, kept intact)
// ============================================================

add_action('wp_ajax_pildcm_sync_team', 'pildcm_ajax_sync_team');
function pildcm_ajax_sync_team() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Unauthorized');
    $manager_id = get_current_user_id();

    // PHASE 4: teams are now created automatically (includes/24-team-purchase.php,
    // on order completion) and kept in sync by construction — there is nothing
    // left to "sync" from an external extension. Kept as a no-op success so any
    // existing "Sync Team" button in the UI still works, just reports status
    // instead of doing a manual re-pull from WC Memberships for Teams.
    $teams = function_exists('pild_get_owner_teams') ? pild_get_owner_teams($manager_id) : [];
    if (empty($teams)) wp_send_json_error('No teams found');

    $members = pildcm_get_team_members($manager_id);
    wp_send_json_success(['message' => count($members) . ' member(s) up to date.']);
}

add_action('wp_ajax_pildcm_assign_track', 'pildcm_ajax_assign_track');
function pildcm_ajax_assign_track() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    $manager_id = get_current_user_id();
    // PHASE 4: explicit authorization check (previously relied on
    // pildcm_get_team_members() happening to return empty for non-managers).
    if (!pildcm_is_team_manager($manager_id)) wp_send_json_error('You are not a team manager');
    $user_id       = intval($_POST['user_id']  ?? 0);
    $track_id      = intval($_POST['track_id'] ?? 0);
    $assign_action = sanitize_text_field($_POST['assign_action'] ?? 'assign');
    $deadline      = sanitize_text_field($_POST['deadline'] ?? '');

    if (!$user_id || !$track_id) wp_send_json_error('Missing parameters');

    $members = pildcm_get_team_members($manager_id);
    if (!isset($members[$user_id])) wp_send_json_error('Member not in your team');

    global $wpdb;
    if ($assign_action === 'unassign') {
        $wpdb->delete("{$wpdb->prefix}pild_enrollments", ['user_id' => $user_id, 'track_id' => $track_id]);
        if (function_exists('pild_log_action')) {
            pild_log_action($manager_id, 'track_unassigned', ['subject_user_id' => $user_id, 'track_id' => $track_id]);
        }
        wp_send_json_success(['message' => 'Member removed from track']);
    }

    // Seat enforcement (added 2026-07): find which of the manager's teams
    // actually cover this track (widest/domain plans first), and consume a
    // seat there — reusing an existing seat if the member is already in that
    // team (e.g. from another track under the same domain plan). Only after
    // a real seat is secured do we write the pild_enrollments row.
    $covering_teams = pild_get_covering_teams_for_track($manager_id, $track_id);
    if (empty($covering_teams)) {
        wp_send_json_error('No purchased package covers this track. Please purchase access to this track first.');
    }

    $seated = false;
    $seated_team_id = 0;
    foreach ($covering_teams as $team) {
        if ($team['used'] < $team['seat_count'] || $team['seat_count'] <= 0) {
            if (pild_team_add_member_if_room($team['team_id'], $user_id, $manager_id)) { $seated = true; $seated_team_id = $team['team_id']; break; }
        }
    }
    // Second pass: some candidates may already have the member seated
    // (no cost) even if their seat_count/used snapshot looked full above.
    if (!$seated) {
        foreach ($covering_teams as $team) {
            if (pild_team_add_member_if_room($team['team_id'], $user_id, $manager_id)) { $seated = true; $seated_team_id = $team['team_id']; break; }
        }
    }
    if (!$seated) {
        wp_send_json_error('No seats available for this track. Please contact us to purchase additional seats.');
    }

    // Access expires 1 year from the TEAM's original purchase date, not from
    // today — everyone on a purchased batch of seats loses access at the
    // same time, whether they were added on day one or 6 months later.
    $access_expires = null;
    if ($seated_team_id) {
        $team_purchased_at = $wpdb->get_var($wpdb->prepare(
            "SELECT date_created FROM {$wpdb->prefix}pild_teams WHERE id=%d", $seated_team_id
        ));
        if ($team_purchased_at) {
            $access_expires = date('Y-m-d H:i:s', strtotime($team_purchased_at . ' +1 year'));
        }
    }

    $result = pildcm_enroll_user($user_id, $track_id, 0, $manager_id, $deadline ?: null, $access_expires);
    if ($result === false) wp_send_json_error('Already assigned or error');

    if (function_exists('pild_log_action')) {
        pild_log_action($manager_id, 'track_assigned', ['subject_user_id' => $user_id, 'team_id' => $seated_team_id, 'track_id' => $track_id]);
    }

    $user = get_userdata($user_id);
    $track_url = get_permalink($track_id);
    if ($user && $track_url) {
        $subject = 'New Learning Track Assigned: ' . get_the_title($track_id);
        $body = '<p>Hi ' . esc_html($user->display_name) . ',</p>'
              . '<p>Your manager has assigned you to <strong>' . esc_html(get_the_title($track_id)) . '</strong>.</p>';
        if ($deadline) $body .= '<p>Deadline: <strong>' . esc_html($deadline) . '</strong></p>';
        wp_mail($user->user_email, $subject, pild_email_html('New Track Assigned', $body, 'Start Learning →', $track_url), pild_email_headers());
    }
    wp_send_json_success(['message' => 'Track assigned successfully']);
}

add_action('wp_ajax_pildcm_export_csv', 'pildcm_export_csv');
function pildcm_export_csv() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_die('Unauthorized');
    $manager_id = get_current_user_id();
    if (!pildcm_is_team_manager($manager_id)) wp_die('Unauthorized'); // PHASE 4
    $members    = pildcm_get_team_members($manager_id);
    $tracks     = pildcm_get_manager_tracks($manager_id);

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="team-report-' . date('Y-m-d') . '.csv"');
    header('Pragma: no-cache');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

    $header = ['Member Name', 'Email', 'Last Login'];
    foreach ($tracks as $t) $header[] = get_the_title($t->ID) . ' (%)';
    $header[] = 'Total Points';
    $header[] = 'Badges';
    $header[] = 'Certificates';
    fputcsv($out, $header);

    foreach ($members as $uid => $user) {
        $last_login = get_user_meta($uid, 'pild_last_login', true) ?: '—';
        $row = [$user->display_name, $user->user_email, $last_login];
        foreach ($tracks as $tid => $t) {
            $prog  = pildcm_get_track_progress($uid, $tid);
            $row[] = $prog['pct'] . '%';
        }
        $row[] = pildcm_get_user_points($uid);
        $row[] = count(pildcm_get_user_badges($uid));
        $certs = 0;
        foreach ($tracks as $tid => $t) {
            if (pildcm_get_certificate_url($uid, $tid)) $certs++;
        }
        $row[] = $certs;
        fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

add_action('wp_ajax_pildcm_invite_member', 'pildcm_ajax_invite_member');
function pildcm_ajax_invite_member() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $manager_id = get_current_user_id();
    $email      = sanitize_email($_POST['email'] ?? '');

    if (!$email || !is_email($email)) wp_send_json_error('Invalid email address');

    // PHASE 4: teams now come from includes/23-teams-core.php, not the
    // WC Memberships for Teams extension.
    $teams = function_exists('pild_get_owner_teams') ? pild_get_owner_teams($manager_id) : [];
    if (empty($teams)) wp_send_json_error('No team associated with your account');
    $team      = $teams[0];
    $team_name = $team->name ?: 'the team';
    $team_id   = (int) $team->id;

    $existing_user = get_user_by('email', $email);
    if ($existing_user) {
        $current_members = pildcm_get_team_members($manager_id);
        if (isset($current_members[$existing_user->ID])) wp_send_json_error('Member already in your team');
    }

    global $wpdb;

    // BUGFIX: there was no check here at all for an invite already
    // pending for this email/team. Combined with the fact that a failed
    // wp_mail() still left the row inserted below (see the rollback added
    // a few lines down), every retry after a "Failed to send email"
    // silently piled up ANOTHER pending row for the same person instead
    // of reusing/retrying the first one.
    $already_pending = $wpdb->get_var($wpdb->prepare(
        "SELECT token FROM {$wpdb->prefix}pild_invites WHERE email=%s AND team_id=%d AND status='pending' AND expires_at > NOW() LIMIT 1",
        $email, $team_id
    ));
    if ($already_pending) wp_send_json_error('An invitation is already pending for this email');

    $token   = wp_generate_password(32, false);
    $expires = date('Y-m-d H:i:s', strtotime('+7 days'));

    // PHASE 4: own table instead of a single global 'pildcm_pending_invites'
    // option — fixes the concurrent-invite race condition (two managers
    // inviting at the same moment could silently overwrite each other's
    // update_option() write) and the unbounded option growth (expired,
    // never-clicked invites used to sit in that option forever).
    $inserted = $wpdb->insert($wpdb->prefix . 'pild_invites', [
        'token'        => $token,
        'email'        => $email,
        'manager_id'   => $manager_id,
        'team_id'      => $team_id,
        'status'       => 'pending',
        'expires_at'   => $expires,
        'date_created' => current_time('mysql'),
    ]);
    if (!$inserted) wp_send_json_error('Could not create invitation, please try again');

    $accept_url  = add_query_arg(['pildcm_invite' => $token, 'email' => rawurlencode($email)], home_url('/'));
    $manager      = get_userdata($manager_id);
    $manager_name = $manager->first_name ? trim($manager->first_name . ' ' . $manager->last_name) : $manager->display_name;

    $subject = "You're Invited to Join {$team_name} on PILD";

    if ($existing_user) {
        $action_label = "Accept Your Invitation";
        $action_url   = $accept_url;
        $action_line  = "Click the button below to accept your invitation and access your learning dashboard.";
    } else {
        $action_label = "Create Your Account & Join";
        $action_url   = add_query_arg(['pildcm_invite' => $token, 'email' => rawurlencode($email)], pild_dashboard_url('member-dashboard'));
        $action_line  = "Click the button below to create your account and join your team — your invitation will be accepted automatically.";
    }

    $body = '<p>Dear Learner,</p>'
          . '<p>You have been invited by <strong>' . esc_html($manager_name) . '</strong> to join the <strong>' . esc_html($team_name) . '</strong> team on the PILD Learning Platform.</p>'
          . '<p>' . esc_html($action_line) . '</p>'
          . '<p style="color:#6B7280;font-size:13px;">⏳ This invitation link expires in 7 days. If you did not expect this invitation, you can safely ignore this email.</p>';

    $html_message = pild_email_html("You're Invited!", $body, $action_label, $action_url);

    // Capture wp_mail()'s real failure reason (SMTP/server error), instead
    // of only knowing it returned false. wp_mail() itself never exposes
    // *why* it failed — only this action does.
    $mail_error = '';
    $capture_mail_error = function ($wp_error) use (&$mail_error) {
        $mail_error = $wp_error->get_error_message();
    };
    add_action('wp_mail_failed', $capture_mail_error);
    $sent = wp_mail($email, $subject, $html_message, pild_email_headers());
    remove_action('wp_mail_failed', $capture_mail_error);

    if (!$sent) {
        // BUGFIX: the pending-invite row above was being inserted
        // BEFORE this check and was never removed when the send failed,
        // so the invite existed in the DB while the manager was told the
        // whole action failed — a silent, orphaned row that also blocked
        // a clean retry (see the pending-invite guard added above). Roll
        // it back so "Failed to send email" actually means nothing was
        // created, and the manager can immediately try again.
        $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);

        // Surface the real reason when we have one (e.g. "SMTP Error:
        // could not connect to host") instead of the generic message —
        // this is almost always a server/SMTP configuration issue (no
        // outbound mail transport set up for wp_mail()), not something a
        // retry alone will fix. An SMTP plugin (WP Mail SMTP, FluentSMTP,
        // etc.) configured with real SMTP credentials resolves this.
        wp_send_json_error($mail_error ? "Failed to send email: {$mail_error}" : 'Failed to send email');
    }

    wp_send_json_success(['message' => "Invitation sent to {$email}", 'email' => $email]);
}

add_action('wp_ajax_pildcm_cancel_invite', 'pildcm_ajax_cancel_invite');
function pildcm_ajax_cancel_invite() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Unauthorized');

    $manager_id = get_current_user_id();
    $token      = sanitize_text_field($_POST['token'] ?? '');
    if (!$token) wp_send_json_error('Invalid token');

    global $wpdb;
    $invite = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_invites WHERE token=%s", $token
    ));
    if (!$invite) wp_send_json_error('Invitation not found');
    if ((int) $invite->manager_id !== (int) $manager_id) wp_send_json_error('Unauthorized');

    $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);
    wp_send_json_success('Invitation cancelled');
}

// PHASE 12: per-visitor cookie for the "pending invite, waiting on
// login/registration" leg of the invite-accept flow — see the FIX note at
// the call site above for why this replaced a global transient.
function pild_set_pending_invite_cookie($token) {
    setcookie('pild_invite_token', $token, [
        'expires'  => time() + 3600,
        'path'     => '/',
        'secure'   => is_ssl(),
        'httponly' => true,   // not needed by any JS, no reason to expose it
        'samesite' => 'Lax',  // survives the top-level redirect from the email link
    ]);
}
function pild_get_pending_invite_token() {
    return isset($_COOKIE['pild_invite_token']) ? sanitize_text_field($_COOKIE['pild_invite_token']) : '';
}
function pild_clear_pending_invite_cookie() {
    setcookie('pild_invite_token', '', time() - 3600, '/');
}

add_action('init', 'pildcm_handle_invite_accept');
function pildcm_handle_invite_accept() {
    if (empty($_GET['pildcm_invite'])) return;
    $token = sanitize_text_field($_GET['pildcm_invite']);

    global $wpdb;
    $invite = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_invites WHERE token=%s AND status='pending'", $token
    ));
    if (!$invite) return;
    if (strtotime($invite->expires_at) < time()) {
        $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);
        return;
    }
    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        if (strtolower($user->user_email) === strtolower($invite->email)) {
            pildcm_accept_team_invite($user->ID, (array) $invite);
            $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);
            wp_redirect(home_url('/?invite=accepted')); exit;
        }
    }
    // PHASE 12 FIX: this used to be set_transient('pildcm_pending_invite_token', ...)
    // — a WordPress transient is stored in ONE shared place site-wide
    // (wp_options), NOT per-visitor. If two people opened two different
    // invite links within the same hour (routine — a manager inviting
    // several employees at once), the second person's set_transient() call
    // overwrote the first person's, silently corrupting or dropping the
    // first person's invite. A cookie belongs to the one browser that
    // requested it, which is what this actually needs.
    pild_set_pending_invite_cookie($token);
    // Redirect to login/register page — after login, pildcm_after_login_invite handles acceptance
    wp_redirect(home_url('/my-account/')); exit;
}

add_action('wp_login', 'pildcm_after_login_invite', 10, 2);
function pildcm_after_login_invite($user_login, $user) {
    $token = pild_get_pending_invite_token();
    if (!$token) return;

    global $wpdb;
    $invite = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_invites WHERE token=%s AND status='pending'", $token
    ));
    if (!$invite) return;
    if (strtolower($user->user_email) === strtolower($invite->email)) {
        pildcm_accept_team_invite($user->ID, (array) $invite);
        $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);
        pild_clear_pending_invite_cookie();
        // Set redirect cookie so login_redirect filter picks it up
        setcookie('pildcm_invite_accepted', '1', time() + 60, '/');
    }
}

// Fix display_name on WooCommerce registration to use real name not username
// woocommerce_created_customer fires before meta is saved, so we hook later
add_action('woocommerce_created_customer', 'pildcm_fix_display_name_on_register', 99, 1);
function pildcm_fix_display_name_on_register($user_id) {
    // first_name/last_name come from POST at this point (not yet in usermeta)
    $first = sanitize_text_field($_POST['billing_first_name'] ?? $_POST['first_name'] ?? '');
    $last  = sanitize_text_field($_POST['billing_last_name']  ?? $_POST['last_name']  ?? '');
    $full  = trim("$first $last");
    if ($full) {
        update_user_meta($user_id, 'first_name', $first);
        update_user_meta($user_id, 'last_name',  $last);
        wp_update_user(['ID' => $user_id, 'display_name' => $full]);
    }

    // Accept pending invite if a token exists in the per-visitor cookie
    // (PHASE 12 FIX — see pildcm_after_login_invite() above for why this
    // isn't a transient any more).
    $token = pild_get_pending_invite_token();
    if (!$token) return;

    global $wpdb;
    $invite = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_invites WHERE token=%s AND status='pending'", $token
    ));
    if (!$invite) return;

    $new_user = get_userdata($user_id);
    if (!$new_user) return;

    if (strtolower($new_user->user_email) === strtolower($invite->email)) {
        pildcm_accept_team_invite($user_id, (array) $invite);
        $wpdb->delete($wpdb->prefix . 'pild_invites', ['token' => $token]);
        pild_clear_pending_invite_cookie();
        setcookie('pildcm_invite_accepted', '1', time() + 60, '/');
    }
}

// Fix display_name on standard WP registration
add_action('user_register', 'pildcm_fix_display_name_wp_register', 10, 1);
function pildcm_fix_display_name_wp_register($user_id) {
    $first = get_user_meta($user_id, 'first_name', true);
    $last  = get_user_meta($user_id, 'last_name',  true);
    $full  = trim("$first $last");
    if ($full) {
        wp_update_user(['ID' => $user_id, 'display_name' => $full]);
    }
}

function pildcm_accept_team_invite($user_id, $invite) {
    $manager_id = (int) ($invite['manager_id'] ?? 0);
    $user_id    = (int) $user_id;
    if (!$user_id) return;

    // PHASE 4: join every team the manager currently owns (new pild_teams
    // schema, includes/23-teams-core.php) — same intent as before ("a
    // manager who buys more tracks later doesn't need to re-invite anyone"),
    // but pild_team_add_member() now does a REAL seat check against the
    // exact same table used to count seats, so there's no separate "local
    // mirror" that can drift from the real membership — the bug class
    // described in the old FIX comment here can't happen anymore.
    $team_ids = [];
    if ($manager_id && function_exists('pild_get_owner_teams')) {
        foreach (pild_get_owner_teams($manager_id) as $team) $team_ids[] = (int) $team->id;
    }
    if (empty($team_ids) && !empty($invite['team_id'])) $team_ids[] = (int) $invite['team_id'];

    $joined_any = false;
    $primary_team_id = 0;
    foreach ($team_ids as $tid) {
        if (function_exists('pild_team_add_member') && pild_team_add_member($tid, $user_id, 'member')) {
            $joined_any = true;
            if (!$primary_team_id) $primary_team_id = $tid;
        }
    }

    global $wpdb;

    $manager = get_userdata($manager_id);
    $member  = get_userdata($user_id);
    if ($manager && $member) {
        $body = '<p>Great news — a new member just joined your team!</p>'
              . '<p><strong>' . esc_html($member->display_name) . '</strong> (' . esc_html($member->user_email) . ') has joined. 🎉</p>';
        wp_mail($manager->user_email, '✅ New team member joined — PILD', pild_email_html('New Team Member', $body), pild_email_headers());
    }
}

add_action('wp_ajax_pildcm_save_settings', 'pildcm_ajax_save_settings');
function pildcm_ajax_save_settings() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $user_id = get_current_user_id();

    $display_name = sanitize_text_field($_POST['display_name'] ?? '');
    $team_name    = sanitize_text_field($_POST['team_name']    ?? '');
    $company_name = sanitize_text_field($_POST['company_name'] ?? '');
    $phone        = sanitize_text_field($_POST['phone']        ?? '');
    $website      = esc_url_raw($_POST['website']              ?? '');
    $address      = sanitize_textarea_field($_POST['address']  ?? '');

    if ($display_name) wp_update_user(['ID' => $user_id, 'display_name' => $display_name]);
    if ($team_name)    update_user_meta($user_id, 'pild_team_name',    $team_name);
    if ($company_name) update_user_meta($user_id, 'pild_company_name', $company_name);
    if ($phone)        update_user_meta($user_id, 'pild_phone',        $phone);
    if ($website)      update_user_meta($user_id, 'pild_website',      $website);
    if ($address)      update_user_meta($user_id, 'pild_address',      $address);

    foreach (['avatar', 'company_logo'] as $field) {
        if (!empty($_FILES[$field]['name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $att_id = media_handle_upload($field, 0);
            if (!is_wp_error($att_id)) {
                update_user_meta($user_id, $field === 'avatar' ? 'pild_avatar_id' : 'pild_company_logo_id', $att_id);
                // Company logos are auto-normalized to a single standard size
                // (pildcm_company_logo_box()) so every uploaded logo — whatever
                // size it was — ends up consistent on certificates and reports.
                if ($field === 'company_logo') {
                    pildcm_normalize_company_logo($att_id);
                }
            }
        }
    }
    wp_send_json_success(['message' => 'Settings saved successfully.']);
}

add_action('wp_ajax_pildcm_save_member_settings', 'pildcm_ajax_save_member_settings');
function pildcm_ajax_save_member_settings() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $user_id = get_current_user_id();

    $display_name = sanitize_text_field($_POST['display_name'] ?? '');
    $phone        = sanitize_text_field($_POST['phone']        ?? '');
    $bio          = sanitize_textarea_field($_POST['bio']      ?? '');
    $job_title    = sanitize_text_field($_POST['job_title']    ?? '');
    $country      = sanitize_text_field($_POST['country']      ?? '');
    $profile_public = sanitize_text_field($_POST['profile_public'] ?? '');
    $profile_slug   = sanitize_title($_POST['profile_slug'] ?? '');

    // Validate the custom profile-link slug BEFORE saving anything else,
    // so the member gets one clear error instead of a half-saved form.
    if ($profile_slug && function_exists('pildcm_is_profile_slug_available')
        && !pildcm_is_profile_slug_available($profile_slug, $user_id)) {
        wp_send_json_error(['message' => 'That link is already taken. Please choose another.']);
    }

    if ($display_name) wp_update_user(['ID' => $user_id, 'display_name' => $display_name]);
    if ($phone)     update_user_meta($user_id, 'pild_phone',     $phone);
    if ($bio)       update_user_meta($user_id, 'pild_bio',       $bio);
    if ($job_title) update_user_meta($user_id, 'pild_job_title', $job_title);
    update_user_meta($user_id, 'pild_country', $country);
    update_user_meta($user_id, 'pild_profile_slug', $profile_slug);
    if ($profile_public !== '') update_user_meta($user_id, 'pild_profile_public', $profile_public === 'yes' ? 'yes' : 'no');

    if (!empty($_FILES['avatar']['name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $att_id = media_handle_upload('avatar', 0);
        if (!is_wp_error($att_id)) update_user_meta($user_id, 'pild_avatar_id', $att_id);
    }
    wp_send_json_success(['message' => 'Profile updated successfully.']);
}

// Track last login
add_action('wp_login', function($user_login, $user) {
    update_user_meta($user->ID, 'pild_last_login', current_time('mysql'));
}, 10, 2);

// ── Team Player badge — Case 1: team member joins a team ──
// PHASE 4: badge is now awarded centrally inside pild_team_add_member()
// (includes/23-teams-core.php) whenever anyone actually joins a team —
// covers invite-acceptance and any future join path in one place. The two
// hooks that used to sit here (wc_memberships_for_teams_team_member_added
// / _saved) were the WC Memberships for Teams extension's own action hooks
// and will never fire once that extension is deactivated, so they were
// removed rather than left as dead registrations. pildcm_team_member_badge()
// itself is kept below in case anything else still calls it directly.
function pildcm_team_member_badge($team, $user_membership, $member) {
    // $member can be a WP_User or a team member object
    $uid = 0;
    if ( is_object($member) && isset($member->ID) ) {
        $uid = (int) $member->ID;
    } elseif ( is_object($member) && method_exists($member, 'get_user_id') ) {
        $uid = (int) $member->get_user_id();
    } elseif ( is_numeric($member) ) {
        $uid = (int) $member;
    }
    if ( $uid ) pildcm_award_team_player_badge($uid);
}

// ── Team Player badge — Case 2: solo member purchases any package ──
add_action('wc_memberships_user_membership_created',        'pildcm_solo_membership_badge', 10, 1);
add_action('wc_memberships_user_membership_status_changed', 'pildcm_solo_membership_status_badge', 10, 3);
// Fallback: catch badge award after order payment is confirmed
add_action('woocommerce_payment_complete',       'pildcm_order_payment_membership_badge', 10, 1);
add_action('woocommerce_order_status_completed', 'pildcm_order_payment_membership_badge', 10, 1);
add_action('woocommerce_order_status_processing','pildcm_order_payment_membership_badge', 10, 1);

function pildcm_solo_membership_badge($user_membership) {
    if (!is_object($user_membership)) return;
    $user_id = method_exists($user_membership, 'get_user_id') ? (int) $user_membership->get_user_id() : 0;
    if (!$user_id) return;
    // Only award badge if membership is already active at creation time
    // (some gateways create membership as 'active' immediately)
    $status = method_exists($user_membership, 'get_status') ? $user_membership->get_status() : '';
    if ($status !== 'active') return;
    pildcm_award_team_player_badge($user_id);
}

function pildcm_solo_membership_status_badge($user_membership, $old_status, $new_status) {
    if ($new_status !== 'active') return;
    if (!is_object($user_membership)) return;
    $user_id = method_exists($user_membership, 'get_user_id') ? (int) $user_membership->get_user_id() : 0;
    if (!$user_id) return;
    pildcm_award_team_player_badge($user_id);
}

function pildcm_order_payment_membership_badge($order_id) {
    // After payment is confirmed, find any active memberships linked to this order and award badge
    if (!function_exists('wc_memberships_get_user_memberships')) return;
    $order = wc_get_order($order_id);
    if (!$order) return;
    $user_id = (int) $order->get_customer_id();
    if (!$user_id) return;
    $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
    if (empty($memberships)) return;
    pildcm_award_team_player_badge($user_id);
}

// ── Team Player badge — Case 3: plain registration ──────────────────
// Matches the "Any customer who registers ... becomes a member" rule used
// by pildcm_smart_login_redirect()/pildcm_myaccount_page_redirect() above:
// a brand-new account is a member from the moment it's created, not only
// once it joins a team or completes a purchase, so the badge (already
// awarded for both of those) should also fire right on registration.
// 'user_register' fires for both plain WP registration and WooCommerce's
// own wc_create_new_customer(), so this single hook covers both paths.
add_action('user_register', 'pildcm_registration_badge', 20, 1);
function pildcm_registration_badge($user_id) {
    pildcm_award_team_player_badge((int) $user_id);
}

function pildcm_award_team_player_badge($user_id) {
    global $wpdb;
    $already = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_badges WHERE user_id=%d AND badge_key='team_player' LIMIT 1",
        $user_id
    ));
    if (!$already) {
        $wpdb->insert("{$wpdb->prefix}pild_badges", [
            'user_id'   => $user_id,
            'badge_key' => 'team_player',
            'ref_id'    => 0,
            'earned_at' => current_time('mysql'),
        ]);
    }
}

// ============================================================
// SMART LOGIN REDIRECT
// Priority:
//   1. Team Manager (owns a team)                -> /company-dashboard/
//   2. Team Member  (member of team)              -> /member-dashboard/
//   3. Solo Membership OR any WooCommerce order
//      (free package, paid package, book, quiz)   -> /solo-dashboard/
// Any customer who registers or buys anything becomes a member and is
// routed to the unified Independent Member ("solo") Dashboard, which
// dynamically shows only what they actually have access to.
// ============================================================
add_filter('login_redirect', 'pildcm_smart_login_redirect', 20, 3);
function pildcm_smart_login_redirect($redirect_to, $requested_redirect_to, $user) {
    if (!($user instanceof WP_User) || is_wp_error($user)) {
        return $redirect_to;
    }
    // Admins / editors go to wp-admin as usual
    if (user_can($user, 'edit_posts')) {
        return $redirect_to;
    }

    // If invite was just accepted — go straight to member-dashboard
    if (isset($_COOKIE['pildcm_invite_accepted'])) {
        setcookie('pildcm_invite_accepted', '', time() - 3600, '/');
        return pild_dashboard_url('member-dashboard');
    }

    $user_id = $user->ID;

    global $wpdb;

    // 1. Manager: owns a team — check DB directly (most reliable)
    // PHASE 4: was wc_memberships_teams (WC Memberships for Teams extension) —
    // now the plugin's own pild_teams table (includes/23-teams-core.php),
    // same owner_id column, so this is a straight source swap.
    $is_owner = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_teams WHERE owner_id = %d LIMIT 1",
        $user_id
    ));
    if ($is_owner) {
        return pild_dashboard_url('company-dashboard');
    }

    // 2. Team Member: sits in pild_team_members with role='member'
    $in_team = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id=%d AND role='member' LIMIT 1",
        $user_id
    ));
    if ($in_team) {
        return pild_dashboard_url('member-dashboard');
    }

    // 3. Solo Membership: active WC Membership NOT linked to a team
    if (function_exists('wc_memberships_get_user_memberships')) {
        $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
        foreach ($memberships as $membership) {
            // Skip memberships that were granted via a team
            if (method_exists($membership, 'get_order') && $membership->get_order()) {
                $order = $membership->get_order();
                $is_team_order = false;
                if ($order) {
                    foreach ($order->get_items() as $item) {
                        $product_id = $item->get_product_id();
                        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $teams_table)) === $teams_table) {
                            // Check if any team was created from this order
                            $team_from_order = $wpdb->get_var($wpdb->prepare(
                                "SELECT id FROM `$teams_table` WHERE owner_id = %d LIMIT 1",
                                $user_id
                            ));
                            if ($team_from_order) { $is_team_order = true; break; }
                        }
                    }
                }
                if ($is_team_order) continue;
            }
            // This membership is individual — go to solo dashboard
            return pild_dashboard_url('solo-dashboard');
        }
    }

    // 4. WooCommerce customer: at least one completed/processing order
    //    (free package, paid package, book, or assessment) — becomes a
    //    member and goes to the unified solo dashboard.
    if (function_exists('wc_get_orders')) {
        $orders = wc_get_orders([
            'customer' => $user_id,
            'limit'    => 1,
            'status'   => ['completed', 'processing'],
        ]);
        if (!empty($orders)) {
            return pild_dashboard_url('solo-dashboard');
        }
    }

    // 5. Brand new account: no team, no membership, no order yet. Per the
    // rule documented above the top of this function — "Any customer who
    // registers ... becomes a member" — this must NOT fall through to WP's
    // default $redirect_to (wp-admin, or the plain WooCommerce My Account
    // page). pildcm_solo_dashboard_shortcode() already renders a sensible
    // empty state for exactly this case (defaults to the Badges tab), so
    // every fresh registrant lands on their own member dashboard immediately.
    return pild_dashboard_url('solo-dashboard');
}

// ============================================================
// MY-ACCOUNT PAGE REDIRECT (for direct visits / email links)
// Uses 'wp' hook — WP is fully loaded, user is known,
// but we redirect BEFORE WooCommerce renders the page.
// ============================================================
add_action('template_redirect', 'pildcm_myaccount_page_redirect', 5);
function pildcm_myaccount_page_redirect() {
    // Must be logged in
    if (!is_user_logged_in()) return;

    // Only act on /my-account/ root — not sub-endpoints
    // Check 1: WooCommerce native check (most reliable)
    $is_myaccount_root = false;
    if (function_exists('is_account_page')) {
        $is_myaccount_root = is_account_page();
        // Make sure it's the ROOT and not a sub-endpoint
        if ($is_myaccount_root && function_exists('WC') && isset(WC()->query)) {
            $endpoint = WC()->query->get_current_endpoint();
            if (!empty($endpoint)) $is_myaccount_root = false;
        }
    }
    // Check 2: Fallback via URL path. This site's URLs are never bare
    // "/my-account/" — every page sits under a fixed "/sa/" root, and the
    // Arabic version additionally sits under "/sa/ar/" (see the site's own
    // partner/certificates pages), so an EXACT match against '/my-account'
    // never matched anything and this fallback was effectively dead code.
    // On top of that, is_account_page() itself can return false here: with
    // Polylang, the Arabic and English "My Account" pages are two separate
    // WP pages/IDs, and WooCommerce's "myaccount_page_id" setting only ever
    // points at ONE of them — so whichever language ISN'T the one on file
    // is never recognized as the account page by WooCommerce's own check,
    // and Check 1 silently fails for that language. Matching on the path's
    // last segment instead of the whole path fixes both languages/prefixes
    // at once, regardless of which one WooCommerce's setting points to.
    if (!$is_myaccount_root) {
        $path = rtrim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
        if (substr($path, -11) === '/my-account') $is_myaccount_root = true;
    }
    // Check 3: the page actually renders the [woocommerce_my_account]
    // shortcode — catches any remaining case (a translated copy of the
    // page under a different slug, etc.) that Checks 1 and 2 both miss.
    if (!$is_myaccount_root) {
        global $post;
        if ($post instanceof WP_Post && has_shortcode($post->post_content, 'woocommerce_my_account')) {
            $is_myaccount_root = true;
        }
    }

    if (!$is_myaccount_root) return;

    // Sub-endpoints check — a bare query string (e.g. a language switcher
    // or tracking param) must not be mistaken for a real WC endpoint here.
    if (function_exists('WC') && isset(WC()->query) && !empty(WC()->query->get_current_endpoint())) return;

    $user    = wp_get_current_user();
    $user_id = $user->ID;

    // Admins stay on my-account
    if (user_can($user, 'edit_posts')) return;

    global $wpdb;

    // Suppress DB errors from other plugins during our queries
    $wpdb->suppress_errors(true);

    // 1. Manager
    // PHASE 4: was wc_memberships_teams — now pild_teams (includes/23-teams-core.php).
    $is_owner = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_teams WHERE owner_id = %d LIMIT 1",
        $user_id
    ));
    if ($is_owner) {
        $wpdb->suppress_errors(false);
        wp_safe_redirect(pild_dashboard_url('company-dashboard')); exit;
    }

    // 2. Team Member
    $in_team = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id = %d AND role = 'member' LIMIT 1",
        $user_id
    ));
    if ($in_team) {
        $wpdb->suppress_errors(false);
        wp_safe_redirect(pild_dashboard_url('member-dashboard')); exit;
    }

    // 3. Solo — has active WC membership and is NOT a team owner or member
    if (function_exists('wc_memberships_get_user_memberships')) {
        $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
        if (!empty($memberships)) {
            $wpdb->suppress_errors(false);
            wp_safe_redirect(pild_dashboard_url('solo-dashboard')); exit;
        }
    }

    // 4. WooCommerce customer — check both HPOS table and legacy posts table
    $has_order = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}wc_orders WHERE customer_id = %d AND status IN ('wc-completed','wc-processing') LIMIT 1",
        $user_id
    ));
    if (!$has_order) {
        // Legacy orders stored in wp_posts
        $has_order = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
             WHERE p.post_type = 'shop_order'
             AND p.post_status IN ('wc-completed','wc-processing')
             AND pm.meta_key = '_customer_user' AND pm.meta_value = %d
             LIMIT 1",
            $user_id
        ));
    }
    if (!$has_order && function_exists('wc_get_orders')) {
        $orders = wc_get_orders([
            'customer' => $user_id,
            'limit'    => 1,
            'status'   => ['completed', 'processing'],
        ]);
        $has_order = !empty($orders);
    }
    if ($has_order) {
        $wpdb->suppress_errors(false);
        wp_safe_redirect(pild_dashboard_url('solo-dashboard')); exit;
    }

    // No team / membership / order yet — still a brand-new registered
    // member, and shouldn't be stranded on the plain WooCommerce My Account
    // page. Same rule as pildcm_smart_login_redirect() above: route to the
    // unified solo dashboard, which renders a sensible empty state for a
    // fresh account (see pildcm_solo_dashboard_shortcode()'s $default_tab
    // fallback in includes/06-dashboard-solo.php).
    $wpdb->suppress_errors(false);
    wp_safe_redirect(pild_dashboard_url('solo-dashboard')); exit;
}

// ============================================================
// POST-PURCHASE REDIRECT — after checkout, send user to their dashboard
// Fires on the WooCommerce "Thank You" page for every order
// ============================================================
add_action('woocommerce_thankyou', 'pildcm_post_purchase_redirect', 5);
function pildcm_post_purchase_redirect($order_id) {
    if (!$order_id) return;
    if (!is_user_logged_in()) return;

    $user_id = get_current_user_id();
    global $wpdb;
    $wpdb->suppress_errors(true);

    // 1. Team Manager
    // PHASE 4: was wc_memberships_teams — now pild_teams.
    $is_owner = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_teams WHERE owner_id = %d LIMIT 1",
        $user_id
    ));
    if ($is_owner) {
        $wpdb->suppress_errors(false);
        wp_safe_redirect(pild_dashboard_url('company-dashboard')); exit;
    }

    // 2. Team Member
    $in_team = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id = %d AND role = 'member' LIMIT 1",
        $user_id
    ));
    if ($in_team) {
        $wpdb->suppress_errors(false);
        wp_safe_redirect(pild_dashboard_url('member-dashboard')); exit;
    }

    // 3. Solo — has active WC membership
    if (function_exists('wc_memberships_get_user_memberships')) {
        $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
        if (!empty($memberships)) {
            $wpdb->suppress_errors(false);
            wp_safe_redirect(pild_dashboard_url('solo-dashboard')); exit;
        }
    }

    // 4. Regular customer (purchased but membership record not visible yet) —
    //    still becomes a member and goes to the unified solo dashboard.
    $wpdb->suppress_errors(false);
    wp_safe_redirect(pild_dashboard_url('solo-dashboard')); exit;
}

// ============================================================
// EMAIL LINK REPLACEMENT
// Replace /my-account/members-area/... links in all emails
// with the correct dashboard URL per user type
// ============================================================

function pildcm_get_dashboard_url_for_user($user_id) {
    if (!$user_id) return home_url('/my-account/');
    global $wpdb;
    $wpdb->suppress_errors(true);

    // PHASE 4: was wc_memberships_teams — now pild_teams.
    $is_owner = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_teams WHERE owner_id = %d LIMIT 1",
        $user_id
    ));
    if ($is_owner) { $wpdb->suppress_errors(false); return pild_dashboard_url('company-dashboard'); }

    $in_team = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id = %d AND role = 'member' LIMIT 1",
        $user_id
    ));
    if ($in_team) { $wpdb->suppress_errors(false); return pild_dashboard_url('member-dashboard'); }

    if (function_exists('wc_memberships_get_user_memberships')) {
        $memberships = wc_memberships_get_user_memberships($user_id, ['status' => 'active']);
        if (!empty($memberships)) { $wpdb->suppress_errors(false); return pild_dashboard_url('solo-dashboard'); }
    }

    // Any customer with at least one order also becomes a member —
    // route to the unified solo dashboard instead of the removed
    // standalone customer dashboard.
    if (function_exists('wc_get_orders')) {
        $orders = wc_get_orders(['customer' => $user_id, 'limit' => 1, 'status' => ['completed', 'processing']]);
        if (!empty($orders)) { $wpdb->suppress_errors(false); return pild_dashboard_url('solo-dashboard'); }
    }

    // Same fallback as pildcm_smart_login_redirect()/pildcm_myaccount_page_redirect()
    // above: a registered-but-otherwise-empty account still gets its member
    // dashboard, not the plain My Account page.
    $wpdb->suppress_errors(false);
    return pild_dashboard_url('solo-dashboard');
}

// WC Memberships: "View my membership" URL in activation email
add_filter('wc_memberships_my_membership_content_access_url', 'pildcm_replace_membership_email_url', 10, 2);
function pildcm_replace_membership_email_url($url, $user_membership) {
    $user_id = is_object($user_membership) && method_exists($user_membership, 'get_user_id')
        ? (int) $user_membership->get_user_id() : 0;
    return pildcm_get_dashboard_url_for_user($user_id);
}

// WC Memberships: members area URL used in emails/account links
add_filter('wc_memberships_get_members_area_url', 'pildcm_replace_members_area_url', 10, 3);
function pildcm_replace_members_area_url($url, $membership_plan, $user_id) {
    return pildcm_get_dashboard_url_for_user((int) $user_id);
}

// Override button URL in "Membership Activated" email actions
add_filter('wc_memberships_email_membership_activated_actions', 'pildcm_override_activated_email_button', 10, 2);
function pildcm_override_activated_email_button($actions, $user_membership) {
    if (!is_array($actions)) return $actions;
    $user_id = is_object($user_membership) && method_exists($user_membership, 'get_user_id')
        ? (int) $user_membership->get_user_id() : 0;
    $dashboard_url = pildcm_get_dashboard_url_for_user($user_id);
    foreach ($actions as &$action) {
        if (isset($action['url'])) $action['url'] = $dashboard_url;
    }
    return $actions;
}

// Catch-all: strip any remaining /my-account/members-area/ links from email body text
add_filter('woocommerce_email_additional_content_customer_completed_order',  'pildcm_rewrite_email_body_links', 99);
add_filter('woocommerce_email_additional_content_customer_processing_order', 'pildcm_rewrite_email_body_links', 99);
add_filter('wc_memberships_email_content',                                   'pildcm_rewrite_email_body_links', 99);
function pildcm_rewrite_email_body_links($content) {
    if (!is_string($content)) return $content;
    return preg_replace(
        '#https?://[^/]*/my-account/members-area/[^\s"\'<>]*#i',
        home_url('/my-account/'),
        $content
    );
}