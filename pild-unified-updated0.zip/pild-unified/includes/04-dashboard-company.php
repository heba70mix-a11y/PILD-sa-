<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 15. SHORTCODE — [pild_company_dashboard] (MANAGER)
// ============================================================
add_shortcode('pild_company_dashboard', 'pildcm_company_dashboard_shortcode');
function pildcm_company_dashboard_shortcode() {
    if (!is_user_logged_in()) {
        return '<div style="text-align:center;padding:4rem;"><p>' . sprintf( __( 'Please %1$slog in%2$s to access your dashboard.', 'pild-unified' ), '<a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">', '</a>' ) . '</p></div>';
    }

    $manager_id   = get_current_user_id();
    $manager      = wp_get_current_user();
    $company_name = get_user_meta($manager_id, 'pild_company_name', true) ?: $manager->display_name;
    $team_name    = get_user_meta($manager_id, 'pild_team_name',    true) ?: __('My Team', 'pild-unified');
    $phone        = get_user_meta($manager_id, 'pild_phone',        true);
    $website      = get_user_meta($manager_id, 'pild_website',      true);
    $address      = get_user_meta($manager_id, 'pild_address',      true);
    $avatar_id    = get_user_meta($manager_id, 'pild_avatar_id',    true);
    $logo_id      = get_user_meta($manager_id, 'pild_company_logo_id', true);
    $avatar_url   = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
    $logo_url     = $logo_id   ? wp_get_attachment_image_url($logo_id,   'medium')    : '';
    $joined       = date_i18n('F Y', strtotime($manager->user_registered));
    $last_login   = get_user_meta($manager_id, 'pild_last_login', true);

    global $wpdb;
    $members = pildcm_get_team_members($manager_id);
    $tracks  = pildcm_get_manager_tracks($manager_id);

    // ── Detect Practice Areas vs plain Tracks ──────────────────────────────
    // For each track in the plan, read its ACF field 'track_domain' (a domain post ID).
    // If at least one track belongs to a domain, we group by Practice Area.
    $practice_areas = []; // [ domain_id => [ 'title'=>..., 'permalink'=>..., 'tracks'=>[tid=>track,...] ] ]
    $tracks_no_domain = []; // tracks that have NO domain assigned
    foreach ($tracks as $tid => $track) {
        $domain_id = function_exists('get_field') ? (int) get_field('track_domain', $tid) : 0;
        if ($domain_id) {
            if (!isset($practice_areas[$domain_id])) {
                $practice_areas[$domain_id] = [
                    'title'     => pild_bilingual_title($domain_id),
                    'permalink' => get_permalink($domain_id),
                    'tracks'    => [],
                ];
            }
            $practice_areas[$domain_id]['tracks'][$tid] = $track;
        } else {
            $tracks_no_domain[$tid] = $track;
        }
    }
    // Decide which tabs to show
    $has_practice_areas = !empty($practice_areas);
    $has_plain_tracks   = !empty($tracks_no_domain);

    $total_enrolled = 0;
    $total_complete = 0;
    if (!empty($members)) {
        $ids = implode(',', array_map('intval', array_keys($members)));
        $total_enrolled = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT user_id, track_id) FROM {$wpdb->prefix}pild_enrollments WHERE user_id IN ($ids) AND status='active'"
        );
        foreach ($members as $uid => $u) {
            foreach ($tracks as $tid => $t) {
                $prog = pildcm_get_track_progress($uid, $tid);
                if ($prog['pct'] >= 100) $total_complete++;
            }
        }
    }

    $total_certs = 0;
    foreach ($members as $uid => $u) {
        foreach ($tracks as $tid => $t) {
            if (pildcm_get_certificate_url($uid, $tid)) $total_certs++;
        }
    }

    wp_enqueue_script('pildcm-js', PILDCM_URL . 'assets/pildcm.js', ['jquery'], PILDCM_VERSION, true);
    wp_localize_script('pildcm-js', 'pildcm_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('pildcm_nonce'),
        'i18n'     => [
            'practice_areas'          => __( 'Practice Areas', 'pild-unified' ),
            'no_members_match'        => __( 'No members match %s filter.', 'pild-unified' ),
            'filter_active'           => __( 'Active', 'pild-unified' ),
            'filter_at_risk'          => __( 'At Risk', 'pild-unified' ),
            'filter_completed'        => __( 'Completed', 'pild-unified' ),
            'assign_short'            => __( '+ Assign', 'pild-unified' ),
            'remove'                  => __( 'Remove', 'pild-unified' ),
            'track_assigned'          => __( 'Track assigned successfully', 'pild-unified' ),
            'error'                   => __( 'Error', 'pild-unified' ),
            'network_error'           => __( 'Network error', 'pild-unified' ),
            'member_removed'          => __( 'Member removed from track', 'pild-unified' ),
            'all_already_assigned'    => __( 'All tracks already assigned', 'pild-unified' ),
            'confirm_assign_all'      => __( 'Assign all %d track(s) to this member?', 'pild-unified' ),
            'all_assigned'            => __( 'All tracks assigned!', 'pild-unified' ),
            'done_with_errors'        => __( 'Done — %d error(s)', 'pild-unified' ),
            'saving'                  => __( 'Saving…', 'pild-unified' ),
            'changes_saved'           => __( '✓ Changes saved successfully', 'pild-unified' ),
            'connection_failed'       => __( '✗ Connection failed', 'pild-unified' ),
            'confirm_remove_member'   => __( 'Remove this member from the track?', 'pild-unified' ),
            'sync_failed'             => __( 'Sync failed', 'pild-unified' ),
            'sync_team'               => __( 'Sync Team', 'pild-unified' ),
            'syncing'                 => __( '⏳ Syncing…', 'pild-unified' ),
            'enter_email'             => __( 'Please enter an email address', 'pild-unified' ),
            'sending'                 => __( 'Sending…', 'pild-unified' ),
            'error_occurred'          => __( 'An error occurred', 'pild-unified' ),
            'send_invitation'         => __( 'Send Invitation', 'pild-unified' ),
            'confirm_cancel_invite'   => __( 'Cancel this invitation?', 'pild-unified' ),
            'cancel'                  => __( 'Cancel', 'pild-unified' ),
        ],
    ]);

    ob_start();
    echo pildcm_css();
    ?>

    <div class="cm-wrap">

      <!-- ══════════════════════ HEADER BAR ══════════════════════ -->
      <div class="cm-header-bar">
        <div class="cm-header-brand">
          <?php if ($logo_url): ?>
            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($company_name); ?>" class="cm-header-logo">
          <?php else: ?>
            <div class="cm-header-logo-fallback"><?php echo esc_html(strtoupper(substr($company_name, 0, 2))); ?></div>
          <?php endif; ?>
          <div>
            <div class="cm-header-company"><?php echo esc_html($company_name); ?></div>
            <div class="cm-header-role"><?php esc_html_e( 'Manager Portal', 'pild-unified' ); ?></div>
          </div>
        </div>
        <div class="cm-header-actions">
          <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=pildcm_export_csv&nonce=' . wp_create_nonce('pildcm_nonce'))); ?>" class="cm-hdr-btn">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <?php esc_html_e( 'Export CSV', 'pild-unified' ); ?>
          </a>
          <button onclick="pildcmSyncTeam(this)" class="cm-hdr-btn">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
            <?php esc_html_e( 'Sync Team', 'pild-unified' ); ?>
          </button>
        </div>
      </div>

      <!-- ══════════════════════ HERO ══════════════════════ -->
      <div class="cm-hero">
        <div class="cm-hero-bg-orb cm-hero-bg-orb-1"></div>
        <div class="cm-hero-bg-orb cm-hero-bg-orb-2"></div>
        <div class="cm-hero-left">
          <div class="cm-hero-eyebrow"><?php esc_html_e( 'Development Dashboard', 'pild-unified' ); ?></div>
          <h1 class="cm-hero-title"><?php printf( esc_html__( 'Welcome back, %s', 'pild-unified' ), esc_html( explode( ' ', $manager->display_name )[0] ) ); ?></h1>
          <p class="cm-hero-sub"><?php esc_html_e( "Monitor your team's progress and manage learning assignments", 'pild-unified' ); ?></p>
        </div>
        <div class="cm-hero-kpis">
          <div class="cm-kpi">
            <div class="cm-kpi-num"><?php echo count($members); ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Team Members', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi">
            <div class="cm-kpi-num"><?php echo count($tracks); ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Development Tracks', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi">
            <div class="cm-kpi-num"><?php echo $total_enrolled; ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Access', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi">
            <div class="cm-kpi-num"><?php echo $total_certs; ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Professional Certificates', 'pild-unified' ); ?></div>
          </div>
        </div>
      </div>


      <!-- ══════════════════════ TABS ══════════════════════ -->
      <div class="cm-tabs-wrap">
        <div class="cm-tabs">
          <button class="cm-tab cm-tab-active" data-tab="overview">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            <?php esc_html_e( 'Overview', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="members">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            <?php esc_html_e( 'Team Members', 'pild-unified' ); ?>
          </button>
          <?php if ($has_plain_tracks): ?>
          <button class="cm-tab" data-tab="tracks">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
            <?php esc_html_e( 'Tracks', 'pild-unified' ); ?>
          </button>
          <?php endif; ?>
          <?php if ($has_practice_areas): ?>
          <div class="cm-tab-dropdown" id="cm-pa-dropdown">
            <button class="cm-tab cm-tab-dropdown-trigger" id="cm-pa-trigger" type="button">
              <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 000 20M12 2a14.5 14.5 0 010 20M2 12h20"/></svg>
              <span id="cm-pa-label"><?php esc_html_e( 'Practice Areas', 'pild-unified' ); ?></span>
              <svg class="cm-pa-chevron" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
            <div class="cm-tab-dropdown-menu" id="cm-pa-menu">
              <?php foreach ($practice_areas as $did => $da): ?>
              <button class="cm-tab-dropdown-item" data-tab="domain-<?php echo $did; ?>" type="button">
                <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
                <?php echo esc_html($da['title']); ?>
              </button>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
          <button class="cm-tab" data-tab="assign">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
            <?php esc_html_e( 'Assign Tracks', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="leaderboard">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            <?php esc_html_e( 'Leaderboard', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="articles">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
            <?php esc_html_e( 'Insights & Articles', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="profile">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <?php esc_html_e( 'Profile', 'pild-unified' ); ?>
          </button>
        </div>
      </div>

      <!-- ══════════════════════ TAB: OVERVIEW ══════════════════════ -->
      <div class="cm-panel cm-exec-dash" id="tab-overview">

        <?php
        // ── Compute all overview metrics ──────────────────────────────────
        $ov_total_members   = count($members);
        $ov_total_tracks    = count($tracks);
        $ov_total_enrolled  = 0;
        $ov_total_complete  = 0;
        $ov_total_certs_ov  = 0;
        $ov_at_risk         = 0;  // enrolled < 30% progress
        $ov_total_pct_sum   = 0;
        $ov_members_enrolled = 0;

        // Per-track breakdown for chart
        $ov_track_stats = [];
        foreach ($tracks as $tid => $track) {
            $t_enrolled = 0; $t_complete = 0; $t_pct_sum = 0;
            foreach ($members as $uid => $u) {
                if (pildcm_is_enrolled($uid, $tid)) {
                    $t_enrolled++;
                    $prog = pildcm_get_track_progress($uid, $tid);
                    $t_pct_sum += $prog['pct'];
                    if ($prog['pct'] >= 100) $t_complete++;
                }
                if (pildcm_get_certificate_url($uid, $tid)) $ov_total_certs_ov++;
            }
            $t_avg = $t_enrolled > 0 ? round($t_pct_sum / $t_enrolled) : 0;
            $ov_track_stats[$tid] = [
                'title'    => pild_bilingual_title($tid),
                'enrolled' => $t_enrolled,
                'complete' => $t_complete,
                'avg'      => $t_avg,
            ];
            $ov_total_enrolled += $t_enrolled;
            $ov_total_complete += $t_complete;
        }

        // Member-level metrics
        foreach ($members as $uid => $u) {
            $m_pct = 0; $m_enrolled = 0;
            foreach ($tracks as $tid => $t) {
                if (pildcm_is_enrolled($uid, $tid)) {
                    $m_enrolled++;
                    $prog = pildcm_get_track_progress($uid, $tid);
                    $m_pct += $prog['pct'];
                }
            }
            if ($m_enrolled > 0) {
                $ov_members_enrolled++;
                $avg = $m_pct / $m_enrolled;
                $ov_total_pct_sum += $avg;
                if ($avg < 30) $ov_at_risk++;
            }
        }
        $ov_overall_pct = $ov_members_enrolled > 0 ? round($ov_total_pct_sum / $ov_members_enrolled) : 0;

        // Recent activity (last logins)
        $ov_activity = [];
        foreach ($members as $uid => $u) {
            $ll = get_user_meta($uid, 'pild_last_login', true);
            if ($ll) $ov_activity[$uid] = ['name' => $u->display_name, 'time' => strtotime($ll), 'email' => $u->user_email];
        }
        usort($ov_activity, fn($a, $b) => $b['time'] - $a['time']);
        $ov_activity = array_slice($ov_activity, 0, 5);

        // Sort tracks by avg desc for breakdown
        uasort($ov_track_stats, fn($a, $b) => $b['avg'] - $a['avg']);
        $ov_top_tracks = array_slice($ov_track_stats, 0, 5, true);
        ?>

        <!-- ── KPI Strip ─────────────────────────────────────────── -->
        <div class="ed-kpi-strip">
          <div class="ed-kpi ed-kpi-teal">
            <div class="ed-kpi-accent"></div>
            <div class="ed-kpi-val"><?php echo $ov_total_members; ?></div>
            <div class="ed-kpi-delta ed-delta-up">
              <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M5 2l4 6H1z"/></svg>
              <?php esc_html_e( 'Active', 'pild-unified' ); ?>
            </div>
            <div class="ed-kpi-label"><?php esc_html_e( 'Team Members', 'pild-unified' ); ?></div>
          </div>
          <div class="ed-kpi ed-kpi-gold">
            <div class="ed-kpi-accent"></div>
            <div class="ed-kpi-val"><?php echo $ov_overall_pct; ?>%</div>
            <div class="ed-kpi-delta <?php echo $ov_overall_pct >= 60 ? 'ed-delta-up' : ($ov_overall_pct >= 35 ? 'ed-delta-mid' : 'ed-delta-dn'); ?>">
              <?php if ($ov_overall_pct >= 60): ?><svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M5 2l4 6H1z"/></svg><?php endif; ?>
              <?php echo $ov_overall_pct >= 60 ? esc_html__('On Track', 'pild-unified') : ($ov_overall_pct >= 35 ? esc_html__('In Progress', 'pild-unified') : esc_html__('Needs Attention', 'pild-unified')); ?>
            </div>
            <div class="ed-kpi-label"><?php esc_html_e( 'Avg Completion', 'pild-unified' ); ?></div>
          </div>
          <div class="ed-kpi ed-kpi-green">
            <div class="ed-kpi-accent"></div>
            <div class="ed-kpi-val"><?php echo $ov_total_certs_ov; ?></div>
            <div class="ed-kpi-delta ed-delta-up">
              <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor"><path d="M5 2l4 6H1z"/></svg>
              <?php esc_html_e( 'Earned', 'pild-unified' ); ?>
            </div>
            <div class="ed-kpi-label"><?php esc_html_e( 'Certificates', 'pild-unified' ); ?></div>
          </div>
          <div class="ed-kpi ed-kpi-red">
            <div class="ed-kpi-accent"></div>
            <div class="ed-kpi-val"><?php echo $ov_at_risk; ?></div>
            <div class="ed-kpi-delta <?php echo $ov_at_risk > 0 ? 'ed-delta-dn' : 'ed-delta-up'; ?>">
              <?php echo $ov_at_risk > 0 ? esc_html__('Needs Action', 'pild-unified') : esc_html__('All Clear', 'pild-unified'); ?>
            </div>
            <div class="ed-kpi-label"><?php esc_html_e( 'At Risk', 'pild-unified' ); ?></div>
          </div>
        </div>

        <!-- ── Middle Row ────────────────────────────────────────── -->
        <div class="ed-mid-row">

          <!-- Completion Trend: bar chart per track -->
          <div class="ed-panel ed-panel-chart">
            <div class="ed-panel-head">
              <span class="ed-panel-title"><?php esc_html_e( 'Track Completion Overview', 'pild-unified' ); ?></span>
              <span class="ed-panel-sub"><?php esc_html_e( 'Average progress per development track', 'pild-unified' ); ?></span>
            </div>
            <?php if (empty($ov_track_stats)): ?>
              <div class="cm-empty" style="padding:2rem 0"><?php esc_html_e( 'No tracks available yet.', 'pild-unified' ); ?></div>
            <?php else: ?>
            <div class="ed-bar-chart" id="ed-bar-chart">
              <?php foreach ($ov_track_stats as $tid => $ts):
                $bar_class = $ts['avg'] >= 80 ? 'ed-bar-high' : ($ts['avg'] >= 40 ? 'ed-bar-mid' : 'ed-bar-low');
                $short = mb_strtolower(mb_substr($ts['title'], 0, 14));
              ?>
              <div class="ed-bar-col">
                <div class="ed-bar-wrap">
                  <div class="ed-bar-pct"><?php echo $ts['avg']; ?>%</div>
                  <div class="ed-bar <?php echo $bar_class; ?>" style="height:<?php echo max(4, $ts['avg']); ?>%"
                       data-pct="<?php echo $ts['avg']; ?>"></div>
                </div>
                <div class="ed-bar-label"><?php echo esc_html($short); ?></div>
              </div>
              <?php endforeach; ?>
            </div>
            <div class="ed-chart-legend">
              <span class="ed-leg"><span class="ed-leg-dot ed-leg-high"></span><?php esc_html_e( '≥ 80%', 'pild-unified' ); ?></span>
              <span class="ed-leg"><span class="ed-leg-dot ed-leg-mid"></span><?php esc_html_e( '40–79%', 'pild-unified' ); ?></span>
              <span class="ed-leg"><span class="ed-leg-dot ed-leg-low"></span><?php esc_html_e( '< 40%', 'pild-unified' ); ?></span>
            </div>
            <?php endif; ?>
          </div>

          <!-- Track Breakdown -->
          <div class="ed-panel">
            <div class="ed-panel-head">
              <span class="ed-panel-title"><?php esc_html_e( 'Track Breakdown', 'pild-unified' ); ?></span>
              <span class="ed-panel-sub"><?php esc_html_e( 'Top tracks by average progress', 'pild-unified' ); ?></span>
            </div>
            <?php if (empty($ov_top_tracks)): ?>
              <div class="cm-empty"><?php esc_html_e( 'No track data yet.', 'pild-unified' ); ?></div>
            <?php else: ?>
            <div class="ed-breakdown-list">
              <?php foreach ($ov_top_tracks as $tid => $ts):
                $bar_cls = $ts['avg'] >= 80 ? 'ed-blf-high' : ($ts['avg'] >= 40 ? 'ed-blf-mid' : 'ed-blf-low');
                $pct_cls = $ts['avg'] >= 80 ? 'ed-pct-high' : ($ts['avg'] >= 40 ? 'ed-pct-mid' : 'ed-pct-low');
              ?>
              <div class="ed-bl-item">
                <div class="ed-bl-head">
                  <span class="ed-bl-name"><?php echo esc_html(mb_strtolower(mb_substr($ts['title'], 0, 28))); ?></span>
                  <span class="ed-bl-pct <?php echo $pct_cls; ?>"><?php echo $ts['avg']; ?>%</span>
                </div>
                <div class="ed-bl-meta">
                  <span><?php printf( esc_html__( '%d enrolled', 'pild-unified' ), $ts['enrolled'] ); ?></span>
                  <span class="ed-bl-sep">·</span>
                  <span><?php printf( esc_html__( '%d completed', 'pild-unified' ), $ts['complete'] ); ?></span>
                </div>
                <div class="ed-bl-bar">
                  <div class="ed-bl-fill <?php echo $bar_cls; ?>" style="width:0" data-w="<?php echo $ts['avg']; ?>%"></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

        </div><!-- /ed-mid-row -->

        <!-- ── Bottom Row ─────────────────────────────────────────── -->
        <div class="ed-bot-row">

          <!-- Recent Activity -->
          <div class="ed-panel">
            <div class="ed-panel-head">
              <span class="ed-panel-title"><?php esc_html_e( 'Recent Activity', 'pild-unified' ); ?></span>
              <span class="ed-panel-sub"><?php esc_html_e( 'Latest member logins', 'pild-unified' ); ?></span>
            </div>
            <?php if (empty($ov_activity)): ?>
              <div class="ed-empty-state"><?php esc_html_e( 'No recent activity to show.', 'pild-unified' ); ?></div>
            <?php else: ?>
            <div class="ed-activity-list">
              <?php foreach ($ov_activity as $act):
                $diff = time() - $act['time'];
                if ($diff < 3600)        $time_str = __('Just now', 'pild-unified');
                elseif ($diff < 86400)   $time_str = sprintf( __('%dh ago', 'pild-unified'), floor($diff/3600) );
                elseif ($diff < 604800)  $time_str = sprintf( __('%dd ago', 'pild-unified'), floor($diff/86400) );
                else                     $time_str = date_i18n('d M', $act['time']);
                $initials = strtoupper(mb_substr($act['name'], 0, 2));
                $h = crc32($act['email']) % 360;
              ?>
              <div class="ed-act-item">
                <div class="ed-act-av" style="background:hsl(<?php echo $h; ?>,40%,38%)"><?php echo esc_html($initials); ?></div>
                <div class="ed-act-body">
                  <div class="ed-act-name"><?php echo esc_html($act['name']); ?></div>
                  <div class="ed-act-detail"><?php esc_html_e( 'Logged in to their dashboard', 'pild-unified' ); ?></div>
                </div>
                <div class="ed-act-time"><?php echo esc_html($time_str); ?></div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- Alerts & Actions -->
          <div class="ed-panel">
            <div class="ed-panel-head">
              <span class="ed-panel-title"><?php esc_html_e( 'Priority Actions', 'pild-unified' ); ?></span>
              <span class="ed-panel-sub"><?php esc_html_e( 'Items requiring your attention', 'pild-unified' ); ?></span>
            </div>
            <div class="ed-alerts">

              <?php if ($ov_at_risk > 0): ?>
              <div class="ed-alert ed-alert-crit">
                <div class="ed-alert-icon">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <div class="ed-alert-body">
                  <div class="ed-alert-title"><?php printf( esc_html( _n( '%d member at risk', '%d members at risk', $ov_at_risk, 'pild-unified' ) ), $ov_at_risk ); ?></div>
                  <div class="ed-alert-desc"><?php esc_html_e( 'Progress below 30% — consider re-engagement or deadline adjustment.', 'pild-unified' ); ?></div>
                </div>
              </div>
              <?php endif; ?>

              <?php
              // Tracks with 0 completions but have enrolled members
              $no_complete_tracks = array_filter($ov_track_stats, fn($t) => $t['enrolled'] > 0 && $t['complete'] === 0);
              if (!empty($no_complete_tracks)):
              ?>
              <div class="ed-alert ed-alert-warn">
                <div class="ed-alert-icon">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                </div>
                <div class="ed-alert-body">
                  <div class="ed-alert-title"><?php printf( esc_html( _n( '%d track with no completions yet', '%d tracks with no completions yet', count($no_complete_tracks), 'pild-unified' ) ), count($no_complete_tracks) ); ?></div>
                  <div class="ed-alert-desc"><?php esc_html_e( 'Members are enrolled but no one has finished. Review content or deadlines.', 'pild-unified' ); ?></div>
                </div>
              </div>
              <?php endif; ?>

              <?php if ($ov_total_certs_ov > 0): ?>
              <div class="ed-alert ed-alert-info">
                <div class="ed-alert-icon">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <div class="ed-alert-body">
                  <div class="ed-alert-title"><?php printf( esc_html( _n( '%d certificate earned', '%d certificates earned', $ov_total_certs_ov, 'pild-unified' ) ), $ov_total_certs_ov ); ?></div>
                  <div class="ed-alert-desc"><?php esc_html_e( 'Your team is building verified credentials — export a report to share with stakeholders.', 'pild-unified' ); ?></div>
                </div>
              </div>
              <?php endif; ?>

              <?php if ($ov_at_risk === 0 && empty($no_complete_tracks) && $ov_total_certs_ov === 0): ?>
              <div class="ed-alert ed-alert-info">
                <div class="ed-alert-icon">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                </div>
                <div class="ed-alert-body">
                  <div class="ed-alert-title"><?php esc_html_e( 'No urgent actions right now', 'pild-unified' ); ?></div>
                  <div class="ed-alert-desc"><?php esc_html_e( 'Your team is progressing well. Check the Members tab for individual detail.', 'pild-unified' ); ?></div>
                </div>
              </div>
              <?php endif; ?>

              <!-- Track Summary Stats -->
              <div class="ed-summary-stats">
                <div class="ed-ss-item">
                  <div class="ed-ss-val"><?php echo $ov_total_tracks; ?></div>
                  <div class="ed-ss-lbl"><?php esc_html_e( 'Tracks Available', 'pild-unified' ); ?></div>
                </div>
                <div class="ed-ss-item">
                  <div class="ed-ss-val"><?php echo $ov_total_enrolled; ?></div>
                  <div class="ed-ss-lbl"><?php esc_html_e( 'Enrollments', 'pild-unified' ); ?></div>
                </div>
                <div class="ed-ss-item">
                  <div class="ed-ss-val"><?php echo $ov_total_complete; ?></div>
                  <div class="ed-ss-lbl"><?php esc_html_e( 'Completions', 'pild-unified' ); ?></div>
                </div>
              </div>

            </div><!-- /ed-alerts -->
          </div>

        </div><!-- /ed-bot-row -->

        <!-- ── Full Track Grid (collapsed by default) ─────────────── -->
        <div class="ed-tracks-section">
          <div class="ed-tracks-toggle" onclick="this.parentElement.classList.toggle('ed-tracks-open')">
            <span><?php esc_html_e( 'All Tracks Detail', 'pild-unified' ); ?></span>
            <svg class="ed-toggle-icon" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
          <div class="ed-tracks-body">
            <?php if (empty($tracks)): ?>
              <div class="cm-empty"><?php esc_html_e( "No tracks available in your membership plan.", 'pild-unified' ); ?></div>
            <?php else: ?>
            <div class="cm-track-grid">
              <?php foreach ($tracks as $tid => $track):
                  $enrolled_in_track = 0; $avg_pct = 0; $completed_count = 0;
                  foreach ($members as $uid => $u) {
                      if (pildcm_is_enrolled($uid, $tid)) {
                          $enrolled_in_track++;
                          $prog = pildcm_get_track_progress($uid, $tid);
                          $avg_pct += $prog['pct'];
                          if ($prog['pct'] >= 100) $completed_count++;
                      }
                  }
                  $avg_pct = $enrolled_in_track > 0 ? round($avg_pct / $enrolled_in_track) : 0;
                  $color_class = $avg_pct >= 80 ? 'prog-high' : ($avg_pct >= 40 ? 'prog-mid' : 'prog-low');
              ?>
              <div class="cm-track-card">
                <div class="cm-track-card-top">
                  <a href="<?php echo esc_url(get_permalink($tid)); ?>" class="cm-track-ext-link" target="_blank" title="<?php esc_attr_e( 'View track', 'pild-unified' ); ?>">
                    <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                  </a>
                </div>
                <h3 class="cm-track-card-title"><?php echo esc_html(pild_bilingual_title($tid)); ?></h3>
                <div class="cm-track-card-stats">
                  <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $enrolled_in_track; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Access', 'pild-unified' ); ?></div></div>
                  <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $completed_count; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></div></div>
                  <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $avg_pct; ?>%</div><div class="cm-tstat-l"><?php esc_html_e( 'Avg Progress', 'pild-unified' ); ?></div></div>
                </div>
                <div class="cm-track-prog-wrap">
                  <div class="cm-track-prog-bar <?php echo $color_class; ?>" style="width:<?php echo $avg_pct; ?>%"></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>

      </div><!-- /tab-overview -->

      <!-- ══════════════════════ TAB: MEMBERS ══════════════════════ -->
      <div class="cm-panel cm-panel-hidden" id="tab-members">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Team Members', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Detailed profiles, development maps and activity tracking for each team member', 'pild-unified' ); ?></div>
        </div>

        <!-- Invite Box -->
        <div class="cm-invite-box">
          <div class="cm-invite-box-left">
            <div class="cm-invite-box-title"><?php esc_html_e( 'Invite New Member', 'pild-unified' ); ?></div>
            <div class="cm-invite-box-sub"><?php esc_html_e( 'Send an email invitation to add someone to your team', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-invite-box-right">
            <input type="email" id="cm-invite-email" placeholder="colleague@company.com" class="cm-invite-input" />
            <button onclick="pildcmInviteMember(this)" class="cm-btn-primary">
              <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
              <?php esc_html_e( 'Send Invitation', 'pild-unified' ); ?>
            </button>
          </div>
          <div id="cm-invite-msg" class="cm-invite-msg"></div>
          <?php
          // PHASE 4: pending invites now come from the pild_invites table
          // (includes/23-teams-core.php) instead of the 'pildcm_pending_invites'
          // option — same display, different source.
          global $wpdb;
          $my_invites_rows = $wpdb->get_results($wpdb->prepare(
              "SELECT token, email, date_created, expires_at FROM {$wpdb->prefix}pild_invites
               WHERE manager_id = %d AND status = 'pending' ORDER BY date_created DESC",
              $manager_id
          ));
          if (!empty($my_invites_rows)): ?>
          <div class="cm-pending-invites">
            <div class="cm-pending-title"><?php esc_html_e( 'Pending Invitations', 'pild-unified' ); ?></div>
            <?php foreach ($my_invites_rows as $inv): $tok = $inv->token; ?>
            <div class="cm-pending-row" id="invite-row-<?php echo esc_attr($tok); ?>">
              <span class="cm-pending-email"><?php echo esc_html($inv->email); ?></span>
              <span class="cm-pending-date"><?php printf( esc_html__( 'Sent %s', 'pild-unified' ), esc_html( substr( $inv->date_created, 0, 10 ) ) ); ?></span>
              <span class="cm-pending-status <?php echo strtotime($inv->expires_at) < time() ? 'expired' : 'valid'; ?>">
                <?php echo strtotime($inv->expires_at) < time() ? esc_html__('Expired', 'pild-unified') : esc_html__('Valid', 'pild-unified'); ?>
              </span>
              <button onclick="pildcmCancelInvite('<?php echo esc_js($tok); ?>', this)" style="margin-left:auto;background:none;border:1px solid #EF4444;color:#EF4444;border-radius:6px;padding:.25rem .7rem;font-size:.75rem;cursor:pointer;"><?php esc_html_e( 'Cancel', 'pild-unified' ); ?></button>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- Search & Filter -->
        <div class="cm-members-filter-bar">
          <div class="cm-search-wrap">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" id="cm-member-search" placeholder="<?php esc_attr_e( 'Search members by name or email...', 'pild-unified' ); ?>" class="cm-search-input">
          </div>
          <div class="cm-filter-pills">
            <button class="cm-filter-pill cm-filter-pill-active" data-filter="all"><?php esc_html_e( 'All Members', 'pild-unified' ); ?></button>
            <button class="cm-filter-pill" data-filter="active"><?php esc_html_e( 'Active', 'pild-unified' ); ?></button>
            <button class="cm-filter-pill" data-filter="at-risk"><?php esc_html_e( 'At Risk', 'pild-unified' ); ?></button>
            <button class="cm-filter-pill" data-filter="completed"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></button>
          </div>
        </div>

        <?php if (empty($members)): ?>
          <div class="cm-empty"><?php esc_html_e( 'No team members found. Use the invite form above to add members.', 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-members-list" id="cm-members-list">
        <?php foreach ($members as $uid => $user):
            $user_points  = pildcm_get_user_points($uid);
            $user_badges  = pildcm_get_user_badges($uid);
            $badges_cfg   = pildcm_badges_config();
            $streak       = pildcm_get_streak($uid);
            $enrollments  = pildcm_get_user_enrollments($uid);
            $member_avatar = pildcm_get_member_avatar($uid);
            $member_phone  = get_user_meta($uid, 'pild_phone',     true);
            $member_bio    = get_user_meta($uid, 'pild_bio',       true);
            $member_title  = get_user_meta($uid, 'pild_job_title', true);
            $last_login    = get_user_meta($uid, 'pild_last_login', true);
            $member_joined = date_i18n('d M Y', strtotime($user->user_registered));
            $initial       = strtoupper(substr($user->display_name, 0, 1));

            // Last seen status
            $last_seen_label = __('Never', 'pild-unified');
            $last_seen_class = 'offline';
            if ($last_login) {
                $diff = time() - strtotime($last_login);
                if ($diff < 3600)        { $last_seen_label = __('Online now', 'pild-unified');    $last_seen_class = 'online'; }
                elseif ($diff < 86400)   { $last_seen_label = __('Today', 'pild-unified');         $last_seen_class = 'recent'; }
                elseif ($diff < 172800)  { $last_seen_label = __('Yesterday', 'pild-unified');     $last_seen_class = 'recent'; }
                elseif ($diff < 604800)  { $last_seen_label = sprintf( __('%dd ago', 'pild-unified'), floor($diff/86400) ); $last_seen_class = 'recent'; }
                elseif ($diff < 2592000) { $last_seen_label = sprintf( __('%dw ago', 'pild-unified'), floor($diff/604800) ); $last_seen_class = 'away'; }
                else                     { $last_seen_label = __('30d+ ago', 'pild-unified');       $last_seen_class = 'offline'; }
            }

            // Calc total progress across enrolled tracks
            $total_pct = 0; $enrolled_count = 0; $member_certs = [];
            foreach ($tracks as $tid => $t) {
                if (pildcm_is_enrolled($uid, $tid)) {
                    $enrolled_count++;
                    $prog = pildcm_get_track_progress($uid, $tid);
                    $total_pct += $prog['pct'];
                    $cert_url = pildcm_get_certificate_url($uid, $tid);
                    if ($cert_url) $member_certs[$tid] = ['title' => pild_bilingual_title($tid), 'url' => $cert_url];
                }
            }
            $avg_progress = $enrolled_count > 0 ? round($total_pct / $enrolled_count) : 0;

            // Data attributes for filter/search
            // Active = has at least one enrolled track and progress < 100%
            $data_active    = ($enrolled_count > 0 && $avg_progress < 100) ? 'true' : 'false';
            // At Risk = enrolled but progress below 30%
            $data_atrisk    = ($enrolled_count > 0 && $avg_progress < 30) ? 'true' : 'false';
            // Completed = all enrolled tracks at 100%
            $data_completed = ($enrolled_count > 0 && $avg_progress >= 100) ? 'true' : 'false';
        ?>
        <div class="cm-member-card"
             data-name="<?php echo esc_attr(strtolower($user->display_name . ' ' . $user->user_email)); ?>"
             data-active="<?php echo $data_active; ?>"
             data-atrisk="<?php echo $data_atrisk; ?>"
             data-completed="<?php echo $data_completed; ?>">

          <!-- Card Header -->
          <div class="cm-mc-header">
            <div class="cm-mc-avatar-wrap">
              <?php if ($member_avatar): ?>
                <img src="<?php echo esc_url($member_avatar); ?>" alt="<?php echo esc_attr($user->display_name); ?>" class="cm-mc-avatar-img">
              <?php else: ?>
                <div class="cm-mc-avatar-fallback"><?php echo esc_html($initial); ?></div>
              <?php endif; ?>
              <span class="cm-mc-status cm-status-<?php echo $last_seen_class; ?>" title="<?php echo esc_attr($last_seen_label); ?>"></span>
            </div>

            <div class="cm-mc-identity">
              <div class="cm-mc-name"><?php echo esc_html($user->display_name); ?></div>
              <?php if ($member_title): ?>
                <div class="cm-mc-title"><?php echo esc_html($member_title); ?></div>
              <?php endif; ?>
              <div class="cm-mc-email"><?php echo esc_html($user->user_email); ?></div>
              <?php if ($member_phone): ?>
                <div class="cm-mc-phone"><?php echo esc_html($member_phone); ?></div>
              <?php endif; ?>
            </div>

            <div class="cm-mc-meta">
              <div class="cm-mc-last-seen cm-seen-<?php echo $last_seen_class; ?>">
                <svg width="10" height="10" fill="currentColor" viewBox="0 0 10 10"><circle cx="5" cy="5" r="5"/></svg>
                <?php echo esc_html($last_seen_label); ?>
              </div>
              <div class="cm-mc-joined"><?php printf( esc_html__( 'Joined %s', 'pild-unified' ), esc_html( $member_joined ) ); ?></div>
            </div>
          </div>

          <!-- Stats Row -->
          <div class="cm-mc-stats-row">
            <div class="cm-mc-stat">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span><?php printf( esc_html__( '%s pts', 'pild-unified' ), number_format( $user_points ) ); ?></span>
            </div>
            <div class="cm-mc-stat">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>
              <span><?php printf( esc_html__( '%dd streak', 'pild-unified' ), $streak ); ?></span>
            </div>
            <div class="cm-mc-stat">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
              <span><?php printf( esc_html__( '%d badges', 'pild-unified' ), count( $user_badges ) ); ?></span>
            </div>
            <div class="cm-mc-stat">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
              <span><?php printf( esc_html__( '%d tracks', 'pild-unified' ), $enrolled_count ); ?></span>
            </div>
            <div class="cm-mc-stat">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              <span><?php printf( esc_html__( '%d certs', 'pild-unified' ), count( $member_certs ) ); ?></span>
            </div>
          </div>

          <?php if ($member_bio): ?>
          <div class="cm-mc-bio"><?php echo esc_html($member_bio); ?></div>
          <?php endif; ?>

          <!-- Achievement Badges -->
          <?php if (!empty($user_badges)): ?>
          <div class="cm-mc-badges">
            <?php foreach ($user_badges as $b):
                $cfg = $badges_cfg[$b->badge_key] ?? null;
                if (!$cfg) continue;
            ?>
            <span class="cm-mc-badge" title="<?php echo esc_attr($cfg['label'] . ': ' . $cfg['desc']); ?>">
              <?php echo $cfg['icon']; ?> <?php echo esc_html($cfg['label']); ?>
            </span>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <!-- Learning Map -->
          <div class="cm-mc-section-label"><?php esc_html_e( 'Learning Map', 'pild-unified' ); ?></div>
          <div class="cm-mc-tracks">
            <?php
            $has_enrollment = false;
            foreach ($tracks as $tid => $track):
                if (!pildcm_is_enrolled($uid, $tid)) continue;
                $has_enrollment = true;
                $prog    = pildcm_get_track_progress($uid, $tid);
                $enrow   = get_from_db_pildcm_enrollment($uid, $tid);
                $dl      = $enrow ? $enrow->deadline : '';
                $is_over = $dl && strtotime($dl) < time() && $prog['pct'] < 100;
                $is_done = $prog['pct'] >= 100;
                $cert_url = pildcm_get_certificate_url($uid, $tid);
                $pct_class = $is_done ? 'done' : ($is_over ? 'overdue' : ($prog['pct'] > 50 ? 'good' : 'low'));
            ?>
            <div class="cm-mc-track-row">
              <div class="cm-mc-track-left">
                <div class="cm-mc-track-dot cm-dot-<?php echo $pct_class; ?>"></div>
                <div class="cm-mc-track-info">
                  <div class="cm-mc-track-name"><?php echo esc_html(pild_bilingual_title($tid)); ?></div>
                  <div class="cm-mc-track-meta-row">
                    <span><?php printf( esc_html__( '%1$d/%2$d Playbooks', 'pild-unified' ), $prog['done'], $prog['total'] ); ?></span>
                    <?php if ($dl): ?>
                      <span class="cm-mc-deadline <?php echo $is_over ? 'overdue' : ''; ?>">
                        <?php echo $is_over ? '⚠ ' . esc_html__('Overdue:', 'pild-unified') : esc_html__('Due:', 'pild-unified'); ?> <?php echo esc_html($dl); ?>
                      </span>
                    <?php endif; ?>
                    <?php if ($cert_url): ?>
                      <a href="<?php echo esc_url($cert_url); ?>" class="cm-cert-link" target="_blank">
                        <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
                        <?php esc_html_e( 'View Certificate', 'pild-unified' ); ?>
                      </a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="cm-mc-track-right">
                <span class="cm-mc-pct-label <?php echo $pct_class; ?>"><?php echo $prog['pct']; ?>%</span>
                <div class="cm-mc-prog-wrap">
                  <div class="cm-mc-prog-bar cm-mbar-<?php echo $pct_class; ?>" style="width:<?php echo $prog['pct']; ?>%"></div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
            <?php if (!$has_enrollment): ?>
              <div class="cm-mc-no-tracks"><?php esc_html_e( 'No tracks assigned yet', 'pild-unified' ); ?></div>
            <?php endif; ?>
          </div>

          <!-- Activity Timeline (last 30 days) -->
          <?php
          global $wpdb;
          $activity = $wpdb->get_results($wpdb->prepare(
              "SELECT DATE(completed_at) as day, COUNT(*) as count
               FROM {$wpdb->prefix}pild_progress
               WHERE user_id=%d AND completed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
               GROUP BY day ORDER BY day ASC",
              $uid
          ));
          if (!empty($activity)):
              $act_map = [];
              foreach ($activity as $a) $act_map[$a->day] = (int) $a->count;
              $max_count = max(array_values($act_map));
          ?>
          <div class="cm-mc-section-label" style="margin-top:1.25rem"><?php esc_html_e( 'Activity — Last 30 Days', 'pild-unified' ); ?></div>
          <div class="cm-activity-timeline">
            <?php for ($i = 29; $i >= 0; $i--):
                $day   = date('Y-m-d', strtotime("-{$i} days"));
                $count = $act_map[$day] ?? 0;
                $h_pct = $max_count > 0 ? round($count / $max_count * 100) : 0;
                $label = date('d M', strtotime($day));
                $bar_class = $count > 0 ? 'active' : '';
            ?>
            <div class="cm-act-bar-wrap" title="<?php printf( esc_attr( _n( '%1$s: %2$d Playbook', '%1$s: %2$d Playbooks', $count, 'pild-unified' ) ), $label, $count ); ?>">
              <div class="cm-act-bar <?php echo $bar_class; ?>" style="height:<?php echo max(4, $h_pct); ?>%"></div>
            </div>
            <?php endfor; ?>
          </div>
          <?php endif; ?>

          <!-- Professional Certificates Section -->
          <?php if (!empty($member_certs)): ?>
          <div class="cm-mc-section-label" style="margin-top:1.25rem"><?php esc_html_e( 'Professional Certificates Earned', 'pild-unified' ); ?></div>
          <div class="cm-mc-certs-row">
            <?php foreach ($member_certs as $tid => $cert): ?>
            <a href="<?php echo esc_url($cert['url']); ?>" class="cm-mc-cert-card" target="_blank">
              <div class="cm-mc-cert-icon">🏅</div>
              <div class="cm-mc-cert-title"><?php echo esc_html($cert['title']); ?></div>
              <div class="cm-mc-cert-action"><?php esc_html_e( 'View →', 'pild-unified' ); ?></div>
            </a>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

        </div><!-- /cm-member-card -->
        <?php endforeach; ?>
        </div><!-- /cm-members-list -->
        <?php endif; ?>
      </div><!-- /tab-members -->

      <!-- ============================================================ -->
      <!-- TAB: TRACKS (plain tracks not belonging to a Practice Area)  -->
      <!-- ============================================================ -->
      <?php if ($has_plain_tracks): ?>
      <div class="cm-panel cm-panel-hidden" id="tab-tracks">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Development Tracks', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Team-wide progress across your subscribed development tracks', 'pild-unified' ); ?></div>
        </div>
        <div class="cm-track-grid">
          <?php foreach ($tracks_no_domain as $tid => $track):
              $enrolled_in_track = 0; $avg_pct = 0; $completed_count = 0;
              foreach ($members as $uid => $u) {
                  if (pildcm_is_enrolled($uid, $tid)) {
                      $enrolled_in_track++;
                      $prog     = pildcm_get_track_progress($uid, $tid);
                      $avg_pct += $prog['pct'];
                      if ($prog['pct'] >= 100) $completed_count++;
                  }
              }
              $avg_pct = $enrolled_in_track > 0 ? round($avg_pct / $enrolled_in_track) : 0;
              $color_class = $avg_pct >= 80 ? 'prog-high' : ($avg_pct >= 40 ? 'prog-mid' : 'prog-low');
          ?>
          <div class="cm-track-card">
            <div class="cm-track-card-top">
              <a href="<?php echo esc_url(get_permalink($tid)); ?>" class="cm-track-ext-link" target="_blank" title="<?php esc_attr_e( 'View track', 'pild-unified' ); ?>">
                <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              </a>
            </div>
            <h3 class="cm-track-card-title"><?php echo esc_html(pild_bilingual_title($tid)); ?></h3>
            <div class="cm-track-card-stats">
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $enrolled_in_track; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Access', 'pild-unified' ); ?></div></div>
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $completed_count; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></div></div>
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $avg_pct; ?>%</div><div class="cm-tstat-l"><?php esc_html_e( 'Avg Progress', 'pild-unified' ); ?></div></div>
            </div>
            <div class="cm-track-prog-wrap">
              <div class="cm-track-prog-bar <?php echo $color_class; ?>" style="width:<?php echo $avg_pct; ?>%"></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div><!-- /tab-tracks -->
      <?php endif; ?>

      <!-- ============================================================ -->
      <!-- TAB: PRACTICE AREAS (one panel per domain)                   -->
      <!-- ============================================================ -->
      <?php foreach ($practice_areas as $did => $da): ?>
      <div class="cm-panel cm-panel-hidden" id="tab-domain-<?php echo $did; ?>">
        <div class="cm-panel-header">
          <div class="cm-panel-title">
            <?php echo esc_html($da['title']); ?>
            <a href="<?php echo esc_url($da['permalink']); ?>" class="cm-track-ext-link" target="_blank" title="<?php esc_attr_e( 'View Practice Area', 'pild-unified' ); ?>" style="margin-left:8px;vertical-align:middle;">
              <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            </a>
          </div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Team-wide progress across all tracks in this Practice Area', 'pild-unified' ); ?></div>
        </div>
        <?php if (empty($da['tracks'])): ?>
          <div class="cm-empty"><?php esc_html_e( 'No tracks found in this Practice Area.', 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-track-grid">
          <?php foreach ($da['tracks'] as $tid => $track):
              $enrolled_in_track = 0; $avg_pct = 0; $completed_count = 0;
              foreach ($members as $uid => $u) {
                  if (pildcm_is_enrolled($uid, $tid)) {
                      $enrolled_in_track++;
                      $prog     = pildcm_get_track_progress($uid, $tid);
                      $avg_pct += $prog['pct'];
                      if ($prog['pct'] >= 100) $completed_count++;
                  }
              }
              $avg_pct = $enrolled_in_track > 0 ? round($avg_pct / $enrolled_in_track) : 0;
              $color_class = $avg_pct >= 80 ? 'prog-high' : ($avg_pct >= 40 ? 'prog-mid' : 'prog-low');
          ?>
          <div class="cm-track-card">
            <div class="cm-track-card-top">
              <a href="<?php echo esc_url(get_permalink($tid)); ?>" class="cm-track-ext-link" target="_blank" title="<?php esc_attr_e( 'View track', 'pild-unified' ); ?>">
                <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              </a>
            </div>
            <h3 class="cm-track-card-title"><?php echo esc_html(pild_bilingual_title($tid)); ?></h3>
            <div class="cm-track-card-stats">
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $enrolled_in_track; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Access', 'pild-unified' ); ?></div></div>
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $completed_count; ?></div><div class="cm-tstat-l"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></div></div>
              <div class="cm-tstat"><div class="cm-tstat-n"><?php echo $avg_pct; ?>%</div><div class="cm-tstat-l"><?php esc_html_e( 'Avg Progress', 'pild-unified' ); ?></div></div>
            </div>
            <div class="cm-track-prog-wrap">
              <div class="cm-track-prog-bar <?php echo $color_class; ?>" style="width:<?php echo $avg_pct; ?>%"></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div><!-- /tab-domain-<?php echo $did; ?> -->
      <?php endforeach; ?>


      <!-- ══════════════════════ TAB: ASSIGN ══════════════════════ -->
      <div class="cm-panel cm-panel-hidden" id="tab-assign">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Assign Development Tracks', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Assign tracks to individual team members with optional deadlines', 'pild-unified' ); ?></div>
        </div>
        <?php if (empty($members)): ?>
          <div class="cm-empty"><?php esc_html_e( 'No team members found. Invite members first from the Team Members tab.', 'pild-unified' ); ?></div>
        <?php elseif (empty($tracks)): ?>
          <div class="cm-empty"><?php esc_html_e( "No tracks available in your membership plan.", 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-filter-bar">
          <div class="cm-filter-label-txt"><?php esc_html_e( 'Filter by track:', 'pild-unified' ); ?></div>
          <div class="cm-filter-tracks-row">
            <button class="cm-filter-pill cm-filter-pill-active" data-filter="all"><?php esc_html_e( 'All Tracks', 'pild-unified' ); ?></button>
            <?php foreach ($tracks as $tid => $track): ?>
            <button class="cm-filter-pill" data-filter="<?php echo $tid; ?>"><?php echo esc_html(pild_bilingual_title($tid)); ?></button>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="cm-assign-list">
          <?php foreach ($members as $uid => $user):
              if (!is_object($user) || empty($user->ID)) continue;
              $user_badges   = (array) pildcm_get_user_badges($uid);
              $user_points   = (int)   pildcm_get_user_points($uid);
              $enrolled_tids = [];
              foreach ($tracks as $tid => $t) { if (pildcm_is_enrolled($uid, $tid)) $enrolled_tids[] = (int)$tid; }
              $display_name  = !empty($user->display_name) ? $user->display_name : $user->user_login;
              $initial       = strtoupper(substr($display_name, 0, 1));
              $av            = pildcm_get_member_avatar($uid);
          ?>
          <div class="cm-assign-card">
            <div class="cm-assign-card-header">
              <div class="cm-assign-avatar">
                <?php if ($av): ?>
                  <img src="<?php echo esc_url($av); ?>" alt="<?php echo esc_attr($display_name); ?>">
                <?php else: ?><?php echo esc_html($initial); ?>
                <?php endif; ?>
              </div>
              <div class="cm-assign-member-info">
                <div class="cm-assign-name"><?php echo esc_html($display_name); ?></div>
                <div class="cm-assign-email"><?php echo esc_html($user->user_email); ?></div>
                <div class="cm-assign-meta">
                  <?php printf( esc_html__( '%s pts', 'pild-unified' ), $user_points ); ?> &middot;
                  <?php printf( esc_html__( '%d badges', 'pild-unified' ), count($user_badges) ); ?> &middot;
                  <?php printf( esc_html__( '%1$d/%2$d tracks', 'pild-unified' ), count($enrolled_tids), count($tracks) ); ?>
                </div>
              </div>
              <button class="cm-btn-assign-all" data-uid="<?php echo (int)$uid; ?>"><?php esc_html_e( 'Assign All', 'pild-unified' ); ?></button>
            </div>
            <div class="cm-assign-tracks-list">
              <?php foreach ($tracks as $tid => $track):
                  $tid         = (int) $tid;
                  $is_enrolled = in_array($tid, $enrolled_tids);
                  $prog        = null;
                  if ($is_enrolled) {
                      $prog    = pildcm_get_track_progress($uid, $tid);
                      $enrow   = get_from_db_pildcm_enrollment($uid, $tid);
                      $deadline = $enrow ? $enrow->deadline : '';
                  }
              ?>
              <div class="cm-assign-row <?php echo $is_enrolled ? 'assigned' : ''; ?>" data-track="<?php echo $tid; ?>">
                <div class="cm-assign-row-left">
                  <div class="cm-assign-track-n"><?php echo esc_html(pild_bilingual_title($tid)); ?></div>
                  <?php if ($is_enrolled && $prog): ?>
                    <div class="cm-assign-prog-mini">
                      <div class="cm-assign-prog-bar-mini" style="width:<?php echo $prog['pct']; ?>%"></div>
                    </div>
                    <div class="cm-assign-pct-txt"><?php printf( esc_html__( '%d%% complete', 'pild-unified' ), $prog['pct'] ); ?></div>
                    <?php if (!empty($deadline)): ?>
                      <span class="cm-assign-dl">📅 <?php echo esc_html($deadline); ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
                <div class="cm-assign-row-right">
                  <?php if ($is_enrolled): ?>
                    <a href="<?php echo esc_url(get_permalink($tid)); ?>" class="cm-btn-view" target="_blank">↗</a>
                    <button class="cm-btn-danger cm-unassign-btn" data-uid="<?php echo $uid; ?>" data-tid="<?php echo $tid; ?>"><?php esc_html_e( 'Remove', 'pild-unified' ); ?></button>
                  <?php else: ?>
                    <input type="date" class="cm-deadline-input" id="dl-<?php echo $uid; ?>-<?php echo $tid; ?>" min="<?php echo date('Y-m-d'); ?>" title="<?php esc_attr_e( 'Optional deadline', 'pild-unified' ); ?>">
                    <button class="cm-btn-assign cm-assign-btn" data-uid="<?php echo $uid; ?>" data-tid="<?php echo $tid; ?>">+ <?php esc_html_e( 'Assign', 'pild-unified' ); ?></button>
                  <?php endif; ?>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- ══════════════════════ TAB: LEADERBOARD ══════════════════════ -->
      <div class="cm-panel cm-panel-hidden" id="tab-leaderboard">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Achievement Board', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Ranking based on total development points earned', 'pild-unified' ); ?></div>
        </div>
        <?php if (empty($members)): ?>
          <div class="cm-empty"><?php esc_html_e( 'No team members yet.', 'pild-unified' ); ?></div>
        <?php else:
            $lb = [];
            foreach ($members as $uid => $user) {
                $pts         = pildcm_get_user_points($uid);
                $bdg         = count(pildcm_get_user_badges($uid));
                $stk         = pildcm_get_streak($uid);
                $done        = 0;
                foreach ($tracks as $tid => $t) {
                    $p = pildcm_get_track_progress($uid, $tid);
                    if ($p['pct'] >= 100) $done++;
                }
                $certs = 0;
                foreach ($tracks as $tid => $t) { if (pildcm_get_certificate_url($uid, $tid)) $certs++; }
                $lb[] = ['uid' => $uid, 'name' => $user->display_name, 'email' => $user->user_email,
                    'points' => $pts, 'badges' => $bdg, 'streak' => $stk, 'tracks_done' => $done, 'certs' => $certs];
            }
            usort($lb, fn($a, $b) => $b['points'] - $a['points']);
            $max_pts = !empty($lb) ? max(array_column($lb, 'points')) : 1;
        ?>
        <div class="cm-lb-wrap">
          <!-- Top 3 Podium -->
          <?php if (count($lb) >= 3): ?>
          <div class="cm-podium">
            <?php
            $podium_order = [1, 0, 2]; // Silver, Gold, Bronze
            $medals = ['🥇', '🥈', '🥉'];
            $podium_heights = ['130px', '160px', '110px'];
            foreach ($podium_order as $idx):
                if (!isset($lb[$idx])) continue;
                $r = $lb[$idx];
                $av = pildcm_get_member_avatar($r['uid']);
            ?>
            <div class="cm-podium-slot cm-podium-pos-<?php echo $idx; ?>">
              <div class="cm-podium-avatar-wrap">
                <?php if ($av): ?>
                  <img src="<?php echo esc_url($av); ?>" alt="" class="cm-podium-avatar">
                <?php else: ?>
                  <div class="cm-podium-avatar-fb"><?php echo esc_html(strtoupper(substr($r['name'],0,1))); ?></div>
                <?php endif; ?>
                <div class="cm-podium-medal"><?php echo $medals[$idx]; ?></div>
              </div>
              <div class="cm-podium-name"><?php echo esc_html(explode(' ', $r['name'])[0]); ?></div>
              <div class="cm-podium-pts"><?php printf( esc_html__( '%s pts', 'pild-unified' ), number_format( $r['points'] ) ); ?></div>
              <div class="cm-podium-block" style="height:<?php echo $podium_heights[$idx]; ?>">
                <span class="cm-podium-rank">#<?php echo $idx + 1; ?></span>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <!-- Full Table -->
          <div class="cm-lb-table">
            <div class="cm-lb-thead">
              <span><?php esc_html_e( 'Rank', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Member', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Streak', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Completed', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Professional Certificates', 'pild-unified' ); ?></span>
              <span><?php esc_html_e( 'Progress', 'pild-unified' ); ?></span>
            </div>
            <?php foreach ($lb as $rank => $row):
                $medal = $rank === 0 ? '🥇' : ($rank === 1 ? '🥈' : ($rank === 2 ? '🥉' : ''));
                $av    = pildcm_get_member_avatar($row['uid']);
                $pct   = $max_pts > 0 ? round($row['points'] / $max_pts * 100) : 0;
            ?>
            <div class="cm-lb-row <?php echo $rank < 3 ? 'cm-lb-podium-row' : ''; ?>">
              <span class="cm-lb-rank"><?php echo $medal ?: '#' . ($rank + 1); ?></span>
              <span class="cm-lb-member">
                <div class="cm-lb-avatar">
                  <?php if ($av): ?>
                    <img src="<?php echo esc_url($av); ?>" alt="">
                  <?php else: ?><?php echo esc_html(strtoupper(substr($row['name'],0,1))); ?>
                  <?php endif; ?>
                </div>
                <div>
                  <div class="cm-lb-name"><?php echo esc_html($row['name']); ?></div>
                  <div class="cm-lb-email"><?php echo esc_html($row['email']); ?></div>
                </div>
              </span>
              <span class="cm-lb-pts-cell">
                <span class="cm-lb-pts-val"><?php echo number_format($row['points']); ?></span>
                <div class="cm-lb-pts-bar"><div style="width:<?php echo $pct; ?>%"></div></div>
              </span>
              <span>🔥 <?php echo $row['streak']; ?>d</span>
              <span>🏅 <?php echo $row['badges']; ?></span>
              <span>🏁 <?php echo $row['tracks_done']; ?></span>
              <span><?php echo $row['certs'] > 0 ? '🎓 ' . $row['certs'] : '—'; ?></span>
              <span class="cm-lb-prog-cell">
                <div class="cm-lb-prog-bar"><div style="width:<?php echo $pct; ?>%"></div></div>
              </span>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- ══════════════════════ TAB: PROFILE (Settings + Billing + Logout) ══════════════════════ -->
      <div class="cm-panel cm-panel-hidden" id="tab-profile">

        <!-- ── SECTION: Personal & Organization Settings ── -->
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Profile & Account', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Manage your personal profile, organization details, billing, and account', 'pild-unified' ); ?></div>
        </div>

      <!-- ══════════════════════ INFO CARDS ROW ══════════════════════ -->
      <div class="cm-info-cards-row">

        <!-- Company Card -->
        <div class="cm-info-card cm-company-card">
          <div class="cm-info-card-header">
            <div class="cm-info-card-icon cm-icon-teal">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </div>
            <div class="cm-info-card-label"><?php esc_html_e( 'Organization', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-company-logo-wrap">
            <?php if ($logo_url): ?>
              <img src="<?php echo esc_url($logo_url); ?>" alt="logo" class="cm-company-logo-img">
            <?php else: ?>
              <div class="cm-company-logo-placeholder"><?php echo esc_html(strtoupper(substr($company_name, 0, 2))); ?></div>
            <?php endif; ?>
          </div>
          <div class="cm-info-card-name"><?php echo esc_html($company_name); ?></div>
          <?php if ($team_name): ?>
            <div class="cm-info-card-sub">
              <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
              <?php echo esc_html($team_name); ?>
            </div>
          <?php endif; ?>
          <div class="cm-info-card-details">
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <span><?php echo esc_html($manager->user_email); ?></span>
            </div>
            <?php if ($phone): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .82h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.92z"/></svg>
              <span><?php echo esc_html($phone); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($website): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
              <a href="<?php echo esc_url($website); ?>" target="_blank"><?php echo esc_html($website); ?></a>
            </div>
            <?php endif; ?>
            <?php if ($address): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span><?php echo esc_html($address); ?></span>
            </div>
            <?php endif; ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <span><?php printf( esc_html__( 'Member since %s', 'pild-unified' ), esc_html( $joined ) ); ?></span>
            </div>
          </div>
        </div>

        <!-- Manager Personal Card -->
        <div class="cm-info-card cm-personal-card">
          <div class="cm-info-card-header">
            <div class="cm-info-card-icon cm-icon-gold">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <div class="cm-info-card-label"><?php esc_html_e( 'Manager Profile', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-personal-avatar-wrap">
            <?php if ($avatar_url): ?>
              <img src="<?php echo esc_url($avatar_url); ?>" alt="avatar" class="cm-personal-avatar">
            <?php else: ?>
              <div class="cm-personal-avatar-fallback"><?php echo esc_html(strtoupper(substr($manager->display_name, 0, 2))); ?></div>
            <?php endif; ?>
            <div class="cm-personal-avatar-badge">
              <svg width="10" height="10" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
            </div>
          </div>
          <div class="cm-info-card-name"><?php echo esc_html($manager->display_name); ?></div>
          <div class="cm-info-card-sub"><?php esc_html_e( 'Team Manager', 'pild-unified' ); ?></div>
          <div class="cm-info-card-details">
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <span><?php echo esc_html($manager->user_email); ?></span>
            </div>
            <?php if ($phone): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .82h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.92z"/></svg>
              <span><?php echo esc_html($phone); ?></span>
            </div>
            <?php endif; ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <span><?php printf( esc_html__( 'Joined %s', 'pild-unified' ), esc_html( $joined ) ); ?></span>
            </div>
            <?php if ($last_login): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <span><?php printf( esc_html__( 'Last login: %s', 'pild-unified' ), esc_html( date_i18n( 'd M Y, g:i a', strtotime( $last_login ) ) ) ); ?></span>
            </div>
            <?php endif; ?>
          </div>
          <div class="cm-personal-stats-row">
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo count($members); ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Members', 'pild-unified' ); ?></div>
            </div>
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo $total_complete; ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Completions', 'pild-unified' ); ?></div>
            </div>
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo $total_certs; ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Professional Certificates', 'pild-unified' ); ?></div>
            </div>
          </div>
        </div>

      </div><!-- /cm-info-cards-row -->

        <?php
        $uid          = get_current_user_id();
        $u            = wp_get_current_user();
        $s_team_name  = get_user_meta($uid, 'pild_team_name',    true);
        $s_company    = get_user_meta($uid, 'pild_company_name', true);
        $s_phone      = get_user_meta($uid, 'pild_phone',        true);
        $s_website    = get_user_meta($uid, 'pild_website',      true);
        $s_address    = get_user_meta($uid, 'pild_address',      true);
        $s_avatar_id  = get_user_meta($uid, 'pild_avatar_id',    true);
        $s_logo_id    = get_user_meta($uid, 'pild_company_logo_id', true);
        $s_avatar_url = $s_avatar_id ? wp_get_attachment_image_url($s_avatar_id, 'thumbnail') : '';
        $s_logo_url   = $s_logo_id   ? wp_get_attachment_image_url($s_logo_id, 'medium')      : '';
        ?>
        <div class="cm-settings-layout">

          <!-- Personal Profile -->
          <div class="cm-settings-section">
            <div class="cm-settings-section-title"><?php esc_html_e( 'Personal Profile', 'pild-unified' ); ?></div>
            <div class="cm-settings-avatar-row">
              <div class="cm-settings-avatar" id="avatar-preview">
                <?php if ($s_avatar_url): ?>
                  <img src="<?php echo esc_url($s_avatar_url); ?>" alt="avatar">
                <?php else: ?>
                  <span><?php echo strtoupper(substr($u->display_name, 0, 1)); ?></span>
                <?php endif; ?>
              </div>
              <div>
                <label class="cm-upload-btn">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  <?php esc_html_e( 'Upload Photo', 'pild-unified' ); ?>
                  <input type="file" id="pild-avatar-input" accept="image/*" style="display:none">
                </label>
                <p class="cm-upload-hint"><?php esc_html_e( 'PNG, JPG — max 2MB', 'pild-unified' ); ?></p>
              </div>
            </div>
            <div class="cm-settings-fields">
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Full Name', 'pild-unified' ); ?></label>
                <input type="text" id="pild-display-name" value="<?php echo esc_attr($u->display_name); ?>" placeholder="<?php esc_attr_e( 'Your full name', 'pild-unified' ); ?>">
              </div>
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Phone Number', 'pild-unified' ); ?></label>
                <input type="text" id="pild-phone" value="<?php echo esc_attr($s_phone); ?>" placeholder="+1 234 567 8900">
              </div>
            </div>
          </div>

          <!-- Organization Profile -->
          <div class="cm-settings-section">
            <div class="cm-settings-section-title"><?php esc_html_e( 'Organization Profile', 'pild-unified' ); ?></div>
            <div class="cm-settings-logo-area">
              <div class="cm-settings-logo-preview" id="logo-preview">
                <?php if ($s_logo_url): ?>
                  <img src="<?php echo esc_url($s_logo_url); ?>" alt="logo">
                <?php else: ?>
                  <div class="cm-logo-placeholder-icon">
                    <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                    <span><?php esc_html_e( 'No logo', 'pild-unified' ); ?></span>
                  </div>
                <?php endif; ?>
              </div>
              <label class="cm-upload-btn">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <?php esc_html_e( 'Upload Logo', 'pild-unified' ); ?>
                <input type="file" id="pild-logo-input" accept="image/*" style="display:none">
              </label>
              <p class="cm-upload-hint">
                <?php printf( esc_html__( 'Recommended %s.', 'pild-unified' ), esc_html( pildcm_company_logo_size_label() ) ); ?>
                <?php esc_html_e( "Any size works — it's automatically resized to fit, so your logo always looks consistent on certificates.", 'pild-unified' ); ?>
              </p>
            </div>
            <div class="cm-settings-fields">
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Organization Name', 'pild-unified' ); ?></label>
                <input type="text" id="pild-company-name" value="<?php echo esc_attr($s_company); ?>" placeholder="<?php esc_attr_e( 'e.g., Acme Corporation', 'pild-unified' ); ?>">
              </div>
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Team Name', 'pild-unified' ); ?></label>
                <input type="text" id="pild-team-name" value="<?php echo esc_attr($s_team_name); ?>" placeholder="<?php esc_attr_e( 'e.g., Development Team', 'pild-unified' ); ?>">
              </div>
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Website', 'pild-unified' ); ?></label>
                <input type="url" id="pild-website" value="<?php echo esc_attr($s_website); ?>" placeholder="https://yourcompany.com">
              </div>
              <div class="cm-settings-field cm-field-full">
                <label><?php esc_html_e( 'Address', 'pild-unified' ); ?></label>
                <input type="text" id="pild-address" value="<?php echo esc_attr($s_address); ?>" placeholder="<?php esc_attr_e( 'City, Country', 'pild-unified' ); ?>">
              </div>
            </div>
          </div>

          <div class="cm-settings-footer">
            <button class="cm-btn-primary cm-btn-save" id="pild-save-settings">
              <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
              <?php esc_html_e( 'Save Changes', 'pild-unified' ); ?>
            </button>
            <span id="pild-settings-msg"></span>
          </div>
        </div>

        <!-- ── SECTION: Billing ── -->
        <div style="margin-top:40px;">
          <div style="font-size:18px;font-weight:700;color:var(--cm-text);margin-bottom:4px;"><?php esc_html_e( 'Billing & Subscription', 'pild-unified' ); ?></div>
          <div style="font-size:13px;color:var(--cm-text-muted);margin-bottom:24px;"><?php esc_html_e( 'Your invoices and membership subscription details', 'pild-unified' ); ?></div>
          <?php
          $mgr_orders = wc_get_orders(['customer' => $manager_id, 'limit' => 20, 'orderby' => 'date', 'order' => 'DESC']);
          // PHASE 5: was wc_memberships_get_user_memberships() (WC Memberships
          // Plan data — plan name, status, end date). Now sourced directly from
          // this plugin's own pild_teams (includes/23-teams-core.php) — the last
          // place in the plugin that still read from the Memberships data model.
          // No Membership Plan is involved any more, so "plan status/expiry"
          // becomes "seats used / purchase date", which is what's actually true
          // of a one-time Team product purchase (no subscription/expiry concept
          // exists in this model — see note below if that's ever needed).
          $mgr_teams = function_exists('pild_get_owner_teams_current') ? pild_get_owner_teams_current($manager_id) : ( function_exists('pild_get_owner_teams') ? pild_get_owner_teams($manager_id) : [] );
          // Expired-by-date teams move to the read-only "Ended Teams"
          // section below instead of showing (with an "Expired" badge) in
          // this active-packages list — same data, clearer separation.
          $mgr_teams_expired = function_exists('pild_get_owner_teams_expired') ? pild_get_owner_teams_expired($manager_id) : [];
          ?>
          <?php if (!empty($mgr_teams)): ?>
          <div style="margin-bottom:24px;">
            <div style="font-size:13px;font-weight:600;color:var(--cm-text-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px;"><?php esc_html_e( 'Active Team Packages', 'pild-unified' ); ?></div>
            <?php foreach ($mgr_teams as $team):
              $seats_used = function_exists('pild_team_seats_used') ? pild_team_seats_used($team->id) : 0;
              $seats_total = (int) $team->seat_count;
              $purchased  = $team->date_created ? date_i18n('d M Y', strtotime($team->date_created)) : '—';
              $team_expires_at = $team->date_created ? strtotime($team->date_created . ' +1 year') : 0;
              // No longer branches on $is_expired here — $mgr_teams is
              // already filtered to non-expired teams (pild_get_owner_teams_current()).
              // Expired ones render in the "Ended Teams" section below instead.
              $sc = $seats_used < $seats_total ? '#10B981' : '#F59E0B';
              $status_label = $seats_used < $seats_total ? __('Active', 'pild-unified') : __('Full', 'pild-unified');
            ?>
            <div style="background:var(--cm-card-bg);border:1px solid var(--cm-border);border-radius:12px;padding:16px 20px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
              <div>
                <div style="font-weight:600;font-size:15px;color:var(--cm-text);"><?php echo esc_html($team->name); ?></div>
                <div style="font-size:12px;color:var(--cm-text-muted);margin-top:4px;">
                  <?php printf( esc_html__( 'Purchased: %s', 'pild-unified' ), esc_html( $purchased ) ); ?>
                  &nbsp;·&nbsp;
                  <?php printf( esc_html__( '%1$d / %2$d seats used', 'pild-unified' ), (int) $seats_used, (int) $seats_total ); ?>
                  &nbsp;·&nbsp;<?php printf( esc_html__( 'Access until %s', 'pild-unified' ), esc_html( date_i18n('d M Y', $team_expires_at) ) ); ?>
                </div>
              </div>
              <div style="display:flex;align-items:center;gap:12px;">
                <span style="font-size:12px;font-weight:600;color:<?php echo $sc; ?>;background:<?php echo $sc; ?>20;padding:4px 10px;border-radius:20px;text-transform:uppercase;"><?php echo esc_html($status_label); ?></span>
                <?php if ($team->product_id): ?>
                  <a href="<?php echo esc_url(get_permalink($team->product_id)); ?>" class="cm-btn-primary cm-btn-sm" style="font-size:12px;"><?php esc_html_e( 'Buy More Seats', 'pild-unified' ); ?></a>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <?php
          // ── Ended Teams (read-only history) ──────────────────────
          // Per client decision: an expired team is never silently
          // reactivated by a new purchase (a fresh purchase starts a new
          // team instead — see pild_team_find_active_by_owner_product() in
          // includes/23-teams-core.php), BUT its record and every member's
          // certificate/profile/CV must stay reachable indefinitely — the
          // manager (or the employee themselves) can come back to it any
          // time. This section is that permanent, read-only view.
          if (!empty($mgr_teams_expired)):
          ?>
          <div style="margin-bottom:24px;">
            <div style="font-size:13px;font-weight:600;color:var(--cm-text-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px;"><?php esc_html_e( 'Ended Teams', 'pild-unified' ); ?></div>
            <div style="font-size:12px;color:var(--cm-text-muted);margin-bottom:12px;"><?php esc_html_e( 'Access has ended for these — kept here so you can still find who was on each team and reach their certificates.', 'pild-unified' ); ?></div>
            <?php global $wpdb; foreach ($mgr_teams_expired as $team):
              $ended_at = $team->date_created ? date_i18n('d M Y', strtotime($team->date_created . ' +1 year')) : '—';
              $members  = $wpdb->get_results($wpdb->prepare(
                  "SELECT tm.user_id FROM {$wpdb->prefix}pild_team_members tm WHERE tm.team_id=%d AND tm.role='member' ORDER BY tm.id ASC",
                  $team->id
              ));
            ?>
            <div style="background:var(--cm-card-bg);border:1px solid var(--cm-border);border-radius:12px;padding:16px 20px;margin-bottom:10px;opacity:.85;">
              <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:<?php echo $members ? '10px' : '0'; ?>;">
                <div>
                  <div style="font-weight:600;font-size:15px;color:var(--cm-text);"><?php echo esc_html($team->name); ?></div>
                  <div style="font-size:12px;color:var(--cm-text-muted);margin-top:4px;"><?php printf( esc_html__( 'Ended: %s', 'pild-unified' ), esc_html($ended_at) ); ?> &nbsp;·&nbsp; <?php printf( esc_html__( '%d seats', 'pild-unified' ), (int) $team->seat_count ); ?></div>
                </div>
                <?php if ($team->product_id): ?>
                  <a href="<?php echo esc_url(get_permalink($team->product_id)); ?>" class="cm-btn-primary cm-btn-sm" style="font-size:12px;"><?php esc_html_e( 'Renew Access', 'pild-unified' ); ?></a>
                <?php endif; ?>
              </div>
              <?php if ($members): ?>
              <div style="display:flex;flex-wrap:wrap;gap:8px;">
                <?php foreach ($members as $m): $u = get_userdata($m->user_id); if (!$u) continue; ?>
                  <a href="<?php echo esc_url( function_exists('pildcm_get_public_profile_url') ? pildcm_get_public_profile_url($u->ID) : '#' ); ?>" target="_blank" rel="noopener" style="font-size:12px;padding:4px 10px;border-radius:20px;background:var(--cm-bg2,#f3f4f6);color:var(--cm-text);text-decoration:none;"><?php echo esc_html($u->display_name); ?> ↗</a>
                <?php endforeach; ?>
              </div>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div style="font-size:13px;font-weight:600;color:var(--cm-text-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px;"><?php esc_html_e( 'Invoices & Orders', 'pild-unified' ); ?></div>
          <?php if (empty($mgr_orders)): ?>
            <div class="cm-empty"><?php esc_html_e( 'No orders found.', 'pild-unified' ); ?></div>
          <?php else: ?>
          <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
              <thead><tr style="border-bottom:2px solid var(--cm-border);">
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Order #', 'pild-unified' ); ?></th>
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Date', 'pild-unified' ); ?></th>
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Items', 'pild-unified' ); ?></th>
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Total', 'pild-unified' ); ?></th>
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Status', 'pild-unified' ); ?></th>
                <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Invoice', 'pild-unified' ); ?></th>
              </tr></thead>
              <tbody>
              <?php foreach ($mgr_orders as $order):
                $smap = ['completed'=>'#10B981','processing'=>'#3B82F6','pending'=>'#F59E0B','cancelled'=>'#EF4444','refunded'=>'#6B7280'];
                $sc   = $smap[$order->get_status()] ?? '#6B7280';
                $items_list = implode(', ', array_map(fn($i) => $i->get_name(), $order->get_items()));
              ?>
                <tr style="border-bottom:1px solid var(--cm-border);">
                  <td style="padding:12px;font-weight:600;color:var(--cm-text);">#<?php echo $order->get_order_number(); ?></td>
                  <td style="padding:12px;color:var(--cm-text-muted);"><?php echo date_i18n('d M Y', strtotime($order->get_date_created())); ?></td>
                  <td style="padding:12px;color:var(--cm-text);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?php echo esc_attr($items_list); ?>"><?php echo esc_html($items_list); ?></td>
                  <td style="padding:12px;font-weight:600;color:var(--cm-text);"><?php echo $order->get_formatted_order_total(); ?></td>
                  <td style="padding:12px;"><span style="font-size:11px;font-weight:600;color:<?php echo $sc; ?>;background:<?php echo $sc; ?>20;padding:3px 8px;border-radius:20px;text-transform:uppercase;"><?php echo esc_html($order->get_status()); ?></span></td>
                  <td style="padding:12px;"><a href="<?php echo esc_url($order->get_view_order_url()); ?>" target="_blank" style="color:var(--cm-accent);font-size:12px;font-weight:600;text-decoration:none;"><?php esc_html_e( 'View →', 'pild-unified' ); ?></a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <?php endif; ?>
        </div>

        <!-- ── SECTION: Log Out ── -->
        <div style="margin-top:40px;padding-top:32px;border-top:1px solid var(--cm-border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
          <div>
            <div style="font-size:15px;font-weight:600;color:var(--cm-text);margin-bottom:4px;"><?php esc_html_e( 'Sign Out', 'pild-unified' ); ?></div>
            <div style="font-size:13px;color:var(--cm-text-muted);"><?php esc_html_e( "You'll be redirected to the home page", 'pild-unified' ); ?></div>
          </div>
          <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" style="display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:8px;background:var(--cm-danger,#EF4444);color:#fff;font-size:13px;font-weight:600;text-decoration:none;">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <?php esc_html_e( 'Log Out', 'pild-unified' ); ?>
          </a>
        </div>

      </div><!-- /tab-profile -->

      <!-- ══════════════════════ TAB: INSIGHTS & ARTICLES (MANAGER) ══════════════════════ -->
      <div class="cm-panel cm-panel-hidden" id="tab-articles">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Insights & Articles', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Exclusive articles and insights included in your membership plan', 'pild-unified' ); ?></div>
        </div>
        <?php
        $manager_articles = pildcm_get_member_articles($manager_id);
        if (empty($manager_articles)): ?>
          <div class="cm-empty"><?php esc_html_e( 'No articles are included in your current membership plan.', 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-articles-grid">
          <?php foreach ($manager_articles as $article):
            $thumb     = get_the_post_thumbnail_url($article->ID, 'medium');
            $excerpt   = wp_trim_words($article->post_excerpt ?: wp_strip_all_tags($article->post_content), 20);
            $date      = date_i18n('d M Y', strtotime($article->post_date));
            $cats      = get_the_category($article->ID);
            $cat_label = !empty($cats) ? $cats[0]->name : __('Article', 'pild-unified');
            $read_time = max(1, round(str_word_count(wp_strip_all_tags($article->post_content)) / 200));
          ?>
          <div class="cm-article-card">
            <?php if ($thumb): ?>
              <div class="cm-article-thumb" style="background-image:url('<?php echo esc_url($thumb); ?>')"></div>
            <?php else: ?>
              <div class="cm-article-thumb cm-article-thumb-empty">
                <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              </div>
            <?php endif; ?>
            <div class="cm-article-body">
              <div class="cm-article-meta-row">
                <span class="cm-article-cat"><?php echo esc_html($cat_label); ?></span>
                <span class="cm-article-date"><?php echo esc_html($date); ?></span>
                <span class="cm-article-read"><?php printf( esc_html__( '~%d min read', 'pild-unified' ), $read_time ); ?></span>
              </div>
              <h3 class="cm-article-title"><?php echo esc_html($article->post_title); ?></h3>
              <?php if ($excerpt): ?>
                <p class="cm-article-excerpt"><?php echo esc_html($excerpt); ?></p>
              <?php endif; ?>
              <a href="<?php echo esc_url(get_permalink($article->ID)); ?>" class="cm-btn-primary cm-btn-sm"><?php esc_html_e( 'Read Article →', 'pild-unified' ); ?></a>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

    </div><!-- /cm-wrap -->

    <div id="cm-toast" class="cm-toast cm-toast-hidden"></div>

    <script>
    (function($) {

      // Practice Areas dropdown toggle
      $('#cm-pa-trigger').on('click', function(e) {
        e.stopPropagation();
        var menu = $('#cm-pa-menu');
        var isOpen = menu.hasClass('cm-pa-menu-open');
        $('.cm-tab-dropdown-menu').removeClass('cm-pa-menu-open');
        $('.cm-pa-chevron').removeClass('cm-pa-chevron-open');
        if (!isOpen) {
          menu.addClass('cm-pa-menu-open');
          $(this).find('.cm-pa-chevron').addClass('cm-pa-chevron-open');
        }
      });

      // Close dropdown when clicking outside
      $(document).on('click', function() {
        $('.cm-tab-dropdown-menu').removeClass('cm-pa-menu-open');
        $('.cm-pa-chevron').removeClass('cm-pa-chevron-open');
      });

      // Practice Area dropdown item click
      $(document).on('click', '.cm-tab-dropdown-item', function(e) {
        e.stopPropagation();
        var tab = $(this).data('tab');
        // Close dropdown
        $('.cm-tab-dropdown-menu').removeClass('cm-pa-menu-open');
        $('.cm-pa-chevron').removeClass('cm-pa-chevron-open');
        // Deactivate all tabs
        $('.cm-tab').removeClass('cm-tab-active');
        $('.cm-tab-dropdown-item').removeClass('cm-tab-dropdown-item-active');
        // Mark trigger as active and this item
        $('#cm-pa-trigger').addClass('cm-tab-active');
        $(this).addClass('cm-tab-dropdown-item-active');
        // Show panel
        $('.cm-panel').addClass('cm-panel-hidden');
        $('#tab-' + tab).removeClass('cm-panel-hidden');
        // Update trigger label
        $('#cm-pa-label').text($(this).text().trim());
        // Scroll the newly opened panel into view — otherwise, on long
        // pages (or mobile, where this becomes a sidebar), the Overview
        // info cards stay on screen and the user thinks nothing happened.
        pildcmScrollToPanel('tab-' + tab);
      });

      // Tab switching (non-dropdown)
      $('.cm-tab:not(.cm-tab-dropdown-trigger):not(.cm-tab-logout)').on('click', function() {
        $('.cm-tab').removeClass('cm-tab-active');
        $('.cm-tab-dropdown-item').removeClass('cm-tab-dropdown-item-active');
        $(this).addClass('cm-tab-active');
        $('.cm-panel').addClass('cm-panel-hidden');
        var tab = $(this).data('tab');
        $('#tab-' + tab).removeClass('cm-panel-hidden');
        // Close dropdown
        $('.cm-tab-dropdown-menu').removeClass('cm-pa-menu-open');
        $('.cm-pa-chevron').removeClass('cm-pa-chevron-open');
        // Reset trigger label
        $('#cm-pa-label').text(pildcm_ajax.i18n.practice_areas);
        // Trigger dashboard animations if switching to overview
        if (tab === 'overview') { pildcmAnimateDash(); }
        // Scroll the newly opened panel into view (see note above).
        pildcmScrollToPanel('tab-' + tab);
      });

      // Scrolls so the tab bar + newly active panel are visible right
      // under the header, instead of leaving the user stuck wherever
      // they had scrolled to on the previous tab.
      function pildcmScrollToPanel(panelId) {
        // NOTE: .cm-tabs-wrap is position:fixed on desktop, so its own
        // position never changes — using it as the scroll target was
        // the bug (it always computed "scroll to where we already are").
        // We scroll to the actual panel element instead, which sits in
        // normal document flow.
        var target = document.getElementById(panelId);
        if (!target) return;
        var headerOffset = document.body.classList.contains('admin-bar') ? 122 : 90;
        var top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
        window.scrollTo({ top: Math.max(top, 0), behavior: 'smooth' });
      }


      // Member Search
      $('#cm-member-search').on('input', function() {
        var q = $(this).val().toLowerCase();
        $('#cm-members-list .cm-member-card').each(function() {
          $(this).toggle($(this).data('name').includes(q));
        });
      });

      // Member Filter Pills
      $(document).on('click', '.cm-filter-pill', function() {
        var bar = $(this).closest('.cm-members-filter-bar, .cm-filter-bar, .cm-filter-tracks-row');
        bar.find('.cm-filter-pill').removeClass('cm-filter-pill-active');
        $(this).addClass('cm-filter-pill-active');
        var f = $(this).data('filter');
        if ($(this).closest('#tab-members').length) {
          // Member filter
          var labels = {active:pildcm_ajax.i18n.filter_active, 'at-risk':pildcm_ajax.i18n.filter_at_risk, completed:pildcm_ajax.i18n.filter_completed};
          var visible = 0;
          $('#cm-members-list .cm-member-card').each(function() {
            if (f === 'all') { $(this).show(); visible++; return; }
            // Use .attr() not .data() — jQuery .data() auto-casts "true"/"false" to booleans
            var show = false;
            if (f === 'active')    show = $(this).attr('data-active') === 'true';
            if (f === 'at-risk')   show = $(this).attr('data-atrisk') === 'true';
            if (f === 'completed') show = $(this).attr('data-completed') === 'true';
            $(this).toggle(show);
            if (show) visible++;
          });
          // Show empty state if no results
          $('#cm-members-list .cm-filter-empty').remove();
          if (visible === 0 && f !== 'all') {
            $('#cm-members-list').append('<div class="cm-filter-empty cm-empty" style="padding:2rem;text-align:center;color:#888;">' + pildcm_ajax.i18n.no_members_match.replace('%s', '<strong>' + (labels[f]||f) + '</strong>') + '</div>');
          }
        } else {
          // Track filter in Assign tab
          if (f === 'all') { $('.cm-assign-row').show(); }
          else { $('.cm-assign-row').hide(); $('.cm-assign-row[data-track="'+f+'"]').show(); }
        }
      });

      // Assign single track
      $(document).on('click', '.cm-assign-btn', function() {
        var btn = $(this), uid = btn.data('uid'), tid = btn.data('tid'), dl = $('#dl-'+uid+'-'+tid).val();
        btn.prop('disabled', true).text('…');
        $.post(pildcm_ajax.ajax_url, {action:'pildcm_assign_track', nonce:pildcm_ajax.nonce, user_id:uid, track_id:tid, deadline:dl, assign_action:'assign'}, function(res) {
          if (res.success) { showToast(pildcm_ajax.i18n.track_assigned, 'success'); setTimeout(() => location.reload(), 900); }
          else { showToast(res.data || pildcm_ajax.i18n.error, 'error'); btn.prop('disabled',false).text(pildcm_ajax.i18n.assign_short); }
        }).fail(function() { showToast(pildcm_ajax.i18n.network_error, 'error'); btn.prop('disabled',false).text(pildcm_ajax.i18n.assign_short); });
      });

      // Unassign track
      $(document).on('click', '.cm-unassign-btn', function() {
        if (!confirm(pildcm_ajax.i18n.confirm_remove_member)) return;
        var btn = $(this), uid = btn.data('uid'), tid = btn.data('tid');
        btn.prop('disabled',true).text('…');
        $.post(pildcm_ajax.ajax_url, {action:'pildcm_assign_track', nonce:pildcm_ajax.nonce, user_id:uid, track_id:tid, assign_action:'unassign'}, function(res) {
          if (res.success) { showToast(pildcm_ajax.i18n.member_removed, 'success'); setTimeout(() => location.reload(), 900); }
          else { showToast(res.data||pildcm_ajax.i18n.error,'error'); btn.prop('disabled',false).text(pildcm_ajax.i18n.remove); }
        }).fail(function() { showToast(pildcm_ajax.i18n.network_error,'error'); btn.prop('disabled',false).text(pildcm_ajax.i18n.remove); });
      });

      // Assign ALL tracks
      $(document).on('click', '.cm-btn-assign-all', function() {
        var btn = $(this), uid = btn.data('uid');
        var unassigned = btn.closest('.cm-assign-card').find('.cm-assign-btn');
        if (!unassigned.length) { showToast(pildcm_ajax.i18n.all_already_assigned, 'success'); return; }
        if (!confirm(pildcm_ajax.i18n.confirm_assign_all.replace('%d', unassigned.length))) return;
        btn.prop('disabled', true).text('…');
        var queue = [];
        unassigned.each(function() { queue.push({uid:$(this).data('uid'), tid:$(this).data('tid')}); });
        var errors = 0;
        function next() {
          if (!queue.length) {
            if (!errors) showToast(pildcm_ajax.i18n.all_assigned, 'success');
            else showToast(pildcm_ajax.i18n.done_with_errors.replace('%d', errors), 'error');
            setTimeout(() => location.reload(), 1200); return;
          }
          var item = queue.shift();
          $.post(pildcm_ajax.ajax_url, {action:'pildcm_assign_track', nonce:pildcm_ajax.nonce, user_id:item.uid, track_id:item.tid, assign_action:'assign'}, function(r) {
            if (!r.success) errors++; next();
          }).fail(function() { errors++; next(); });
        }
        next();
      });

      // Toast
      function showToast(msg, type) {
        var t = $('#cm-toast');
        t.text(msg).removeClass('cm-toast-hidden cm-toast-success cm-toast-error').addClass('cm-toast-' + type);
        setTimeout(() => t.addClass('cm-toast-hidden'), 3500);
      }

      // Settings: Image previews
      document.getElementById('pild-avatar-input')?.addEventListener('change', function() {
        if (!this.files[0]) return;
        var r = new FileReader();
        r.onload = e => { document.getElementById('avatar-preview').innerHTML = '<img src="'+e.target.result+'" alt="avatar">'; };
        r.readAsDataURL(this.files[0]);
      });
      document.getElementById('pild-logo-input')?.addEventListener('change', function() {
        if (!this.files[0]) return;
        var r = new FileReader();
        r.onload = e => { document.getElementById('logo-preview').innerHTML = '<img src="'+e.target.result+'" alt="logo">'; };
        r.readAsDataURL(this.files[0]);
      });

      // Settings: Save
      document.getElementById('pild-save-settings')?.addEventListener('click', function() {
        var btn = this, msg = document.getElementById('pild-settings-msg');
        btn.disabled = true; btn.querySelector('svg + *') || (btn.lastChild.textContent = pildcm_ajax.i18n.saving);
        var fd = new FormData();
        fd.append('action',       'pildcm_save_settings');
        fd.append('nonce',        pildcm_ajax.nonce);
        fd.append('display_name', document.getElementById('pild-display-name').value);
        fd.append('team_name',    document.getElementById('pild-team-name').value);
        fd.append('company_name', document.getElementById('pild-company-name').value);
        fd.append('phone',        document.getElementById('pild-phone').value);
        fd.append('website',      document.getElementById('pild-website').value);
        fd.append('address',      document.getElementById('pild-address').value);
        var af = document.getElementById('pild-avatar-input').files[0];
        var lf = document.getElementById('pild-logo-input').files[0];
        if (af) fd.append('avatar', af);
        if (lf) fd.append('company_logo', lf);
        fetch(pildcm_ajax.ajax_url, {method:'POST', body:fd}).then(r=>r.json()).then(res => {
          msg.textContent = res.success ? pildcm_ajax.i18n.changes_saved : '✗ ' + (res.data?.message||pildcm_ajax.i18n.error);
          msg.className   = 'cm-settings-status ' + (res.success ? 'ok' : 'err');
          btn.disabled    = false;
          if (res.success) setTimeout(() => location.reload(), 1500);
        }).catch(() => { msg.textContent=pildcm_ajax.i18n.connection_failed; btn.disabled=false; });
      });

    })(jQuery);

    /* ── Executive Dashboard Animations ── */
    function pildcmAnimateDash() {
      // Animate breakdown bars
      setTimeout(function() {
        document.querySelectorAll('.ed-bl-fill').forEach(function(el) {
          el.style.width = el.getAttribute('data-w') || '0%';
        });
      }, 80);
      // KPI count-up
      document.querySelectorAll('.ed-kpi-val').forEach(function(el) {
        var raw = el.textContent.trim();
        var isPct = raw.indexOf('%') > -1;
        var target = parseInt(raw.replace('%',''), 10);
        if (isNaN(target) || target === 0) return;
        var start = 0, dur = 900, startTime = null;
        function step(ts) {
          if (!startTime) startTime = ts;
          var p = Math.min((ts - startTime) / dur, 1);
          var ease = 1 - Math.pow(1 - p, 3);
          var cur = Math.round(ease * target);
          el.textContent = cur + (isPct ? '%' : '');
          if (p < 1) requestAnimationFrame(step);
          else el.textContent = raw;
        }
        requestAnimationFrame(step);
      });
    }

    // Run on page load (overview is active by default)
    document.addEventListener('DOMContentLoaded', function() {
      pildcmAnimateDash();
    });

    function pildcmSyncTeam(btn) {
      btn.disabled = true; btn.textContent = pildcm_ajax.i18n.syncing;
      fetch(pildcm_ajax.ajax_url, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({action:'pildcm_sync_team', nonce:pildcm_ajax.nonce})})
        .then(r=>r.json()).then(res => {
          if (res.success) { jQuery('#cm-toast').text('✓ '+res.data.message).removeClass('cm-toast-hidden cm-toast-error').addClass('cm-toast-success'); setTimeout(()=>location.reload(), 1200); }
          else { alert(pildcm_ajax.i18n.sync_failed); btn.disabled=false; btn.textContent=pildcm_ajax.i18n.sync_team; }
        }).catch(()=>{ alert(pildcm_ajax.i18n.network_error); btn.disabled=false; btn.textContent=pildcm_ajax.i18n.sync_team; });
    }

    function pildcmInviteMember(btn) {
      var email = document.getElementById('cm-invite-email').value.trim();
      var msg   = document.getElementById('cm-invite-msg');
      if (!email) { msg.innerHTML='<span class="cm-invite-err">'+pildcm_ajax.i18n.enter_email+'</span>'; return; }
      btn.disabled=true; btn.textContent=pildcm_ajax.i18n.sending; msg.innerHTML='';
      fetch(pildcm_ajax.ajax_url, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({action:'pildcm_invite_member', nonce:pildcm_ajax.nonce, email:email})})
        .then(r=>r.json()).then(res => {
          if (res.success) { msg.innerHTML='<span class="cm-invite-ok">'+res.data.message+'</span>'; document.getElementById('cm-invite-email').value=''; setTimeout(()=>location.reload(), 2000); }
          else { msg.innerHTML='<span class="cm-invite-err">'+res.data+'</span>'; }
        }).catch(()=>{ msg.innerHTML='<span class="cm-invite-err">'+pildcm_ajax.i18n.error_occurred+'</span>'; })
        .finally(()=>{ btn.disabled=false; btn.innerHTML='<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> '+pildcm_ajax.i18n.send_invitation; });
    }

    function pildcmCancelInvite(token, btn) {
        if (!confirm(pildcm_ajax.i18n.confirm_cancel_invite)) return;
        btn.disabled = true;
        btn.textContent = '...';
        fetch(pildcm_ajax.ajax_url, {
            method: 'POST',
            body: new URLSearchParams({action:'pildcm_cancel_invite', nonce:pildcm_ajax.nonce, token:token})
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                var row = document.getElementById('invite-row-' + token);
                if (row) row.remove();
            } else {
                btn.disabled = false;
                btn.textContent = pildcm_ajax.i18n.cancel;
                alert(res.data || pildcm_ajax.i18n.error);
            }
        })
        .catch(() => { btn.disabled=false; btn.textContent=pildcm_ajax.i18n.cancel; });
    }
    </script>
    <?php
    return ob_get_clean();
}