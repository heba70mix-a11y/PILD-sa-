<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 16. SHORTCODE — [pild_member_dashboard] (MEMBER)
// ============================================================
add_shortcode('pild_member_dashboard', 'pildcm_member_dashboard_shortcode');
function pildcm_member_dashboard_shortcode() {
    if (!is_user_logged_in()) {
        return '<div style="text-align:center;padding:3rem;"><p>' . sprintf( __( 'Please %1$slog in%2$s.', 'pild-unified' ), '<a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">', '</a>' ) . '</p></div>';
    }

    $user_id    = get_current_user_id();
    $user       = wp_get_current_user();
    $phone      = get_user_meta($user_id, 'pild_phone',     true);
    $bio        = get_user_meta($user_id, 'pild_bio',       true);
    $job_title  = get_user_meta($user_id, 'pild_job_title', true);
    $avatar_id  = get_user_meta($user_id, 'pild_avatar_id', true);
    $avatar_url = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
    $joined     = date_i18n('F Y', strtotime($user->user_registered));
    $last_login = get_user_meta($user_id, 'pild_last_login', true);

    $manager_id   = pildcm_get_member_manager($user_id);
    $company_name = $manager_id ? get_user_meta($manager_id, 'pild_company_name', true) : '';
    $team_name    = $manager_id ? get_user_meta($manager_id, 'pild_team_name',    true) : '';
    $logo_id      = $manager_id ? get_user_meta($manager_id, 'pild_company_logo_id', true) : '';
    $logo_url     = $logo_id    ? wp_get_attachment_image_url($logo_id, 'medium') : '';
    $comp_phone   = $manager_id ? get_user_meta($manager_id, 'pild_phone',   true) : '';
    $comp_website = $manager_id ? get_user_meta($manager_id, 'pild_website', true) : '';
    $comp_address = $manager_id ? get_user_meta($manager_id, 'pild_address', true) : '';
    $mgr          = $manager_id ? get_userdata($manager_id) : null;
    $mgr_joined   = $mgr ? date_i18n('F Y', strtotime($mgr->user_registered)) : '';

    $enrollments = pildcm_get_user_enrollments($user_id);
    $points      = pildcm_get_user_points($user_id);
    $badges      = pildcm_get_user_badges($user_id);
    $streak      = pildcm_get_streak($user_id);
    $badges_cfg  = pildcm_badges_config();
    $tracks      = $manager_id ? pildcm_get_manager_tracks($manager_id) : [];

    wp_enqueue_script('pildcm-js', PILDCM_URL . 'assets/pildcm.js', ['jquery'], PILDCM_VERSION, true);
    wp_localize_script('pildcm-js', 'pildcm_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('pildcm_nonce'),
        'i18n'     => [
            'profile_updated'   => __( '✓ Profile updated', 'pild-unified' ),
            'error'             => __( 'Error', 'pild-unified' ),
            'connection_failed' => __( '✗ Connection failed', 'pild-unified' ),
            'confirm_delete'    => __( 'Delete this entry?', 'pild-unified' ),
        ],
    ]);

    ob_start();
    echo pildcm_css();
    ?>

    <div class="cm-wrap cm-member-wrap">


      <!-- ══════════════════════ MEMBER HERO ══════════════════════ -->
      <div class="cm-hero cm-member-hero">
        <div class="cm-hero-bg-orb cm-hero-bg-orb-1"></div>
        <div class="cm-hero-bg-orb cm-hero-bg-orb-2"></div>
        <div class="cm-hero-left">
          <div class="cm-hero-eyebrow"><?php esc_html_e( 'Development Dashboard', 'pild-unified' ); ?></div>
          <h1 class="cm-hero-title"><?php printf( esc_html__( 'Hello, %s', 'pild-unified' ), esc_html( explode( ' ', $user->display_name )[0] ) ); ?></h1>
          <p class="cm-hero-sub"><?php echo $team_name ? esc_html($team_name) . ' · ' : ''; ?><?php esc_html_e( 'Keep up the great work!', 'pild-unified' ); ?></p>
        </div>
        <div class="cm-hero-kpis">
          <div class="cm-kpi">
            <div class="cm-kpi-icon">⭐</div>
            <div class="cm-kpi-num"><?php echo number_format($points); ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi">
            <div class="cm-kpi-icon">🔥</div>
            <div class="cm-kpi-num"><?php echo $streak; ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Day Streak', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi">
            <div class="cm-kpi-icon">🏅</div>
            <div class="cm-kpi-num"><?php echo count($badges); ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-kpi-divider"></div>
          <?php
          // Count completed tracks (progress = 100%)
          $completed_tracks = 0;
          foreach ($enrollments as $enroll) {
              $prog = pildcm_get_track_progress($user_id, (int)$enroll->track_id);
              if ($prog['pct'] >= 100) $completed_tracks++;
          }
          ?>
          <div class="cm-kpi">
            <div class="cm-kpi-icon">🏁</div>
            <div class="cm-kpi-num"><?php echo $completed_tracks; ?></div>
            <div class="cm-kpi-lbl"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></div>
          </div>
        </div>
      </div>


      <!-- ══════════════════════ TABS (MEMBER) ══════════════════════ -->
      <div class="cm-tabs-wrap">
        <div class="cm-tabs">
          <button class="cm-tab cm-tab-active" data-tab="member-home">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            <?php esc_html_e( 'My Tracks', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="member-badges">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
            <?php esc_html_e( 'Achievements', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="member-articles">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
            <?php esc_html_e( 'Insights & Articles', 'pild-unified' ); ?>
          </button>
          <button class="cm-tab" data-tab="member-profile">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <?php esc_html_e( 'Profile', 'pild-unified' ); ?>
          </button>
          <a class="cm-tab" href="<?php echo esc_url( function_exists('pildcm_edit_profile_url') ? pildcm_edit_profile_url() : '#' ); ?>" style="text-decoration:none;display:inline-flex;align-items:center;gap:.4rem">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg>
            <?php esc_html_e( 'Professional Profile', 'pild-unified' ); ?>
          </a>
          <button class="cm-tab" data-tab="member-settings">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14"/></svg>
            <?php esc_html_e( 'My Settings', 'pild-unified' ); ?>
          </button>
          <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="cm-tab cm-tab-logout">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            <?php esc_html_e( 'Log Out', 'pild-unified' ); ?>
          </a>
        </div>
      </div>

      <!-- TAB: PROFILE — shows only when the "Profile" tab above is clicked,
           not on every dashboard view (this used to sit above the tabs and
           render on every tab; moved into its own hidden panel). -->
      <div class="cm-panel cm-panel-hidden" id="tab-member-profile">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Profile', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Your personal snapshot and organization details', 'pild-unified' ); ?></div>
        </div>
      <div class="cm-info-cards-row">

        <!-- Company Card -->
        <div class="cm-info-card cm-company-card">
          <div class="cm-info-card-header">
            <div class="cm-info-card-icon cm-icon-teal">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </div>
            <div class="cm-info-card-label"><?php esc_html_e( 'Organization', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-company-logo-wrap">
            <?php if ($logo_url): ?>
              <img src="<?php echo esc_url($logo_url); ?>" alt="logo" class="cm-company-logo-img">
            <?php else: ?>
              <div class="cm-company-logo-placeholder"><?php echo esc_html(strtoupper(substr($company_name ?: 'ORG', 0, 2))); ?></div>
            <?php endif; ?>
          </div>
          <div class="cm-info-card-name"><?php echo esc_html($company_name ?: __('Your Organization', 'pild-unified')); ?></div>
          <?php if ($team_name): ?>
            <div class="cm-info-card-sub">
              <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
              <?php echo esc_html($team_name); ?>
            </div>
          <?php endif; ?>
          <div class="cm-info-card-details">
            <?php if ($mgr): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              <span><?php printf( esc_html__( 'Manager: %s', 'pild-unified' ), esc_html( $mgr->display_name ) ); ?></span>
            </div>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <span><?php echo esc_html($mgr->user_email); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($comp_phone): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .82h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.92z"/></svg>
              <span><?php echo esc_html($comp_phone); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($comp_website): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>
              <a href="<?php echo esc_url($comp_website); ?>" target="_blank"><?php echo esc_html($comp_website); ?></a>
            </div>
            <?php endif; ?>
            <?php if ($comp_address): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span><?php echo esc_html($comp_address); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($mgr_joined): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <span><?php printf( esc_html__( 'On PILD since %s', 'pild-unified' ), esc_html( $mgr_joined ) ); ?></span>
            </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Member Personal Card -->
        <div class="cm-info-card cm-personal-card">
          <div class="cm-info-card-header">
            <div class="cm-info-card-icon cm-icon-gold">
              <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <div class="cm-info-card-label"><?php esc_html_e( 'My Profile', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-personal-avatar-wrap">
            <?php if ($avatar_url): ?>
              <img src="<?php echo esc_url($avatar_url); ?>" alt="avatar" class="cm-personal-avatar">
            <?php else: ?>
              <div class="cm-personal-avatar-fallback"><?php echo esc_html(strtoupper(substr($user->display_name, 0, 2))); ?></div>
            <?php endif; ?>
          </div>
          <div class="cm-info-card-name"><?php echo esc_html($user->display_name); ?></div>
          <?php if ($job_title): ?>
            <div class="cm-info-card-sub"><?php echo esc_html($job_title); ?></div>
          <?php else: ?>
            <div class="cm-info-card-sub"><?php esc_html_e( 'Team Member', 'pild-unified' ); ?></div>
          <?php endif; ?>
          <?php if ($bio): ?>
            <div class="cm-personal-bio"><?php echo esc_html($bio); ?></div>
          <?php endif; ?>
          <div class="cm-info-card-details">
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
              <span><?php echo esc_html($user->user_email); ?></span>
            </div>
            <?php if ($phone): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .82h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.92z"/></svg>
              <span><?php echo esc_html($phone); ?></span>
            </div>
            <?php endif; ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              <span><?php printf( esc_html__( 'Member since %s', 'pild-unified' ), esc_html( $joined ) ); ?></span>
            </div>
            <?php if ($last_login): ?>
            <div class="cm-info-detail-row">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <span><?php printf( esc_html__( 'Last login: %s', 'pild-unified' ), esc_html( date_i18n( 'd M Y, g:i a', strtotime( $last_login ) ) ) ); ?></span>
            </div>
            <?php endif; ?>
          </div>
          <div class="cm-personal-stats-row">
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo number_format($points); ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></div>
            </div>
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo $streak; ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Streak', 'pild-unified' ); ?></div>
            </div>
            <div class="cm-pstat">
              <div class="cm-pstat-num"><?php echo count($badges); ?></div>
              <div class="cm-pstat-lbl"><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></div>
            </div>
          </div>
        </div>

      </div><!-- /info-cards-row -->
      </div><!-- /tab-member-profile -->

      <!-- TAB: MY TRACKS -->
      <div class="cm-panel" id="tab-member-home">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'My Development Tracks', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Track your progress across all assigned development paths', 'pild-unified' ); ?></div>
        </div>
        <?php if (empty($enrollments)): ?>
          <div class="cm-empty"><?php esc_html_e( 'No tracks assigned yet. Your manager will assign learning tracks for you soon.', 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-member-tracks-grid">
          <?php foreach ($enrollments as $enroll):
              $tid         = (int) $enroll->track_id;
              $track       = get_post($tid);
              if (!$track || $track->post_status !== 'publish') continue;
              $prog        = pildcm_get_track_progress($user_id, $tid);
              $deadline    = $enroll->deadline ?? '';
              $is_overdue  = $deadline && strtotime($deadline) < time() && $prog['pct'] < 100;
              $is_complete = $prog['pct'] >= 100;
              $track_url   = get_permalink($tid);
              $cert_url    = pildcm_get_certificate_url($user_id, $tid);
              // Build public verify URL for LinkedIn
              global $wpdb;
              $cert_code_m = '';
              if ($cert_url) {
                  $cert_code_m = $wpdb->get_var($wpdb->prepare(
                      "SELECT certificate_code FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id=%d AND passed='yes' ORDER BY completed_at DESC LIMIT 1",
                      $user_id, $tid
                  ));
              }
              $cert_verify_url_m = $cert_code_m ? home_url('/verify-certificate/' . $cert_code_m) : $cert_url;
              $cert_id_m = $cert_code_m ? $cert_code_m : ('PILD-' . $user_id . '-' . $tid);
              $status_class = $is_complete ? 'complete' : ($is_overdue ? 'overdue' : 'active');
          ?>
          <div class="cm-member-track-card cm-mtrack-<?php echo $status_class; ?>">
            <div class="cm-mtrack-top">
              <?php if ($is_complete): ?><span class="cm-mtrack-status-badge complete"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></span>
              <?php elseif ($is_overdue): ?><span class="cm-mtrack-status-badge overdue"><?php esc_html_e( 'Overdue', 'pild-unified' ); ?></span>
              <?php else: ?><span class="cm-mtrack-status-badge active"><?php esc_html_e( 'In Progress', 'pild-unified' ); ?></span>
              <?php endif; ?>
            </div>
            <h3 class="cm-mtrack-title"><?php echo esc_html($track->post_title); ?></h3>
            <div class="cm-mtrack-pct-row">
              <span class="cm-mtrack-pct"><?php echo $prog['pct']; ?>%</span>
              <span class="cm-mtrack-playbooks"><?php printf( esc_html__( '%1$d/%2$d Playbooks', 'pild-unified' ), $prog['done'], $prog['total'] ); ?></span>
            </div>
            <div class="cm-mtrack-prog-wrap">
              <div class="cm-mtrack-prog-bar <?php echo $status_class; ?>" style="width:<?php echo $prog['pct']; ?>%"></div>
            </div>
            <?php if ($deadline): ?>
              <div class="cm-mtrack-deadline <?php echo $is_overdue ? 'overdue' : ''; ?>">
                <?php echo $is_overdue ? '⚠ ' . esc_html__('Overdue:', 'pild-unified' ) . ' ' : '📅 ' . esc_html__('Deadline:', 'pild-unified' ) . ' '; ?><?php echo esc_html($deadline); ?>
              </div>
            <?php endif; ?>
            <div class="cm-mtrack-actions">
              <a href="<?php echo esc_url($track_url); ?>" class="cm-btn-primary cm-btn-sm">
                <?php if ($is_complete): ?><?php esc_html_e( 'Review Track', 'pild-unified' ); ?>
                <?php elseif ($prog['done'] > 0): ?><?php esc_html_e( 'Continue →', 'pild-unified' ); ?>
                <?php else: ?><?php esc_html_e( 'Start Track →', 'pild-unified' ); ?>
                <?php endif; ?>
              </a>
              <?php if ($cert_url): ?>
                <a href="<?php echo esc_url($cert_url); ?>" class="cm-cert-btn" target="_blank">
                  🏅 <?php esc_html_e( 'View Certificate', 'pild-unified' ); ?>
                </a>
                <?php
                  $li_org        = $company_name ?: get_bloginfo('name');
                  $li_cert_name  = esc_attr($track->post_title) . ' — ' . $li_org;
                  $li_issued_y   = date('Y');
                  $li_issued_m   = date('n');
                  $li_add_url    = 'https://www.linkedin.com/profile/add?' . http_build_query([
                      'startTask'        => 'CERTIFICATION_NAME',
                      'name'             => $li_cert_name,
                      'organizationName' => $li_org,
                      'issueYear'        => $li_issued_y,
                      'issueMonth'       => $li_issued_m,
                      'certUrl'          => $cert_verify_url_m,
                      'certId'           => $cert_id_m,
                  ]);
                  $li_share_text = urlencode( sprintf( __( '🏅 I just earned the "%1$s" certificate from %2$s! #Learning #Certificate', 'pild-unified' ), $track->post_title, $li_org ) );
                  $li_share_url  = 'https://www.linkedin.com/sharing/share-offsite/?url=' . urlencode($cert_verify_url_m) . '&summary=' . $li_share_text;
                ?>
                <a href="<?php echo esc_url($li_add_url); ?>" class="cm-linkedin-add-btn" target="_blank" rel="noopener">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  <?php esc_html_e( 'Add to Profile', 'pild-unified' ); ?>
                </a>
                <a href="<?php echo esc_url($li_share_url); ?>" class="cm-linkedin-share-btn" target="_blank" rel="noopener">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  <?php esc_html_e( 'Share', 'pild-unified' ); ?>
                </a>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- TAB: INSIGHTS & ARTICLES -->
      <div class="cm-panel cm-panel-hidden" id="tab-member-articles">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Insights & Articles', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Exclusive articles and insights included in your membership', 'pild-unified' ); ?></div>
        </div>
        <?php
        // Members don't have their own membership plan — inherit free-plan articles
        // from their manager's plan, same as before. On top of that (and completely
        // independent of any membership plan), merge in whatever articles this
        // member's own active Track enrollments unlock by Domain — see
        // includes/37-track-articles.php. A member's Track enrollment is always
        // tied to their own user_id, never the manager's, so this part always uses
        // $user_id regardless of $articles_source_id above.
        $member_manager_id = pildcm_get_member_manager($user_id);
        $articles_source_id = $member_manager_id ? (int) $member_manager_id : $user_id;
        $member_articles = pildcm_get_member_articles($articles_source_id);
        $member_track_articles = function_exists('pildcm_get_member_track_articles') ? pildcm_get_member_track_articles($user_id) : [];
        if (!empty($member_track_articles)) {
            $seen_ids = array_map(function ($a) { return $a->ID; }, $member_articles);
            foreach ($member_track_articles as $ta) {
                if (!in_array($ta->ID, $seen_ids, true)) $member_articles[] = $ta;
            }
            usort($member_articles, function ($a, $b) { return strtotime($b->post_date) <=> strtotime($a->post_date); });
        }
        if (empty($member_articles)): ?>
          <div class="cm-empty"><?php esc_html_e( "No articles are included in your team's membership plan.", 'pild-unified' ); ?></div>
        <?php else: ?>
        <div class="cm-articles-grid">
          <?php foreach ($member_articles as $article):
            $thumb     = get_the_post_thumbnail_url($article->ID, 'medium');
            $excerpt   = wp_trim_words($article->post_excerpt ?: wp_strip_all_tags($article->post_content), 20);
            $date      = date_i18n('d M Y', strtotime($article->post_date));
            $cats      = get_the_category($article->ID);
            $cat_label = !empty($cats) ? $cats[0]->name : __('Article', 'pild-unified');
            $read_time = max(1, round(str_word_count(wp_strip_all_tags($article->post_content)) / 200));
          ?>
          <div class="cm-article-card">
            <?php if ($thumb): ?>
              <div class="cm-article-thumb" style="background-image:url('<?php echo esc_url($thumb); ?>')"></div>
            <?php else: ?>
              <div class="cm-article-thumb cm-article-thumb-empty">
                <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              </div>
            <?php endif; ?>
            <div class="cm-article-body">
              <div class="cm-article-meta-row">
                <span class="cm-article-cat"><?php echo esc_html($cat_label); ?></span>
                <span class="cm-article-date"><?php echo esc_html($date); ?></span>
                <span class="cm-article-read"><?php printf( esc_html__( '~%d min read', 'pild-unified' ), $read_time ); ?></span>
              </div>
              <h3 class="cm-article-title"><?php echo esc_html($article->post_title); ?></h3>
              <?php if ($excerpt): ?>
                <p class="cm-article-excerpt"><?php echo esc_html($excerpt); ?></p>
              <?php endif; ?>
              <a href="<?php echo esc_url(get_permalink($article->ID)); ?>" class="cm-btn-primary cm-btn-sm"><?php esc_html_e( 'Read Article →', 'pild-unified' ); ?></a>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- TAB: ACHIEVEMENTS -->
      <div class="cm-panel cm-panel-hidden" id="tab-member-badges">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Achievements', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Your earned achievement badges and locked achievements to unlock', 'pild-unified' ); ?></div>
        </div>
        <div class="cm-achievements-grid">
          <?php
          $earned_keys = array_column((array)$badges, 'badge_key');
          foreach ($badges_cfg as $key => $cfg):
              $earned = in_array($key, $earned_keys);
          ?>
          <div class="cm-achievement-card <?php echo !$earned ? 'locked' : 'earned'; ?>">
            <div class="cm-achievement-icon"><?php echo $cfg['icon']; ?></div>
            <div class="cm-achievement-label"><?php echo esc_html($cfg['label']); ?></div>
            <div class="cm-achievement-desc"><?php echo esc_html($cfg['desc']); ?></div>
            <?php if ($earned): ?><div class="cm-achievement-earned-badge"><?php esc_html_e( 'Earned', 'pild-unified' ); ?></div><?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- TAB: MY SETTINGS -->
      <div class="cm-panel cm-panel-hidden" id="tab-member-settings">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'My Settings', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Update your personal profile and contact information', 'pild-unified' ); ?></div>
        </div>
        <div class="cm-settings-layout">
          <div class="cm-settings-section">
            <div class="cm-settings-section-title"><?php esc_html_e( 'Personal Profile', 'pild-unified' ); ?></div>
            <div class="cm-settings-avatar-row">
              <div class="cm-settings-avatar" id="member-avatar-preview">
                <?php if ($avatar_url): ?>
                  <img src="<?php echo esc_url($avatar_url); ?>" alt="avatar">
                <?php else: ?>
                  <span><?php echo strtoupper(substr($user->display_name, 0, 1)); ?></span>
                <?php endif; ?>
              </div>
              <div>
                <label class="cm-upload-btn">
                  <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  <?php esc_html_e( 'Upload Photo', 'pild-unified' ); ?>
                  <input type="file" id="member-avatar-input" accept="image/*" style="display:none">
                </label>
                <p class="cm-upload-hint"><?php esc_html_e( 'PNG, JPG — max 2MB', 'pild-unified' ); ?></p>
              </div>
            </div>
            <div class="cm-settings-fields">
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Full Name', 'pild-unified' ); ?></label>
                <input type="text" id="member-display-name" value="<?php echo esc_attr($user->display_name); ?>" placeholder="<?php esc_attr_e( 'Your full name', 'pild-unified' ); ?>">
              </div>
              <div class="cm-settings-field">
                <label><?php esc_html_e( 'Phone Number', 'pild-unified' ); ?></label>
                <input type="text" id="member-phone" value="<?php echo esc_attr($phone); ?>" placeholder="+1 234 567 8900">
              </div>
            </div>
            <p class="cm-upload-hint" style="margin-top:.5rem"><?php printf( wp_kses( __( 'Job title, bio, and country now live on your %s page (bilingual).', 'pild-unified' ), ['a' => ['href' => []]] ), '<a href="' . esc_url( function_exists('pildcm_edit_profile_url') ? pildcm_edit_profile_url() : '#' ) . '">' . esc_html__( 'Professional Profile', 'pild-unified' ) . '</a>' ); ?></p>
          </div>
          <div class="cm-settings-footer">
            <button class="cm-btn-primary cm-btn-save" id="member-save-settings">
              <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
              <?php esc_html_e( 'Save Changes', 'pild-unified' ); ?>
            </button>
            <span id="member-settings-msg"></span>
          </div>
        </div>
      </div>

    </div><!-- /cm-wrap -->

    <div id="cm-toast" class="cm-toast cm-toast-hidden"></div>

    <script>
    (function($) {
      $('.cm-tab').on('click', function() {
        $('.cm-tab').removeClass('cm-tab-active');
        $(this).addClass('cm-tab-active');
        $('.cm-panel').addClass('cm-panel-hidden');
        $('#tab-' + $(this).data('tab')).removeClass('cm-panel-hidden');
        pildcmScrollToPanel('tab-' + $(this).data('tab'));
      });

      // Scrolls the newly opened panel into view. .cm-tabs-wrap is
      // position:fixed on desktop, so we target the panel itself
      // (which is in normal document flow), not the sidebar.
      function pildcmScrollToPanel(panelId) {
        var target = document.getElementById(panelId);
        if (!target) return;
        var headerOffset = document.body.classList.contains('admin-bar') ? 122 : 90;
        var top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
        window.scrollTo({ top: Math.max(top, 0), behavior: 'smooth' });
      }

      document.getElementById('member-avatar-input')?.addEventListener('change', function() {
        if (!this.files[0]) return;
        var r = new FileReader();
        r.onload = e => { document.getElementById('member-avatar-preview').innerHTML='<img src="'+e.target.result+'" alt="avatar">'; };
        r.readAsDataURL(this.files[0]);
      });

      document.getElementById('member-save-settings')?.addEventListener('click', function() {
        var btn = this, msg = document.getElementById('member-settings-msg');
        btn.disabled = true;
        var fd = new FormData();
        fd.append('action',       'pildcm_save_member_settings');
        fd.append('nonce',        pildcm_ajax.nonce);
        fd.append('display_name', document.getElementById('member-display-name').value);
        fd.append('phone',        document.getElementById('member-phone').value);
        var af = document.getElementById('member-avatar-input').files[0];
        if (af) fd.append('avatar', af);
        fetch(pildcm_ajax.ajax_url, {method:'POST', body:fd}).then(r=>r.json()).then(res => {
          msg.textContent = res.success ? pildcm_ajax.i18n.profile_updated : '✗ ' + (res.data?.message||pildcm_ajax.i18n.error);
          msg.className   = 'cm-settings-status ' + (res.success ? 'ok' : 'err');
          btn.disabled    = false;
          if (res.success) setTimeout(() => location.reload(), 1500);
        }).catch(()=>{ msg.textContent=pildcm_ajax.i18n.connection_failed; btn.disabled=false; });
      });
    })(jQuery);
    </script>
    <?php
    return ob_get_clean();
}