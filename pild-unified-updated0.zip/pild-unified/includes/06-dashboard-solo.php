<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 17b. SHORTCODE — [pild_solo_dashboard] (INDIVIDUAL MEMBER)
// ============================================================
add_shortcode('pild_solo_dashboard', 'pildcm_solo_dashboard_shortcode');
function pildcm_solo_dashboard_shortcode() {
    if (!is_user_logged_in()) {
        return '<div style="text-align:center;padding:3rem;"><p>' . sprintf( __( 'Please %1$slog in%2$s.', 'pild-unified' ), '<a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">', '</a>' ) . '</p></div>';
    }
    $user_id    = get_current_user_id();
    $user       = wp_get_current_user();
    $phone      = get_user_meta($user_id, 'pild_phone',     true);
    $bio        = get_user_meta($user_id, 'pild_bio',       true);
    $job_title  = get_user_meta($user_id, 'pild_job_title', true);
    $avatar_id  = get_user_meta($user_id, 'pild_avatar_id', true);
    $avatar_url = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';
    $joined     = date_i18n('F Y', strtotime($user->user_registered));
    $last_login = get_user_meta($user_id, 'pild_last_login', true);
    $enrollments = pildcm_get_solo_enrollments($user_id);
    $points      = pildcm_get_user_points($user_id);
    $badges      = pildcm_get_user_badges($user_id);
    $streak      = pildcm_get_streak($user_id);
    $badges_cfg  = pildcm_badges_config();

    // ------------------------------------------------------------
    // Dynamic, permission-based sections: a member only sees tabs for
    // what they actually have access to.
    //   - My Development Tracks : paid packages (knowledge/domain/tracks)
    //   - My Books & Assessments: standalone paid Playbook/Assessment purchases
    //   - Free Resources        : the free plan's articles + playbooks (by category)
    // ------------------------------------------------------------
    $paid_track_ids     = array_map(function ($e) { return (int) $e->track_id; }, $enrollments);
    $free_articles      = pildcm_get_member_articles($user_id);
    $free_playbooks     = pildcm_get_member_free_playbooks($user_id, $paid_track_ids);
    // Articles unlocked by an actual paid Track enrollment (by Domain), fully
    // separate from the free-plan articles above — see includes/37-track-articles.php.
    $track_articles     = function_exists('pildcm_get_member_track_articles') ? pildcm_get_member_track_articles($user_id) : [];
    $purchased_products = pildcm_get_member_purchased_products($user_id);

    // Book Store purchases (includes/34-book-store.php) all land together in one
    // unified "My Library" tab, regardless of which Sector/Domain they belong to.
    // Everything else (Playbooks, Assessments, ...) keeps the existing behavior:
    // grouped by its actual product category, each category getting its own tab.
    $purchased_books = [];
    $product_groups  = [];
    foreach ($purchased_products as $prod) {
        if (!empty($prod->is_book)) {
            $purchased_books[] = $prod;
            continue;
        }
        $cat_key = $prod->cat_label;
        if (!isset($product_groups[$cat_key])) $product_groups[$cat_key] = [];
        $product_groups[$cat_key][] = $prod;
    }

    $has_tracks   = !empty($enrollments);
    $has_library  = !empty($purchased_books);
    $has_products = !empty($product_groups);
    $has_free     = !empty($free_articles) || !empty($free_playbooks);
    $has_track_articles = !empty($track_articles);

    // First populated section becomes the tab that opens by default.
    if ($has_tracks) {
        $default_tab = 'solo-home';
    } elseif ($has_library) {
        $default_tab = 'solo-library';
    } elseif ($has_products) {
        $default_tab = 'solo-products-' . sanitize_title(array_key_first($product_groups));
    } elseif ($has_track_articles) {
        $default_tab = 'solo-track-articles';
    } elseif ($has_free) {
        $default_tab = 'solo-articles';
    } else {
        $default_tab = 'solo-badges';
    }

    wp_enqueue_script('pildcm-js', PILDCM_URL . 'assets/pildcm.js', ['jquery'], PILDCM_VERSION, true);
    wp_localize_script('pildcm-js', 'pildcm_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('pildcm_nonce'),
        'i18n'     => [
            'copied'            => __( '✓ Copied', 'pild-unified' ),
            'profile_updated'   => __( '✓ Profile updated', 'pild-unified' ),
            'error'             => __( 'Error', 'pild-unified' ),
            'connection_failed' => __( '✗ Connection failed', 'pild-unified' ),
            'confirm_delete'    => __( 'Delete this entry?', 'pild-unified' ),
        ],
    ]);
    ob_start();
    echo pildcm_css();
    ?>
    <div class="cm-wrap cm-member-wrap">
      <div class="cm-hero cm-member-hero">
        <div class="cm-hero-bg-orb cm-hero-bg-orb-1"></div>
        <div class="cm-hero-bg-orb cm-hero-bg-orb-2"></div>
        <div class="cm-hero-left">
          <div class="cm-hero-eyebrow"><?php esc_html_e( 'Development Dashboard', 'pild-unified' ); ?></div>
          <h1 class="cm-hero-title"><?php printf( esc_html__( 'Hello, %s', 'pild-unified' ), esc_html( explode( ' ', $user->display_name )[0] ) ); ?></h1>
          <p class="cm-hero-sub"><?php esc_html_e( 'Keep up the great work!', 'pild-unified' ); ?></p>
        </div>
        <div class="cm-hero-kpis">
          <div class="cm-kpi"><div class="cm-kpi-icon">⭐</div><div class="cm-kpi-num"><?php echo number_format($points); ?></div><div class="cm-kpi-lbl"><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></div></div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi"><div class="cm-kpi-icon">🔥</div><div class="cm-kpi-num"><?php echo $streak; ?></div><div class="cm-kpi-lbl"><?php esc_html_e( 'Day Streak', 'pild-unified' ); ?></div></div>
          <div class="cm-kpi-divider"></div>
          <div class="cm-kpi"><div class="cm-kpi-icon">🏅</div><div class="cm-kpi-num"><?php echo count($badges); ?></div><div class="cm-kpi-lbl"><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></div></div>
          <div class="cm-kpi-divider"></div>
          <?php $ct=0; foreach($enrollments as $e){$p=pildcm_get_track_progress($user_id,(int)$e->track_id);if($p['pct']>=100)$ct++;} ?>
          <div class="cm-kpi"><div class="cm-kpi-icon">🏁</div><div class="cm-kpi-num"><?php echo $ct; ?></div><div class="cm-kpi-lbl"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></div></div>
        </div>
      </div>
      <div class="cm-tabs-wrap"><div class="cm-tabs">
        <!-- pild-debug: purchased_products=<?php echo count($purchased_products); ?> purchased_books=<?php echo count($purchased_books); ?> product_groups=<?php echo implode('|', array_keys($product_groups)); ?> plugin_build=2026-09-23-bilingual -->
        <?php if ($has_tracks): ?>
        <button class="cm-tab<?php echo $default_tab === 'solo-home' ? ' cm-tab-active' : ''; ?>" data-tab="solo-home"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg> <?php esc_html_e( 'My Development Tracks', 'pild-unified' ); ?></button>
        <?php endif; ?>
        <?php if ($has_track_articles): ?>
        <button class="cm-tab<?php echo $default_tab === 'solo-track-articles' ? ' cm-tab-active' : ''; ?>" data-tab="solo-track-articles"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg> <?php esc_html_e( 'Track Articles', 'pild-unified' ); ?></button>
        <?php endif; ?>
        <?php if ($has_library): ?>
        <button class="cm-tab<?php echo $default_tab === 'solo-library' ? ' cm-tab-active' : ''; ?>" data-tab="solo-library"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg> <?php esc_html_e( 'My Library', 'pild-unified' ); ?></button>
        <?php endif; ?>
        <?php foreach ($product_groups as $cat_label => $items):
            $tab_id = 'solo-products-' . sanitize_title($cat_label);
        ?>
        <button class="cm-tab<?php echo $default_tab === $tab_id ? ' cm-tab-active' : ''; ?>" data-tab="<?php echo esc_attr($tab_id); ?>"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg> <?php echo esc_html($cat_label); ?></button>
        <?php endforeach; ?>
        <?php if ($has_free): ?>
        <button class="cm-tab<?php echo $default_tab === 'solo-articles' ? ' cm-tab-active' : ''; ?>" data-tab="solo-articles"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg> <?php esc_html_e( 'Free Resources & Articles', 'pild-unified' ); ?></button>
        <?php endif; ?>
        <!-- LEADERSHIP ASSESSMENT: two tabs added 2026 — free, self-report,
             not gated by any purchase, so shown unconditionally like
             Achievements/Billing/Profile below. See includes/42-leadership-assessment.php. -->
        <button class="cm-tab<?php echo $default_tab === 'solo-la-assessment' ? ' cm-tab-active' : ''; ?>" data-tab="la-assessment"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2l3 6 6 1-4.5 4.5L17.5 20 12 17l-5.5 3 1-6.5L3 9l6-1z"/></svg> <?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['tab_label'] : 'التقييم القيادي' ); ?></button>
        <button class="cm-tab<?php echo $default_tab === 'solo-la-team' ? ' cm-tab-active' : ''; ?>" data-tab="la-team"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg> <?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['team_tab_label'] : 'My Team' ); ?></button>
        <button class="cm-tab<?php echo $default_tab === 'solo-badges' ? ' cm-tab-active' : ''; ?>" data-tab="solo-badges"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg> <?php esc_html_e( 'Achievements', 'pild-unified' ); ?></button>
        <button class="cm-tab" data-tab="solo-billing"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg> <?php esc_html_e( 'Billing', 'pild-unified' ); ?></button>
        <button class="cm-tab" data-tab="solo-profile"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> <?php esc_html_e( 'Profile', 'pild-unified' ); ?></button>
        <a class="cm-tab" href="<?php echo esc_url( function_exists('pildcm_edit_profile_url') ? pildcm_edit_profile_url() : '#' ); ?>" style="text-decoration:none;display:inline-flex;align-items:center;gap:.4rem"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/></svg> <?php esc_html_e( 'Professional Profile', 'pild-unified' ); ?></a>
        <button class="cm-tab" data-tab="solo-settings"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 010 14.14M4.93 4.93a10 10 0 000 14.14"/></svg> <?php esc_html_e( 'My Settings', 'pild-unified' ); ?></button>
        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="cm-tab cm-tab-logout"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg> <?php esc_html_e( 'Log Out', 'pild-unified' ); ?></a>
      </div></div>

      <!-- TAB: PROFILE — shows only when the "Profile" tab above is clicked,
           not on every dashboard view (this used to sit above the tabs and
           render on every tab; moved into its own hidden panel). -->
      <div class="cm-panel cm-panel-hidden" id="tab-solo-profile">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'Profile', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Your personal snapshot', 'pild-unified' ); ?></div></div>
      <div class="cm-info-cards-row" style="justify-content:center;">
        <div class="cm-info-card cm-personal-card" style="max-width:420px;width:100%;">
          <div class="cm-info-card-header">
            <div class="cm-info-card-icon cm-icon-gold"><svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
            <div class="cm-info-card-label"><?php esc_html_e( 'My Profile', 'pild-unified' ); ?></div>
          </div>
          <div class="cm-personal-avatar-wrap">
            <?php if ($avatar_url): ?><img src="<?php echo esc_url($avatar_url); ?>" alt="avatar" class="cm-personal-avatar">
            <?php else: ?><div class="cm-personal-avatar-fallback"><?php echo esc_html(strtoupper(substr($user->display_name,0,2))); ?></div><?php endif; ?>
          </div>
          <div class="cm-info-card-name"><?php echo esc_html($user->display_name); ?></div>
          <div class="cm-info-card-sub"><?php echo $job_title ? esc_html($job_title) : esc_html__( 'Individual Member', 'pild-unified' ); ?></div>
          <?php if ($bio): ?><div class="cm-personal-bio"><?php echo esc_html($bio); ?></div><?php endif; ?>
          <div class="cm-info-card-details">
            <div class="cm-info-detail-row"><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg><span><?php echo esc_html($user->user_email); ?></span></div>
            <?php if ($phone): ?><div class="cm-info-detail-row"><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .82h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 15.92z"/></svg><span><?php echo esc_html($phone); ?></span></div><?php endif; ?>
            <div class="cm-info-detail-row"><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span><?php printf( esc_html__( 'Member since %s', 'pild-unified' ), esc_html( $joined ) ); ?></span></div>
          </div>
          <div class="cm-personal-stats-row">
            <div class="cm-pstat"><div class="cm-pstat-num"><?php echo number_format($points); ?></div><div class="cm-pstat-lbl"><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></div></div>
            <div class="cm-pstat"><div class="cm-pstat-num"><?php echo $streak; ?></div><div class="cm-pstat-lbl"><?php esc_html_e( 'Streak', 'pild-unified' ); ?></div></div>
            <div class="cm-pstat"><div class="cm-pstat-num"><?php echo count($badges); ?></div><div class="cm-pstat-lbl"><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></div></div>
          </div>
        </div>
      </div>
      </div><!-- /tab-solo-profile -->

      <!-- TAB: MY TRACKS -->
      <?php if ($has_tracks): ?>
      <div class="cm-panel<?php echo $default_tab === 'solo-home' ? '' : ' cm-panel-hidden'; ?>" id="tab-solo-home">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'My Development Tracks', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Track your progress across all your development paths', 'pild-unified' ); ?></div></div>
        <div class="cm-member-tracks-grid">
          <?php foreach ($enrollments as $enroll):
            $tid=$enroll->track_id; $track=get_post($tid);
            if (!$track||$track->post_status!=='publish') continue;
            // Title + link follow the member's CURRENT browsing language when a
            // translation exists; progress/certificate stay tied to $tid itself
            // (see pild_bilingual_track_display()).
            list($display_track, $track_permalink) = pild_bilingual_track_display($tid, $track);
            $prog=pildcm_get_track_progress($user_id,$tid);
            $deadline=$enroll->deadline??'';
            $is_overdue=$deadline&&strtotime($deadline)<time()&&$prog['pct']<100;
            $is_complete=$prog['pct']>=100;
            $cert_url=pildcm_get_certificate_url($user_id,$tid);
            $cert_url=$cert_url?add_query_arg('solo','1',$cert_url):'';
            // Build public verify URL for LinkedIn (no login required)
            global $wpdb;
            $cert_code_row = $cert_url ? $wpdb->get_var($wpdb->prepare(
                "SELECT certificate_code FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id=%d AND passed='yes' ORDER BY completed_at DESC LIMIT 1",
                $user_id, $tid
            )) : '';
            $cert_verify_url = $cert_code_row ? home_url('/verify-certificate/' . $cert_code_row) : $cert_url;
            $cert_id_clean   = $cert_code_row ?: ('PILD-' . $user_id . '-' . $tid);
            $sc=$is_complete?'complete':($is_overdue?'overdue':'active');
          ?>
          <div class="cm-member-track-card cm-mtrack-<?php echo $sc; ?>">
            <div class="cm-mtrack-top">
              <?php if($is_complete):?><span class="cm-mtrack-status-badge complete"><?php esc_html_e( 'Completed', 'pild-unified' ); ?></span>
              <?php elseif($is_overdue):?><span class="cm-mtrack-status-badge overdue"><?php esc_html_e( 'Overdue', 'pild-unified' ); ?></span>
              <?php else:?><span class="cm-mtrack-status-badge active"><?php esc_html_e( 'In Progress', 'pild-unified' ); ?></span><?php endif;?>
            </div>
            <h3 class="cm-mtrack-title"><?php echo esc_html($display_track->post_title); ?></h3>
            <div class="cm-mtrack-pct-row"><span class="cm-mtrack-pct"><?php echo $prog['pct'];?>%</span><span class="cm-mtrack-playbooks"><?php printf( esc_html__( '%1$d/%2$d Playbooks', 'pild-unified' ), $prog['done'], $prog['total'] ); ?></span></div>
            <div class="cm-mtrack-prog-wrap"><div class="cm-mtrack-prog-bar <?php echo $sc;?>" style="width:<?php echo $prog['pct'];?>%"></div></div>
            <div class="cm-mtrack-actions">
              <a href="<?php echo esc_url($track_permalink);?>" class="cm-btn-primary cm-btn-sm"><?php echo $is_complete?esc_html__('Review Track', 'pild-unified'):($prog['done']>0?esc_html__('Continue →', 'pild-unified'):esc_html__('Start Track →', 'pild-unified'));?></a>
              <?php if($cert_url):?>
                <a href="<?php echo esc_url($cert_url);?>" class="cm-cert-btn" target="_blank">🏅 <?php esc_html_e( 'View Certificate', 'pild-unified' ); ?></a>
                <?php
                  $li_org_solo   = get_bloginfo('name');
                  $li_add_url_s  = 'https://www.linkedin.com/profile/add?' . http_build_query([
                      'startTask'        => 'CERTIFICATION_NAME',
                      'name'             => $display_track->post_title . ' — ' . $li_org_solo,
                      'organizationName' => $li_org_solo,
                      'issueYear'        => date('Y'),
                      'issueMonth'       => date('n'),
                      'certUrl'          => $cert_verify_url,
                      'certId'           => $cert_id_clean,
                  ]);
                  $li_share_text_s = urlencode( sprintf( __( '🏅 I just earned the "%1$s" certificate from %2$s! #Learning #Certificate', 'pild-unified' ), $display_track->post_title, $li_org_solo ) );
                  $li_share_url_s  = 'https://www.linkedin.com/sharing/share-offsite/?url=' . urlencode($cert_verify_url) . '&summary=' . $li_share_text_s;
                ?>
                <a href="<?php echo esc_url($li_add_url_s);?>" class="cm-linkedin-add-btn" target="_blank" rel="noopener">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  <?php esc_html_e( 'Add to Profile', 'pild-unified' ); ?>
                </a>
                <a href="<?php echo esc_url($li_share_url_s);?>" class="cm-linkedin-share-btn" target="_blank" rel="noopener">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  <?php esc_html_e( 'Share', 'pild-unified' ); ?>
                </a>
              <?php endif;?>
            </div>
          </div>
          <?php endforeach;?>
        </div>
      </div>
      <?php endif; ?>

      <!-- TAB: TRACK ARTICLES — articles unlocked by an active enrollment in a Track
           whose Domain matches the article's Category (includes/37-track-articles.php).
           Entirely separate from the "Free Resources & Articles" tab below: these are
           earned by an actual Track purchase, not included with any free plan. -->
      <?php if ($has_track_articles): ?>
      <div class="cm-panel<?php echo $default_tab === 'solo-track-articles' ? '' : ' cm-panel-hidden'; ?>" id="tab-solo-track-articles">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Track Articles', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Articles unlocked by your enrolled Development Tracks', 'pild-unified' ); ?></div>
        </div>
        <div class="cm-articles-grid">
          <?php foreach ($track_articles as $article):
            $thumb     = get_the_post_thumbnail_url($article->ID, 'medium');
            $excerpt   = wp_trim_words($article->post_excerpt ?: wp_strip_all_tags($article->post_content), 20);
            $date      = date_i18n('d M Y', strtotime($article->post_date));
            $cats      = get_the_category($article->ID);
            $cat_label = !empty($cats) ? $cats[0]->name : __('Article', 'pild-unified');
            $read_time = max(1, round(str_word_count(wp_strip_all_tags($article->post_content)) / 200));
          ?>
          <div class="cm-article-card">
            <?php if ($thumb): ?>
              <div class="cm-article-thumb" style="background-image:url('<?php echo esc_url($thumb); ?>')"></div>
            <?php else: ?>
              <div class="cm-article-thumb cm-article-thumb-empty">
                <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              </div>
            <?php endif; ?>
            <div class="cm-article-body">
              <div class="cm-article-meta-row">
                <span class="cm-article-cat"><?php echo esc_html($cat_label); ?></span>
                <span class="cm-article-date"><?php echo esc_html($date); ?></span>
                <span class="cm-article-read"><?php printf( esc_html__( '~%d min read', 'pild-unified' ), $read_time ); ?></span>
              </div>
              <h3 class="cm-article-title"><?php echo esc_html($article->post_title); ?></h3>
              <?php if ($excerpt): ?>
                <p class="cm-article-excerpt"><?php echo esc_html($excerpt); ?></p>
              <?php endif; ?>
              <a href="<?php echo esc_url(get_permalink($article->ID)); ?>" class="cm-btn-primary cm-btn-sm"><?php esc_html_e( 'Read Article →', 'pild-unified' ); ?></a>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- TAB: MY LIBRARY — every Book Store purchase together, regardless of Sector/Domain -->
      <?php if ($has_library): ?>
      <div class="cm-panel<?php echo $default_tab === 'solo-library' ? '' : ' cm-panel-hidden'; ?>" id="tab-solo-library">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'My Library', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Every book you purchased, ready to read', 'pild-unified' ); ?></div></div>
        <div class="cm-member-tracks-grid">
          <?php foreach ($purchased_books as $book): ?>
          <div class="cm-member-track-card cm-mtrack-active" style="display:flex;flex-direction:column;gap:12px;">
            <?php if ($book->thumb): ?>
              <img src="<?php echo esc_url($book->thumb); ?>" alt="<?php echo esc_attr($book->name); ?>" style="width:100%;height:140px;object-fit:cover;border-radius:8px;">
            <?php endif; ?>
            <span class="cm-level-badge"><?php echo esc_html($book->cat_label); ?></span>
            <h3 class="cm-mtrack-title" style="margin:0;"><?php echo esc_html($book->name); ?></h3>
            <?php if ($book->short_desc): ?>
              <p style="font-size:13px;color:var(--cm-text-muted);margin:0;line-height:1.5;"><?php echo esc_html(wp_trim_words($book->short_desc, 15)); ?></p>
            <?php endif; ?>
            <div class="cm-mtrack-actions" style="margin-top:auto;display:flex;gap:8px;flex-wrap:wrap;">
              <?php if ($book->url_ar && $book->url_en):
                // The button matching the member's CURRENT browsing language is
                // highlighted (primary); the other edition stays one tap away
                // as a proper secondary button — both always open the book,
                // never plain unstyled text.
                $current_lang = function_exists('pll_current_language') ? pll_current_language() : '';
                $ar_class = $current_lang === 'en' ? 'cm-btn-secondary' : 'cm-btn-primary';
                $en_class = $current_lang === 'en' ? 'cm-btn-primary' : 'cm-btn-secondary';
              ?>
                <a href="<?php echo esc_url($book->url_ar); ?>" class="<?php echo esc_attr($ar_class); ?> cm-btn-sm">📖 <?php esc_html_e( 'Read in Arabic', 'pild-unified' ); ?></a>
                <a href="<?php echo esc_url($book->url_en); ?>" class="<?php echo esc_attr($en_class); ?> cm-btn-sm">📖 <?php esc_html_e( 'Read in English', 'pild-unified' ); ?></a>
              <?php else: ?>
                <a href="<?php echo esc_url($book->url); ?>" class="cm-btn-primary cm-btn-sm">📖 <?php esc_html_e( 'Read Now', 'pild-unified' ); ?></a>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- TAB: PURCHASED PRODUCTS — one independent tab per category -->
      <?php foreach ($product_groups as $cat_label => $items):
          $tab_id = 'solo-products-' . sanitize_title($cat_label);
      ?>
      <div class="cm-panel<?php echo $default_tab === $tab_id ? '' : ' cm-panel-hidden'; ?>" id="tab-<?php echo esc_attr($tab_id); ?>">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php echo esc_html($cat_label); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Items you purchased individually in this category', 'pild-unified' ); ?></div></div>
        <div class="cm-member-tracks-grid">
          <?php foreach ($items as $prod): ?>
          <div class="cm-member-track-card cm-mtrack-active" style="display:flex;flex-direction:column;gap:12px;">
            <?php if ($prod->thumb): ?>
              <img src="<?php echo esc_url($prod->thumb); ?>" alt="<?php echo esc_attr($prod->name); ?>" style="width:100%;height:140px;object-fit:cover;border-radius:8px;">
            <?php endif; ?>
            <span class="cm-level-badge"><?php echo esc_html($prod->cat_label); ?></span>
            <h3 class="cm-mtrack-title" style="margin:0;"><?php echo esc_html($prod->name); ?></h3>
            <?php if ($prod->short_desc): ?>
              <p style="font-size:13px;color:var(--cm-text-muted);margin:0;line-height:1.5;"><?php echo esc_html(wp_trim_words($prod->short_desc, 15)); ?></p>
            <?php endif; ?>
            <div class="cm-mtrack-actions" style="margin-top:auto;">
              <a href="<?php echo esc_url($prod->url); ?>" class="cm-btn-primary cm-btn-sm">📖 <?php esc_html_e( 'Read Now', 'pild-unified' ); ?></a>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- TAB: ACHIEVEMENTS -->
      <div class="cm-panel<?php echo $default_tab === 'solo-badges' ? '' : ' cm-panel-hidden'; ?>" id="tab-solo-badges">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'Achievements', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Your earned achievement badges and locked achievements', 'pild-unified' ); ?></div></div>
        <div class="cm-achievements-grid">
          <?php $earned_keys=array_column((array)$badges,'badge_key');
          foreach($badges_cfg as $key=>$cfg): $earned=in_array($key,$earned_keys);?>
          <div class="cm-achievement-card <?php echo !$earned?'locked':'earned';?>">
            <div class="cm-achievement-icon"><?php echo $cfg['icon'];?></div>
            <div class="cm-achievement-label"><?php echo esc_html($cfg['label']);?></div>
            <div class="cm-achievement-desc"><?php echo esc_html($cfg['desc']);?></div>
            <?php if($earned):?><div class="cm-achievement-earned-badge"><?php esc_html_e( 'Earned', 'pild-unified' ); ?></div><?php endif;?>
          </div>
          <?php endforeach;?>
        </div>
      </div>

      <!-- TAB: LEADERSHIP ASSESSMENT (free, self-report — includes/42-leadership-assessment.php) -->
      <div class="cm-panel<?php echo $default_tab === 'solo-la-assessment' ? '' : ' cm-panel-hidden'; ?>" id="tab-la-assessment">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['tab_label'] : 'التقييم القيادي' ); ?></div><div class="cm-panel-desc"><?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['panel_desc'] : 'ملفك القيادي الشخصي المجاني' ); ?></div></div>
        <?php echo function_exists('pild_la_render_assessment_tab') ? pild_la_render_assessment_tab($user_id) : ''; ?>
      </div>

      <!-- TAB: MY TEAM (free invite system — includes/42-leadership-assessment.php) -->
      <div class="cm-panel<?php echo $default_tab === 'solo-la-team' ? '' : ' cm-panel-hidden'; ?>" id="tab-la-team">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['team_tab_label'] : 'My Team' ); ?></div><div class="cm-panel-desc"><?php echo esc_html( function_exists('pild_la_strings') ? pild_la_strings()['team_panel_desc'] : 'ادعُ زملاءك لأخذ التقييم القيادي المجاني وتابع نتائجهم من هنا' ); ?></div></div>
        <?php echo function_exists('pild_la_render_team_tab') ? pild_la_render_team_tab($user_id) : ''; ?>
      </div>

      <!-- TAB: FREE RESOURCES & ARTICLES -->
      <?php if ($has_free): ?>
      <div class="cm-panel<?php echo $default_tab === 'solo-articles' ? '' : ' cm-panel-hidden'; ?>" id="tab-solo-articles">
        <div class="cm-panel-header">
          <div class="cm-panel-title"><?php esc_html_e( 'Free Resources & Articles', 'pild-unified' ); ?></div>
          <div class="cm-panel-desc"><?php esc_html_e( 'Articles and playbooks included in your free membership', 'pild-unified' ); ?></div>
        </div>
        <?php
        // Merge articles + free-plan playbooks into one unified, date-sorted list.
        // Each card is labeled with its category name (articles: WP category, playbooks: "Playbook").
        $free_items = [];
        foreach ($free_articles as $article) {
            $cats = get_the_category($article->ID);
            $free_items[] = [
                'id'        => $article->ID,
                'type'      => 'article',
                'title'     => $article->post_title,
                'thumb'     => get_the_post_thumbnail_url($article->ID, 'medium'),
                'excerpt'   => wp_trim_words($article->post_excerpt ?: wp_strip_all_tags($article->post_content), 20),
                'date'      => $article->post_date,
                'cat_label' => !empty($cats) ? $cats[0]->name : __('Article', 'pild-unified'),
                'read_time' => max(1, round(str_word_count(wp_strip_all_tags($article->post_content)) / 200)),
                'url'       => get_permalink($article->ID),
            ];
        }
        foreach ($free_playbooks as $playbook) {
            $free_items[] = [
                'id'        => $playbook->ID,
                'type'      => 'playbook',
                'title'     => $playbook->post_title,
                'thumb'     => get_the_post_thumbnail_url($playbook->ID, 'medium'),
                'excerpt'   => wp_trim_words($playbook->post_excerpt ?: wp_strip_all_tags($playbook->post_content), 20),
                'date'      => $playbook->post_date,
                'cat_label' => __('Playbook', 'pild-unified'),
                'read_time' => max(1, round(str_word_count(wp_strip_all_tags($playbook->post_content)) / 200)),
                'url'       => get_permalink($playbook->ID),
            ];
        }
        usort($free_items, function ($a, $b) { return strtotime($b['date']) <=> strtotime($a['date']); });
        ?>
        <div class="cm-articles-grid">
          <?php foreach ($free_items as $item): ?>
          <div class="cm-article-card">
            <?php if ($item['thumb']): ?>
              <div class="cm-article-thumb" style="background-image:url('<?php echo esc_url($item['thumb']); ?>')"></div>
            <?php else: ?>
              <div class="cm-article-thumb cm-article-thumb-empty">
                <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              </div>
            <?php endif; ?>
            <div class="cm-article-body">
              <div class="cm-article-meta-row">
                <span class="cm-article-cat"><?php echo esc_html($item['cat_label']); ?></span>
                <span class="cm-article-date"><?php echo esc_html(date_i18n('d M Y', strtotime($item['date']))); ?></span>
                <span class="cm-article-read"><?php printf( esc_html__( '~%d min read', 'pild-unified' ), $item['read_time'] ); ?></span>
              </div>
              <h3 class="cm-article-title"><?php echo esc_html($item['title']); ?></h3>
              <?php if ($item['excerpt']): ?>
                <p class="cm-article-excerpt"><?php echo esc_html($item['excerpt']); ?></p>
              <?php endif; ?>
              <a href="<?php echo esc_url($item['url']); ?>" class="cm-btn-primary cm-btn-sm"><?php echo $item['type'] === 'playbook' ? esc_html__('Open Playbook →', 'pild-unified') : esc_html__('Read Article →', 'pild-unified'); ?></a>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- TAB: BILLING (SOLO) -->
      <div class="cm-panel cm-panel-hidden" id="tab-solo-billing">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'Billing & Invoices', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Your orders and payment history', 'pild-unified' ); ?></div></div>
        <?php $solo_orders=wc_get_orders(['customer'=>$user_id,'limit'=>20,'orderby'=>'date','order'=>'DESC']); ?>
        <?php if(empty($solo_orders)):?>
          <div class="cm-empty"><?php esc_html_e( 'No orders found.', 'pild-unified' ); ?></div>
        <?php else:?>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;font-size:13px;">
            <thead><tr style="border-bottom:2px solid var(--cm-border);">
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Order #', 'pild-unified' ); ?></th>
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Date', 'pild-unified' ); ?></th>
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Items', 'pild-unified' ); ?></th>
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Total', 'pild-unified' ); ?></th>
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Status', 'pild-unified' ); ?></th>
              <th style="text-align:left;padding:10px 12px;color:var(--cm-text-muted);font-weight:600;"><?php esc_html_e( 'Invoice', 'pild-unified' ); ?></th>
            </tr></thead>
            <tbody>
            <?php foreach($solo_orders as $order):
              $smap=['completed'=>'#10B981','processing'=>'#3B82F6','pending'=>'#F59E0B','cancelled'=>'#EF4444','refunded'=>'#6B7280'];
              $sc=$smap[$order->get_status()]??'#6B7280';
              $items_list=implode(', ',array_map(fn($i)=>$i->get_name(),$order->get_items()));
            ?>
              <tr style="border-bottom:1px solid var(--cm-border);">
                <td style="padding:12px;font-weight:600;color:var(--cm-text);">#<?php echo $order->get_order_number();?></td>
                <td style="padding:12px;color:var(--cm-text-muted);"><?php echo date_i18n('d M Y',strtotime($order->get_date_created()));?></td>
                <td style="padding:12px;color:var(--cm-text);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?php echo esc_attr($items_list);?>"><?php echo esc_html($items_list);?></td>
                <td style="padding:12px;font-weight:600;color:var(--cm-text);"><?php echo $order->get_formatted_order_total();?></td>
                <td style="padding:12px;"><span style="font-size:11px;font-weight:600;color:<?php echo $sc;?>;background:<?php echo $sc;?>20;padding:3px 8px;border-radius:20px;text-transform:uppercase;"><?php echo esc_html($order->get_status());?></span></td>
                <td style="padding:12px;"><a href="<?php echo esc_url($order->get_view_order_url());?>" target="_blank" style="color:var(--cm-accent);font-size:12px;font-weight:600;text-decoration:none;"><?php esc_html_e( 'View →', 'pild-unified' ); ?></a></td>
              </tr>
            <?php endforeach;?>
            </tbody>
          </table>
        </div>
        <?php endif;?>
      </div>

      <!-- TAB: SETTINGS -->
      <div class="cm-panel cm-panel-hidden" id="tab-solo-settings">
        <div class="cm-panel-header"><div class="cm-panel-title"><?php esc_html_e( 'My Settings', 'pild-unified' ); ?></div><div class="cm-panel-desc"><?php esc_html_e( 'Update your personal profile', 'pild-unified' ); ?></div></div>
        <div class="cm-settings-layout">
          <div class="cm-settings-section">
            <div class="cm-settings-section-title"><?php esc_html_e( 'Personal Profile', 'pild-unified' ); ?></div>
            <div class="cm-settings-avatar-row">
              <div class="cm-settings-avatar" id="solo-avatar-preview">
                <?php if($avatar_url):?><img src="<?php echo esc_url($avatar_url);?>" alt="avatar"><?php else:?><span><?php echo strtoupper(substr($user->display_name,0,1));?></span><?php endif;?>
              </div>
              <div>
                <label class="cm-upload-btn"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> <?php esc_html_e( 'Upload Photo', 'pild-unified' ); ?><input type="file" id="solo-avatar-input" accept="image/*" style="display:none"></label>
                <p class="cm-upload-hint"><?php esc_html_e( 'PNG, JPG — max 2MB', 'pild-unified' ); ?></p>
              </div>
            </div>
            <div class="cm-settings-fields">
              <div class="cm-settings-field"><label><?php esc_html_e( 'Full Name', 'pild-unified' ); ?></label><input type="text" id="solo-display-name" value="<?php echo esc_attr($user->display_name);?>" placeholder="<?php esc_attr_e( 'Your full name', 'pild-unified' ); ?>"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Phone Number', 'pild-unified' ); ?></label><input type="text" id="solo-phone" value="<?php echo esc_attr($phone);?>" placeholder="+1 234 567 8900"></div>
            </div>
            <p class="cm-upload-hint" style="margin-top:.5rem"><?php printf( wp_kses( __( 'Job title, bio, and country now live on your %s page (bilingual).', 'pild-unified' ), ['a' => ['href' => []]] ), '<a href="' . esc_url( function_exists('pildcm_edit_profile_url') ? pildcm_edit_profile_url() : '#' ) . '">' . esc_html__( 'Professional Profile', 'pild-unified' ) . '</a>' ); ?></p>
          </div>
          <div class="cm-settings-footer">
            <button class="cm-btn-primary cm-btn-save" id="solo-save-settings"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> <?php esc_html_e( 'Save Changes', 'pild-unified' ); ?></button>
            <span id="solo-settings-msg"></span>
          </div>
          <div class="cm-settings-section" style="margin-top:2rem">
            <div class="cm-settings-section-title"><?php esc_html_e( 'Public Professional Profile', 'pild-unified' ); ?></div>
            <p class="cm-upload-hint" style="margin-bottom:.75rem"><?php esc_html_e( 'Turn this on to get a shareable link showing your completed tracks, Practice Area certificates, badges, and points — perfect for LinkedIn or your CV. Off by default; only you can turn it on.', 'pild-unified' ); ?></p>
            <label style="display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem">
              <input type="checkbox" id="solo-profile-public" <?php checked(get_user_meta($user->ID, 'pild_profile_public', true), 'yes'); ?>>
              <span><?php esc_html_e( 'Make my profile public', 'pild-unified' ); ?></span>
            </label>
            <div class="cm-settings-field cm-field-full">
              <label><?php esc_html_e( 'Custom Link (optional)', 'pild-unified' ); ?></label>
              <div style="display:flex;align-items:center;gap:.4rem">
                <span style="color:#888;font-size:.9rem;white-space:nowrap"><?php echo esc_html(home_url('/profile/')); ?></span>
                <input type="text" id="solo-profile-slug" value="<?php echo esc_attr(get_user_meta($user->ID, 'pild_profile_slug', true));?>" placeholder="<?php echo esc_attr($user->user_nicename); ?>">
              </div>
              <p class="cm-upload-hint" id="solo-slug-hint"><?php esc_html_e( 'Pick your own link, e.g. your full name instead of the auto-generated username. Leave blank to keep the default.', 'pild-unified' ); ?></p>
            </div>
            <div class="cm-settings-field cm-field-full">
              <label><?php esc_html_e( 'Your Public Link', 'pild-unified' ); ?></label>
              <div style="display:flex;gap:.5rem">
                <input type="text" readonly id="solo-public-profile-url" value="<?php echo esc_attr(function_exists('pildcm_get_public_profile_url') ? pildcm_get_public_profile_url($user->ID) : ''); ?>">
                <button type="button" class="cm-btn-primary" id="solo-copy-profile-url"><?php esc_html_e( 'Copy', 'pild-unified' ); ?></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="cm-toast" class="cm-toast cm-toast-hidden"></div>
    <script>(function($){
      $('.cm-tab').on('click',function(){$('.cm-tab').removeClass('cm-tab-active');$(this).addClass('cm-tab-active');$('.cm-panel').addClass('cm-panel-hidden');$('#tab-'+$(this).data('tab')).removeClass('cm-panel-hidden');pildcmScrollToPanel('tab-'+$(this).data('tab'));});
      function pildcmScrollToPanel(panelId){var target=document.getElementById(panelId);if(!target)return;var headerOffset=document.body.classList.contains('admin-bar')?122:90;var top=target.getBoundingClientRect().top+window.pageYOffset-headerOffset;window.scrollTo({top:Math.max(top,0),behavior:'smooth'});}
      document.getElementById('solo-avatar-input')?.addEventListener('change',function(){if(!this.files[0])return;var r=new FileReader();r.onload=e=>{document.getElementById('solo-avatar-preview').innerHTML='<img src="'+e.target.result+'" alt="avatar">';};r.readAsDataURL(this.files[0]);});
      document.getElementById('solo-copy-profile-url')?.addEventListener('click',function(){var inp=document.getElementById('solo-public-profile-url');inp.select();navigator.clipboard.writeText(inp.value).then(()=>{var t=this.textContent;this.textContent=pildcm_ajax.i18n.copied;setTimeout(()=>{this.textContent=t;},1500);});});
      document.getElementById('solo-save-settings')?.addEventListener('click',function(){
        var btn=this,msg=document.getElementById('solo-settings-msg');btn.disabled=true;
        var fd=new FormData();fd.append('action','pildcm_save_member_settings');fd.append('nonce',pildcm_ajax.nonce);
        fd.append('display_name',document.getElementById('solo-display-name').value);fd.append('phone',document.getElementById('solo-phone').value);
        fd.append('profile_slug',document.getElementById('solo-profile-slug').value);
        fd.append('profile_public',document.getElementById('solo-profile-public').checked?'yes':'no');
        var af=document.getElementById('solo-avatar-input').files[0];if(af)fd.append('avatar',af);
        fetch(pildcm_ajax.ajax_url,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{msg.textContent=res.success?pildcm_ajax.i18n.profile_updated:'✗ '+(res.data?.message||pildcm_ajax.i18n.error);msg.className='cm-settings-status '+(res.success?'ok':'err');btn.disabled=false;if(res.success)setTimeout(()=>location.reload(),1500);}).catch(()=>{msg.textContent=pildcm_ajax.i18n.connection_failed;btn.disabled=false;});
      });
    })(jQuery);</script>
    <?php
    return ob_get_clean();
}

