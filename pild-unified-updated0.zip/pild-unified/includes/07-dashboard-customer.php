<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// NOTE: The standalone "Customer Dashboard" ([pild_customer_dashboard])
// has been removed. Any customer who registers or purchases anything
// (a free package, a paid package, a book, or an assessment) is now
// routed to the unified Independent Member Dashboard
// ([pild_solo_dashboard] in 06-dashboard-solo.php), which dynamically
// shows only the tabs the member actually has access to (Tracks,
// Books & Assessments, Free Resources, Achievements, Billing, Settings).
// See pild_get_user_dashboard_url() in pild-unified.php and the
// redirect helpers in 03-ajax.php.
// ============================================================

// ============================================================
// 17. SHORTCODE — [pild_my_badges]
// ============================================================
add_shortcode('pild_my_badges', 'pildcm_my_badges_shortcode');
function pildcm_my_badges_shortcode() {
    if (!is_user_logged_in()) return '';
    $uid        = get_current_user_id();
    $points     = pildcm_get_user_points($uid);
    $badges     = pildcm_get_user_badges($uid);
    $badges_cfg = pildcm_badges_config();
    $streak     = pildcm_get_streak($uid);

    ob_start();
    echo pildcm_css();
    ?>
    <div class="cm-student-gamification">
      <div class="cm-sg-stats">
        <div class="cm-sg-stat"><span class="cm-sg-num"><?php echo number_format($points); ?></span><span class="cm-sg-lbl">Total Development Points</span></div>
        <div class="cm-sg-stat"><span class="cm-sg-num"><?php echo $streak; ?></span><span class="cm-sg-lbl">Day Streak 🔥</span></div>
        <div class="cm-sg-stat"><span class="cm-sg-num"><?php echo count($badges); ?></span><span class="cm-sg-lbl">Achievement Badges Earned</span></div>
      </div>
      <div class="cm-achievements-grid" style="margin-top:2rem">
        <?php
        $earned_keys = array_column($badges, 'badge_key');
        foreach ($badges_cfg as $key => $cfg):
            $earned = in_array($key, $earned_keys);
        ?>
        <div class="cm-achievement-card <?php echo !$earned ? 'locked' : 'earned'; ?>">
          <div class="cm-achievement-icon"><?php echo $cfg['icon']; ?></div>
          <div class="cm-achievement-label"><?php echo esc_html($cfg['label']); ?></div>
          <div class="cm-achievement-desc"><?php echo esc_html($cfg['desc']); ?></div>
          <?php if ($earned): ?><div class="cm-achievement-earned-badge">Earned</div><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php
    return ob_get_clean();
}

