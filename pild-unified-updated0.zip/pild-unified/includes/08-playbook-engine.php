<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 18. ENROLLMENT DISPLAY ON TRACK PAGES
// ============================================================
add_filter('the_content', 'pildcm_show_enrollment_count', 15);
function pildcm_show_enrollment_count($content) {
    if (!is_singular('track')) return $content;
    global $post, $wpdb;
    $count = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}pild_enrollments WHERE track_id=%d AND status='active'",
        $post->ID
    ));
    if (!$count) return $content;
    $badge = '<div style="display:inline-flex;align-items:center;gap:.4rem;font-size:.75rem;color:#0E6655;background:rgba(14,102,85,.08);border:1px solid rgba(14,102,85,.2);padding:.3rem .85rem;border-radius:99px;margin-bottom:1rem;">
        <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
        ' . $count . ' learner' . ($count !== 1 ? 's' : '') . ' enrolled</div>';
    return $badge . $content;
}

// ============================================================
// 18b. PLAYBOOK COMPLETION BUTTON
// Injects a "Mark as Complete" button at the bottom of every
// playbook page. Turns green with a checkmark once clicked.
// ============================================================
add_filter('the_content', 'pildcm_inject_playbook_complete_button', 20);
function pildcm_inject_playbook_complete_button($content) {
    if (!is_singular('playbook') || !is_user_logged_in()) return $content;

    global $post, $wpdb;
    $user_id    = get_current_user_id();
    $playbook_id  = $post->ID;
    $program_id = (int) get_post_meta($playbook_id, 'playbook_program', true);
    $track_id   = $program_id ? (int) get_post_meta($program_id, 'program_track', true) : 0;

    // Check completion across BOTH language editions of this playbook — a
    // step finished while reading the Arabic track must already show as
    // done when the member switches to English (and vice versa).
    $playbook_ids_bi = pild_bilingual_post_ids($playbook_id);
    $ph = implode(',', array_fill(0, count($playbook_ids_bi), '%d'));
    $done = (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND playbook_id IN ($ph) LIMIT 1",
        array_merge([$user_id], $playbook_ids_bi)
    ));

    $nonce    = wp_create_nonce('pildcm_nonce');
    $ajax_url = esc_url(admin_url('admin-ajax.php'));

    if ($done) {
        $btn_html = '<button id="pildcm-playbook-btn" disabled style="background:#0E6655;color:#fff;cursor:default;opacity:0.85;border:none;padding:14px 36px;border-radius:8px;font-size:1rem;font-weight:600;">✅ Playbook Completed</button>';
    } else {
        $btn_html = '<button id="pildcm-playbook-btn"
            data-playbook="' . esc_attr($playbook_id) . '"
            data-program="' . esc_attr($program_id) . '"
            data-track="' . esc_attr($track_id) . '"
            data-nonce="' . esc_attr($nonce) . '"
            style="background:#0E6655;color:#fff;cursor:pointer;border:none;padding:14px 36px;border-radius:8px;font-size:1rem;font-weight:600;transition:all .3s;">
            ✔ Mark as Complete
        </button>';
    }

    $button = '<div id="pildcm-playbook-wrap" style="margin-top:2rem;text-align:center;">'
        . $btn_html
        . '<div id="pildcm-playbook-msg" style="margin-top:.75rem;font-size:.9rem;color:#0E6655;font-weight:500;"></div>'
        . '</div>';

    if (!$done) {
        $button .= '<script>
(function(){
    var btn = document.getElementById("pildcm-playbook-btn");
    if (!btn) return;
    btn.addEventListener("click", function(){
        btn.disabled = true;
        btn.textContent = "⏳ Saving…";
        var fd = new FormData();
        fd.append("action",     "pildcm_mark_playbook_complete");
        fd.append("nonce",      btn.dataset.nonce);
        fd.append("playbook_id",  btn.dataset.playbook);
        fd.append("program_id", btn.dataset.program);
        fd.append("track_id",   btn.dataset.track);
        fetch("' . $ajax_url . '", {method:"POST",body:fd})
            .then(function(r){ return r.json(); })
            .then(function(res){
                if (res.success) {
                    btn.textContent = "✅ Playbook Completed";
                    btn.style.cursor = "default";
                    document.getElementById("pildcm-playbook-msg").textContent = res.data && res.data.message ? res.data.message : "";
                } else {
                    btn.disabled = false;
                    btn.textContent = "✔ Mark as Complete";
                    document.getElementById("pildcm-playbook-msg").textContent = "Error: " + (res.data || "Please try again");
                }
            })
            .catch(function(){
                btn.disabled = false;
                btn.textContent = "✔ Mark as Complete";
                document.getElementById("pildcm-playbook-msg").textContent = "Connection error. Please try again.";
            });
    });
})();
</script>';
    }

    return $content . $button;
}

// ============================================================
// 18c. AJAX — Record playbook in pild_progress, award points,
//            check and grant all applicable badges.
// ============================================================
add_action('wp_ajax_pildcm_mark_playbook_complete', 'pildcm_ajax_mark_playbook_complete');
function pildcm_ajax_mark_playbook_complete() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');

    global $wpdb;
    $user_id    = get_current_user_id();
    $playbook_id  = (int) ($_POST['playbook_id']  ?? 0);
    $program_id = (int) ($_POST['program_id'] ?? 0);
    $track_id   = (int) ($_POST['track_id']   ?? 0);

    if (!$playbook_id) wp_send_json_error('Invalid playbook');

    // Resolve program/track from meta if not passed
    if (!$program_id) $program_id = (int) get_post_meta($playbook_id, 'playbook_program', true);
    if (!$track_id && $program_id) $track_id = (int) get_post_meta($program_id, 'program_track', true);

    // Must be enrolled — accept either a pild_enrollments row OR direct WC Memberships access (solo members)
    if ($track_id && !pildcm_is_enrolled($user_id, $track_id)) {
        $has_membership_access = false;
        if (function_exists('wc_memberships_user_can')) {
            $has_membership_access = wc_memberships_user_can($user_id, 'view', ['post' => $track_id]);
        }
        if (!$has_membership_access) {
            wp_send_json_error('Not enrolled in this track');
        }
    }

    // Prevent duplicate — same bilingual check as the button render above,
    // so completing the Arabic edition and then (re)clicking on the English
    // edition never inserts a second row, double-awards points, or re-fires
    // the "first playbook" / streak badges.
    $playbook_ids_bi = pild_bilingual_post_ids($playbook_id);
    $ph = implode(',', array_fill(0, count($playbook_ids_bi), '%d'));
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND playbook_id IN ($ph) LIMIT 1",
        array_merge([$user_id], $playbook_ids_bi)
    ));
    if ($exists) wp_send_json_success(['message' => 'Already completed']);

    // ── 1. Record progress ─────────────────────────────────────
    $wpdb->insert("{$wpdb->prefix}pild_progress", [
        'user_id'      => $user_id,
        'playbook_id'    => $playbook_id,
        'program_id'   => $program_id,
        'track_id'     => $track_id,
        'completed_at' => current_time('mysql'),
    ]);

    // ── 2. Points for playbook ───────────────────────────────────
    $pts_cfg = pildcm_points_config();
    $wpdb->insert("{$wpdb->prefix}pild_points", [
        'user_id'   => $user_id,
        'points'    => $pts_cfg['playbook_complete'],
        'reason'    => 'playbook_complete',
        'ref_id'    => $playbook_id,
        'earned_at' => current_time('mysql'),
    ]);
    $message = '+' . $pts_cfg['playbook_complete'] . ' points';

    // Helper: insert badge once
    $award_badge = function($key, $ref = 0) use ($wpdb, $user_id) {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_badges WHERE user_id=%d AND badge_key=%s AND ref_id=%d LIMIT 1",
            $user_id, $key, $ref
        ));
        if (!$exists) {
            $wpdb->insert("{$wpdb->prefix}pild_badges", [
                'user_id'   => $user_id,
                'badge_key' => $key,
                'ref_id'    => $ref,
                'earned_at' => current_time('mysql'),
            ]);
            return true;
        }
        return false;
    };

    // ── 3. first_playbook badge ──────────────────────────────────
    $total_playbooks = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d", $user_id
    ));
    if ($total_playbooks === 1 && $award_badge('first_playbook')) {
        $message .= ' · 🌱 Badge: First Step!';
    }

    // ── 4. fast_learner badge (5 playbooks today) ────────────────
    $today = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND DATE(completed_at)=CURDATE()",
        $user_id
    ));
    if ($today >= 5 && $award_badge('fast_learner')) {
        $message .= ' · ⚡ Badge: Fast Learner!';
    }

    // ── 5. early_bird badge (before 08:00) ─────────────────────
    if ((int) date('G') < 8 && $award_badge('early_bird')) {
        $message .= ' · 🌅 Badge: Early Bird!';
    }

    // ── 6. streak badges ───────────────────────────────────────
    $streak = pildcm_get_streak($user_id);
    if ($streak >= 7  && $award_badge('streak_7'))  $message .= ' · 🔥 7-Day Streak!';
    if ($streak >= 30 && $award_badge('streak_30')) $message .= ' · ⚡ 30-Day Streak!';

    // ── 7. track_finisher badge + bonus points ─────────────────
    if ($track_id) {
        $prog = pildcm_get_track_progress($user_id, $track_id);
        // Bonus points / badge / certificate are keyed to the bilingual GROUP,
        // not the specific track_id this request happened to fire on — so
        // finishing the track (in whichever mix of languages) awards them
        // exactly once, instead of once per language edition.
        $track_ids_bi   = pild_bilingual_post_ids($track_id);
        $track_ph       = implode(',', array_fill(0, count($track_ids_bi), '%d'));
        $track_group_id = pild_bilingual_group_key($track_id);
        if ($prog['pct'] >= 100) {
            // Bonus points (once)
            $track_pts_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_points WHERE user_id=%d AND reason='track_complete' AND ref_id IN ($track_ph) LIMIT 1",
                array_merge([$user_id], $track_ids_bi)
            ));
            if (!$track_pts_exists) {
                $wpdb->insert("{$wpdb->prefix}pild_points", [
                    'user_id'   => $user_id,
                    'points'    => $pts_cfg['track_complete'],
                    'reason'    => 'track_complete',
                    'ref_id'    => $track_id,
                    'earned_at' => current_time('mysql'),
                ]);
                $message .= ' · Track complete! +' . $pts_cfg['track_complete'] . ' bonus points';
            }
            if ($award_badge('track_finisher', $track_group_id)) {
                $message .= ' · 🏁 Badge: Track Finisher!';
            }

            // ── 8. Auto-certificate for tracks without a quiz ──────
            // Only generate if no quiz-based certificate already exists
            // for THIS track or its translation.
            $existing_cert = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id IN ($track_ph) AND passed='yes' LIMIT 1",
                array_merge([$user_id], $track_ids_bi)
            ));
            if (!$existing_cert) {
                // Check if track has a linked quiz — if yes, skip (quiz will generate its own cert)
                $linked_quiz = get_post_meta($track_id, 'track_quiz_id', true);
                if (!$linked_quiz) {
                    $cert_code = strtoupper(wp_generate_password(12, false));
                    $user_obj  = get_userdata($user_id);
                    $cert_data = [
                        'user_name'   => $user_obj ? $user_obj->display_name : '',
                        'track_title' => pild_bilingual_title($track_id),
                        'score'       => 100,
                    ];
                    $cert_url = '';
                    if (function_exists('pildcm_generate_branded_certificate')) {
                        $cert_url = pildcm_generate_branded_certificate($user_id, $track_id, 0, 100, $cert_code, $cert_data);
                    }
                    $wpdb->insert("{$wpdb->prefix}pild_results", [
                        'user_id'          => $user_id,
                        'track_id'         => $track_id,
                        'score'            => 100,
                        'total_questions'  => 0,
                        'passed'           => 'yes',
                        'certificate_code' => $cert_code,
                        'certificate_url'  => $cert_url ?: home_url('/certificate/' . $cert_code),
                        'completed_at'     => current_time('mysql'),
                    ]);
                    $award_badge('certified');
                    $message .= ' · 🏅 Certificate issued!';
                }
            }
        }
    }

    wp_send_json_success(['message' => $message]);
}