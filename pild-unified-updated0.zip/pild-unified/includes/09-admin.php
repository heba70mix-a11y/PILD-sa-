<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 19. ADMIN PAGE
// ------------------------------------------------------------
// PHASE 9: was capped at 500 rows with zero filters and no export — an
// admin with more than 500 active enrollments simply couldn't see the
// rest. Rewritten with: track/status/search filters, real pagination,
// and a CSV export that respects whichever filters are currently set
// (not just "export everything").
// ============================================================
add_action('admin_menu', 'pildcm_admin_menu');
function pildcm_admin_menu() {
    add_submenu_page('pild-settings', 'Enrollment Report', 'Enrollment Report',
        'manage_options', 'pild-enrollments', 'pildcm_enrollment_admin_page');
    add_submenu_page('pild-settings', 'Audit Log', 'Audit Log',
        'manage_options', 'pild-audit-log', 'pildcm_audit_log_admin_page');
}

// PHASE 10: who assigned/removed which seat or track, and when — the
// question "how many seats did we actually use last month" now has a
// real answer instead of needing to be reconstructed by hand.
function pildcm_audit_log_admin_page() {
    global $wpdb;
    $per_page = 50;
    $paged    = max(1, (int) ($_GET['paged'] ?? 1));
    $action_filter = sanitize_text_field($_GET['audit_action'] ?? '');

    $where  = ['1=1'];
    $params = [];
    if ($action_filter) { $where[] = 'l.action = %s'; $params[] = $action_filter; }

    $total = (int) ($params
        ? $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}pild_audit_log l WHERE " . implode(' AND ', $where), $params))
        : $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}pild_audit_log l WHERE " . implode(' AND ', $where)));

    $sql = "SELECT l.*, a.display_name as actor_name, s.display_name as subject_name, t.name as team_name
            FROM {$wpdb->prefix}pild_audit_log l
            LEFT JOIN {$wpdb->users} a ON a.ID = l.actor_id
            LEFT JOIN {$wpdb->users} s ON s.ID = l.subject_user_id
            LEFT JOIN {$wpdb->prefix}pild_teams t ON t.id = l.team_id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY l.created_at DESC LIMIT %d OFFSET %d";
    $params[] = $per_page; $params[] = ($paged - 1) * $per_page;
    $rows = $wpdb->get_results($wpdb->prepare($sql, $params));
    $total_pages = max(1, ceil($total / $per_page));

    $action_labels = [
        'team_created'      => '🆕 Team purchased',
        'seat_assigned'     => '➕ Seat assigned',
        'seat_removed'      => '➖ Seat removed',
        'track_assigned'    => '📘 Track assigned',
        'track_unassigned'  => '📕 Track unassigned',
    ];
    ?>
    <div class="wrap">
      <h1>🕓 PILD Audit Log</h1>
      <p><?php esc_html_e('Every seat and track assignment change, with who did it and when.', 'pild-unified'); ?></p>

      <form method="get" style="display:flex;gap:10px;align-items:center;margin:16px 0;">
        <input type="hidden" name="page" value="pild-audit-log" />
        <select name="audit_action">
          <option value=""><?php esc_html_e('All Actions', 'pild-unified'); ?></option>
          <?php foreach ($action_labels as $key => $label): ?>
            <option value="<?php echo esc_attr($key); ?>" <?php selected($action_filter, $key); ?>><?php echo esc_html($label); ?></option>
          <?php endforeach; ?>
        </select>
        <button class="button button-primary"><?php esc_html_e('Filter', 'pild-unified'); ?></button>
      </form>

      <table class="widefat fixed striped">
        <thead><tr><th style="width:160px;">When</th><th>Action</th><th>Actor</th><th>Subject</th><th>Team</th><th>Track</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td><?php echo esc_html($r->created_at); ?></td>
            <td><?php echo esc_html($action_labels[$r->action] ?? $r->action); ?></td>
            <td><?php echo esc_html($r->actor_name ?: '#' . $r->actor_id); ?></td>
            <td><?php echo $r->subject_user_id ? esc_html($r->subject_name ?: '#' . $r->subject_user_id) : '—'; ?></td>
            <td><?php echo $r->team_id ? esc_html($r->team_name ?: '#' . $r->team_id) : '—'; ?></td>
            <td><?php echo $r->track_id ? esc_html(get_the_title($r->track_id)) : '—'; ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($rows)): ?>
          <tr><td colspan="6"><?php esc_html_e('No activity yet.', 'pild-unified'); ?></td></tr>
          <?php endif; ?>
        </tbody>
      </table>

      <?php if ($total_pages > 1): ?>
      <div style="margin-top:16px;">
        <?php echo paginate_links([
            'base' => add_query_arg('paged', '%#%'), 'format' => '',
            'current' => $paged, 'total' => $total_pages, 'prev_text' => '‹', 'next_text' => '›',
        ]); ?>
      </div>
      <?php endif; ?>
    </div>
    <?php
}

// Shared by both the on-screen table and the CSV export, so filtering logic
// can't silently drift between what the admin sees and what gets exported.
function pildcm_enrollment_report_query($args = []) {
    global $wpdb;

    $where  = ["1=1"];
    $params = [];

    if (!empty($args['track_id'])) {
        $where[] = "e.track_id = %d";
        $params[] = (int) $args['track_id'];
    }
    if (!empty($args['status']) && $args['status'] === 'expired') {
        $where[] = "e.access_expires IS NOT NULL AND e.access_expires <= NOW()";
    } elseif (!empty($args['status']) && $args['status'] === 'active') {
        $where[] = "(e.access_expires IS NULL OR e.access_expires > NOW())";
    }
    if (!empty($args['search'])) {
        $where[] = "(u.display_name LIKE %s OR u.user_email LIKE %s)";
        $like = '%' . $wpdb->esc_like($args['search']) . '%';
        $params[] = $like;
        $params[] = $like;
    }
    $where[] = "e.status = 'active'"; // 'active' enrollment row (not soft-deleted) — separate from the access_expires-based expiry filter above

    $sql = "SELECT e.*, u.display_name, u.user_email, m.display_name as manager_name
            FROM {$wpdb->prefix}pild_enrollments e
            LEFT JOIN {$wpdb->users} u ON u.ID = e.user_id
            LEFT JOIN {$wpdb->users} m ON m.ID = e.enrolled_by
            WHERE " . implode(' AND ', $where) . "
            ORDER BY e.enrolled_at DESC";

    if (!empty($args['limit'])) {
        $sql .= $wpdb->prepare(" LIMIT %d OFFSET %d", (int) $args['limit'], (int) ($args['offset'] ?? 0));
    }

    return $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);
}

function pildcm_enrollment_report_count($args = []) {
    global $wpdb;
    $where  = ["1=1", "e.status = 'active'"];
    $params = [];
    if (!empty($args['track_id'])) { $where[] = "e.track_id = %d"; $params[] = (int) $args['track_id']; }
    if (!empty($args['status']) && $args['status'] === 'expired') $where[] = "e.access_expires IS NOT NULL AND e.access_expires <= NOW()";
    elseif (!empty($args['status']) && $args['status'] === 'active') $where[] = "(e.access_expires IS NULL OR e.access_expires > NOW())";
    if (!empty($args['search'])) {
        $where[] = "(u.display_name LIKE %s OR u.user_email LIKE %s)";
        $like = '%' . $wpdb->esc_like($args['search']) . '%';
        $params[] = $like; $params[] = $like;
    }
    $sql = "SELECT COUNT(*) FROM {$wpdb->prefix}pild_enrollments e
            LEFT JOIN {$wpdb->users} u ON u.ID = e.user_id
            WHERE " . implode(' AND ', $where);
    return (int) ($params ? $wpdb->get_var($wpdb->prepare($sql, $params)) : $wpdb->get_var($sql));
}

function pildcm_enrollment_report_filters_from_request() {
    return [
        'track_id' => isset($_GET['track_id']) ? (int) $_GET['track_id'] : 0,
        'status'   => isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '',
        'search'   => isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '',
    ];
}

function pildcm_enrollment_admin_page() {
    $filters   = pildcm_enrollment_report_filters_from_request();
    $per_page  = 50;
    $paged     = max(1, (int) ($_GET['paged'] ?? 1));
    $total     = pildcm_enrollment_report_count($filters);
    $enrollments = pildcm_enrollment_report_query(array_merge($filters, [
        'limit' => $per_page, 'offset' => ($paged - 1) * $per_page,
    ]));
    $total_pages = max(1, ceil($total / $per_page));

    $tracks = get_posts(['post_type' => 'track', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC']);

    $export_url = wp_nonce_url(
        add_query_arg(array_merge($filters, ['action' => 'pildcm_export_enrollment_csv']), admin_url('admin-post.php')),
        'pildcm_export_enrollment_csv'
    );
    ?>
    <div class="wrap">
      <h1>📋 PILD Access Report</h1>
      <p>Total matching: <strong><?php echo (int) $total; ?></strong> <?php echo $total !== (int) pildcm_enrollment_report_count([]) ? '(filtered from ' . (int) pildcm_enrollment_report_count([]) . ')' : ''; ?></p>

      <form method="get" style="display:flex;gap:10px;align-items:center;margin:16px 0;flex-wrap:wrap;">
        <input type="hidden" name="page" value="pild-enrollments" />
        <select name="track_id">
          <option value=""><?php esc_html_e('All Tracks', 'pild-unified'); ?></option>
          <?php foreach ($tracks as $t): ?>
            <option value="<?php echo (int) $t->ID; ?>" <?php selected($filters['track_id'], $t->ID); ?>><?php echo esc_html($t->post_title); ?></option>
          <?php endforeach; ?>
        </select>
        <select name="status">
          <option value=""><?php esc_html_e('All Statuses', 'pild-unified'); ?></option>
          <option value="active" <?php selected($filters['status'], 'active'); ?>><?php esc_html_e('Active (not expired)', 'pild-unified'); ?></option>
          <option value="expired" <?php selected($filters['status'], 'expired'); ?>><?php esc_html_e('Expired', 'pild-unified'); ?></option>
        </select>
        <input type="search" name="s" value="<?php echo esc_attr($filters['search']); ?>" placeholder="<?php esc_attr_e('Search name or email…', 'pild-unified'); ?>" />
        <button class="button button-primary"><?php esc_html_e('Filter', 'pild-unified'); ?></button>
        <?php if ($filters['track_id'] || $filters['status'] || $filters['search']): ?>
          <a href="<?php echo esc_url(remove_query_arg(['track_id', 'status', 's'])); ?>" class="button"><?php esc_html_e('Clear', 'pild-unified'); ?></a>
        <?php endif; ?>
        <a href="<?php echo esc_url($export_url); ?>" class="button" style="margin-left:auto;">⬇ <?php esc_html_e('Export CSV (current filters)', 'pild-unified'); ?></a>
      </form>

      <table class="widefat fixed striped">
        <thead><tr><th>Member</th><th>Email</th><th>Track</th><th>Access Granted By</th><th>Access Granted At</th><th>Access Expires</th><th>Deadline</th><th>Progress</th></tr></thead>
        <tbody>
          <?php foreach ($enrollments as $e):
              $prog    = pildcm_get_track_progress($e->user_id, $e->track_id);
              $overdue = $e->deadline && strtotime($e->deadline) < time() && $prog['pct'] < 100;
              $expired = $e->access_expires && strtotime($e->access_expires) <= time();
          ?>
          <tr <?php echo $expired ? 'style="background:#fde8e8"' : ($overdue ? 'style="background:#fff3cd"' : ''); ?>>
            <td><?php echo esc_html($e->display_name); ?></td>
            <td><?php echo esc_html($e->user_email); ?></td>
            <td><a href="<?php echo get_permalink($e->track_id); ?>" target="_blank"><?php echo esc_html(get_the_title($e->track_id)); ?></a></td>
            <td><?php echo $e->manager_name ? esc_html($e->manager_name) : '—'; ?></td>
            <td><?php echo esc_html($e->enrolled_at); ?></td>
            <td><?php echo $e->access_expires ? esc_html($e->access_expires) . ($expired ? ' ⛔' : '') : '—'; ?></td>
            <td><?php echo $e->deadline ? esc_html($e->deadline) . ($overdue ? ' ⚠️' : '') : '—'; ?></td>
            <td>
              <div style="background:#eee;border-radius:99px;height:8px;width:100px;overflow:hidden;">
                <div style="background:#0E6655;height:100%;width:<?php echo $prog['pct']; ?>%;border-radius:99px;"></div>
              </div>
              <small><?php echo $prog['pct']; ?>% (<?php echo $prog['done']; ?>/<?php echo $prog['total']; ?>)</small>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($enrollments)): ?>
          <tr><td colspan="8"><?php esc_html_e('No matching enrollments.', 'pild-unified'); ?></td></tr>
          <?php endif; ?>
        </tbody>
      </table>

      <?php if ($total_pages > 1): ?>
      <div style="margin-top:16px;">
        <?php echo paginate_links([
            'base'      => add_query_arg('paged', '%#%'),
            'format'    => '',
            'current'   => $paged,
            'total'     => $total_pages,
            'prev_text' => '‹', 'next_text' => '›',
        ]); ?>
      </div>
      <?php endif; ?>
    </div>
    <?php
}

add_action('admin_post_pildcm_export_enrollment_csv', 'pildcm_export_enrollment_csv');
function pildcm_export_enrollment_csv() {
    if (!current_user_can('manage_options')) wp_die('Unauthorized');
    check_admin_referer('pildcm_export_enrollment_csv');

    $filters = pildcm_enrollment_report_filters_from_request();
    $rows    = pildcm_enrollment_report_query($filters); // no limit — full filtered set

    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="pild-enrollments-' . date('Y-m-d') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Member', 'Email', 'Track', 'Access Granted By', 'Access Granted At', 'Access Expires', 'Deadline', 'Progress %']);
    foreach ($rows as $e) {
        $prog = pildcm_get_track_progress($e->user_id, $e->track_id);
        fputcsv($out, [
            $e->display_name, $e->user_email, get_the_title($e->track_id),
            $e->manager_name ?: '—', $e->enrolled_at, $e->access_expires ?: '—', $e->deadline ?: '—', $prog['pct'],
        ]);
    }
    fclose($out);
    exit;
}

// ============================================================
// 20. WooCommerce Team Auto-Sync — REMOVED (PHASE 4)
// ------------------------------------------------------------
// This section used to mirror data from the "WooCommerce Memberships
// for Teams" extension into a local wc_memberships_teams / _team_members
// table pair, triggered by that extension's own action hooks
// (wc_memberships_for_teams_team_created / _team_member_added / _removed).
//
// Team creation, membership, and seat enforcement are now handled
// directly by this plugin — see includes/23-teams-core.php (schema +
// core functions) and includes/24-team-purchase.php (creates a team on
// order completion). Every function elsewhere in the plugin that used
// to read wc_memberships_teams / wc_memberships_team_members has been
// repointed at pild_teams / pild_team_members instead.
//
// Since those extension action hooks will never fire once the extension
// itself is deactivated, this whole section was dead code — removed
// rather than left in place, so the codebase doesn't carry a second,
// silently-unused copy of the team/seat logic alongside the real one.
// ============================================================

