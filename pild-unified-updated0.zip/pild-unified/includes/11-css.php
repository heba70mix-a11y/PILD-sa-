<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 22. CSS — PREMIUM INSTITUTIONAL DESIGN
// ============================================================
function pildcm_css() {
    // PHASE 19 FIX: same issue as pild_global_css() in pild-unified.php —
    // see the comment there. Removed the static "print once" guard.
    return '
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════
   PILD DASHBOARD v2 — Premium Institutional
   Font: DM Serif Display + DM Sans
═══════════════════════════════════════════════ */
:root {
  /* Ink scale */
  --ink:   #0A0F1E;
  --ink2:  #2D3348;
  --ink3:  #6B7280;
  --ink4:  #9CA3AF;

  /* Backgrounds */
  --bg:    #F4F3F0;
  --bg2:   #EDECEA;
  --bg3:   #E5E3DF;
  --white: #FAFAF8;

  /* Brand — Deep Teal */
  --teal:  #0D5C4E;
  --teal2: #0F7A68;
  --teal3: #D1EAE5;
  --teal4: rgba(13,92,78,.08);

  /* Accent — Antique Gold */
  --gold:  #8B6914;
  --gold2: #C09A20;
  --gold3: #F5EAC4;
  --gold4: rgba(139,105,20,.1);

  /* Status */
  --red:   #B91C1C;
  --red-bg:rgba(185,28,28,.08);
  --green: #166534;
  --green-bg:rgba(22,101,52,.08);

  /* Borders */
  --b1:    rgba(10,15,30,.07);
  --b2:    rgba(10,15,30,.14);

  /* Geometry */
  --r:     8px;
  --r-lg:  14px;
  --r-xl:  20px;

  /* Shadows */
  --s1: 0 1px 3px rgba(10,15,30,.06), 0 1px 2px rgba(10,15,30,.04);
  --s2: 0 4px 16px rgba(10,15,30,.08), 0 2px 4px rgba(10,15,30,.04);
  --s3: 0 16px 48px rgba(10,15,30,.12), 0 4px 8px rgba(10,15,30,.06);
}

/* ── Base ── */
.cm-wrap {
  font-family: "DM Sans", system-ui, sans-serif;
  color: var(--ink);
  background: var(--bg);
  min-height: 100vh;
  padding: 0 0 6rem;
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
}

/* ── Header Bar ── */
.cm-header-bar {
  background: var(--white);
  border-bottom: 1px solid var(--b1);
  padding: 1rem 2.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  position: relative;
  z-index: 1;
  box-shadow: var(--s1);
}
.cm-header-brand {
  display: flex;
  align-items: center;
  gap: .9rem;
}
.cm-header-logo {
  height: 40px;
  max-width: 120px;
  object-fit: contain;
  border-radius: 6px;
}
.cm-header-logo-fallback {
  width: 40px; height: 40px;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-family: "DM Serif Display", serif;
  font-size: .9rem; font-weight: 400; letter-spacing: .02em;
}
.cm-header-company {
  font-weight: 600; font-size: .9rem; color: var(--ink);
  line-height: 1.2;
}
.cm-header-role {
  font-size: .68rem; color: var(--ink3);
  text-transform: uppercase; letter-spacing: .12em;
}
.cm-header-actions { display: flex; gap: .5rem; align-items: center; }
.cm-hdr-btn {
  font-family: "DM Sans", sans-serif;
  font-size: .75rem; font-weight: 500;
  color: var(--ink2); background: var(--bg);
  border: 1px solid var(--b2); border-radius: var(--r);
  padding: .45rem 1rem; cursor: pointer; text-decoration: none;
  display: inline-flex; align-items: center; gap: .4rem;
  transition: all .18s;
}
.cm-hdr-btn:hover { background: var(--bg2); color: var(--ink); border-color: var(--b2); }

/* ── Hero ── */
.cm-hero {
  background: var(--ink);
  padding: 3rem 2.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 2rem;
  flex-wrap: wrap;
  position: relative;
  overflow: hidden;
}
.cm-hero-bg-orb {
  position: absolute; border-radius: 50%; pointer-events: none;
}
.cm-hero-bg-orb-1 {
  width: 500px; height: 500px; top: -200px; right: -100px;
  background: radial-gradient(circle, rgba(13,92,78,.25) 0%, transparent 70%);
}
.cm-hero-bg-orb-2 {
  width: 300px; height: 300px; bottom: -150px; left: 200px;
  background: radial-gradient(circle, rgba(139,105,20,.15) 0%, transparent 70%);
}
.cm-hero-eyebrow {
  font-size: .65rem; font-weight: 500;
  letter-spacing: .22em; text-transform: uppercase;
  color: var(--gold2); margin-bottom: .6rem;
}
.cm-hero-title {
  font-family: "DM Serif Display", serif;
  font-size: 2.1rem; font-weight: 400;
  color: #fff; margin: 0 0 .5rem; line-height: 1.15;
}
.cm-hero-sub {
  font-size: .85rem; color: rgba(255,255,255,.4);
  font-weight: 300;
}
.cm-hero-kpis {
  display: flex; align-items: center;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: var(--r-lg);
  overflow: hidden; flex-shrink: 0;
}
.cm-kpi {
  padding: 1.4rem 1.75rem; text-align: center; min-width: 90px;
}
.cm-kpi-icon {
  font-size: 1.3rem; margin-bottom: .2rem; line-height: 1;
}
.cm-kpi-num {
  font-family: "DM Serif Display", serif;
  font-size: 2rem; font-weight: 400; color: var(--gold2);
  line-height: 1;
}
.cm-kpi-lbl {
  font-size: .58rem; color: rgba(255,255,255,.32);
  text-transform: uppercase; letter-spacing: .1em;
  margin-top: .35rem;
}
.cm-kpi-divider {
  width: 1px; height: 50px;
  background: rgba(255,255,255,.08); flex-shrink: 0;
}

/* ── Info Cards Row ── */
.cm-info-cards-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.25rem;
  padding: 1.75rem 2.5rem;
}
.cm-info-card {
  background: var(--white);
  border: 1px solid var(--b1);
  border-radius: var(--r-xl);
  padding: 1.75rem;
  box-shadow: var(--s1);
}
.cm-info-card-header {
  display: flex; align-items: center; gap: .7rem;
  margin-bottom: 1.5rem;
}
.cm-info-card-icon {
  width: 36px; height: 36px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.cm-icon-teal { background: var(--teal3); color: var(--teal); }
.cm-icon-gold { background: var(--gold3); color: var(--gold); }
.cm-info-card-label {
  font-size: .65rem; font-weight: 600;
  letter-spacing: .18em; text-transform: uppercase;
  color: var(--ink3);
}

/* Company Logo */
.cm-company-logo-wrap {
  display: flex; justify-content: center;
  margin-bottom: 1.1rem;
}
.cm-company-logo-img {
  max-width: 140px; max-height: 70px; object-fit: contain;
}
.cm-company-logo-placeholder {
  width: 80px; height: 80px;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  font-family: "DM Serif Display", serif; font-size: 1.5rem;
}

.cm-info-card-name {
  font-family: "DM Serif Display", serif;
  font-size: 1.25rem; font-weight: 400;
  color: var(--ink); text-align: center; margin-bottom: .4rem;
}
.cm-info-card-sub {
  font-size: .75rem; color: var(--ink3);
  text-align: center; margin-bottom: 1.25rem;
  display: flex; align-items: center; justify-content: center; gap: .35rem;
}
.cm-info-card-details {
  border-top: 1px solid var(--b1); padding-top: 1rem;
  display: flex; flex-direction: column; gap: .6rem;
}
.cm-info-detail-row {
  display: flex; align-items: center; gap: .6rem;
  font-size: .78rem; color: var(--ink2);
}
.cm-info-detail-row svg { flex-shrink: 0; color: var(--ink3); }
.cm-info-detail-row a { color: var(--teal); text-decoration: none; }
.cm-info-detail-row a:hover { text-decoration: underline; }

/* Personal Card */
.cm-personal-avatar-wrap {
  display: flex; justify-content: center;
  margin-bottom: 1rem; position: relative; width: fit-content; margin-inline: auto;
}
.cm-personal-avatar {
  width: 80px; height: 80px; border-radius: 50%;
  object-fit: cover; border: 3px solid var(--gold3);
}
.cm-personal-avatar-fallback {
  width: 80px; height: 80px; border-radius: 50%;
  background: linear-gradient(135deg, var(--gold), var(--gold2));
  color: #fff; display: flex; align-items: center; justify-content: center;
  font-family: "DM Serif Display", serif; font-size: 1.5rem;
  border: 3px solid var(--gold3);
}
.cm-personal-avatar-badge {
  position: absolute; bottom: 2px; right: 2px;
  width: 22px; height: 22px;
  background: var(--gold2); color: #fff;
  border-radius: 50%; border: 2px solid var(--white);
  display: flex; align-items: center; justify-content: center;
  font-size: .55rem;
}
.cm-personal-bio {
  font-size: .8rem; color: var(--ink3); font-style: italic;
  text-align: center; margin-bottom: 1rem; line-height: 1.5;
}
.cm-personal-stats-row {
  display: flex; border-top: 1px solid var(--b1);
  margin-top: 1rem; padding-top: 1rem; gap: 0;
}
.cm-pstat {
  flex: 1; text-align: center;
  border-right: 1px solid var(--b1);
}
.cm-pstat:last-child { border-right: none; }
.cm-pstat-num {
  font-family: "DM Serif Display", serif;
  font-size: 1.25rem; color: var(--teal); line-height: 1;
}
.cm-pstat-lbl {
  font-size: .6rem; color: var(--ink3);
  text-transform: uppercase; letter-spacing: .1em; margin-top: .2rem;
}

/* ── Tabs ── */
/* Desktop default: FIXED VERTICAL SIDEBAR (like large SaaS platforms).
   Below 960px it reverts to the original horizontal top-tab bar
   (see the responsive override further down) — no HTML changes needed,
   since .cm-tabs-wrap / .cm-tabs / .cm-tab are the same elements either way. */
:root { --sidebar-w: 248px; --site-header-h: 90px; }

.cm-tabs-wrap {
  position: fixed;
  top: var(--site-header-h); left: 0;
  width: var(--sidebar-w);
  height: calc(100vh - var(--site-header-h));
  padding: 1.5rem 0;
  border-bottom: none;
  border-right: 1px solid var(--b1);
  background: var(--white);
  overflow-y: auto;
  z-index: 40;
  box-sizing: border-box;
}
body.admin-bar .cm-tabs-wrap { top: calc(var(--site-header-h) + 32px); height: calc(100vh - var(--site-header-h) - 32px); }
@media (max-width: 782px) {
  body.admin-bar .cm-tabs-wrap { top: calc(var(--site-header-h) + 46px); height: calc(100vh - var(--site-header-h) - 46px); }
}

/* Reserve the sidebar width so the hero + panels sit beside it instead
   of underneath it (sidebar is position:fixed, taken out of normal flow). */
.cm-wrap { padding-left: var(--sidebar-w); box-sizing: border-box; }

.cm-tabs {
  display: flex; flex-direction: column; align-items: stretch;
  gap: .15rem; height: 100%;
}
.cm-tab {
  font-family: "DM Sans", sans-serif;
  font-size: .82rem; font-weight: 500;
  color: var(--ink3); background: transparent;
  border: none; border-right: 3px solid transparent;
  cursor: pointer; padding: .75rem 1.4rem;
  display: flex; align-items: center; gap: .65rem;
  justify-content: flex-start;
  transition: all .18s; white-space: nowrap;
  border-radius: 0; width: 100%; text-align: left;
}
.cm-tab:hover { color: var(--ink); background: var(--bg2); }
.cm-tab svg { flex-shrink: 0; }
.cm-tab-active {
  color: var(--teal);
  background: var(--teal4);
  border-right-color: var(--teal);
  font-weight: 600;
}

/* ── Practice Areas — inline expanding sub-section on desktop sidebar ── */
.cm-tab-dropdown {
  position: relative;
  display: flex; flex-direction: column;
  align-items: stretch;
  width: 100%;
}
.cm-tab-dropdown-trigger {
  display: flex; width: 100%;
  align-items: center;
  gap: .65rem;
}
.cm-tab-dropdown-trigger #cm-pa-label {
  pointer-events: none;
}
.cm-pa-chevron {
  transition: transform .2s ease;
  flex-shrink: 0;
  margin-left: auto;
  pointer-events: none;
}
.cm-pa-chevron-open {
  transform: rotate(180deg);
}
.cm-tab-dropdown-menu {
  display: none;
  position: static;
  min-width: 0; width: 100%;
  background: var(--bg2);
  border: none; border-radius: 0;
  box-shadow: none;
  z-index: 1;
  overflow: hidden;
  margin-top: 0;
}
.cm-tab-dropdown-menu.cm-pa-menu-open {
  display: block;
  animation: cm-fadein .15s ease;
}
.cm-tab-dropdown-menu::before { content: none; }
.cm-tab-dropdown-item {
  display: flex;
  align-items: center;
  gap: .55rem;
  width: 100%;
  padding: .6rem 1.4rem .6rem 2.25rem;
  font-family: "DM Sans", sans-serif;
  font-size: .78rem;
  font-weight: 500;
  color: #555;
  background: transparent;
  border: none;
  border-bottom: none;
  cursor: pointer;
  text-align: left;
  transition: background .13s, color .13s;
  white-space: nowrap;
}
.cm-tab-dropdown-item:last-child { border-bottom: none; }
.cm-tab-dropdown-item:hover {
  background: var(--bg3);
  color: var(--teal, #1a7f6e);
}
.cm-tab-dropdown-item-active {
  background: var(--teal4);
  color: var(--teal, #1a7f6e);
  font-weight: 600;
}

/* ── Log Out Tab — pinned to the bottom of the sidebar ── */
.cm-tab-logout {
  margin-left: 0;
  margin-top: auto;
  border-top: 1px solid var(--b1);
  border-right-color: transparent !important;
  color: #d94f4f !important;
  text-decoration: none;
}
.cm-tab-logout:hover {
  color: #b83a3a !important;
  background: rgba(217,79,79,.06);
}

/* ── Panel ── */
.cm-panel { animation: cm-fadein .2s ease; padding: 2rem 2.5rem; }
.cm-panel-hidden { display: none; }
@keyframes cm-fadein { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:none} }

.cm-panel-header { margin-bottom: 1.75rem; }
.cm-panel-title {
  font-family: "DM Serif Display", serif;
  font-size: 1.4rem; font-weight: 400; color: var(--ink); margin-bottom: .3rem;
}
.cm-panel-desc { font-size: .82rem; color: var(--ink3); }

.cm-empty {
  text-align: center; padding: 3rem;
  color: var(--ink3); font-size: .88rem;
  border: 1px dashed var(--b2); border-radius: var(--r-lg);
}

/* ── Track Overview Cards ── */
.cm-track-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1rem;
}
.cm-track-card {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-lg); padding: 1.5rem;
  box-shadow: var(--s1); transition: box-shadow .2s;
}
.cm-track-card:hover { box-shadow: var(--s2); }
.cm-track-card-top {
  display: flex; align-items: center;
  justify-content: space-between; margin-bottom: .75rem;
}
.cm-level-badge {
  font-size: .58rem; font-weight: 600;
  letter-spacing: .14em; text-transform: uppercase;
  color: var(--gold); background: var(--gold4);
  border: 1px solid rgba(139,105,20,.15);
  padding: .2rem .65rem; border-radius: 99px;
}
.cm-track-ext-link {
  color: var(--ink3); transition: color .18s;
}
.cm-track-ext-link:hover { color: var(--teal); }
.cm-track-card-title {
  font-family: "DM Serif Display", serif;
  font-size: .95rem; font-weight: 400;
  color: var(--ink); margin: 0 0 1rem; line-height: 1.3;
}
.cm-track-card-stats {
  display: flex; gap: 0; margin-bottom: 1rem;
  border: 1px solid var(--b1); border-radius: var(--r); overflow: hidden;
}
.cm-tstat {
  flex: 1; text-align: center; padding: .65rem .5rem;
  border-right: 1px solid var(--b1);
}
.cm-tstat:last-child { border-right: none; }
.cm-tstat-n {
  font-family: "DM Serif Display", serif;
  font-size: 1.1rem; color: var(--teal); line-height: 1;
}
.cm-tstat-l { font-size: .58rem; color: var(--ink3); text-transform: uppercase; letter-spacing: .1em; }
.cm-track-prog-wrap { height: 5px; background: var(--bg2); border-radius: 99px; overflow: hidden; }
.cm-track-prog-bar { height: 100%; border-radius: 99px; transition: width .8s ease; }
.cm-track-prog-bar.prog-high { background: linear-gradient(90deg, var(--teal), var(--teal2)); }
.cm-track-prog-bar.prog-mid  { background: linear-gradient(90deg, var(--gold), var(--gold2)); }
.cm-track-prog-bar.prog-low  { background: linear-gradient(90deg, #DC2626, #EF4444); }

/* ── Members Tab ── */
.cm-invite-box {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); padding: 1.5rem 1.75rem;
  margin-bottom: 1.5rem; box-shadow: var(--s1);
  display: flex; align-items: flex-start;
  gap: 1.5rem; flex-wrap: wrap; position: relative;
}
.cm-invite-box-left { flex: 1; min-width: 200px; }
.cm-invite-box-title {
  font-weight: 600; font-size: .9rem; color: var(--ink); margin-bottom: .25rem;
}
.cm-invite-box-sub { font-size: .78rem; color: var(--ink3); }
.cm-invite-box-right {
  display: flex; gap: .65rem; align-items: center; flex-wrap: wrap; flex-shrink: 0;
}
.cm-invite-input {
  font-family: "DM Sans", sans-serif;
  padding: .55rem 1rem; border: 1.5px solid var(--b2);
  border-radius: var(--r); font-size: .85rem; outline: none;
  transition: border-color .2s; min-width: 250px; color: var(--ink);
}
.cm-invite-input:focus { border-color: var(--teal); }
.cm-invite-msg { width: 100%; margin-top: -.25rem; font-size: .8rem; }
.cm-invite-ok { color: var(--teal); }
.cm-invite-err { color: var(--red); }

.cm-pending-invites { width: 100%; border-top: 1px solid var(--b1); padding-top: .85rem; margin-top: .25rem; }
.cm-pending-title {
  font-size: .65rem; font-weight: 600; letter-spacing: .14em;
  text-transform: uppercase; color: var(--ink3); margin-bottom: .5rem;
}
.cm-pending-row {
  display: flex; align-items: center; gap: 1rem;
  font-size: .78rem; color: var(--ink2); padding: .3rem 0;
  border-bottom: 1px solid var(--b1); flex-wrap: wrap;
}
.cm-pending-row:last-child { border-bottom: none; }
.cm-pending-email { flex: 1; font-weight: 500; }
.cm-pending-date { color: var(--ink3); font-size: .72rem; }
.cm-pending-status { font-size: .65rem; font-weight: 600; padding: .15rem .6rem; border-radius: 99px; }
.cm-pending-status.valid   { background: var(--teal4); color: var(--teal); }
.cm-pending-status.expired { background: var(--red-bg); color: var(--red); }

/* Members Filter Bar */
.cm-members-filter-bar {
  display: flex; align-items: center; gap: 1rem;
  margin-bottom: 1.25rem; flex-wrap: wrap;
}
.cm-search-wrap {
  display: flex; align-items: center; gap: .5rem;
  background: var(--white); border: 1px solid var(--b2);
  border-radius: var(--r); padding: .45rem .85rem;
  flex: 1; min-width: 240px; max-width: 360px;
}
.cm-search-wrap svg { color: var(--ink3); flex-shrink: 0; }
.cm-search-input {
  border: none; outline: none; font-family: "DM Sans", sans-serif;
  font-size: .82rem; color: var(--ink); background: transparent; flex: 1;
}
.cm-filter-pills { display: flex; gap: .4rem; flex-wrap: wrap; }
.cm-filter-pill {
  font-family: "DM Sans", sans-serif;
  font-size: .72rem; font-weight: 500;
  color: var(--ink3); background: var(--white);
  border: 1px solid var(--b2); border-radius: 99px;
  padding: .3rem .9rem; cursor: pointer; transition: all .18s;
}
.cm-filter-pill:hover { color: var(--teal); border-color: var(--teal); }
.cm-filter-pill-active { color: var(--teal); border-color: var(--teal); background: var(--teal4); }

/* Member Cards */
.cm-members-list { display: flex; flex-direction: column; gap: 1.1rem; }
.cm-member-card {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); padding: 1.75rem;
  box-shadow: var(--s1); transition: box-shadow .2s;
}
.cm-member-card:hover { box-shadow: var(--s2); }

.cm-mc-header {
  display: flex; align-items: flex-start; gap: 1.1rem;
  margin-bottom: 1.25rem; padding-bottom: 1.25rem;
  border-bottom: 1px solid var(--b1);
}
.cm-mc-avatar-wrap { position: relative; flex-shrink: 0; }
.cm-mc-avatar-img {
  width: 56px; height: 56px; border-radius: 50%;
  object-fit: cover; border: 2px solid var(--b1);
}
.cm-mc-avatar-fallback {
  width: 56px; height: 56px; border-radius: 50%;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; font-family: "DM Serif Display", serif;
  font-size: 1.2rem; display: flex; align-items: center; justify-content: center;
  border: 2px solid var(--b1);
}
.cm-mc-status {
  position: absolute; bottom: 2px; right: 2px;
  width: 14px; height: 14px; border-radius: 50%;
  border: 2px solid var(--white);
}
.cm-status-online  { background: #22C55E; }
.cm-status-recent  { background: #F59E0B; }
.cm-status-away    { background: #94A3B8; }
.cm-status-offline { background: #CBD5E1; }

.cm-mc-identity { flex: 1; min-width: 0; }
.cm-mc-name {
  font-weight: 600; font-size: .95rem; color: var(--ink); margin-bottom: .15rem;
}
.cm-mc-title { font-size: .75rem; color: var(--teal); margin-bottom: .2rem; }
.cm-mc-email { font-size: .75rem; color: var(--ink3); }
.cm-mc-phone { font-size: .72rem; color: var(--ink3); margin-top: .1rem; }

.cm-mc-meta { text-align: right; flex-shrink: 0; }
.cm-mc-last-seen {
  font-size: .7rem; font-weight: 500;
  display: inline-flex; align-items: center; gap: .3rem;
  padding: .2rem .65rem; border-radius: 99px; margin-bottom: .3rem;
}
.cm-seen-online  { color: #166534; background: #DCFCE7; }
.cm-seen-recent  { color: #92400E; background: #FEF3C7; }
.cm-seen-away    { color: var(--ink3); background: var(--bg2); }
.cm-seen-offline { color: var(--ink4); background: var(--bg2); }
.cm-mc-joined { font-size: .68rem; color: var(--ink4); }

/* Stats Row */
.cm-mc-stats-row {
  display: flex; gap: 1.25rem; flex-wrap: wrap;
  margin-bottom: 1rem; padding-bottom: 1rem;
  border-bottom: 1px solid var(--b1);
}
.cm-mc-stat {
  display: flex; align-items: center; gap: .35rem;
  font-size: .75rem; color: var(--ink2);
}
.cm-mc-stat svg { color: var(--ink3); }

.cm-mc-bio {
  font-size: .78rem; color: var(--ink3); font-style: italic;
  line-height: 1.5; margin-bottom: 1rem;
  padding: .6rem .8rem; background: var(--bg);
  border-radius: var(--r); border-left: 2px solid var(--teal3);
}

/* Badges */
.cm-mc-badges {
  display: flex; flex-wrap: wrap; gap: .35rem;
  margin-bottom: 1.25rem;
}
.cm-mc-badge {
  font-size: .68rem; font-weight: 500;
  background: var(--gold4); color: var(--gold);
  border: 1px solid rgba(139,105,20,.2);
  padding: .2rem .65rem; border-radius: 99px;
}

/* Learning Map */
.cm-mc-section-label {
  font-size: .62rem; font-weight: 600;
  letter-spacing: .16em; text-transform: uppercase;
  color: var(--ink3); margin-bottom: .85rem;
}
.cm-mc-tracks { display: flex; flex-direction: column; gap: 0; }
.cm-mc-track-row {
  display: flex; align-items: center; justify-content: space-between;
  gap: 1rem; padding: .7rem 0;
  border-bottom: 1px solid var(--b1);
}
.cm-mc-track-row:last-child { border-bottom: none; }
.cm-mc-track-left { display: flex; align-items: flex-start; gap: .65rem; flex: 1; min-width: 0; }
.cm-mc-track-dot {
  width: 10px; height: 10px; border-radius: 50%;
  flex-shrink: 0; margin-top: 4px;
}
.cm-dot-done     { background: var(--teal); }
.cm-dot-good     { background: var(--gold2); }
.cm-dot-low      { background: #94A3B8; }
.cm-dot-overdue  { background: var(--red); }
.cm-mc-track-info { flex: 1; min-width: 0; }
.cm-mc-track-name { font-size: .82rem; font-weight: 500; color: var(--ink2); margin-bottom: .2rem; }
.cm-mc-track-meta-row {
  display: flex; align-items: center; gap: .65rem;
  font-size: .7rem; color: var(--ink3); flex-wrap: wrap;
}
.cm-mc-deadline { font-size: .68rem; }
.cm-mc-deadline.overdue { color: var(--red); }
.cm-cert-link {
  font-size: .68rem; color: var(--teal); font-weight: 500;
  text-decoration: none; display: inline-flex; align-items: center; gap: .25rem;
  background: var(--teal4); padding: .15rem .55rem; border-radius: 99px;
}
.cm-cert-link:hover { background: var(--teal3); }
.cm-mc-track-right {
  display: flex; flex-direction: column; align-items: flex-end;
  gap: .3rem; flex-shrink: 0; min-width: 90px;
}
.cm-mc-pct-label {
  font-family: "JetBrains Mono", monospace;
  font-size: .78rem; font-weight: 500;
}
.cm-mc-pct-label.done     { color: var(--teal); }
.cm-mc-pct-label.good     { color: var(--gold); }
.cm-mc-pct-label.low      { color: var(--ink3); }
.cm-mc-pct-label.overdue  { color: var(--red); }
.cm-mc-prog-wrap { width: 90px; height: 4px; background: var(--bg2); border-radius: 99px; overflow: hidden; }
.cm-mc-prog-bar { height: 100%; border-radius: 99px; }
.cm-mbar-done    { background: linear-gradient(90deg, var(--teal), var(--teal2)); }
.cm-mbar-good    { background: linear-gradient(90deg, var(--gold), var(--gold2)); }
.cm-mbar-low     { background: #CBD5E1; }
.cm-mbar-overdue { background: linear-gradient(90deg, var(--red), #EF4444); }
.cm-mc-no-tracks { font-size: .78rem; color: var(--ink4); padding: .5rem 0; }

/* Activity Timeline */
.cm-activity-timeline {
  display: flex; align-items: flex-end;
  gap: 3px; height: 48px;
  background: var(--bg); border-radius: var(--r);
  padding: .5rem; overflow: hidden;
}
.cm-act-bar-wrap { flex: 1; height: 100%; display: flex; align-items: flex-end; }
.cm-act-bar {
  width: 100%; min-height: 4px; border-radius: 2px;
  background: var(--bg3); transition: background .2s;
}
.cm-act-bar.active { background: var(--teal3); }
.cm-act-bar-wrap:hover .cm-act-bar.active { background: var(--teal2); }

/* Cert Cards */
.cm-mc-certs-row { display: flex; gap: .65rem; flex-wrap: wrap; }
.cm-mc-cert-card {
  display: flex; align-items: center; gap: .5rem;
  background: var(--gold4); border: 1px solid rgba(139,105,20,.2);
  border-radius: var(--r); padding: .55rem .9rem;
  text-decoration: none; transition: all .18s;
}
.cm-mc-cert-card:hover { background: var(--gold3); }
.cm-mc-cert-icon { font-size: 1rem; }
.cm-mc-cert-title { font-size: .75rem; font-weight: 500; color: var(--gold); }
.cm-mc-cert-action { font-size: .68rem; color: var(--gold); }

/* ── Assign Tab ── */
.cm-filter-bar {
  display: flex; align-items: center; gap: 1rem;
  margin-bottom: 1.25rem; flex-wrap: wrap;
}
.cm-filter-label-txt {
  font-size: .72rem; font-weight: 600;
  color: var(--ink3); text-transform: uppercase; letter-spacing: .1em;
  white-space: nowrap;
}
.cm-filter-tracks-row { display: flex; gap: .4rem; flex-wrap: wrap; }
.cm-assign-list { display: flex; flex-direction: column; gap: 1rem; }
.cm-assign-card {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); padding: 1.5rem; box-shadow: var(--s1);
}
.cm-assign-card-header {
  display: flex; align-items: center; gap: 1rem;
  margin-bottom: 1.25rem; padding-bottom: 1.25rem;
  border-bottom: 1px solid var(--b1);
}
.cm-assign-avatar {
  width: 44px; height: 44px; border-radius: 50%;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; font-family: "DM Serif Display", serif; font-size: 1rem;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; overflow: hidden;
}
.cm-assign-avatar img { width: 100%; height: 100%; object-fit: cover; }
.cm-assign-member-info { flex: 1; min-width: 0; }
.cm-assign-name { font-weight: 600; font-size: .88rem; color: var(--ink); }
.cm-assign-email { font-size: .73rem; color: var(--ink3); }
.cm-assign-meta { font-size: .7rem; color: var(--teal); margin-top: .2rem; }
.cm-assign-tracks-list { display: flex; flex-direction: column; gap: 6px; }
.cm-assign-row {
  display: flex; align-items: center; justify-content: space-between;
  gap: 1rem; padding: .75rem 1rem;
  border: 1px solid var(--b1); border-radius: var(--r); transition: all .18s;
}
.cm-assign-row.assigned {
  border-color: rgba(13,92,78,.2); background: rgba(13,92,78,.03);
}
.cm-assign-row-left { flex: 1; min-width: 0; }
.cm-assign-track-n { font-size: .82rem; color: var(--ink2); font-weight: 500; margin-bottom: .2rem; }
.cm-assign-prog-mini {
  height: 3px; background: var(--bg2); border-radius: 99px; overflow: hidden;
  margin: .2rem 0; width: 120px;
}
.cm-assign-prog-bar-mini { height: 100%; background: var(--teal); border-radius: 99px; }
.cm-assign-pct-txt { font-size: .68rem; color: var(--teal); }
.cm-assign-dl { font-size: .68rem; color: var(--ink3); }
.cm-assign-row-right { display: flex; align-items: center; gap: .5rem; flex-shrink: 0; }
.cm-deadline-input {
  font-family: "DM Sans", sans-serif; font-size: .73rem;
  padding: .3rem .5rem; border: 1px solid var(--b2);
  border-radius: 6px; color: var(--ink2);
}

/* ── Leaderboard ── */
.cm-lb-wrap { }
.cm-podium {
  display: flex; align-items: flex-end; justify-content: center;
  gap: 1rem; padding: 2rem 0; margin-bottom: 1.5rem;
}
.cm-podium-slot {
  display: flex; flex-direction: column; align-items: center; gap: .5rem;
}
.cm-podium-avatar-wrap { position: relative; }
.cm-podium-avatar {
  width: 56px; height: 56px; border-radius: 50%;
  object-fit: cover; border: 3px solid var(--gold2);
}
.cm-podium-avatar-fb {
  width: 56px; height: 56px; border-radius: 50%;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; font-family: "DM Serif Display", serif; font-size: 1.2rem;
  display: flex; align-items: center; justify-content: center;
  border: 3px solid var(--gold2);
}
.cm-podium-medal {
  position: absolute; top: -8px; right: -8px; font-size: 1.2rem;
}
.cm-podium-name { font-size: .82rem; font-weight: 600; color: var(--ink); }
.cm-podium-pts { font-size: .72rem; color: var(--teal); font-weight: 500; }
.cm-podium-block {
  width: 80px; background: var(--ink);
  border-radius: var(--r) var(--r) 0 0;
  display: flex; align-items: flex-start; justify-content: center; padding-top: .75rem;
}
.cm-podium-pos-0 .cm-podium-block { background: #C0A020; }
.cm-podium-pos-1 .cm-podium-block { background: var(--ink); }
.cm-podium-pos-2 .cm-podium-block { background: #8B6914; }
.cm-podium-rank { font-family: "DM Serif Display", serif; font-size: 1.5rem; color: rgba(255,255,255,.4); }

.cm-lb-table {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); overflow: hidden; box-shadow: var(--s1);
}
.cm-lb-thead {
  display: grid; grid-template-columns: 50px 1fr 130px 100px 90px 110px 110px 100px;
  gap: .5rem; padding: .85rem 1.5rem;
  background: var(--bg); border-bottom: 1px solid var(--b1);
  font-size: .62rem; font-weight: 600;
  text-transform: uppercase; letter-spacing: .1em; color: var(--ink3);
}
.cm-lb-row {
  display: grid; grid-template-columns: 50px 1fr 130px 100px 90px 110px 110px 100px;
  gap: .5rem; padding: .85rem 1.5rem;
  border-top: 1px solid var(--b1);
  font-size: .8rem; color: var(--ink2); align-items: center;
  transition: background .15s;
}
.cm-lb-row:hover { background: var(--bg); }
.cm-lb-podium-row { background: rgba(192,160,32,.04); }
.cm-lb-rank { text-align: center; font-size: 1rem; }
.cm-lb-member { display: flex; align-items: center; gap: .65rem; }
.cm-lb-avatar {
  width: 34px; height: 34px; border-radius: 50%;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; font-family: "DM Serif Display", serif; font-size: .85rem;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden; flex-shrink: 0;
}
.cm-lb-avatar img { width: 100%; height: 100%; object-fit: cover; }
.cm-lb-name { font-weight: 600; font-size: .82rem; color: var(--ink); }
.cm-lb-email { font-size: .68rem; color: var(--ink3); }
.cm-lb-pts-cell { display: flex; flex-direction: column; gap: .3rem; }
.cm-lb-pts-val { font-family: "JetBrains Mono", monospace; font-weight: 500; color: var(--gold); font-size: .82rem; }
.cm-lb-pts-bar { height: 3px; background: var(--bg2); border-radius: 99px; overflow: hidden; }
.cm-lb-pts-bar div { height: 100%; background: var(--gold2); border-radius: 99px; }
.cm-lb-prog-cell { }
.cm-lb-prog-bar { height: 4px; background: var(--bg2); border-radius: 99px; overflow: hidden; }
.cm-lb-prog-bar div { height: 100%; background: var(--teal); border-radius: 99px; }

/* ── Settings ── */
.cm-settings-layout { max-width: 720px; display: flex; flex-direction: column; gap: 1.75rem; }
.cm-settings-section {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); padding: 1.75rem; box-shadow: var(--s1);
}
.cm-settings-section-title {
  font-weight: 600; font-size: .82rem; color: var(--ink);
  margin-bottom: 1.25rem; padding-bottom: .75rem;
  border-bottom: 1px solid var(--b1);
}
.cm-settings-avatar-row {
  display: flex; align-items: center; gap: 1.25rem;
  margin-bottom: 1.5rem;
}
.cm-settings-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  background: linear-gradient(135deg, var(--teal), var(--teal2));
  color: #fff; font-family: "DM Serif Display", serif; font-size: 1.4rem;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden; flex-shrink: 0;
}
.cm-settings-avatar img { width: 100%; height: 100%; object-fit: cover; }
.cm-upload-btn {
  font-family: "DM Sans", sans-serif; font-size: .75rem; font-weight: 500;
  color: var(--teal); background: var(--teal4);
  border: 1px solid var(--teal3); border-radius: var(--r);
  padding: .45rem .9rem; cursor: pointer;
  display: inline-flex; align-items: center; gap: .4rem;
  transition: all .18s;
}
.cm-upload-btn:hover { background: var(--teal3); }
.cm-upload-hint { font-size: .68rem; color: var(--ink3); margin-top: .35rem; }
.cm-settings-fields {
  display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;
}
.cm-field-full { grid-column: 1 / -1; }
.cm-settings-field label {
  display: block; font-size: .72rem; font-weight: 600;
  color: var(--ink2); margin-bottom: .4rem;
  text-transform: uppercase; letter-spacing: .08em;
}
.cm-settings-field input,
.cm-settings-field textarea {
  width: 100%; font-family: "DM Sans", sans-serif;
  font-size: .85rem; color: var(--ink);
  border: 1.5px solid var(--b2); border-radius: var(--r);
  padding: .6rem .9rem; outline: none;
  transition: border-color .18s; box-sizing: border-box;
  background: var(--white);
}
.cm-settings-field input:focus,
.cm-settings-field textarea:focus { border-color: var(--teal); }
.cm-settings-field textarea { resize: vertical; }

.cm-settings-logo-area {
  display: flex; align-items: center; gap: 1.25rem;
  margin-bottom: 1.25rem; flex-wrap: wrap;
}
.cm-settings-logo-preview {
  width: 120px; height: 70px; background: var(--bg);
  border: 1.5px dashed var(--b2); border-radius: var(--r);
  display: flex; align-items: center; justify-content: center;
  overflow: hidden; flex-shrink: 0;
}
.cm-settings-logo-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
.cm-logo-placeholder-icon { display: flex; flex-direction: column; align-items: center; gap: .25rem; color: var(--ink3); }
.cm-logo-placeholder-icon span { font-size: .65rem; }

.cm-settings-footer {
  display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
}
.cm-settings-status { font-size: .8rem; }
.cm-settings-status.ok  { color: var(--teal); }
.cm-settings-status.err { color: var(--red); }

/* ── Member Tracks Grid ── */
.cm-member-tracks-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.1rem;
}
.cm-member-track-card {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-xl); padding: 1.5rem;
  box-shadow: var(--s1); transition: box-shadow .2s;
  border-top: 3px solid transparent;
}
.cm-member-track-card:hover { box-shadow: var(--s2); }
.cm-mtrack-complete { border-top-color: var(--teal); }
.cm-mtrack-overdue  { border-top-color: var(--red); }
.cm-mtrack-active   { border-top-color: var(--gold2); }

.cm-mtrack-top {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: .85rem;
}
.cm-mtrack-status-badge {
  font-size: .6rem; font-weight: 600; letter-spacing: .1em;
  text-transform: uppercase; padding: .2rem .65rem; border-radius: 99px;
}
.cm-mtrack-status-badge.complete { background: var(--teal4); color: var(--teal); }
.cm-mtrack-status-badge.overdue  { background: var(--red-bg); color: var(--red); }
.cm-mtrack-status-badge.active   { background: var(--gold4); color: var(--gold); }

.cm-mtrack-title {
  font-family: "DM Serif Display", serif;
  font-size: 1rem; font-weight: 400; color: var(--ink);
  margin: 0 0 .85rem; line-height: 1.3;
}
.cm-mtrack-pct-row {
  display: flex; align-items: baseline; gap: .6rem; margin-bottom: .65rem;
}
.cm-mtrack-pct {
  font-family: "JetBrains Mono", monospace;
  font-size: 1.6rem; font-weight: 500; color: var(--ink);
}
.cm-mtrack-playbooks { font-size: .75rem; color: var(--ink3); }
.cm-mtrack-prog-wrap { height: 6px; background: var(--bg2); border-radius: 99px; overflow: hidden; margin-bottom: .75rem; }
.cm-mtrack-prog-bar { height: 100%; border-radius: 99px; }
.cm-mtrack-prog-bar.complete { background: linear-gradient(90deg, var(--teal), var(--teal2)); }
.cm-mtrack-prog-bar.overdue  { background: linear-gradient(90deg, var(--red), #EF4444); }
.cm-mtrack-prog-bar.active   { background: linear-gradient(90deg, var(--gold), var(--gold2)); }
.cm-mtrack-deadline {
  font-size: .72rem; color: var(--ink3); margin-bottom: .75rem;
}
.cm-mtrack-deadline.overdue { color: var(--red); }
.cm-mtrack-actions { display: flex; gap: .6rem; flex-wrap: wrap; }
.cm-cert-btn {
  font-family: "DM Sans", sans-serif; font-size: .75rem; font-weight: 500;
  color: var(--gold); background: var(--gold4);
  border: 1px solid rgba(139,105,20,.2);
  padding: .42rem .85rem; border-radius: var(--r);
  text-decoration: none; transition: all .18s;
}
.cm-cert-btn:hover { background: var(--gold3); }

/* ── Achievements ── */
.cm-achievements-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
  gap: .85rem;
}
.cm-achievement-card {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-lg); padding: 1.25rem 1rem;
  text-align: center; position: relative;
  transition: all .2s;
}
.cm-achievement-card.earned:hover { transform: translateY(-2px); box-shadow: var(--s2); }
.cm-achievement-card.locked { opacity: .4; filter: grayscale(1); }
.cm-achievement-icon { font-size: 1.75rem; margin-bottom: .4rem; }
.cm-achievement-label { font-size: .72rem; font-weight: 600; color: var(--ink); margin-bottom: .2rem; }
.cm-achievement-desc  { font-size: .62rem; color: var(--ink3); line-height: 1.35; }
.cm-achievement-earned-badge {
  position: absolute; top: .4rem; right: .4rem;
  font-size: .55rem; font-weight: 600; letter-spacing: .1em;
  text-transform: uppercase;
  background: var(--teal); color: #fff;
  padding: .15rem .45rem; border-radius: 99px;
}

/* ── Student Gamification ── */
.cm-student-gamification { font-family: "DM Sans", sans-serif; }
.cm-sg-stats { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1.5rem; }
.cm-sg-stat {
  background: var(--white); border: 1px solid var(--b1);
  border-radius: var(--r-lg); padding: 1.25rem 1.5rem;
  text-align: center; flex: 1; min-width: 100px;
}
.cm-sg-num {
  font-family: "DM Serif Display", serif;
  font-size: 1.8rem; color: var(--teal); line-height: 1;
}
.cm-sg-lbl { font-size: .62rem; color: var(--ink3); text-transform: uppercase; letter-spacing: .1em; margin-top: .3rem; }

/* ── Buttons ── */
.cm-btn-primary {
  font-family: "DM Sans", sans-serif;
  font-size: .8rem; font-weight: 600;
  color: #fff; background: var(--teal);
  border: none; cursor: pointer;
  padding: .55rem 1.25rem; border-radius: var(--r);
  transition: all .18s; white-space: nowrap;
  display: inline-flex; align-items: center; gap: .45rem;
}
.cm-btn-primary:hover { background: var(--teal2); }
.cm-btn-primary:disabled { opacity: .5; cursor: not-allowed; }
.cm-btn-sm { padding: .42rem .9rem; font-size: .76rem; }

/* Secondary button — same shape/weight as primary so a card that shows both
   (e.g. "Read in Arabic" + "Read in English") reads as two equal actions
   instead of one real button next to plain text. */
.cm-btn-secondary {
  font-family: "DM Sans", sans-serif;
  font-size: .8rem; font-weight: 600;
  color: var(--teal); background: #fff;
  border: 1.5px solid var(--teal);
  cursor: pointer;
  padding: .55rem 1.25rem; border-radius: var(--r);
  transition: all .18s; white-space: nowrap;
  display: inline-flex; align-items: center; gap: .45rem;
  text-decoration: none;
}
.cm-btn-secondary:hover { background: var(--teal); color: #fff; }
.cm-btn-secondary:disabled { opacity: .5; cursor: not-allowed; }

.cm-btn-assign {
  font-family: "DM Sans", sans-serif;
  font-size: .72rem; font-weight: 500;
  color: #fff; background: var(--teal);
  border: none; cursor: pointer;
  padding: .38rem .9rem; border-radius: var(--r);
  transition: all .18s; white-space: nowrap;
}
.cm-btn-assign:hover { background: var(--teal2); }
.cm-btn-assign:disabled { opacity: .5; cursor: not-allowed; }

.cm-btn-assign-all {
  font-family: "DM Sans", sans-serif;
  font-size: .72rem; font-weight: 500;
  color: var(--teal); background: var(--teal4);
  border: 1px solid var(--teal3); cursor: pointer;
  padding: .38rem .9rem; border-radius: var(--r);
  transition: all .18s; white-space: nowrap; flex-shrink: 0;
}
.cm-btn-assign-all:hover { background: var(--teal3); }
.cm-btn-assign-all:disabled { opacity: .5; cursor: not-allowed; }

.cm-btn-danger {
  font-family: "DM Sans", sans-serif;
  font-size: .72rem; font-weight: 500;
  color: var(--red); background: var(--red-bg);
  border: 1px solid rgba(185,28,28,.2); cursor: pointer;
  padding: .35rem .85rem; border-radius: var(--r);
  transition: all .18s; white-space: nowrap;
}
.cm-btn-danger:hover { background: rgba(185,28,28,.14); }

.cm-btn-view {
  font-size: .82rem; color: var(--ink2); background: var(--bg);
  border: 1px solid var(--b2); border-radius: var(--r);
  padding: .32rem .65rem; text-decoration: none; transition: all .18s;
}
.cm-btn-view:hover { border-color: var(--teal); color: var(--teal); }

.cm-btn-save {
  padding: .65rem 1.5rem; font-size: .85rem;
}

/* ── Toast ── */
.cm-toast {
  position: fixed; bottom: 1.5rem; left: 50%; transform: translateX(-50%);
  font-family: "DM Sans", sans-serif; font-size: .82rem; font-weight: 500;
  padding: .7rem 1.5rem; border-radius: 99px; z-index: 9999;
  box-shadow: var(--s3); transition: all .3s; white-space: nowrap;
}
.cm-toast-hidden { opacity: 0; pointer-events: none; transform: translateX(-50%) translateY(10px); }
.cm-toast-success { background: var(--ink); color: #fff; }
.cm-toast-error   { background: var(--red); color: #fff; }

/* ── Responsive ── */
/* Below 960px: revert the sidebar back to the original horizontal top-tab
   bar — same elements, just re-laid-out, so no JS/HTML changes are needed. */
@media (max-width: 960px) {
  .cm-tabs-wrap {
    position: static; width: 100%; height: auto;
    border-right: none; border-bottom: 1px solid var(--b1);
    padding: 0 1.5rem; overflow-y: visible; overflow-x: auto;
  }
  .cm-wrap { padding-left: 0; }
  .cm-tabs { flex-direction: row; align-items: center; gap: 0; height: auto; }
  .cm-tab {
    flex-direction: row; width: auto;
    border-right: none; border-bottom: 2px solid transparent;
    padding: .9rem 1.2rem;
  }
  .cm-tab-active { border-right-color: transparent; border-bottom-color: var(--teal); }
  .cm-tab-dropdown { width: auto; }
  .cm-tab-dropdown-trigger { width: auto; }
  .cm-pa-chevron { margin-left: 0; }
  .cm-tab-dropdown-menu {
    position: absolute; top: 100%; left: 50%;
    transform: translateX(-50%);
    width: max-content; min-width: 210px;
    background: #fff; border: 1px solid #e8e5e0; border-radius: 12px;
    box-shadow: 0 12px 32px rgba(0,0,0,.13); margin-top: 6px;
  }
  .cm-tab-dropdown-item { padding: .8rem 1.2rem; border-bottom: 1px solid #f0ede8; }
  .cm-tab-logout { margin-top: 0; margin-left: auto; border-top: none; }
}
@media (max-width: 900px) {
  .cm-info-cards-row { grid-template-columns: 1fr; }
  .cm-lb-thead, .cm-lb-row { grid-template-columns: 40px 1fr 90px 80px; }
  .cm-lb-thead span:nth-child(n+5), .cm-lb-row span:nth-child(n+5) { display: none; }
}
@media (max-width: 768px) {
  .cm-hero { padding: 1.75rem 1.25rem; flex-direction: column; }
  .cm-hero-kpis { width: 100%; }
  .cm-header-bar { padding: .85rem 1.25rem; }
  .cm-info-cards-row { padding: 1.25rem; }
  .cm-panel { padding: 1.25rem; }
  .cm-settings-fields { grid-template-columns: 1fr; }
  .cm-member-tracks-grid { grid-template-columns: 1fr; }
  .cm-tabs-wrap { padding: 0 1.25rem; }
  .cm-tabs { overflow-x: auto; }
  .cm-tab { padding: .75rem .9rem; font-size: .72rem; }
  .cm-podium { gap: .5rem; }
}

@media (max-width: 480px) {
        .cm-invite-box { flex-direction: column; }
        .cm-invite-box-right { width: 100%; }
        .cm-invite-input { min-width: 100%; }
        .cm-hero-kpis { flex-wrap: wrap; }
        .cm-kpi { flex: 1; min-width: 80px; }
    }

/* ── LinkedIn Buttons ── */
.cm-linkedin-add-btn,
.cm-linkedin-share-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: .35rem .75rem;
  border-radius: 6px;
  font-size: .75rem;
  font-weight: 600;
  text-decoration: none;
  transition: opacity .2s, transform .15s;
  white-space: nowrap;
}
.cm-linkedin-add-btn {
  background: #0A66C2;
  color: #fff;
}
.cm-linkedin-share-btn {
  background: #fff;
  color: #0A66C2;
  border: 1.5px solid #0A66C2;
}
.cm-linkedin-add-btn:hover,
.cm-linkedin-share-btn:hover {
  opacity: .88;
  transform: translateY(-1px);
  color: inherit;
}
@media (max-width: 480px) {
  .cm-mtrack-actions { flex-wrap: wrap; }
  .cm-linkedin-add-btn, .cm-linkedin-share-btn { font-size: .7rem; padding: .3rem .6rem; }
}

/* ── Insights & Articles Grid ─────────────────────────────── */
.cm-articles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.25rem;
  margin-top: .5rem;
}
.cm-article-card {
  background: var(--cm-card-bg);
  border: 1px solid var(--cm-border);
  border-radius: 12px;
  overflow: hidden;
  transition: box-shadow .2s, transform .2s;
  display: flex;
  flex-direction: column;
}
.cm-article-card:hover {
  box-shadow: 0 6px 24px rgba(0,0,0,.10);
  transform: translateY(-2px);
}
.cm-article-thumb {
  height: 160px;
  background-size: cover;
  background-position: center;
  background-color: var(--cm-bg);
  flex-shrink: 0;
}
.cm-article-thumb-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--cm-text-muted);
  opacity: .35;
}
.cm-article-body {
  padding: 1.1rem 1.25rem 1.25rem;
  display: flex;
  flex-direction: column;
  flex: 1;
}
.cm-article-meta-row {
  display: flex;
  align-items: center;
  gap: .5rem;
  flex-wrap: wrap;
  margin-bottom: .6rem;
}
.cm-article-cat {
  font-size: .62rem;
  font-weight: 600;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--cm-accent);
  background: rgba(var(--cm-accent-rgb, 184,150,12), .1);
  padding: .18rem .55rem;
  border-radius: 99px;
  border: 1px solid rgba(var(--cm-accent-rgb, 184,150,12), .2);
}
.cm-article-date,
.cm-article-read {
  font-size: .68rem;
  color: var(--cm-text-muted);
}
.cm-article-date::before { content: "·"; margin-right: .5rem; color: var(--cm-border); }
.cm-article-title {
  font-size: .95rem;
  font-weight: 700;
  color: var(--cm-text);
  line-height: 1.4;
  margin: 0 0 .5rem;
}
.cm-article-excerpt {
  font-size: .82rem;
  color: var(--cm-text-muted);
  line-height: 1.6;
  margin: 0 0 1rem;
  flex: 1;
}
@media (max-width: 600px) {
  .cm-articles-grid { grid-template-columns: 1fr; }
}

/* ═══════════════════════════════════════════════
   EXECUTIVE DASHBOARD — Overview Tab
═══════════════════════════════════════════════ */

/* Panel override for exec dash */
.cm-exec-dash {
  padding: 1.75rem 2rem;
  background: var(--bg);
}

/* ── KPI Strip ── */
.ed-kpi-strip {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
  margin-bottom: 18px;
}
.ed-kpi {
  background: var(--white);
  border: 1px solid var(--b1);
  border-radius: 12px;
  padding: 18px 20px 16px;
  position: relative;
  overflow: hidden;
  transition: box-shadow .2s, transform .2s;
}
.ed-kpi:hover { box-shadow: var(--s2); transform: translateY(-2px); }
.ed-kpi-accent {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  border-radius: 12px 12px 0 0;
}
.ed-kpi-teal  .ed-kpi-accent { background: linear-gradient(90deg, var(--teal), var(--teal2)); }
.ed-kpi-gold  .ed-kpi-accent { background: linear-gradient(90deg, var(--gold), var(--gold2)); }
.ed-kpi-green .ed-kpi-accent { background: linear-gradient(90deg, #166534, #16A34A); }
.ed-kpi-red   .ed-kpi-accent { background: linear-gradient(90deg, var(--red), #DC2626); }

.ed-kpi-val {
  font-family: "DM Serif Display", serif;
  font-size: 2.2rem; line-height: 1;
  color: var(--ink); margin-bottom: 5px;
}
.ed-kpi-delta {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: .68rem; font-weight: 600;
  padding: 2px 8px; border-radius: 99px;
  margin-bottom: 5px;
}
.ed-delta-up  { background: rgba(22,101,52,.1); color: #166534; }
.ed-delta-mid { background: rgba(139,105,20,.1); color: var(--gold); }
.ed-delta-dn  { background: rgba(185,28,28,.1);  color: var(--red); }
.ed-kpi-label {
  font-size: .72rem; color: var(--ink3);
  text-transform: uppercase; letter-spacing: .1em;
}

/* ── Mid Row ── */
.ed-mid-row {
  display: grid;
  grid-template-columns: 1.35fr 1fr;
  gap: 14px;
  margin-bottom: 14px;
}
.ed-mid-row > .ed-panel {
  min-width: 0;
}

/* ── Bot Row ── */
.ed-bot-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  margin-bottom: 18px;
}
.ed-bot-row > .ed-panel {
  min-width: 0;
}

/* ── Panel base ── */
.ed-panel {
  background: var(--white);
  border: 1px solid var(--b1);
  border-radius: 12px;
  padding: 20px 22px;
  box-shadow: var(--s1);
}
.ed-panel-head {
  display: flex; flex-direction: column; gap: 2px;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--b1);
}
.ed-panel-title {
  font-weight: 600; font-size: .88rem; color: var(--ink);
}
.ed-panel-sub {
  font-size: .72rem; color: var(--ink3);
}

/* ── Bar Chart ── */
.ed-panel-chart {}
.ed-bar-chart {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  height: 110px;
  margin-bottom: 10px;
  overflow-x: auto;
}
.ed-bar-col {
  flex: 1;
  min-width: 28px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
  height: 100%;
}
.ed-bar-wrap {
  flex: 1;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  gap: 3px;
}
.ed-bar-pct {
  font-size: .62rem;
  color: var(--ink3);
  font-weight: 600;
}
.ed-bar {
  width: 100%;
  border-radius: 4px 4px 0 0;
  min-height: 4px;
  transition: height .9s cubic-bezier(.4,0,.2,1);
}
.ed-bar-high { background: linear-gradient(180deg, var(--teal2), rgba(13,92,78,.3)); }
.ed-bar-mid  { background: linear-gradient(180deg, var(--gold2), rgba(139,105,20,.3)); }
.ed-bar-low  { background: linear-gradient(180deg, #EF4444, rgba(185,28,28,.25)); }
.ed-bar-label {
  font-size: .6rem;
  color: var(--ink3);
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}
.ed-chart-legend {
  display: flex;
  gap: 14px;
}
.ed-leg {
  display: flex; align-items: center; gap: 5px;
  font-size: .7rem; color: var(--ink3);
}
.ed-leg-dot {
  width: 8px; height: 8px; border-radius: 2px; flex-shrink: 0;
}
.ed-leg-high { background: var(--teal2); }
.ed-leg-mid  { background: var(--gold2); }
.ed-leg-low  { background: #EF4444; }

/* ── Breakdown List ── */
.ed-breakdown-list { display: flex; flex-direction: column; gap: 13px; }
.ed-bl-item {}
.ed-bl-head {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 2px;
}
.ed-bl-name {
  font-size: .8rem; color: var(--ink2); font-weight: 500;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  max-width: 170px;
}
.ed-bl-pct {
  font-family: "DM Serif Display", serif;
  font-size: 1rem; font-weight: 400; flex-shrink: 0;
}
.ed-pct-high { color: var(--teal); }
.ed-pct-mid  { color: var(--gold); }
.ed-pct-low  { color: var(--red); }
.ed-bl-meta {
  font-size: .68rem; color: var(--ink3);
  margin-bottom: 5px;
}
.ed-bl-sep { margin: 0 3px; }
.ed-bl-bar {
  height: 4px;
  background: var(--bg2);
  border-radius: 99px;
  overflow: hidden;
}
.ed-bl-fill {
  height: 100%; border-radius: 99px;
  transition: width 1.1s cubic-bezier(.4,0,.2,1);
}
.ed-blf-high { background: linear-gradient(90deg, var(--teal), var(--teal2)); }
.ed-blf-mid  { background: linear-gradient(90deg, var(--gold), var(--gold2)); }
.ed-blf-low  { background: linear-gradient(90deg, var(--red), #EF4444); }

/* ── Activity Feed ── */
.ed-activity-list { display: flex; flex-direction: column; gap: 10px; }
.ed-act-item {
  display: flex; align-items: center; gap: 10px;
}
.ed-act-av {
  width: 34px; height: 34px; border-radius: 50%;
  flex-shrink: 0; display: flex; align-items: center; justify-content: center;
  font-family: "DM Serif Display", serif; font-size: .85rem; color: #fff;
}
.ed-act-body { flex: 1; min-width: 0; }
.ed-act-name {
  font-size: .82rem; font-weight: 600; color: var(--ink);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.ed-act-detail { font-size: .72rem; color: var(--ink3); }
.ed-act-time {
  font-size: .68rem; color: var(--ink4); flex-shrink: 0;
}
.ed-empty-state {
  font-size: .82rem; color: var(--ink3);
  padding: 1.5rem 0; text-align: center;
}

/* ── Alerts ── */
.ed-alerts { display: flex; flex-direction: column; gap: 9px; }
.ed-alert {
  display: flex; align-items: flex-start; gap: 11px;
  padding: 12px 14px;
  border-radius: 9px;
  border: 1px solid transparent;
  transition: opacity .2s;
}
.ed-alert-crit {
  background: rgba(185,28,28,.05);
  border-color: rgba(185,28,28,.18);
}
.ed-alert-warn {
  background: rgba(139,105,20,.07);
  border-color: rgba(139,105,20,.2);
}
.ed-alert-info {
  background: rgba(13,92,78,.05);
  border-color: rgba(13,92,78,.18);
}
.ed-alert-icon {
  width: 28px; height: 28px; border-radius: 7px;
  flex-shrink: 0; display: flex; align-items: center; justify-content: center;
}
.ed-alert-crit .ed-alert-icon { color: var(--red);  background: rgba(185,28,28,.1); }
.ed-alert-warn .ed-alert-icon { color: var(--gold); background: rgba(139,105,20,.12); }
.ed-alert-info .ed-alert-icon { color: var(--teal); background: rgba(13,92,78,.1); }
.ed-alert-title {
  font-size: .82rem; font-weight: 600; color: var(--ink); margin-bottom: 2px;
}
.ed-alert-desc {
  font-size: .72rem; color: var(--ink3); line-height: 1.5;
}

/* ── Summary Stats ── */
.ed-summary-stats {
  display: grid; grid-template-columns: repeat(3,1fr);
  gap: 1px; background: var(--b1);
  border: 1px solid var(--b1); border-radius: 9px; overflow: hidden;
  margin-top: 12px;
}
.ed-ss-item {
  background: var(--white);
  padding: 12px 10px; text-align: center;
}
.ed-ss-val {
  font-family: "DM Serif Display", serif;
  font-size: 1.4rem; color: var(--teal); line-height: 1;
  margin-bottom: 3px;
}
.ed-ss-lbl {
  font-size: .62rem; color: var(--ink3);
  text-transform: uppercase; letter-spacing: .09em;
}

/* ── Tracks Section Toggle ── */
.ed-tracks-section {
  border: 1px solid var(--b1);
  border-radius: 12px;
  overflow: hidden;
  background: var(--white);
}
.ed-tracks-toggle {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 20px;
  font-size: .82rem; font-weight: 600; color: var(--ink2);
  cursor: pointer; user-select: none;
  transition: background .15s;
}
.ed-tracks-toggle:hover { background: var(--bg); }
.ed-toggle-icon {
  transition: transform .25s;
}
.ed-tracks-section.ed-tracks-open .ed-toggle-icon { transform: rotate(180deg); }
.ed-tracks-body {
  max-height: 0;
  overflow: hidden;
  transition: max-height .4s ease;
  border-top: 1px solid var(--b1);
}
.ed-tracks-section.ed-tracks-open .ed-tracks-body {
  max-height: 2000px;
}
.ed-tracks-body .cm-track-grid { padding: 1.5rem; }

/* Responsive */
@media (max-width: 900px) {
  .ed-kpi-strip   { grid-template-columns: repeat(2,1fr); }
  .ed-mid-row,
  .ed-bot-row     { grid-template-columns: 1fr; }
}
@media (max-width: 560px) {
  .ed-kpi-strip   { grid-template-columns: 1fr 1fr; }
  .ed-kpi-val     { font-size: 1.7rem; }
}
' . ( function_exists('pildcm_cv_tab_css') ? pildcm_cv_tab_css() : '' ) . '
   </style>';
}  // end pildcm_css()

