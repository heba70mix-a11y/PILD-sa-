<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// Color system driven automatically by the track's level (ACF field: track_level).
// No admin color-picking required — the palette is fixed per level.
// ============================================================
function pildcm_get_level_color_palette($level) {
    $level_key = strtolower(trim((string) $level));

    $palettes = [
        'foundation'   => ['border_color' => '#0E6655', 'accent_color' => '#0E6655', 'title_color' => '#0D1117', 'seal' => 'seal-foundation.png'],   // green
        'professional' => ['border_color' => '#1B4F8C', 'accent_color' => '#1B4F8C', 'title_color' => '#0D1117', 'seal' => 'seal-professional.png'], // blue
        'executive'    => ['border_color' => '#5B3A8C', 'accent_color' => '#5B3A8C', 'title_color' => '#0D1117', 'seal' => 'seal-executive.png'],    // purple
    ];

    return isset($palettes[$level_key]) ? $palettes[$level_key] : $palettes['foundation'];
}

// ============================================================
// 23. Add quiz field to Track settings
// ============================================================

function pildcm_add_track_quiz_field() {
    if ( function_exists('acf_add_local_field_group') ) {
        acf_add_local_field_group(array(
            'key' => 'group_pildcm_track_quiz',
            'title' => 'Quiz Settings',
            'fields' => array(
                array(
                    'key' => 'field_track_quiz_id',
                    'label' => 'Quiz ID',
                    'name' => 'track_quiz_id',
                    'type' => 'number',
                    'instructions' => 'Enter the Quiz ID from Quiz Maker',
                    'required' => 0,
                    'default_value' => 0,
                    'placeholder' => 'e.g. 123',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'track',
                    ),
                ),
            ),
        ));
    }
}
add_action('acf/init', 'pildcm_add_track_quiz_field');
// ============================================================
// 24. CERTIFICATE VERIFICATION PAGE
// ============================================================

// Add rewrite rules for verification page
add_action('init', 'pildcm_add_verification_page');
function pildcm_add_verification_page() {
    add_rewrite_rule(
        '^verify-certificate/?$',
        'index.php?pildcm_verify_page=1',
        'top'
    );
    
    add_rewrite_rule(
        '^verify-certificate/([a-zA-Z0-9]+)/?$',
        'index.php?pildcm_verify_page=1&cert_id=$matches[1]',
        'top'
    );
}


// Add query vars
add_filter('query_vars', 'pildcm_verify_query_vars');
function pildcm_verify_query_vars($vars) {
    $vars[] = 'pildcm_verify_page';
    $vars[] = 'cert_id';
    return $vars;
}

// Render verification page
add_action('template_redirect', 'pildcm_render_verification_page');
function pildcm_render_verification_page() {
    if (!get_query_var('pildcm_verify_page')) {
        return;
    }
    
    $cert_id = get_query_var('cert_id');
    pildcm_verification_page_content($cert_id);
    exit;
}

// Verification page content
function pildcm_verification_page_content($cert_id = '') {
    global $wpdb;
    
    $verification_result = null;
    $certificate_data = null;
    
    // Search for certificate
    if (!empty($cert_id)) {
        $certificate_data = $wpdb->get_row($wpdb->prepare(
            "SELECT r.*, u.display_name, u.user_email, t.post_title as track_title
             FROM {$wpdb->prefix}pild_results r
             LEFT JOIN {$wpdb->users} u ON u.ID = r.user_id
             LEFT JOIN {$wpdb->posts} t ON t.ID = r.track_id
             WHERE r.certificate_code = %s AND r.passed = 'yes'
             ORDER BY r.completed_at DESC LIMIT 1",
            sanitize_text_field($cert_id)
        ));

        // Allows includes/15-domain-certification.php to also recognise
        // Practice Area certificate codes, without altering this query.
        $certificate_data = apply_filters('pildcm_verify_certificate_lookup', $certificate_data, $cert_id);
        
        if ($certificate_data) {
            $verification_result = 'valid';
        } else {
            $verification_result = 'invalid';
        }
    }

    // Resolve the certificate's own English title + capabilities once,
    // reused by both the Open Graph meta tags below and the page body
    // further down. Whole page is always English (client decision, Sep
    // 2026), same as the certificate itself.
    $verify_title_en = '';
    $capabilities_text = '';
    if ($certificate_data) {
        $is_domain_result = isset($certificate_data->domain_id) && empty($certificate_data->track_id);
        $content_id_en    = $is_domain_result ? (int) $certificate_data->domain_id : (int) ($certificate_data->track_id ?? 0);
        $verify_title_en  = pildcm_get_english_post_title($content_id_en) ?: $certificate_data->track_title;

        // Capabilities gained — only Tracks carry this (their post_content,
        // set via the القدرات/القدرات_EN column on import); Domain/
        // Practice-Area certs have none.
        if (!$is_domain_result && $content_id_en) {
            $cap_post_id = function_exists('pll_get_post') ? (pll_get_post($content_id_en, 'en') ?: $content_id_en) : $content_id_en;
            $cap_post    = get_post($cap_post_id);
            $capabilities_text = $cap_post ? trim($cap_post->post_content) : '';
        }
    }
    
    // Get site logo
    $site_logo_id = get_theme_mod('custom_logo');
    $site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'medium') : '';
    $site_name = get_bloginfo('name');
    
    // Output HTML — always English (client decision, Sep 2026), not
    // tied to Polylang's current site language.
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Credential Verification - <?php echo esc_html( $site_name ); ?></title>
        <?php if ($verification_result === 'valid' && $certificate_data):
            $og_title       = esc_attr($certificate_data->display_name) . ' — ' . esc_attr($verify_title_en);
            $og_desc        = sprintf( '%1$s has successfully completed "%2$s" on %3$s. Issued %4$s. ID: %5$s', $certificate_data->display_name, $verify_title_en, $site_name, date('F j, Y', strtotime($certificate_data->completed_at)), $certificate_data->certificate_code );
            $og_url         = home_url('/verify-certificate/' . $certificate_data->certificate_code);
            $og_image       = PILD_URL . 'assets/images/pild-logo.png';
        ?>
        <!-- Open Graph / LinkedIn -->
        <meta property="og:type"        content="website">
        <meta property="og:url"         content="<?php echo esc_attr($og_url); ?>">
        <meta property="og:title"       content="🏅 <?php echo $og_title; ?>">
        <meta property="og:description" content="<?php echo esc_attr($og_desc); ?>">
        <meta property="og:image"       content="<?php echo esc_attr($og_image); ?>">
        <meta property="og:image:width"  content="1200">
        <meta property="og:image:height" content="630">
        <meta property="og:site_name"   content="<?php echo esc_attr($site_name); ?>">
        <!-- Twitter Card -->
        <meta name="twitter:card"        content="summary_large_image">
        <meta name="twitter:title"       content="🏅 <?php echo $og_title; ?>">
        <meta name="twitter:description" content="<?php echo esc_attr($og_desc); ?>">
        <meta name="twitter:image"       content="<?php echo esc_attr($og_image); ?>">
        <?php endif; ?>
        <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&amp;family=DM+Sans:wght@300;400;500;600&amp;display=swap" rel="stylesheet">
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: 'DM Sans', sans-serif;
                background: linear-gradient(135deg, #f5f5f0 0%, #e8e6e1 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 2rem;
            }
            .verification-container {
                max-width: 850px;
                width: 100%;
                background: white;
                border-radius: 24px;
                box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
                overflow: hidden;
            }
            .verification-header {
                background: #0D5C4E;
                color: white;
                padding: 2rem;
                text-align: center;
            }
            .verification-header h1 {
                font-family: 'DM Serif Display', serif;
                font-size: 1.8rem;
                margin-bottom: 0.5rem;
                font-weight: 400;
            }
            .verification-header p {
                opacity: 0.85;
                font-size: 0.9rem;
            }
            .verification-body {
                padding: 2rem;
            }
            .search-form {
                margin-bottom: 2rem;
            }
            .search-form label {
                display: block;
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: #2D3348;
                font-size: 0.85rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }
            .search-input-group {
                display: flex;
                gap: 1rem;
                flex-wrap: wrap;
            }
            .search-input-group input {
                flex: 1;
                padding: 14px 18px;
                border: 2px solid #e5e7eb;
                border-radius: 12px;
                font-size: 1rem;
                font-family: 'JetBrains Mono', monospace;
                transition: all 0.3s ease;
                background: #fafafa;
            }
            .search-input-group input:focus {
                outline: none;
                border-color: #0D5C4E;
                background: white;
            }
            .search-input-group button {
                padding: 14px 28px;
                background: #0D5C4E;
                color: white;
                border: none;
                border-radius: 12px;
                cursor: pointer;
                font-weight: 600;
                font-size: 0.9rem;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            .search-input-group button:hover {
                background: #0F7A68;
                transform: translateY(-1px);
            }
            .example-text {
                margin-top: 0.75rem;
                font-size: 0.75rem;
                color: #9CA3AF;
            }
            
            /* Result Styles */
            .result-valid {
                background: linear-gradient(135deg, #f0fdf4, #dcfce7);
                border-left: 4px solid #166534;
                padding: 1.5rem;
                border-radius: 12px;
                margin-top: 1.5rem;
                animation: fadeIn 0.5s ease;
            }
            .result-invalid {
                background: #fef2f2;
                border-left: 4px solid #991b1b;
                padding: 1.5rem;
                border-radius: 12px;
                margin-top: 1.5rem;
                animation: fadeIn 0.5s ease;
            }
            .result-icon {
                display: flex;
                justify-content: center;
                margin-bottom: 1rem;
            }
            .result-title {
                font-size: 1.3rem;
                font-weight: 700;
                margin-bottom: 0.5rem;
            }
            .result-title.valid { color: #166534; }
            .result-title.invalid { color: #991b1b; }
            
            .certificate-details {
                margin-top: 1.5rem;
                border-top: 1px solid rgba(0,0,0,0.1);
                padding-top: 1.5rem;
            }
            .detail-row {
                display: flex;
                padding: 0.75rem 0;
                border-bottom: 1px solid rgba(0,0,0,0.05);
            }
            .detail-label {
                width: 140px;
                font-weight: 600;
                color: #4B5563;
                font-size: 0.85rem;
            }
            .detail-value {
                flex: 1;
                color: #1F2937;
                font-size: 0.9rem;
            }
            .detail-value a {
                color: #0D5C4E;
                text-decoration: none;
            }
            .detail-value a:hover {
                text-decoration: underline;
            }
            .status-badge {
                display: inline-block;
                padding: 0.25rem 0.75rem;
                border-radius: 20px;
                font-size: 0.7rem;
                font-weight: 600;
                text-transform: uppercase;
            }
            .status-valid {
                background: #166534;
                color: white;
            }
            .status-invalid {
                background: #991b1b;
                color: white;
            }
            
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .footer {
                text-align: center;
                padding: 1.5rem;
                background: #f9fafb;
                border-top: 1px solid #e5e7eb;
                font-size: 0.75rem;
                color: #6B7280;
            }
            
            @media (max-width: 640px) {
                .verification-body { padding: 1.5rem; }
                .detail-row { flex-direction: column; gap: 0.25rem; }
                .detail-label { width: 100%; }
                .search-input-group button { width: 100%; justify-content: center; }
            }
        </style>
    </head>
    <body>
        <div class="verification-container">
            <div class="verification-header">
                <?php if ($site_logo_url): ?>
                    <img src="<?php echo esc_url($site_logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>" style="height: 50px; margin-bottom: 1rem;">
                <?php endif; ?>
                <h1>Credential Verification</h1>
                <p>Verify the authenticity of any professional credential issued by <?php echo esc_html( $site_name ); ?></p>
            </div>
            
            <div class="verification-body">
                <form method="GET" action="" class="search-form">
                    <label>🔍 Enter Credential ID</label>
                    <div class="search-input-group">
                        <input type="text" 
                               name="cert_id" 
                               value="<?php echo esc_attr($cert_id); ?>" 
                               placeholder="Example: ABC123XYZ456"
                               autocomplete="off">
                        <button type="submit">
                            <span>🔍</span> Verify Certificate
                        </button>
                    </div>
                    <div class="example-text">
                        💡 Certificate ID can be found at the bottom of any certificate
                    </div>
                </form>
                
                <?php if ($verification_result === 'valid' && $certificate_data): ?>
                    <div class="result-valid">
                        <div class="result-icon result-icon-valid">
                            <svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true">
                                <path d="M20 38l-6 18 12-6 6 10 6-10 12 6-6-18" fill="#0E6655" opacity="0.35"/>
                                <circle cx="32" cy="24" r="21" fill="#0E6655"/>
                                <circle cx="32" cy="24" r="21" fill="none" stroke="#B8960C" stroke-width="2"/>
                                <path d="M22 24.5l6.5 6.5L43 17" stroke="#fff" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="result-title valid">Credential is VALID</div>
                        <p>This certificate has been officially issued by <?php echo esc_html( $site_name ); ?>.</p>
                        
                        <div class="certificate-details">
                            <div class="detail-row">
                                <div class="detail-label">Credential ID:</div>
                                <div class="detail-value">
                                    <code><?php echo esc_html($certificate_data->certificate_code); ?></code>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Issued To:</div>
                                <div class="detail-value">
                                    <strong><?php echo esc_html($certificate_data->display_name); ?></strong><br>
                                    <span style="font-size:0.8rem; color:#6B7280;"><?php echo esc_html($certificate_data->user_email); ?></span>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Certificate For:</div>
                                <div class="detail-value">
                                    <?php echo esc_html($verify_title_en); ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Score:</div>
                                <div class="detail-value">
                                    <?php echo intval($certificate_data->score); ?>%
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Issue Date:</div>
                                <div class="detail-value">
                                    <?php echo date('F j, Y', strtotime($certificate_data->completed_at)); ?>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Status:</div>
                                <div class="detail-value">
                                    <span class="status-badge status-valid">Active &amp; Verified</span>
                                </div>
                            </div>
                            <?php if ($capabilities_text): ?>
                            <div class="detail-row">
                                <div class="detail-label">Capabilities Gained:</div>
                                <div class="detail-value"><?php echo wpautop( esc_html( $capabilities_text ) ); ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                <?php elseif ($verification_result === 'invalid'): ?>
                    <div class="result-invalid">
                        <div class="result-icon result-icon-invalid">
                            <svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true">
                                <circle cx="32" cy="24" r="21" fill="#991B1B"/>
                                <path d="M24 16l16 16M40 16l-16 16" stroke="#fff" stroke-width="3.2" fill="none" stroke-linecap="round"/>
                            </svg>
                        </div>
                        <div class="result-title invalid">Credential is INVALID</div>
                        <p>No valid certificate found with the ID: <strong><?php echo esc_html( $cert_id ); ?></strong></p>
                        <div class="certificate-details">
                            <div class="detail-row">
                                <div class="detail-label">Possible reasons:</div>
                                <div class="detail-value">
                                    <ul style="margin-left: 1.25rem; color: #6B7280;">
                                        <li>The credential ID is incorrect</li>
                                        <li>The credential has been revoked or expired</li>
                                        <li>The credential was never issued</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="detail-row">
                                <div class="detail-label">Need help?</div>
                                <div class="detail-value">
                                    Please contact <a href="mailto:<?php echo esc_attr( get_option('admin_email') ); ?>"><?php echo esc_html( get_option('admin_email') ); ?></a> for assistance.
                                </div>
                            </div>
                        </div>
                    </div>
                <?php elseif ($cert_id && $verification_result === null): ?>
                    <div class="result-invalid">
                        <div class="result-icon">⚠️</div>
                        <div class="result-title invalid">Verification Error</div>
                        <p>Please enter a valid Credential ID to verify.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="footer">
                &copy; <?php echo esc_html( date('Y') . ' ' . $site_name ); ?> - Secure Credential Verification System
            </div>
        </div>
    </body>
    </html>
    <?php
}

// NOTE: There used to be a register_activation_hook(__FILE__, ...) call
// right here. It never actually ran: register_activation_hook() only
// fires for the plugin's MAIN file (pild-unified.php), and __FILE__ inside
// an include file points to THIS file instead — so WordPress never fired
// it. The real flush now happens once, in pild-unified.php's own
// activation flow (see the priority-20 'init' hook near the top of that
// file), AFTER pildcm_add_verification_page() below has already run on
// the same 'init' event and registered its rewrite rules.
// ============================================================
// 25. SECURE CERTIFICATE URL REWRITING
// ============================================================

// Add rewrite rules for secure certificate URLs
add_action('init', 'pildcm_add_certificate_rewrite_rules');
function pildcm_add_certificate_rewrite_rules() {
    add_rewrite_rule(
        '^certificate/([a-zA-Z0-9]+)/?$',
        'index.php?pildcm_certificate_code=$matches[1]',
        'top'
    );
    
    add_rewrite_rule(
        '^cert/([a-zA-Z0-9]+)/?$',
        'index.php?pildcm_certificate_code=$matches[1]',
        'top'
    );
}

// Add query var
add_filter('query_vars', 'pildcm_certificate_query_vars');
function pildcm_certificate_query_vars($vars) {
    $vars[] = 'pildcm_certificate_code';
    return $vars;
}

// Display certificate securely
add_action('template_redirect', 'pildcm_display_secure_certificate');
function pildcm_display_secure_certificate() {
    $cert_code = get_query_var('pildcm_certificate_code');
    
    if (empty($cert_code)) {
        return;
    }
    
    global $wpdb;
    
    // Get certificate data from database
    $certificate = $wpdb->get_row($wpdb->prepare(
        "SELECT r.*, u.display_name, u.user_email, t.post_title as track_title
         FROM {$wpdb->prefix}pild_results r
         LEFT JOIN {$wpdb->users} u ON u.ID = r.user_id
         LEFT JOIN {$wpdb->posts} t ON t.ID = r.track_id
         WHERE r.certificate_code = %s AND r.passed = 'yes'
         ORDER BY r.completed_at DESC LIMIT 1",
        sanitize_text_field($cert_code)
    ));

    // See note in pildcm_verification_page_content() above.
    $certificate = apply_filters('pildcm_verify_certificate_lookup', $certificate, $cert_code);
    
    if (!$certificate) {
        wp_die('Certificate not found or invalid.', 'Error', ['response' => 404]);
    }

    // Certificate is PUBLIC — anyone with the URL can view it
    // (needed for LinkedIn share & verification by third parties)
    // Generate and display certificate HTML
    pildcm_show_certificate_html($certificate);
    exit;
}

// Display certificate HTML
// ============================================================
// PILD BRANDED CERTIFICATE WITH STAMP & WAVY BACKGROUND
// ============================================================

// ============================================================
// PILD BRANDED CERTIFICATE WITH STAMP & WAVY BACKGROUND
// ============================================================
// ── PHASE 22: certificate backgrounds keyed by "Identity", not Sector
// or Track. A Domain's own code (pild_import_code, e.g.
// "DOM-CONSTRUCTION-HR") ends in a shared functional identity — HR,
// LEAD, COMM, MKT, CX, ... — optionally followed by a disambiguating
// number when a Sector has more than one Domain of the same identity
// (e.g. "DOM-EDUCATION-OPS-1" / "...-OPS-2"). Many different Sectors
// share the same identity, and a certificate's background reflects
// that shared identity rather than the specific Sector (client
// decision, Sep 2026 — replaces the earlier per-Sector approach).
// Identities are open-ended: new ones are added anytime from the
// "Certificate Backgrounds" admin page below, no code change needed.
// Stored as one option, identity code => attachment ID:
//   pild_identity_cert_backgrounds = [ 'HR' => 123, 'LEAD' => 456, ... ]
function pildcm_extract_domain_identity($domain_code) {
    $domain_code = trim((string) $domain_code);
    if ($domain_code === '') return '';
    $parts = explode('-', $domain_code);
    if (count($parts) < 2) return '';
    $last = end($parts);
    if (is_numeric($last)) {
        // Drop a trailing disambiguating number: ...-OPS-1 -> ...-OPS
        array_pop($parts);
        $last = end($parts);
    }
    return $last ? strtoupper(trim($last)) : '';
}

function pildcm_get_identity_backgrounds() {
    $stored = get_option('pild_identity_cert_backgrounds', []);
    return is_array($stored) ? $stored : [];
}

function pildcm_get_identity_cert_background($identity) {
    if (!$identity) return '';
    $all           = pildcm_get_identity_backgrounds();
    $attachment_id = (int) ($all[$identity] ?? 0);
    return $attachment_id ? (wp_get_attachment_image_url($attachment_id, 'full') ?: '') : '';
}

// Track -> Domain -> Identity
function pildcm_get_cert_background_for_track($track_id) {
    $domain_id = $track_id ? (int) get_field('track_domain', $track_id) : 0;
    return $domain_id ? pildcm_get_cert_background_for_domain($domain_id) : '';
}
// Domain -> Identity (direct, one hop)
function pildcm_get_cert_background_for_domain($domain_id) {
    if (!$domain_id) return '';
    $code     = get_post_meta($domain_id, 'pild_import_code', true);
    $identity = pildcm_extract_domain_identity($code);
    return pildcm_get_identity_cert_background($identity);
}

// Sector NAME for display only (the certificate's top eyebrow line) —
// separate from the Identity system above, which drives the
// background image and has nothing to do with Sector anymore. Always
// the ENGLISH title regardless of which language the certificate/track/
// domain itself is in (client decision, Sep 2026 — the eyebrow reads
// "{SECTOR NAME} SECTOR" in English no matter what), falling back to
// whatever title exists if there's no English translation or Polylang
// isn't active. Track -> Domain -> Sector ; Domain -> Sector (direct).
function pildcm_get_sector_name_for_track($track_id) {
    $domain_id = $track_id ? (int) get_field('track_domain', $track_id) : 0;
    return $domain_id ? pildcm_get_sector_name_for_domain($domain_id) : '';
}
function pildcm_get_sector_name_for_domain($domain_id) {
    $sector_id = $domain_id ? (int) get_field('domain_sector', $domain_id) : 0;
    return $sector_id ? pildcm_get_english_post_title($sector_id) : '';
}

// Resolves ANY post to its English translation's title (falls back to
// the given post's own title if there's no English version or Polylang
// isn't active). Shared by the Sector eyebrow and the Practice Area /
// content-title helpers below — the whole certificate is English top to
// bottom except the recipient's own name field, which is shown exactly
// as they typed it (client decision, Sep 2026).
function pildcm_get_english_post_title($post_id) {
    if (!$post_id) return '';
    if (function_exists('pll_get_post')) {
        $en_id = pll_get_post($post_id, 'en');
        if ($en_id) $post_id = $en_id;
    }
    return get_the_title($post_id);
}

// Domain (Practice Area) name shown in the certificate's detail box —
// forced to English like everything else on the certificate.
// Track -> Domain (direct).
function pildcm_get_domain_name_for_track($track_id) {
    $domain_id = $track_id ? (int) get_field('track_domain', $track_id) : 0;
    return $domain_id ? pildcm_get_english_post_title($domain_id) : '';
}

// ── 22.1 Admin page: manage identity backgrounds ──────────────────
// ── 22.2 One-off migration tool: rename an existing post's
//         pild_import_code IN PLACE (does not create a new post, does
//         not touch anything else — title, ACF relationships, enrolled
//         members' results all stay attached to the same post). For
//         Sectors/Domains/Tracks/Programs/Books that were imported
//         before the client's Identity naming convention existed (e.g.
//         old-style "DOM-OILGAS-03" that needs to become
//         "DOM-OILGAS-COMM" so its certificates pick up the right
//         Identity background) — see pildcm_extract_domain_identity()
//         above.
add_action('admin_menu', 'pildcm_code_rename_menu');
function pildcm_code_rename_menu() {
    add_submenu_page('pild-settings', 'Fix Import Codes', 'Fix Import Codes',
        'manage_options', 'pild-fix-codes', 'pildcm_code_rename_page');
}

function pildcm_code_rename_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;

    $results = [];
    if (!empty($_POST['pildcm_code_rename_pairs']) && check_admin_referer('pildcm_code_rename', 'pildcm_code_rename_nonce')) {
        $lines = preg_split('/\r?\n/', trim(wp_unslash($_POST['pildcm_code_rename_pairs'])));
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $pair = array_map('trim', explode(',', $line, 2));
            if (count($pair) !== 2 || $pair[0] === '' || $pair[1] === '') {
                $results[] = ['old' => $pair[0] ?? $line, 'new' => $pair[1] ?? '', 'status' => 'صيغة غلط (المفروض: كود_قديم, كود_جديد)'];
                continue;
            }
            [$old_code, $new_code] = $pair;

            $post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='pild_import_code' AND meta_value=%s LIMIT 1",
                $old_code
            ));
            if (!$post_id) {
                $results[] = ['old' => $old_code, 'new' => $new_code, 'status' => '✗ مفيش بوست بالكود القديم ده'];
                continue;
            }
            $conflict = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='pild_import_code' AND meta_value=%s LIMIT 1",
                $new_code
            ));
            if ($conflict) {
                $results[] = ['old' => $old_code, 'new' => $new_code, 'status' => '✗ الكود الجديد ده مستخدم بالفعل في بوست تاني'];
                continue;
            }

            update_post_meta((int) $post_id, 'pild_import_code', $new_code);
            clean_post_cache((int) $post_id);
            $results[] = ['old' => $old_code, 'new' => $new_code, 'status' => '✓ اتغيّر (' . get_the_title($post_id) . ')'];
        }
        if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
    }
    ?>
    <div class="wrap">
        <h1>🔧 تصحيح أكواد الاستيراد</h1>
        <p style="color:#666; max-width:700px">لتصحيح كود قطاع/مجال/تراك/برنامج/كتاب موجود بالفعل — بيغيّر الكود على نفس البوست من غير ما يعمل نسخة جديدة. مفيد لو محتوى قديم مكوّد بشكل مختلف عن الشكل الحالي (زي أكواد المجالات القديمة اللي كانت أرقام بدل هويات).</p>

        <?php if ($results): ?>
        <table class="widefat striped" style="max-width:800px; margin-bottom:1.5rem">
            <thead><tr><th>الكود القديم</th><th>الكود الجديد</th><th>النتيجة</th></tr></thead>
            <tbody>
            <?php foreach ($results as $r): ?>
                <tr><td><code><?php echo esc_html($r['old']); ?></code></td><td><code><?php echo esc_html($r['new']); ?></code></td><td><?php echo esc_html($r['status']); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('pildcm_code_rename', 'pildcm_code_rename_nonce'); ?>
            <p>سطر لكل تغيير، بالصيغة: <code>الكود_القديم, الكود_الجديد</code></p>
            <textarea name="pildcm_code_rename_pairs" rows="10" style="width:100%; max-width:700px; font-family:monospace;" placeholder="DOM-OILGAS-01, DOM-OILGAS-LEAD&#10;DOM-OILGAS-02, DOM-OILGAS-HR&#10;DOM-OILGAS-03, DOM-OILGAS-COMM"></textarea>
            <p><button type="submit" class="button button-primary">تنفيذ التصحيح</button></p>
        </form>
    </div>
    <?php
}


add_action('admin_menu', 'pildcm_identity_bg_menu');
function pildcm_identity_bg_menu() {
    add_submenu_page('pild-settings', 'Certificate Backgrounds', 'Certificate Backgrounds',
        'manage_options', 'pild-cert-identity-bg', 'pildcm_identity_bg_page');
}

function pildcm_identity_bg_page() {
    if (!current_user_can('manage_options')) return;

    // Add or replace one identity's background.
    if (!empty($_POST['pildcm_identity_bg_action']) && check_admin_referer('pildcm_identity_bg', 'pildcm_identity_bg_nonce')) {
        $identity = strtoupper(trim(sanitize_text_field($_POST['identity_code'] ?? '')));
        $identity = preg_replace('/[^A-Z0-9_]/', '', $identity);

        if ($identity === '') {
            echo '<div class="notice notice-error"><p>اكتب كود الهوية (زي HR أو LEAD).</p></div>';
        } elseif (empty($_FILES['identity_image']['name'])) {
            echo '<div class="notice notice-error"><p>اختار صورة الخلفية.</p></div>';
        } else {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            $attachment_id = media_handle_upload('identity_image', 0);
            if (is_wp_error($attachment_id)) {
                echo '<div class="notice notice-error"><p>فشل الرفع: ' . esc_html($attachment_id->get_error_message()) . '</p></div>';
            } else {
                $all = pildcm_get_identity_backgrounds();
                $all[$identity] = $attachment_id;
                update_option('pild_identity_cert_backgrounds', $all);
                if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
                echo '<div class="notice notice-success"><p>✓ اتسجّلت خلفية الهوية "' . esc_html($identity) . '".</p></div>';
            }
        }
    }

    // Remove one identity mapping.
    if (!empty($_POST['pildcm_identity_bg_remove']) && check_admin_referer('pildcm_identity_bg_remove', 'pildcm_identity_bg_remove_nonce')) {
        $identity = sanitize_text_field($_POST['pildcm_identity_bg_remove']);
        $all = pildcm_get_identity_backgrounds();
        unset($all[$identity]);
        update_option('pild_identity_cert_backgrounds', $all);
        echo '<div class="notice notice-success"><p>✓ اتشالت خلفية الهوية "' . esc_html($identity) . '".</p></div>';
    }

    // Bulk upload: one .zip with files named IDENTITY.jpg/png/webp.
    if (!empty($_POST['pildcm_identity_bg_bulk']) && check_admin_referer('pildcm_identity_bg_bulk', 'pildcm_identity_bg_bulk_nonce')) {
        if (empty($_FILES['identity_zip']['name'])) {
            echo '<div class="notice notice-error"><p>اختار ملف ZIP.</p></div>';
        } else {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';

            // unzip_file() needs WP_Filesystem initialized first, or it
            // fails with a generic "Could not access filesystem." error.
            global $wp_filesystem;
            if (empty($wp_filesystem)) WP_Filesystem();

            $tmp_extract_dir = get_temp_dir() . 'pild-identity-bg-' . wp_generate_password(8, false);
            $unzip_result = unzip_file($_FILES['identity_zip']['tmp_name'], $tmp_extract_dir);

            if (is_wp_error($unzip_result)) {
                echo '<div class="notice notice-error"><p>فشل فك الضغط: ' . esc_html($unzip_result->get_error_message()) . '</p></div>';
            } else {
                $all = pildcm_get_identity_backgrounds();
                $ok = []; $skipped = [];
                foreach (glob($tmp_extract_dir . '/*') as $file_path) {
                    $filename = basename($file_path);
                    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) continue;

                    $identity = strtoupper(preg_replace('/[^A-Za-z0-9_]/', '', pathinfo($filename, PATHINFO_FILENAME)));
                    if ($identity === '') { $skipped[] = $filename; continue; }

                    $mime = ($ext === 'png') ? 'image/png' : (($ext === 'webp') ? 'image/webp' : 'image/jpeg');
                    $upload = wp_upload_bits($filename, null, file_get_contents($file_path));
                    if (!empty($upload['error'])) { $skipped[] = $filename; continue; }

                    $attachment_id = wp_insert_attachment([
                        'post_mime_type' => $mime,
                        'post_title'     => sanitize_file_name($filename),
                        'post_status'    => 'inherit',
                    ], $upload['file']);
                    if (is_wp_error($attachment_id) || !$attachment_id) { $skipped[] = $filename; continue; }
                    wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $upload['file']));

                    $all[$identity] = $attachment_id;
                    $ok[] = $identity;
                }
                update_option('pild_identity_cert_backgrounds', $all);
                if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();

                // Clean up extracted temp files.
                foreach (glob($tmp_extract_dir . '/*') as $f) @unlink($f);
                @rmdir($tmp_extract_dir);

                if ($ok) echo '<div class="notice notice-success"><p>✓ اتسجّلوا ' . count($ok) . ' هوية: ' . esc_html(implode(', ', $ok)) . '</p></div>';
                if ($skipped) echo '<div class="notice notice-warning"><p>⚠️ اتجاهلوا (اسم مش صالح أو مش صورة): ' . esc_html(implode(', ', $skipped)) . '</p></div>';
                if (!$ok && !$skipped) echo '<div class="notice notice-warning"><p>الملف المضغوط فاضي أو مفيهوش صور.</p></div>';
            }
        }
    }

    $all = pildcm_get_identity_backgrounds();
    ksort($all);
    ?>
    <div class="wrap">
        <h1>🎨 خلفيات شهادات — حسب الهوية</h1>
        <p style="color:#666; max-width:700px">كل خلفية هنا بتتربط بـ"هوية" (آخر جزء غير رقمي في كود المجال — مثلاً <code>DOM-CONSTRUCTION-HR</code> هويته <code>HR</code>). أي مجال في أي قطاع بنفس الهوية دي هياخد نفس الخلفية تلقائيًا، لتراك المجال ولشهادة المجال نفسها.</p>

        <h2 style="margin-top:2rem">الهويات المسجّلة (<?php echo count($all); ?>)</h2>
        <?php if (empty($all)): ?>
            <p style="color:#888">لسه مفيش أي هوية متسجلة.</p>
        <?php else: ?>
        <table class="widefat striped" style="max-width:800px">
            <thead><tr><th style="width:160px">الهوية</th><th style="width:200px">الخلفية</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($all as $identity => $attachment_id): $url = wp_get_attachment_image_url($attachment_id, 'medium'); ?>
                <tr>
                    <td><strong><?php echo esc_html($identity); ?></strong></td>
                    <td><?php if ($url): ?><img src="<?php echo esc_url($url); ?>" style="max-width:180px; border:1px solid #ddd; border-radius:4px;"><?php else: ?><em style="color:#c00">الصورة اتمسحت من مكتبة الميديا</em><?php endif; ?></td>
                    <td>
                        <form method="post" onsubmit="return confirm('تمسح خلفية الهوية دي؟');">
                            <?php wp_nonce_field('pildcm_identity_bg_remove', 'pildcm_identity_bg_remove_nonce'); ?>
                            <input type="hidden" name="pildcm_identity_bg_remove" value="<?php echo esc_attr($identity); ?>">
                            <button type="submit" class="button">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <h2 style="margin-top:2.5rem">➕ إضافة / تحديث هوية</h2>
        <p style="color:#666; max-width:700px">اكتب كود الهوية بالظبط زي ما هو مستخدم في أكواد المجالات (زي <code>HR</code>, <code>LEAD</code>, <code>COMM</code>, <code>MKT</code>, <code>CX</code>...). لو الهوية موجودة بالفعل، الصورة الجديدة هتستبدل القديمة.</p>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('pildcm_identity_bg', 'pildcm_identity_bg_nonce'); ?>
            <input type="hidden" name="pildcm_identity_bg_action" value="1">
            <table class="form-table">
                <tr>
                    <th><label for="identity_code">كود الهوية</label></th>
                    <td><input type="text" name="identity_code" id="identity_code" placeholder="مثال: HR" style="text-transform:uppercase; width:200px;" required></td>
                </tr>
                <tr>
                    <th><label for="identity_image">صورة الخلفية</label></th>
                    <td><input type="file" name="identity_image" id="identity_image" accept=".jpg,.jpeg,.png,.webp" required>
                        <p class="description">المقاس الموصى به: 3508×2480 بكسل (A4 عرضي، 300 DPI).</p>
                    </td>
                </tr>
            </table>
            <p><button type="submit" class="button button-primary">حفظ</button></p>
        </form>

        <h2 style="margin-top:2.5rem">📦 رفع دفعة واحدة (ZIP)</h2>
        <p style="color:#666; max-width:700px">ملف ZIP فيه أكتر من صورة مع بعض — كل صورة لازم اسمها يكون كود الهوية بالظبط (زي <code>HR.jpg</code>, <code>LEAD.jpg</code>). كل صورة في الملف هتتسجل كهوية لوحدها تلقائيًا، وأي هوية موجودة هتتحدّث.</p>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('pildcm_identity_bg_bulk', 'pildcm_identity_bg_bulk_nonce'); ?>
            <input type="hidden" name="pildcm_identity_bg_bulk" value="1">
            <input type="file" name="identity_zip" accept=".zip" required>
            <p><button type="submit" class="button button-primary">رفع الملف المضغوط</button></p>
        </form>
    </div>
    <?php
}

// Resolves colors/seal/background for ANY certificate row — a Track
// result (has ->track_id) or a Practice-Area/Domain result (has
// ->domain_id instead, no ->track_id — see
// pildcm_verify_domain_certificate_lookup() in
// includes/15-domain-certification.php, which is what makes a Domain
// result reach this same renderer at all). Track certs keep their
// existing per-track Level (Foundation/Professional/Executive,
// track_level ACF field) — this only affects the 'level' value returned
// (no longer used for seal/color rendering now that logo+seal are baked
// into the identity background image itself; kept for any future use).
// Background now always comes from the certificate's Identity (see
// helpers above) — the old per-Track override and per-Sector approach
// are both removed (client decision, Sep 2026); a Track/Domain whose
// identity has no background registered yet falls back to the plugin's
// bundled default pattern.
function pildcm_get_cert_design($certificate) {
    $is_domain_cert = isset($certificate->domain_id) && empty($certificate->track_id);

    if ($is_domain_cert) {
        $bg_image   = pildcm_get_cert_background_for_domain((int) $certificate->domain_id);
        $level      = 'Executive';
        $badge_text = '';
        $font_style = 'serif';
    } else {
        $track_id   = (int) ($certificate->track_id ?? 0);
        $bg_image   = pildcm_get_cert_background_for_track($track_id);
        $level      = get_field('track_level', $track_id) ?: 'Foundation';
        $badge_text = get_post_meta($track_id, 'pildcm_cert_badge_text', true);
        $font_style = get_post_meta($track_id, 'pildcm_cert_font_style', true) ?: 'serif';
    }

    $palette = pildcm_get_level_color_palette($level);

    return [
        'style'        => 'classic',
        'border_color' => $palette['border_color'],
        'accent_color' => $palette['accent_color'],
        'title_color'  => $palette['title_color'],
        'seal'         => $palette['seal'],
        'bg_image'     => $bg_image,
        'badge_text'   => $badge_text,
        'font_style'   => $font_style,
        'level'        => $level,
    ];
}

function pildcm_show_certificate_html($certificate) {
    // Get company info (manager's logo) — only for members linked to an organisation
    $manager_id = pildcm_get_member_manager($certificate->user_id);
    $has_manager = ! empty( $manager_id );
    $company_name = $has_manager ? (get_user_meta($manager_id, 'pild_company_name', true) ?: get_userdata($manager_id)->display_name) : '';
    $company_logo_id = $has_manager ? get_user_meta($manager_id, 'pild_company_logo_id', true) : '';
    $company_logo_url = $company_logo_id ? wp_get_attachment_image_url($company_logo_id, 'medium') : '';

    // Organisation / training-center logo — the site's own logo (Settings →
    // General / Appearance → Customize → Site Identity), shown top-right in
    // place of the track-level badge. Tracks/certificates here don't use
    // levels, so no level word is ever printed on the certificate.
    $org_logo_id  = get_theme_mod( 'custom_logo' );
    $org_logo_url = $org_logo_id ? wp_get_attachment_image_url( $org_logo_id, 'medium' ) : '';

    // Certificate design: colors/seal by Level (Track) or capstone tier
    // (Domain/Practice-Area), background by Identity — see
    // pildcm_get_cert_design() above.
    $design = pildcm_get_cert_design($certificate);
    $is_domain_cert = isset($certificate->domain_id) && empty($certificate->track_id);
    $sector_name = $is_domain_cert
        ? pildcm_get_sector_name_for_domain((int) $certificate->domain_id)
        : pildcm_get_sector_name_for_track((int) ($certificate->track_id ?? 0));
    // Main content title (the Track or Domain name shown under "has
    // successfully demonstrated...") — forced to English like everything
    // else on the certificate except the recipient's own name.
    $content_title_en = pildcm_get_english_post_title(
        $is_domain_cert ? (int) $certificate->domain_id : (int) ($certificate->track_id ?? 0)
    ) ?: $certificate->track_title; // fallback if English resolution somehow fails
    // Practice Area shown in the detail box: for a Track cert, the Domain
    // it belongs to; for a Domain/Practice-Area cert, that Domain itself
    // (same value already shown as the main content title above — this
    // is intentional, a Domain cert's own detail box just confirms it).
    $practice_area_name = $is_domain_cert
        ? $content_title_en
        : pildcm_get_domain_name_for_track((int) ($certificate->track_id ?? 0));
    
    // Font family based on selection
    $font_family = ($design['font_style'] == 'serif') ? "'Playfair Display', serif" : (($design['font_style'] == 'sans') ? "'DM Sans', sans-serif" : "'Playfair Display', 'DM Sans', serif");
    
    // Site logo and level seal are no longer rendered by code — both are
    // baked directly into the identity background image now (client
    // decision, Sep 2026; see pildcm_get_cert_background_for_track() /
    // ..._for_domain() above).
    $site_name = get_bloginfo('name');
    $verification_url = home_url('/verify-certificate/' . $certificate->certificate_code);
    $og_cert_title = '🏅 ' . $certificate->display_name . ' — ' . $certificate->track_title;
    $og_cert_desc  = sprintf( __( '%1$s has successfully completed "%2$s" on %3$s. Issued %4$s. Verify: %5$s', 'pild-unified' ), $certificate->display_name, $certificate->track_title, $site_name, date_i18n('F j, Y', strtotime($certificate->completed_at)), $verification_url );
    $og_cert_image = PILD_URL . 'assets/images/pild-logo.png';
    
    // Background watermark pattern — bundled with the plugin, shown on
    // every certificate whose Sector has no custom background uploaded yet
    // (PILD Settings → edit the Sector → Certificate Background).
    $default_bg_image = PILD_URL . 'assets/images/cert-bg-pattern.jpg';
    $bg_image_to_use   = $design['bg_image'] ?: $default_bg_image;
    $bg_style = "background-image: url('{$bg_image_to_use}'); background-size: cover; background-position: center; background-color: #ffffff;";
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo esc_attr( function_exists('pll_current_language') ? pll_current_language() : 'en' ); ?>" <?php echo (function_exists('pll_current_language') && pll_current_language() === 'ar') ? 'dir="rtl"' : ''; ?>>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php printf( esc_html__( 'PILD Certificate | %s', 'pild-unified' ), esc_html( $certificate->track_title ) ); ?></title>
        <!-- Open Graph / LinkedIn -->
        <meta property="og:type"         content="website">
        <meta property="og:url"          content="<?php echo esc_attr($verification_url); ?>">
        <meta property="og:title"        content="<?php echo esc_attr($og_cert_title); ?>">
        <meta property="og:description"  content="<?php echo esc_attr($og_cert_desc); ?>">
        <meta property="og:image"        content="<?php echo esc_attr($og_cert_image); ?>">
        <meta property="og:image:width"  content="1200">
        <meta property="og:image:height" content="630">
        <meta property="og:site_name"    content="<?php echo esc_attr($site_name); ?>">
        <!-- Twitter Card -->
        <meta name="twitter:card"        content="summary_large_image">
        <meta name="twitter:title"       content="<?php echo esc_attr($og_cert_title); ?>">
        <meta name="twitter:description" content="<?php echo esc_attr($og_cert_desc); ?>">
        <meta name="twitter:image"       content="<?php echo esc_attr($og_cert_image); ?>">
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
        <style>
            *{margin:0;padding:0;box-sizing:border-box}
            @page{size:A4 landscape;margin:0}
            body{font-family:'DM Sans',sans-serif;background:#f0ede8;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:2rem;}
            .certificate{position:relative;width:297mm;height:210mm;<?php echo $bg_style; ?>border-radius:12px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.08);display:flex;flex-direction:column;-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact;direction:ltr;text-align:left;}
            .certificate::before{content:'';position:absolute;top:15px;left:15px;right:15px;bottom:15px;border:1px solid <?php echo esc_attr($design['accent_color']); ?>;border-radius:8px;pointer-events:none;opacity:0.4;z-index:1;}
            <?php if ($org_logo_url): ?>
            .cert-org-logo{position:absolute;top:26px;right:30px;height:38px;max-width:150px;z-index:3;display:flex;align-items:center;}
            .cert-org-logo img{height:100%;width:auto;max-width:150px;object-fit:contain;}
            <?php endif; ?>
            <?php if ($design['badge_text']): ?>
            .cert-track-abbr{display:inline-flex;align-items:center;justify-content:center;font-family:'DM Sans',sans-serif;font-size:14px;line-height:1;font-weight:700;letter-spacing:1.5px;color:#fff;background:<?php echo esc_attr($design['accent_color']); ?>;padding:7px 14px;border-radius:6px;margin-left:14px;vertical-align:middle;white-space:nowrap;}
            <?php endif; ?>
            .certificate-inner{padding:45px 55px;flex:1;display:flex;flex-direction:column;position:relative;z-index:2;}
            .certificate-logos{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid rgba(0,0,0,0.08);}
            .logo-slot{height:55px;width:160px;display:flex;align-items:center;justify-content:flex-start;overflow:hidden;}
            .certificate-logos .logo-slot:last-child{justify-content:flex-end;}
            .logo-slot img{max-height:100%;max-width:100%;object-fit:contain;border:none;box-shadow:none;background:transparent;filter:none;}
            .logo-partner-group{display:flex;align-items:center;gap:18px;}
            .logo-divider{width:1px;align-self:stretch;margin:6px 0;background:rgba(0,0,0,0.12);}
            .logo-partner-label{font-size:9px;letter-spacing:1px;text-transform:uppercase;color:#9CA3AF;text-align:right;margin-bottom:3px;}
            .pild-logo-img{height:50px;width:auto;}
            .company-logo{max-height:55px;max-width:150px;object-fit:contain;}
            .certificate-content{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding-top:38px;}
            .cert-eyebrow-row{display:flex;align-items:center;justify-content:center;gap:14px;margin-bottom:16px;width:100%;max-width:520px;}
            .cert-eyebrow-line{flex:1;height:1px;background:<?php echo esc_attr($design['accent_color']); ?>;opacity:.45;}
            .cert-eyebrow{font-size:11px;line-height:1.4;letter-spacing:3px;text-transform:uppercase;color:<?php echo esc_attr($design['accent_color']); ?>;font-weight:500;white-space:nowrap;}
            .certificate-content > .cert-eyebrow{margin-bottom:16px;}
            .cert-title{font-family:<?php echo $font_family; ?>;font-size:42px;line-height:1.2;font-weight:600;color:<?php echo esc_attr($design['title_color']); ?>;margin-bottom:16px;}
            .cert-title em{font-style:normal;font-weight:600;color:<?php echo esc_attr($design['title_color']); ?>;}
            .cert-subtitle{font-size:13px;line-height:1.5;color:#6B7280;margin-bottom:32px;}
            .cert-recipient-label{font-size:12px;line-height:1.4;text-transform:uppercase;letter-spacing:2px;color:#6B7280;margin-bottom:8px;}
            .cert-recipient-name{font-family:<?php echo $font_family; ?>;font-size:36px;line-height:1.25;font-weight:600;color:<?php echo esc_attr($design['title_color']); ?>;margin-bottom:24px;padding-bottom:16px;border-bottom:2px solid <?php echo esc_attr($design['accent_color']); ?>;display:inline-block;}
            .cert-description{font-size:14px;line-height:1.5;color:#4B5563;margin-bottom:8px;}
            .cert-track{font-family:<?php echo $font_family; ?>;font-size:26px;line-height:1.3;font-weight:600;color:<?php echo esc_attr($design['accent_color']); ?>;margin-bottom:32px;}
            .cert-details{display:flex;gap:48px;justify-content:center;margin-bottom:32px;}
            .cert-detail-item{text-align:center;}
            .cert-detail-label{font-size:10px;line-height:1.4;text-transform:uppercase;letter-spacing:1.5px;color:#6B7280;margin-bottom:4px;}
            .cert-detail-value{font-size:16px;line-height:1.3;font-weight:600;color:#1F2937;}
            .cert-id-line{font-size:12px;color:#6B7280;}
            .cert-id-value{font-family:monospace;font-size:12px;letter-spacing:.5px;}
            .cert-divider{width:100px;height:2px;background:linear-gradient(90deg,transparent,<?php echo esc_attr($design['accent_color']); ?>,transparent);margin:20px auto;}
            .certificate-stamp{position:absolute;bottom:110px;right:65px;width:130px;height:130px;opacity:0.9;z-index:10;} /* unused now — seal is baked into the identity background image */
            .stamp-image{width:100%;height:100%;object-fit:contain;}
            .certificate-footer{margin-top:auto;margin-bottom:22px;padding-top:20px;border-top:1px solid rgba(0,0,0,0.08);display:flex;flex-direction:column;align-items:flex-start;gap:10px;font-size:12px;color:#6B7280;}
            .cert-capability-tags{letter-spacing:1.5px;text-transform:uppercase;font-size:12px;color:#9CA3AF;}
            .verify-link a{color:<?php echo esc_attr($design['accent_color']); ?>;text-decoration:none;}
            .download-buttons{position:fixed;bottom:28px;right:28px;display:flex;gap:10px;z-index:1000;}
            .download-btn{font-family:'DM Sans',sans-serif;font-size:13.5px;font-weight:500;padding:12px 24px;border-radius:8px;cursor:pointer;background:#0D1117;color:#F5F1E8;border:1px solid rgba(255,255,255,0.08);display:inline-flex;align-items:center;gap:9px;letter-spacing:0.2px;box-shadow:0 4px 16px rgba(0,0,0,0.18);transition:background .2s ease,color .2s ease,box-shadow .2s ease,transform .2s ease;}
            .download-btn svg{width:15px;height:15px;flex-shrink:0;}
            .download-btn:hover{background:<?php echo esc_attr($design['accent_color']); ?>;color:#0D1117;box-shadow:0 6px 20px rgba(0,0,0,0.22);transform:translateY(-1px);}
            @media print{html{-webkit-print-color-adjust:exact;print-color-adjust:exact;}body{background:white;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact;}.download-buttons{display:none;}.certificate{box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
        </style>
    </head>
    <body>
        <div class="certificate">
            <?php if ($org_logo_url): ?>
            <div class="cert-org-logo"><img src="<?php echo esc_url($org_logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>"></div>
            <?php endif; ?>
            <div class="certificate-inner">
                <?php if ($has_manager): ?>
                <div class="certificate-logos">
                    <div class="logo-partner-group">
                        <div class="logo-partner-label"><?php esc_html_e( 'In partnership with', 'pild-unified' ); ?></div>
                        <div class="logo-slot">
                            <?php if ($company_logo_url): ?>
                                <img src="<?php echo esc_url($company_logo_url); ?>" alt="<?php echo esc_attr($company_name); ?>" class="company-logo">
                            <?php else: ?>
                                <div style="font-size:12px; color:#6B7280;"><?php echo esc_html($company_name); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="certificate-content">
                    <div class="cert-title">PILD Professional Certification</div>
                    <div class="cert-subtitle">PLATFORM FOR INSTITUTIONAL LEADERSHIP DEVELOPMENT</div>
                    
                    <div class="cert-recipient-label">This is to certify that</div>
                    <div class="cert-recipient-name"><?php echo esc_html($certificate->display_name); ?></div>
                    
                    <div class="cert-description">has successfully demonstrated the required professional capabilities in</div>
                    <div class="cert-track"><?php echo esc_html($content_title_en); ?><?php if ($design['badge_text']): ?><span class="cert-track-abbr"><?php echo esc_html($design['badge_text']); ?></span><?php endif; ?></div>
                    
                    <div class="cert-details">
                        <div class="cert-detail-item">
                            <div class="cert-detail-label">Certification Date</div>
                            <div class="cert-detail-value"><?php echo date('F j, Y', strtotime($certificate->completed_at)); ?></div>
                        </div>
                        <div class="cert-detail-item">
                            <div class="cert-detail-label">Practice Area</div>
                            <div class="cert-detail-value"><?php echo esc_html($practice_area_name); ?></div>
                        </div>
                    </div>

                    <div class="cert-divider"></div>
                </div>
                
                <div class="certificate-footer">
                    <div class="cert-id-line">Certificate ID: <span class="cert-id-value"><?php echo esc_html($certificate->certificate_code); ?></span></div>
                    <div class="verify-link">Verify this certificate at: <a href="<?php echo esc_url($verification_url); ?>" dir="ltr"><?php echo esc_url($verification_url); ?></a></div>
                    <div class="cert-capability-tags">Leadership / Knowledge / Capability / Impact</div>
                </div>
            </div>
        </div>
        
        <div class="download-buttons">
            <button class="download-btn" onclick="window.print()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg><?php esc_html_e( 'Download PDF', 'pild-unified' ); ?></button>
        </div>
    </body>
    </html>
    <?php
}

// Modify the certificate URL generation to use the new secure URL
function pildcm_get_certificate_url_secure($user_id, $track_id) {
    global $wpdb;
    $cert = $wpdb->get_row($wpdb->prepare(
        "SELECT certificate_code FROM {$wpdb->prefix}pild_results 
         WHERE user_id = %d AND track_id = %d AND passed = 'yes' 
         ORDER BY completed_at DESC LIMIT 1",
        $user_id, $track_id
    ));
    
    if ($cert && $cert->certificate_code) {
        return home_url('/certificate/' . $cert->certificate_code);
    }
    
    return '';
}
// ============================================================
// 26. CUSTOM CERTIFICATE DESIGN PER TRACK (METABOX)
// ============================================================

// Add certificate design metabox to Track post type
add_action('add_meta_boxes', 'pildcm_add_cert_design_metabox');
function pildcm_add_cert_design_metabox() {
    add_meta_box(
        'pildcm_cert_design',
        'Certificate Design',
        'pildcm_cert_design_callback',
        'track',
        'normal',
        'high'
    );
}

// Metabox callback
function pildcm_cert_design_callback($post) {
    wp_nonce_field('pildcm_cert_design_nonce', 'pildcm_cert_design_nonce');

    $design_style = get_post_meta($post->ID, 'pildcm_cert_design_style', true);
    // Background image is no longer set per-track — see the Sector's own
    // "Certificate Background" field instead (client decision, Sep 2026).
    $badge_text = get_post_meta($post->ID, 'pildcm_cert_badge_text', true);
    $font_style = get_post_meta($post->ID, 'pildcm_cert_font_style', true);

    $level   = get_field('track_level', $post->ID) ?: 'Foundation';
    $palette = pildcm_get_level_color_palette($level);

    ?>
    <style>
        .pildcm-design-preview {
            background: #f5f5f5;
            padding: 20px;
            margin-top: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .pildcm-color-row {
            display: inline-block;
            width: 50px;
            height: 30px;
            border-radius: 4px;
            margin: 5px;
        }
    </style>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <!-- Left Column -->
        <div>
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Design Style:</label>
                <select name="pildcm_cert_design_style" id="design_style" style="width: 100%;">
                    <option value="classic" <?php selected($design_style, 'classic'); ?>>Classic</option>
                    <option value="modern" <?php selected($design_style, 'modern'); ?>>Modern</option>
                    <option value="elegant" <?php selected($design_style, 'elegant'); ?>>Elegant</option>
                    <option value="minimal" <?php selected($design_style, 'minimal'); ?>>Minimal</option>
                </select>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Font Style:</label>
                <select name="pildcm_cert_font_style" id="font_style" style="width: 100%;">
                    <option value="serif" <?php selected($font_style, 'serif'); ?>>Serif (Playfair Display)</option>
                    <option value="sans" <?php selected($font_style, 'sans'); ?>>Sans Serif (DM Sans)</option>
                    <option value="mix" <?php selected($font_style, 'mix'); ?>>Mixed (Serif + Sans)</option>
                </select>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Track Abbreviation (optional):</label>
                <input type="text" name="pildcm_cert_badge_text" value="<?php echo esc_attr($badge_text); ?>" style="width: 100%;" placeholder="e.g., CFTL">
                <p class="description">Shown as a small badge next to the track name (e.g., "Certified First-Time Leader" → CFTL). This is separate from the Level badge in the corner, which is set automatically from the track's Level field.</p>
            </div>

            <div style="margin-bottom: 20px; padding: 10px 12px; background: #f0f6f4; border-radius: 6px;">
                <p class="description" style="margin: 0;">🖼️ The certificate <strong>background image</strong> is now set once per <strong>Sector</strong> (not per track) — edit this track's Sector and use its "Certificate Background" field.</p>
            </div>
        </div>

        <!-- Right Column -->
        <div>
            <h3 style="margin-bottom: 15px;">Colors (automatic by level)</h3>
            <p class="description" style="margin-bottom: 12px;">Certificate colors are set automatically from this track's <strong>Level</strong> field — no manual color picking needed.</p>

            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                <span class="pildcm-color-row" style="background: <?php echo esc_attr($palette['accent_color']); ?>;"></span>
                <div>
                    <strong>Level:</strong> <?php echo esc_html($level); ?><br>
                    <code><?php echo esc_html($palette['accent_color']); ?></code>
                </div>
            </div>

            <table class="widefat" style="margin-top:10px;">
                <tr><td>🟢 Foundation</td><td><code>#0E6655</code></td></tr>
                <tr><td>🔵 Professional</td><td><code>#1B4F8C</code></td></tr>
                <tr><td>🟣 Executive</td><td><code>#5B3A8C</code></td></tr>
            </table>
            <p class="description" style="margin-top:8px;">To change a certificate's color, change the track's <strong>Level</strong> field — not this screen.</p>

            <div class="pildcm-design-preview" id="design-preview">
                <strong>Preview:</strong>
                <div id="preview-box" style="width: 100%; height: 80px; border: 2px solid <?php echo esc_attr($palette['border_color']); ?>; background: linear-gradient(135deg, #fff, #f8f8f8); border-radius: 8px; margin-top: 10px; display: flex; align-items: center; justify-content: center;">
                    <span style="color: <?php echo esc_attr($palette['title_color']); ?>;">Sample Text</span>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Save certificate design meta
add_action('save_post_track', 'pildcm_save_cert_design_meta');
function pildcm_save_cert_design_meta($post_id) {
    if (!isset($_POST['pildcm_cert_design_nonce']) || !wp_verify_nonce($_POST['pildcm_cert_design_nonce'], 'pildcm_cert_design_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    // pildcm_cert_bg_image removed (client decision, Sep 2026) — background
    // is now set once per Sector, see field_sector_cert_background in
    // pild-unified.php.
    $fields = ['pildcm_cert_design_style', 'pildcm_cert_badge_text', 'pildcm_cert_font_style'];
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }
}

