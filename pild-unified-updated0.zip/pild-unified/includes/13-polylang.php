<?php
/**
 * File: 13-polylang.php
 * Polylang integration for PILD Unified plugin.
 *
 * ما الذي يفعله هذا الملف؟
 * ─────────────────────────
 * 1. يُسجّل CPTs الخاصة بالبلاجن (sector, track, program, playbook, domain, assessment, question)
 *    لدى Polylang حتى تظهر في إعدادات اللغة وتكون قابلة للترجمة.
 * 2. يُضيف lang= تلقائياً لكل WP_Query / get_posts داخل البلاجن
 *    حتى تُعاد المحتويات باللغة الحالية فقط.
 * 3. يُوفّر helper function واحدة pild_lang_args() تستخدمها
 *    جميع استعلامات get_posts في الكود.
 * 4. يُعالج الـ AJAX requests بحيث تُرسَل اللغة الصحيحة معها.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// 1. تسجيل CPTs مع Polylang
// ============================================================

/**
 * نُخبر Polylang بأسماء الـ Custom Post Types التابعة لنا
 * حتى يظهر لها علامة تبويب اللغة في شاشة التحرير،
 * وحتى تظهر في إعدادات Polylang > Languages.
 */
add_filter( 'pll_get_post_types', 'pild_pll_register_post_types', 10, 2 );
function pild_pll_register_post_types( $post_types, $is_settings ) {
    // 'product' (WooCommerce) is registered here too — not one of the
    // plugin's own CPTs, but includes/26-products-importer.php creates
    // Arabic + optional linked English products the same way this file
    // handles sector/domain/track/program/playbook, so it needs the same
    // Polylang registration (language tab in the editor, pll_set_post_language()/
    // pll_save_post_translations() working correctly). If Polylang for
    // WooCommerce is also active it registers 'product' itself too — filters
    // just add array keys, so registering it twice is harmless.
    $pild_cpts = [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment', 'question', 'product', 'store_book' ];
    foreach ( $pild_cpts as $cpt ) {
        $post_types[ $cpt ] = $cpt;
    }
    return $post_types;
}

// ============================================================
// 2. Helper: إضافة lang للـ queries
// ============================================================

/**
 * pild_lang_args( array $args ) : array
 *
 * الاستخدام:
 *   $posts = get_posts( pild_lang_args([ 'post_type' => 'track', ... ]) );
 *
 * - إذا كان Polylang مثبتاً وفعّالاً يُضيف 'lang' => pll_current_language()
 * - إذا لم يكن مثبتاً لا يفعل شيئاً (backward compatible)
 */
function pild_lang_args( array $args ): array {
    if ( function_exists( 'pll_current_language' ) ) {
        // في سياق AJAX نستخدم اللغة المُرسَلة مع الطلب
        $lang = pild_get_request_language();
        if ( $lang ) {
            $args['lang'] = $lang;
        }
    }
    return $args;
}

/**
 * استخراج اللغة الحالية من AJAX request أو من Polylang مباشرة.
 */
function pild_get_request_language(): string {
    // AJAX: يمكن إرسال lang= في POST أو GET
    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
        $lang_from_request = sanitize_key( $_REQUEST['lang'] ?? '' );
        if ( $lang_from_request && function_exists( 'pll_languages_list' ) ) {
            $valid = pll_languages_list();
            if ( in_array( $lang_from_request, $valid, true ) ) {
                return $lang_from_request;
            }
        }
    }

    if ( function_exists( 'pll_current_language' ) ) {
        return (string) pll_current_language();
    }

    return '';
}

// ============================================================
// 3. فلترة get_posts التلقائية داخل البلاجن
// ============================================================

/**
 * نستخدم فلتر pre_get_posts لإضافة اللغة تلقائياً لأي
 * WP_Query تستهدف CPTs خاصة بنا — بدون الحاجة لتعديل كل سطر كود.
 *
 * ملاحظة: هذا الفلتر يعمل فقط إذا كان Polylang مثبتاً.
 */
add_action( 'pre_get_posts', 'pild_inject_language_into_query' );
function pild_inject_language_into_query( WP_Query $query ) {
    if ( ! function_exists( 'pll_current_language' ) ) return;

    // لا نتدخل في الـ admin main query ولا في أي query خارج نطاقنا
    if ( is_admin() && $query->is_main_query() ) return;

    $pild_cpts = [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment', 'question', 'store_book' ];
    $post_type = $query->get( 'post_type' );

    // post_type ممكن يكون string أو array
    $types = is_array( $post_type ) ? $post_type : [ $post_type ];
    $is_pild_query = (bool) array_intersect( $types, $pild_cpts );

    if ( ! $is_pild_query ) return;

    // لا تُعيّن اللغة إذا كانت مُعيَّنة مسبقاً أو إذا كان lang=''  (كل اللغات)
    if ( $query->get( 'lang' ) !== '' ) return;

    $lang = pild_get_request_language();
    if ( $lang ) {
        $query->set( 'lang', $lang );
    }
}

// ============================================================
// 4. Language switcher في الـ AJAX responses
// ============================================================

/**
 * نُضيف اللغة الحالية في كل AJAX response من البلاجن
 * حتى يستطيع الـ JavaScript إرسالها مرة أخرى مع الطلبات التالية.
 */
add_filter( 'pild_ajax_response', 'pild_append_lang_to_ajax_response' );
function pild_append_lang_to_ajax_response( array $response ): array {
    if ( function_exists( 'pll_current_language' ) ) {
        $response['lang'] = pll_current_language();
    }
    return $response;
}

// ============================================================
// 5. تمرير اللغة لـ JavaScript (للـ AJAX من الـ frontend)
// ============================================================

add_action( 'wp_enqueue_scripts', 'pild_pll_localize_script', 20 );
function pild_pll_localize_script() {
    if ( ! function_exists( 'pll_current_language' ) ) return;

    // نُضيف متغير pild_lang لـ JavaScript
    // يفترض أن سكريبت البلاجن الرئيسي مسجّل باسم 'pild-playbook'
    // عدّل اسم الـ handle إذا كان مختلفاً
    $handle = 'pild-playbook';
    if ( wp_script_is( $handle, 'registered' ) || wp_script_is( $handle, 'enqueued' ) ) {
        wp_localize_script( $handle, 'pild_pll', [
            'lang'  => pll_current_language(),
            'nonce' => wp_create_nonce( 'pild_pll_nonce' ),
        ] );
    }
}

// ============================================================
// 6. دعم Language Switcher في شريط الأدوات (Admin Bar)
// ============================================================

/**
 * يضيف Polylang تلقائياً Language Switcher في Admin Bar وفي Frontend
 * بمجرد تسجيل CPTs. لكن إذا أردت Switcher مخصصاً في أي مكان
 * استخدم: pll_the_languages() أو pll_the_languages( ['display_flags' => 1] )
 */

// ============================================================
// 7. مزامنة ACF Meta بين الترجمات (اختياري)
// ============================================================

/**
 * عند نسخ/ترجمة post، نُزامن بعض الـ meta fields الهيكلية
 * (مثل program_track, playbook_program) لأنها تشير لـ IDs في DB
 * وقد تحتاج تحديث يدوي. هذا الفلتر يُبقيها كما هي في الترجمة
 * ثم يمكن للمحرر تعديلها إذا كانت تشير لـ ID مختلف باللغة الأخرى.
 *
 * للتفعيل: فعّل "Synchronize" لهذه الـ fields من Polylang > Settings.
 */
add_filter( 'pll_copy_post_metas', 'pild_pll_sync_meta_fields', 10, 2 );
function pild_pll_sync_meta_fields( array $metas, bool $sync ): array {
    // هذه الـ fields علاقات بربط منشور بمنشور آخر قابل للترجمة (sector/domain/
    // track/program). لازم تُنسخ *مرة واحدة فقط* وقت إنشاء ترجمة جديدة، حتى
    // يبدأ المترجم من قيمة منطقية بدل الفراغ — لكن لازم *ماتفضلش متزامنة* بعد
    // كده، لأن النسخة الإنجليزية للمجال المفروض تتربط بالقطاع الإنجليزي مش
    // العربي، وبالعكس. لو سيبناها في قائمة التزامن الدائم، كل تعديل في لغة
    // هيتفرض على اللغة التانية تلقائيًا ويكسر الربط الصحيح بين الترجمات.
    $relationship_metas = [
        'domain_sector',      // ACF: sector_id تابع لـ domain
        'track_domain',       // ACF: domain_id تابع لـ track
        'program_track',      // ACF: track_id تابع لـ program
        'playbook_program',   // ACF: program_id تابع لـ playbook
    ];

    // هذه الـ fields قيم تقنية بحتة (مدة، ترتيب، نوع...) ومنطقي إنها تتطابق
    // بين اللغات، فهي الوحيدة اللي نُزامنها دائماً.
    $always_sync_metas = [
        'track_quiz_id',
        'playbook_type',        // video, book, webinar...
        'playbook_video_url',
        'playbook_duration',
        'playbook_order',
    ];

    if ( ! $sync ) {
        // $sync === false → Polylang بيسأل: "إيه اللي نملأه تلقائيًا وقت
        // إنشاء ترجمة جديدة؟" — هنا بس نضيف حقول العلاقات كمان (نسخة أولية).
        $metas = array_merge( $metas, $relationship_metas );
    }

    // أما القيم التقنية البحتة فتتزامن دايماً بغض النظر عن $sync.
    return array_unique( array_merge( $metas, $always_sync_metas ) );
}

// ============================================================
// 8. تحويل IDs عند الاستعلام عن Post المترجَم
// ============================================================

/**
 * عند الاستعلام عن برامج أو دروس باستخدام meta_value (ID)،
 * يُحوّل Polylang تلقائياً الـ ID للترجمة الصحيحة باللغة الحالية.
 *
 * لكن إذا احتجت التحويل يدوياً في مكان ما استخدم:
 *   $translated_id = pll_get_post( $original_id ); // يُعيد ID الترجمة
 */

/**
 * مثال: إذا كنت تستعلم عن playbooks بـ meta_value = program_id
 * وأردت الـ playbooks التابعة للـ program المترجَم:
 *
 * function pild_get_translated_program_id( int $program_id ): int {
 *     if ( function_exists( 'pll_get_post' ) ) {
 *         $translated = pll_get_post( $program_id );
 *         return $translated ?: $program_id;
 *     }
 *     return $program_id;
 * }
 */
