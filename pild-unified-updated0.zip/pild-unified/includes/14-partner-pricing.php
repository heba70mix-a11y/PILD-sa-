<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 21. TRAINING PARTNER PRICING
// ------------------------------------------------------------
// Gives approved Training Centers (WordPress role 'pild_training_partner')
// a different, hidden price on WooCommerce products, without touching
// the Team seat-enforcement logic in includes/23-teams-core.php and
// includes/24-team-purchase.php. This file only changes WHAT PRICE is
// shown/charged, never who can enrol how many people.
//
// PHASE 3 SIMPLIFICATION: partner pricing is now a SINGLE flat tier —
// one price per product/variation for every approved partner. The
// previous Registered/Silver/Gold/Platinum tier system (and the
// pild_partner_tier user meta it read) has been removed per instruction;
// nothing else in the plugin referenced those tiers, so this is a
// self-contained change.
//
// Storage: one product meta field per product/variation, set from the
// normal product edit screen:
//   _pild_partner_price  -> the price shown/charged to every user with
//                            the training-partner role. Leave blank to
//                            fall back to the normal retail price.
// ============================================================

// ── 21.0 Safety net: make sure the role exists even on sites where the
// plugin was already active before this file was added (so nobody has
// to deactivate/reactivate to get the role created).
add_action('init', function () {
    if (!get_role('pild_training_partner')) {
        add_role('pild_training_partner', 'Training Partner', ['read' => true]);
    }
});

// ── 21.1 Helper: who is a partner? ──────────────────────────────────
function pildcm_is_training_partner($user_id = null) {
    $user_id = $user_id ?: get_current_user_id();
    if (!$user_id) return false;
    $user = get_userdata($user_id);
    return $user && in_array('pild_training_partner', (array) $user->roles, true);
}

// ── 21.2 Resolve the flat partner price for a given product/variation ID ──
function pildcm_get_partner_price($product_id, $user_id = null) {
    $flat = get_post_meta($product_id, '_pild_partner_price', true);
    if ($flat !== '' && $flat !== null) return (float) $flat;

    return null; // not configured — caller should fall back to retail price
}

// ── 21.3 Admin UI: partner price field on the product edit screen ──────
add_action('woocommerce_product_options_pricing', 'pildcm_partner_price_fields');
function pildcm_partner_price_fields() {
    global $post;
    echo '<div class="options_group pild-partner-pricing" style="padding:10px 0;border-top:1px dashed #ccc;">';
    echo '<p style="padding:0 12px;"><strong>PILD Training Partner Pricing</strong> — leave blank to use retail price.</p>';

    woocommerce_wp_text_input([
        'id'          => '_pild_partner_price',
        'label'       => __('Partner Price', 'pild-unified'),
        'data_type'   => 'price',
        'desc_tip'    => true,
        'description' => __('Price shown to any approved training partner instead of the retail price.', 'pild-unified'),
    ]);
    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'pildcm_save_partner_price_fields');
function pildcm_save_partner_price_fields($post_id) {
    if (isset($_POST['_pild_partner_price'])) {
        $val = wc_format_decimal(sanitize_text_field(wp_unslash($_POST['_pild_partner_price'])));
        update_post_meta($post_id, '_pild_partner_price', $val);
    }
}

// Same field, but on each product VARIATION (needed if seats are sold
// as variations, e.g. "Leadership Track — 50 Seats").
add_action('woocommerce_product_after_variable_attributes', 'pildcm_partner_price_variation_fields', 10, 3);
function pildcm_partner_price_variation_fields($loop, $variation_data, $variation) {
    echo '<div style="clear:both;padding:8px 0;border-top:1px dotted #ccc;"><strong>Partner Pricing</strong></div>';
    woocommerce_wp_text_input([
        'id'            => "_pild_partner_price_{$loop}",
        'name'          => "_pild_partner_price[{$loop}]",
        'label'         => __('Partner Price', 'pild-unified'),
        'data_type'     => 'price',
        'value'         => get_post_meta($variation->ID, '_pild_partner_price', true),
        'wrapper_class' => 'form-row form-row-full',
    ]);
}

add_action('woocommerce_save_product_variation', 'pildcm_save_partner_price_variation_fields', 10, 2);
function pildcm_save_partner_price_variation_fields($variation_id, $loop) {
    if (isset($_POST['_pild_partner_price'][$loop])) {
        $val = wc_format_decimal(sanitize_text_field(wp_unslash($_POST['_pild_partner_price'][$loop])));
        update_post_meta($variation_id, '_pild_partner_price', $val);
    }
}

// ── 21.4 Swap the ACTUAL price used for display + cart/checkout math ───
// Covers simple products, and variations individually.
add_filter('woocommerce_product_get_price',              'pildcm_apply_partner_price', 20, 2);
add_filter('woocommerce_product_get_regular_price',       'pildcm_apply_partner_price', 20, 2);
add_filter('woocommerce_product_variation_get_price',         'pildcm_apply_partner_price', 20, 2);
add_filter('woocommerce_product_variation_get_regular_price', 'pildcm_apply_partner_price', 20, 2);

function pildcm_apply_partner_price($price, $product) {
    if (!is_a($product, 'WC_Product') || !pildcm_is_training_partner()) return $price;

    $partner_price = pildcm_get_partner_price($product->get_id());
    return $partner_price !== null ? $partner_price : $price;
}

// Variable products: make sure the "from $X" range shown on archive/shop
// pages also reflects partner pricing for logged-in partners.
add_filter('woocommerce_variation_prices_price',         'pildcm_apply_partner_price_variation_prices', 20, 3);
add_filter('woocommerce_variation_prices_regular_price', 'pildcm_apply_partner_price_variation_prices', 20, 3);
function pildcm_apply_partner_price_variation_prices($price, $variation, $product) {
    if (!pildcm_is_training_partner()) return $price;
    $partner_price = pildcm_get_partner_price($variation->get_id());
    return $partner_price !== null ? wc_format_decimal($partner_price) : $price;
}

// ── 21.5 Change how the price LOOKS on the page ─────────────────────────
// Partner sees: "Your Partner Price: $90" — no strikethrough retail
// price, no percentage-off badge, per the "no discount framing" rule.
add_filter('woocommerce_get_price_html', 'pildcm_partner_price_html', 20, 2);
function pildcm_partner_price_html($html, $product) {
    if (!pildcm_is_training_partner()) return $html;

    $partner_price = pildcm_get_partner_price($product->get_id());
    if ($partner_price === null) return $html; // not configured for this product — leave default html

    return '<span class="pild-partner-price">'
        . '<span class="pild-partner-price-label">' . esc_html__('Your Partner Price', 'pild-unified') . ':</span> '
        . wc_price($partner_price)
        . '</span>';
}

// ── 21.6 Hide retail price completely from non-partners on products    ──
// that are marked "partner only" (optional flag, off by default).
// Tick "_pild_partner_only" on a product to require Contact Us instead
// of showing any price to the general public.
add_filter('woocommerce_get_price_html', 'pildcm_hide_price_for_non_partners', 5, 2);
function pildcm_hide_price_for_non_partners($html, $product) {
    $partner_only = get_post_meta($product->get_id(), '_pild_partner_only', true);
    if ($partner_only !== 'yes') return $html;
    if (pildcm_is_training_partner()) return $html; // partners still get their real price via 21.5 above

    return '<span class="pild-contact-for-price">' . esc_html__('Customized for every partner — Contact Us', 'pild-unified') . '</span>';
}

add_action('woocommerce_product_options_pricing', 'pildcm_partner_only_checkbox');
function pildcm_partner_only_checkbox() {
    woocommerce_wp_checkbox([
        'id'          => '_pild_partner_only',
        'label'       => __('Partner-only pricing', 'pild-unified'),
        'description' => __('If checked, the public sees "Contact Us" instead of any price; only training partners see the partner price.', 'pild-unified'),
    ]);
}
add_action('woocommerce_process_product_meta', 'pildcm_save_partner_only_checkbox');
function pildcm_save_partner_only_checkbox($post_id) {
    update_post_meta($post_id, '_pild_partner_only', isset($_POST['_pild_partner_only']) ? 'yes' : 'no');
}
