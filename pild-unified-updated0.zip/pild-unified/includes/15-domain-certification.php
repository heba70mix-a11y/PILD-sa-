<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 25. PRACTICE AREA (DOMAIN) PROFESSIONAL CERTIFICATION
// ------------------------------------------------------------
// Adds a second, higher-level certificate: once a learner has
// PASSED THE CERTIFICATION EXAM of every Track that belongs to a
// given Domain (Practice Area), they unlock one additional exam
// (a normal Quiz Maker quiz, linked via the 'domain_quiz_id' ACF
// field on the Domain post type — same pattern as 'track_quiz_id'
// on tracks). Passing it issues a "Practice Area Professional
// Certificate".
//
// This file is purely additive:
//  - New DB table (pild_domain_results) — the existing pild_results
//    table and its track-level logic are never touched.
//  - New ACF field (domain_quiz_id) on the 'domain' post type only.
//  - Existing quiz-result hook (10-quiz-certificate.php) is left
//    completely alone; this file hooks the SAME Quiz Maker filter
//    independently and only acts when the quiz belongs to a Domain,
//    never a Track.
// ============================================================

// ── 25.0 Safety net: create the domain-results table even on sites
// where the plugin was already active before this file was added.
add_action('init', 'pildcm_domain_cert_maybe_create_table');
function pildcm_domain_cert_maybe_create_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'pild_domain_results';
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table) return;

    $charset_collate = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE {$table} (
        id               int(11)      NOT NULL AUTO_INCREMENT,
        user_id          int(11)      NOT NULL,
        domain_id        int(11)      NOT NULL,
        score            int(11)      DEFAULT 0,
        total_questions  int(11)      DEFAULT 0,
        passed           varchar(3)   DEFAULT 'no',
        certificate_code varchar(100) DEFAULT NULL,
        certificate_url  text         DEFAULT NULL,
        completed_at     datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_domain (user_id, domain_id)
    ) {$charset_collate};");
}

// ── 25.1 ACF field: which Quiz Maker quiz is the Domain-level exam
// (exact same pattern as 'track_quiz_id' on the track post type).
add_action('acf/init', 'pildcm_add_domain_quiz_field');
function pildcm_add_domain_quiz_field() {
    if (!function_exists('acf_add_local_field_group')) return;
    acf_add_local_field_group([
        'key'      => 'group_pildcm_domain_quiz',
        'title'    => 'Practice Area Certification Exam',
        'fields'   => [
            [
                'key'           => 'field_domain_quiz_id',
                'label'         => 'Quiz ID',
                'name'          => 'domain_quiz_id',
                'type'          => 'number',
                'instructions'  => 'Quiz Maker Quiz ID for this Practice Area\'s professional certification exam. Only unlocks once the learner has passed the certification exam of every Track in this Practice Area.',
                'required'      => 0,
                'default_value' => 0,
                'placeholder'   => 'e.g. 456',
            ],
        ],
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'domain']]],
    ]);
}

// ── 25.2 Helper: has this learner passed the cert exam of every track
// in this domain? (the "all tracks finished" requirement — option 2:
// finished = holds a passed certificate for that track, not just
// watched the content.)
function pildcm_get_domain_progress($user_id, $domain_id) {
    global $wpdb;

    $track_ids = get_posts([
        'post_type'      => 'track',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_key'       => 'track_domain',
        'meta_value'     => $domain_id,
        'fields'         => 'ids',
    ]);

    $total = count($track_ids);
    if (!$total) {
        return ['total' => 0, 'certified' => 0, 'complete' => false];
    }

    $placeholders = implode(',', array_fill(0, $total, '%d'));
    $params = array_merge([$user_id], $track_ids);
    $certified = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT track_id) FROM {$wpdb->prefix}pild_results
         WHERE user_id=%d AND passed='yes' AND track_id IN ({$placeholders})",
        $params
    ));

    return ['total' => $total, 'certified' => $certified, 'complete' => ($certified >= $total)];
}

// Has the learner already earned the Practice Area certificate itself?
function pildcm_has_domain_certificate($user_id, $domain_id) {
    global $wpdb;
    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_domain_results WHERE user_id=%d AND domain_id=%d AND passed='yes' LIMIT 1",
        $user_id, $domain_id
    ));
}

// Which Domain (if any) uses this Quiz Maker quiz as its Practice
// Area exam? Mirrors pildcm_get_track_for_quiz() in 10-quiz-certificate.php.
function pildcm_get_domain_for_quiz($quiz_id) {
    $domains = get_posts([
        'post_type'      => 'domain',
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'meta_query'     => [['key' => 'domain_quiz_id', 'value' => $quiz_id]],
        'fields'         => 'ids',
    ]);
    return !empty($domains) ? (int) $domains[0] : 0;
}

// ── 25.3 Show unlock status / CTA on the Domain (Practice Area) page.
// Appended after the existing track list (pild_display_tracks_on_domain
// in pild-unified.php); does not modify that function at all.
add_filter('the_content', 'pildcm_show_domain_certification_status', 25);
function pildcm_show_domain_certification_status($content) {
    if (!is_singular('domain')) return $content;
    global $post;
    $domain_id = $post->ID;

    $quiz_id = (int) get_post_meta($domain_id, 'domain_quiz_id', true);
    if (!$quiz_id) return $content; // no exam configured for this Practice Area yet

    if (!is_user_logged_in()) {
        $box = '<div style="margin-top:2rem;padding:1.25rem 1.5rem;border:1px solid rgba(14,102,85,.25);background:rgba(14,102,85,.05);border-radius:10px;">'
            . '<strong>Practice Area Professional Certificate</strong> — log in and complete every Track above to unlock the final certification exam.'
            . '</div>';
        return $content . $box;
    }

    $user_id = get_current_user_id();

    if (pildcm_has_domain_certificate($user_id, $domain_id)) {
        $box = '<div style="margin-top:2rem;padding:1.25rem 1.5rem;border:1px solid rgba(14,102,85,.35);background:rgba(14,102,85,.08);border-radius:10px;">'
            . '🏅 <strong>You hold the Practice Area Professional Certificate</strong> for this Practice Area.'
            . '</div>';
        return $content . $box;
    }

    $progress = pildcm_get_domain_progress($user_id, $domain_id);

    if ($progress['complete']) {
        $box = '<div style="margin-top:2rem;padding:1.25rem 1.5rem;border:1px solid rgba(14,102,85,.35);background:rgba(14,102,85,.08);border-radius:10px;">'
            . '<strong>All Tracks in this Practice Area are certified.</strong> You can now take the Practice Area Professional Certification exam.'
            . '<div style="margin-top:.75rem;">' . do_shortcode('[AYS_QUIZ id="' . $quiz_id . '"]') . '</div>'
            . '</div>';
    } else {
        $remaining = $progress['total'] - $progress['certified'];
        $box = '<div style="margin-top:2rem;padding:1.25rem 1.5rem;border:1px solid rgba(0,0,0,.08);background:rgba(0,0,0,.02);border-radius:10px;">'
            . 'Complete and pass the certification exam of ' . intval($remaining) . ' more Track(s) in this Practice Area to unlock the '
            . '<strong>Practice Area Professional Certificate</strong> (' . intval($progress['certified']) . '/' . intval($progress['total']) . ' done).'
            . '</div>';
    }

    return $content . $box;
}

// ── 25.4 Intercept Quiz Maker results for DOMAIN-level exams only.
// Hooked to the same filter used for track quizzes, but completely
// independent: it only proceeds if this quiz_id belongs to a Domain.
add_filter('ays_qm_finish_quiz_result_data', 'pildcm_intercept_domain_quiz_result', 20, 1);
function pildcm_intercept_domain_quiz_result($data) {
    $quiz_id = isset($data['quiz_id']) ? (int) $data['quiz_id'] : 0;
    $user_id = isset($data['user_id']) ? (int) $data['user_id'] : get_current_user_id();
    if (!$quiz_id || !$user_id) return $data;

    $domain_id = pildcm_get_domain_for_quiz($quiz_id);
    if (!$domain_id) return $data; // not a domain exam — leave entirely to 10-quiz-certificate.php

    // Re-verify eligibility server-side (never trust that the button was only shown when eligible).
    $progress = pildcm_get_domain_progress($user_id, $domain_id);
    if (!$progress['complete']) return $data;

    $score_val = (float) str_replace('%', '', $data['score'] ?? 0);
    $quiz_options = isset($data['options']) ? $data['options'] : null;
    if (is_string($quiz_options)) $quiz_options = json_decode($quiz_options);
    $pass_score = 60;
    if ($quiz_options && isset($quiz_options->certificate_pass)) {
        $pass_score = (float) $quiz_options->certificate_pass;
    }
    $is_passed = ($score_val >= $pass_score);

    global $wpdb;
    if ($is_passed) {
        $cert_code = strtoupper(wp_generate_password(12, false));
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_domain_results WHERE user_id=%d AND domain_id=%d AND passed='yes' LIMIT 1",
            $user_id, $domain_id
        ));
        if ($existing) {
            $wpdb->update("{$wpdb->prefix}pild_domain_results", [
                'score' => (int) round($score_val), 'passed' => 'yes',
                'certificate_code' => $cert_code, 'completed_at' => current_time('mysql'),
            ], ['id' => $existing]);
        } else {
            $wpdb->insert("{$wpdb->prefix}pild_domain_results", [
                'user_id' => $user_id, 'domain_id' => $domain_id,
                'score' => (int) round($score_val),
                'total_questions' => isset($data['questions_count']) ? (int) $data['questions_count'] : 0,
                'passed' => 'yes', 'certificate_code' => $cert_code,
                'completed_at' => current_time('mysql'),
            ]);
        }

        $cert_url = pildcm_generate_domain_certificate($user_id, $domain_id, $score_val, $cert_code);
        if ($cert_url) {
            $wpdb->update("{$wpdb->prefix}pild_domain_results", ['certificate_url' => $cert_url], ['user_id' => $user_id, 'domain_id' => $domain_id, 'passed' => 'yes']);
        }
    } else {
        $already_passed = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_domain_results WHERE user_id=%d AND domain_id=%d AND passed='yes' LIMIT 1",
            $user_id, $domain_id
        ));
        if (!$already_passed) {
            $wpdb->insert("{$wpdb->prefix}pild_domain_results", [
                'user_id' => $user_id, 'domain_id' => $domain_id,
                'score' => (int) round($score_val),
                'total_questions' => isset($data['questions_count']) ? (int) $data['questions_count'] : 0,
                'passed' => 'no', 'completed_at' => current_time('mysql'),
            ]);
        }
    }

    return $data;
}

// ── 25.5 Generate the Practice Area Professional Certificate (HTML,
// downloadable — same mechanism as pildcm_generate_branded_certificate
// in 10-quiz-certificate.php, but visually distinct so it can never be
// confused with a single-track certificate).
function pildcm_generate_domain_certificate($user_id, $domain_id, $score, $cert_code) {
    $user = get_userdata($user_id);
    if ($user) {
        $first = get_user_meta($user->ID, 'first_name', true);
        $last  = get_user_meta($user->ID, 'last_name', true);
        $full  = trim("$first $last");
        $user_name = $full ?: $user->display_name;
    } else {
        $user_name = __('Learner', 'pild');
    }

    $domain_title = get_the_title($domain_id);
    $current_date = date_i18n(get_option('date_format'));
    $site_name    = get_bloginfo('name');

    $manager_id       = function_exists('pildcm_get_member_manager') ? pildcm_get_member_manager($user_id) : 0;
    $has_manager      = !empty($manager_id);
    $company_name     = $has_manager ? (get_user_meta($manager_id, 'pild_company_name', true) ?: get_userdata($manager_id)->display_name) : '';
    $company_logo_id  = $has_manager ? get_user_meta($manager_id, 'pild_company_logo_id', true) : '';
    $company_logo_url = $company_logo_id ? wp_get_attachment_image_url($company_logo_id, 'medium') : '';
    $meta_org         = $has_manager ? " &nbsp;|&nbsp; {$company_name}" : '';

    $site_logo_id  = get_theme_mod('custom_logo');
    $site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'medium') : '';
    $site_logo_html    = $site_logo_url ? "<img src='{$site_logo_url}' style='max-height:60px;max-width:150px;object-fit:contain;'>" : "<span style='font-size:1.2rem;font-weight:700;color:#5B3A0E;'>{$site_name}</span>";
    $company_logo_html = $has_manager ? ($company_logo_url ? "<img src='{$company_logo_url}' style='max-height:60px;max-width:150px;object-fit:contain;'>" : "<span style='font-size:1rem;font-weight:600;color:#0A0F1E;'>{$company_name}</span>") : '';

    $upload_dir   = wp_upload_dir();
    $cert_dir     = $upload_dir['basedir'] . '/pild-certificates/';
    $cert_dir_url = $upload_dir['baseurl'] . '/pild-certificates/';
    if (!file_exists($cert_dir)) wp_mkdir_p($cert_dir);

    $filename  = 'domain-cert-' . $user_id . '-' . $domain_id . '-' . sanitize_title($cert_code) . '.html';
    $cert_path = $cert_dir . $filename;
    $cert_url  = $cert_dir_url . $filename;

    // Gold/amber palette distinguishes this from the green/blue/purple
    // track-level certificates.
    $cert_color = '#9A6B00';

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Practice Area Professional Certificate — {$domain_title}</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&amp;family=DM+Sans:wght@300;400;500;600&amp;display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  @page{size:A4 landscape;margin:0}
  body{font-family:'DM Sans',sans-serif;background:#f0ede8;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:2rem;}
  .cert-wrap{width:297mm;height:210mm;position:relative;background:#fffdf7;border-radius:8px;overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem;}
  .cert-border-outer{position:absolute;inset:14px;border:3px double {$cert_color};border-radius:5px;opacity:0.75;pointer-events:none;}
  .cert-logos{position:absolute;top:20px;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:0 30px;}
  .cert-logo-slot{height:60px;width:150px;display:flex;align-items:center;overflow:hidden;}
  .cert-logos .cert-logo-slot:last-child{justify-content:flex-end;}
  .cert-eyebrow{font-size:.7rem;font-weight:700;letter-spacing:.25em;text-transform:uppercase;color:{$cert_color};margin-bottom:.5rem;}
  .cert-heading{font-family:'DM Serif Display',serif;font-size:2.6rem;color:#0A0F1E;margin-bottom:.5rem;text-align:center;}
  .cert-subtitle{font-size:.95rem;color:#6B7280;margin-bottom:.5rem;text-align:center;}
  .cert-name{font-family:'DM Serif Display',serif;font-size:2.1rem;color:#0A0F1E;margin:0.3rem 0 0.6rem;text-align:center;border-bottom:2px solid {$cert_color};padding-bottom:.35rem;}
  .cert-track{font-size:1.2rem;font-weight:700;color:{$cert_color};text-align:center;margin-bottom:.4rem;}
  .cert-meta{font-size:.82rem;color:#6B7280;text-align:center;margin-bottom:.6rem;}
  .cert-divider{width:60%;height:1px;background:{$cert_color};opacity:.4;margin:.5rem auto;}
  .cert-code{font-family:monospace;font-size:.72rem;color:#9CA3AF;text-align:center;letter-spacing:.1em;}
  .download-buttons{position:fixed;bottom:20px;right:20px;display:flex;gap:10px;}
  .download-btn{background:{$cert_color};color:white;border:none;padding:12px 24px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;}
  @media print{.download-buttons{display:none;}}
</style>
</head>
<body>
<div class="cert-wrap">
  <div class="cert-border-outer"></div>
  <div class="cert-logos">
    <div class="cert-logo-slot">{$site_logo_html}</div>
    <div class="cert-logo-slot">{$company_logo_html}</div>
  </div>
  <div class="cert-eyebrow">Practice Area Professional Certificate</div>
  <div class="cert-heading">Professional Certification</div>
  <div class="cert-subtitle">This is to certify that</div>
  <div class="cert-name">{$user_name}</div>
  <div class="cert-subtitle">has successfully completed every Track and passed the professional certification exam of</div>
  <div class="cert-track">{$domain_title}</div>
  <div class="cert-meta">Final Exam Score: {$score}%{$meta_org} &nbsp;|&nbsp; {$current_date}</div>
  <div class="cert-divider"></div>
  <div class="cert-code">Certificate ID: {$cert_code} &nbsp;|&nbsp; Issued by: {$site_name}</div>
</div>
<div class="download-buttons">
  <button class="download-btn" onclick="window.print()">📄 Download PDF</button>
</div>
</body>
</html>
HTML;

    file_put_contents($cert_path, $html);
    return $cert_url;
}

// ── 25.6 Certificate verification page: also recognise Domain
// certificate codes, without touching the existing track lookup
// logic in 12-cert-verify-acf.php at all.
add_filter('pildcm_verify_certificate_lookup', 'pildcm_verify_domain_certificate_lookup', 10, 2);
function pildcm_verify_domain_certificate_lookup($certificate_data, $cert_id) {
    if ($certificate_data) return $certificate_data; // track lookup already found it
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        "SELECT r.*, u.display_name, u.user_email, d.post_title as track_title
         FROM {$wpdb->prefix}pild_domain_results r
         LEFT JOIN {$wpdb->users} u ON u.ID = r.user_id
         LEFT JOIN {$wpdb->posts} d ON d.ID = r.domain_id
         WHERE r.certificate_code = %s AND r.passed = 'yes'
         ORDER BY r.completed_at DESC LIMIT 1",
        sanitize_text_field($cert_id)
    ));
}
