<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 26. PUBLIC PROFESSIONAL PROFILE — /profile/{username}
// ------------------------------------------------------------
// Opt-in only: nothing is shown to the public until the member
// explicitly enables "Make Public" in My Settings (solo dashboard).
// The toggle itself is saved/read via the 'pild_profile_public'
// user meta ('yes' | anything else = private). Default = private.
//
// URL uses the member's WordPress username (user_nicename), e.g.
//   pild.sa/profile/mohamed-karem
// ============================================================

// ── 26.0 Rewrite rule + query var (same pattern as /sectors and
// the certificate/verification pages elsewhere in this plugin).
add_action('init', 'pildcm_add_public_profile_rewrite');
function pildcm_add_public_profile_rewrite() {
    add_rewrite_rule(
        '^profile/([^/]+)/cv/?$',
        'index.php?pild_profile_cv=1&pild_profile_user=$matches[1]',
        'top'
    );
    add_rewrite_rule(
        '^profile/([^/]+)/?$',
        'index.php?pild_public_profile=1&pild_profile_user=$matches[1]',
        'top'
    );
}

add_filter('query_vars', 'pildcm_public_profile_query_vars');
function pildcm_public_profile_query_vars($vars) {
    $vars[] = 'pild_public_profile';
    $vars[] = 'pild_profile_user';
    $vars[] = 'pild_profile_cv';
    return $vars;
}

// One-time flush so /profile/{username} works immediately after this
// update ships, without requiring a manual Settings → Permalinks save.
add_action('init', function () {
    if (!get_option('pild_public_profile_rewrite_flushed')) {
        flush_rewrite_rules();
        update_option('pild_public_profile_rewrite_flushed', 1);
    }
}, 21);

// ── 26.1 Helper: the canonical public profile URL for a user,
// regardless of whether it's currently public (used in Settings so
// the member can see/copy their link before flipping it on).
function pildcm_get_public_profile_url($user_id) {
    $user = get_userdata($user_id);
    if (!$user) return '';
    $slug = get_user_meta($user_id, 'pild_profile_slug', true);
    if (!$slug) $slug = $user->user_nicename;
    return home_url('/profile/' . $slug . '/');
}

// Custom slugs are opt-in (member picks their own link in Settings).
// Find whichever user — if any — currently owns this slug, checking
// the custom slug meta first and falling back to the default
// WordPress username (user_nicename) for members who never set one.
function pildcm_find_user_by_profile_slug($slug) {
    $slug = sanitize_title($slug);
    if (!$slug) return false;

    $by_custom = get_users([
        'meta_key'   => 'pild_profile_slug',
        'meta_value' => $slug,
        'number'     => 1,
        'fields'     => 'all',
    ]);
    if (!empty($by_custom)) return $by_custom[0];

    $by_nicename = get_user_by('slug', $slug);
    // If someone else has claimed this exact string as their custom
    // slug, don't also let it resolve via a different user's default
    // nicename — custom slugs always win to avoid two profiles
    // fighting over the same URL.
    if ($by_nicename) {
        $their_custom = get_user_meta($by_nicename->ID, 'pild_profile_slug', true);
        if ($their_custom && $their_custom !== $slug) return false;
    }
    return $by_nicename ?: false;
}

// Is $slug available for $user_id to claim as their custom link?
// (free, or already owned by this same user).
function pildcm_is_profile_slug_available($slug, $user_id) {
    $slug = sanitize_title($slug);
    if (!$slug || strlen($slug) < 3) return false;

    $reserved = ['sectors', 'domains', 'profile', 'certificate', 'cert', 'verify-certificate', 'solo-dashboard', 'company-dashboard', 'member-dashboard'];
    if (in_array($slug, $reserved, true)) return false;

    $owner = pildcm_find_user_by_profile_slug($slug);
    if ($owner && (int) $owner->ID !== (int) $user_id) return false;

    // Also block claiming another member's default username as a
    // custom slug, unless it's this member's own username.
    $nicename_owner = get_user_by('slug', $slug);
    if ($nicename_owner && (int) $nicename_owner->ID !== (int) $user_id) return false;

    return true;
}

function pildcm_is_profile_public($user_id) {
    return get_user_meta($user_id, 'pild_profile_public', true) === 'yes';
}

// ── 26.2 Gather everything the profile needs in one place.
function pildcm_get_public_profile_data($user_id, $lang = null) {
    global $wpdb;
    $lang = $lang ?: (function_exists('pildcm_cv_current_lang') ? pildcm_cv_current_lang() : 'ar');

    $user      = get_userdata($user_id);
    $job_title = function_exists('pildcm_cv_pick') ? pildcm_cv_pick(get_user_meta($user_id, 'pild_job_title', true), get_user_meta($user_id, 'pild_job_title_en', true), $lang) : get_user_meta($user_id, 'pild_job_title', true);
    $bio       = function_exists('pildcm_cv_pick') ? pildcm_cv_pick(get_user_meta($user_id, 'pild_bio', true), get_user_meta($user_id, 'pild_bio_en', true), $lang) : get_user_meta($user_id, 'pild_bio', true);
    $country   = function_exists('pildcm_cv_pick') ? pildcm_cv_pick(get_user_meta($user_id, 'pild_country', true), get_user_meta($user_id, 'pild_country_en', true), $lang) : get_user_meta($user_id, 'pild_country', true);
    $avatar    = pildcm_get_member_avatar($user_id);
    $points    = function_exists('pildcm_get_user_points') ? pildcm_get_user_points($user_id) : 0;
    $badges_earned = function_exists('pildcm_get_user_badges') ? pildcm_get_user_badges($user_id) : [];
    $badges_cfg    = function_exists('pildcm_badges_config') ? pildcm_badges_config() : [];

    // Completed (passed) Tracks, most recent first.
    $track_results = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT track_id, certificate_code, completed_at
         FROM {$wpdb->prefix}pild_results
         WHERE user_id=%d AND passed='yes'
         ORDER BY completed_at DESC", $user_id
    )) ?: [];

    $tracks = [];
    $domain_ids_seen = [];
    foreach ($track_results as $r) {
        $track = get_post((int) $r->track_id);
        if (!$track) continue;
        $domain_id = function_exists('get_field') ? (int) get_field('track_domain', $track->ID) : 0;
        if ($domain_id) $domain_ids_seen[$domain_id] = true;
        $tracks[] = [
            'id'          => $track->ID,
            'title'       => $track->post_title,
            'cert_code'   => $r->certificate_code,
            'view_url'    => $r->certificate_code ? home_url('/certificate/' . $r->certificate_code) : '',
            'verify_url'  => $r->certificate_code ? home_url('/verify-certificate/' . $r->certificate_code) : '',
            'completed_at'=> $r->completed_at,
            'domain_id'   => $domain_id,
        ];
    }

    // Practice Area (Domain) professional certificates, if that
    // table exists on this site (15-domain-certification.php).
    $domain_certs = [];
    $dr_table = $wpdb->prefix . 'pild_domain_results';
    if ($wpdb->get_var("SHOW TABLES LIKE '{$dr_table}'") === $dr_table) {
        $domain_results = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT domain_id, certificate_code, certificate_url, completed_at
             FROM {$dr_table} WHERE user_id=%d AND passed='yes' ORDER BY completed_at DESC", $user_id
        )) ?: [];
        foreach ($domain_results as $r) {
            $domain = get_post((int) $r->domain_id);
            if (!$domain) continue;
            $domain_ids_seen[$domain->ID] = true;
            $domain_certs[] = [
                'id'          => $domain->ID,
                'title'       => $domain->post_title,
                'cert_code'   => $r->certificate_code,
                'view_url'    => $r->certificate_url ?: '',
                'verify_url'  => $r->certificate_code ? home_url('/verify-certificate/' . $r->certificate_code) : '',
                'completed_at'=> $r->completed_at,
            ];
        }
    }

    // Practice Areas (Domains) touched, for the "Domains" section —
    // every domain behind a completed track or an earned Domain cert.
    $domains = [];
    foreach (array_keys($domain_ids_seen) as $did) {
        $d = get_post($did);
        if ($d) $domains[] = $d->post_title;
    }

    return [
        'user'          => $user,
        'job_title'     => $job_title,
        'bio'           => $bio,
        'country'       => $country,
        'avatar'        => $avatar,
        'points'        => $points,
        'badges_earned' => $badges_earned,
        'badges_cfg'    => $badges_cfg,
        'tracks'        => $tracks,
        'domain_certs'  => $domain_certs,
        'domains'       => $domains,
        'lang'          => $lang,
        'experience'    => function_exists('pildcm_get_profile_experience') ? pildcm_get_profile_experience($user_id) : [],
        'education'     => function_exists('pildcm_get_profile_education') ? pildcm_get_profile_education($user_id) : [],
        'skills'        => function_exists('pildcm_get_profile_skills') ? pildcm_get_profile_skills($user_id, $lang) : [],
        'linkedin_url'  => get_user_meta($user_id, 'pild_linkedin_url', true),
        'website_url'   => get_user_meta($user_id, 'pild_profile_website', true),
    ];
}

// ── 26.3 Render the page, inside the active theme's header/footer.
add_action('template_redirect', 'pildcm_render_public_profile');
function pildcm_render_public_profile() {
    if (!get_query_var('pild_public_profile')) return;

    $username = sanitize_title(get_query_var('pild_profile_user'));
    $user     = pildcm_find_user_by_profile_slug($username);
    $viewer_is_owner = $user && is_user_logged_in() && get_current_user_id() === $user->ID;

    get_header();
    echo function_exists('pild_global_css') ? pild_global_css() : '';

    // Same message whether the user doesn't exist or the profile is
    // private — never confirm/deny existence of an account to a
    // stranger. The owner themself sees a helpful nudge instead.
    if (!$user || (!pildcm_is_profile_public($user->ID) && !$viewer_is_owner)) {
        ?>
        <div class="pild-wrap">
          <div class="pild-empty-state">
            <div class="pild-empty-icon">🔒</div>
            <p><?php esc_html_e( "This profile is private or doesn't exist.", 'pild-unified' ); ?></p>
          </div>
        </div>
        <?php
        get_footer();
        exit;
    }

    $d = pildcm_get_public_profile_data($user->ID);
    $is_private_preview = $viewer_is_owner && !pildcm_is_profile_public($user->ID);
    $has_verified = !empty($d['tracks']) || !empty($d['domain_certs']) || !empty($d['badges_earned']);
    $has_selfreported = !empty($d['experience']) || !empty($d['education']) || !empty($d['skills']);
    ?>
    <div class="pild-wrap pild-public-profile">
      <?php if ($is_private_preview): ?>
        <div class="pild-empty-state" style="margin-bottom:1.5rem">
          <p>🔒 <?php printf( wp_kses( __( 'This is a preview — your profile is still private. Turn on "Make Public" in %s so others can see it.', 'pild-unified' ), ['a' => ['href' => []]] ), '<a href="' . esc_url( pild_dashboard_url('solo-dashboard') . '#tab-solo-settings' ) . '">' . esc_html__( 'My Settings', 'pild-unified' ) . '</a>' ); ?></p>
        </div>
      <?php endif; ?>

      <div class="pp-header">
        <div class="pp-avatar">
          <?php if ($d['avatar']): ?>
            <img src="<?php echo esc_url($d['avatar']); ?>" alt="<?php echo esc_attr($d['user']->display_name); ?>">
          <?php else: ?>
            <span><?php echo esc_html(strtoupper(substr($d['user']->display_name, 0, 1))); ?></span>
          <?php endif; ?>
        </div>
        <h1 class="pp-name"><?php echo esc_html($d['user']->display_name); ?></h1>
        <?php if ($d['job_title']): ?><p class="pp-title"><?php echo esc_html($d['job_title']); ?></p><?php endif; ?>
        <?php if ($d['country']): ?><p class="pp-location"><?php echo esc_html($d['country']); ?></p><?php endif; ?>
        <?php if ($d['bio']): ?><p class="pp-bio"><?php echo esc_html($d['bio']); ?></p><?php endif; ?>

        <?php if ($d['linkedin_url'] || $d['website_url']): ?>
        <div class="pp-links">
          <?php if ($d['linkedin_url']): ?><a href="<?php echo esc_url($d['linkedin_url']); ?>" target="_blank" rel="noopener">LinkedIn</a><?php endif; ?>
          <?php if ($d['website_url']): ?><a href="<?php echo esc_url($d['website_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Website', 'pild-unified' ); ?></a><?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (count($d['tracks']) || count($d['domain_certs']) || $d['points']): ?>
        <div class="pp-stats">
          <?php if (count($d['tracks'])): ?><div class="pp-stat"><span class="num"><?php echo count($d['tracks']); ?></span><span class="lbl"><?php esc_html_e( 'Track Certificates', 'pild-unified' ); ?></span></div><?php endif; ?>
          <?php if (count($d['domain_certs'])): ?><div class="pp-stat"><span class="num"><?php echo count($d['domain_certs']); ?></span><span class="lbl"><?php esc_html_e( 'Practice Area Certificates', 'pild-unified' ); ?></span></div><?php endif; ?>
          <?php if ($d['points']): ?><div class="pp-stat"><span class="num"><?php echo number_format($d['points']); ?></span><span class="lbl"><?php esc_html_e( 'Development Points', 'pild-unified' ); ?></span></div><?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="pp-actions">
          <button class="pp-btn pp-btn-primary" id="pild-copy-profile-link" data-url="<?php echo esc_url(pildcm_get_public_profile_url($user->ID)); ?>"><?php esc_html_e( 'Share Profile', 'pild-unified' ); ?></button>
          <a class="pp-btn pp-btn-ghost" href="<?php echo esc_url(trailingslashit(pildcm_get_public_profile_url($user->ID)) . 'cv/'); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Download CV', 'pild-unified' ); ?></a>
        </div>
      </div>

      <?php if (!empty($d['skills'])): ?>
      <div class="pp-skills">
        <?php foreach ($d['skills'] as $skill): ?><span class="pp-skill-chip"><?php echo esc_html($skill); ?></span><?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if ($has_verified): ?>
      <div class="pp-zone pp-zone-verified">
        <div class="pp-zone-head">
          <span class="pp-zone-seal">✓</span>
          <div>
            <div class="pp-zone-title"><?php esc_html_e( 'Verified by PILD', 'pild-unified' ); ?></div>
            <div class="pp-zone-caption"><?php esc_html_e( 'Issued automatically by the platform on completion — every certificate below has its own verification link.', 'pild-unified' ); ?></div>
          </div>
        </div>

        <?php if (!empty($d['domains'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Practice Areas', 'pild-unified' ); ?></div>
          <div class="pp-chips">
            <?php foreach ($d['domains'] as $dom): ?><span class="pp-chip"><?php echo esc_html($dom); ?></span><?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($d['badges_earned'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Achievement Badges', 'pild-unified' ); ?></div>
          <div class="pp-chips">
            <?php foreach ($d['badges_earned'] as $b):
                $cfg = $d['badges_cfg'][$b->badge_key] ?? null; if (!$cfg) continue; ?>
              <span class="pp-chip" title="<?php echo esc_attr($cfg['desc']); ?>"><?php echo $cfg['icon']; ?> <?php echo esc_html($cfg['label']); ?></span>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($d['domain_certs'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Practice Area Professional Certificates', 'pild-unified' ); ?></div>
          <div class="pp-cert-list">
            <?php foreach ($d['domain_certs'] as $c): ?>
            <div class="pp-cert-row">
              <div>
                <strong><?php echo esc_html($c['title']); ?></strong>
                <span class="pp-cert-date"><?php echo esc_html(date_i18n('F j, Y', strtotime($c['completed_at']))); ?></span>
              </div>
              <div class="pp-cert-links">
                <?php if ($c['view_url']): ?><a href="<?php echo esc_url($c['view_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'pild-unified' ); ?></a><?php endif; ?>
                <?php if ($c['verify_url']): ?><a href="<?php echo esc_url($c['verify_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Verify', 'pild-unified' ); ?></a><?php endif; ?>
                <?php if ($c['verify_url']): ?><a href="<?php echo esc_url(pildcm_linkedin_add_cert_url($c['title'], $c['completed_at'], $c['verify_url'], $c['cert_code'])); ?>" target="_blank" rel="noopener" class="pp-linkedin-add"><?php esc_html_e( 'Add to LinkedIn', 'pild-unified' ); ?></a><?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($d['tracks'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Track Certificates', 'pild-unified' ); ?></div>
          <div class="pp-cert-list">
            <?php foreach ($d['tracks'] as $t): ?>
            <div class="pp-cert-row">
              <div>
                <strong><?php echo esc_html($t['title']); ?></strong>
                <span class="pp-cert-date"><?php echo esc_html(date_i18n('F j, Y', strtotime($t['completed_at']))); ?></span>
              </div>
              <div class="pp-cert-links">
                <?php if ($t['view_url']): ?><a href="<?php echo esc_url($t['view_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'pild-unified' ); ?></a><?php endif; ?>
                <?php if ($t['verify_url']): ?><a href="<?php echo esc_url($t['verify_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Verify', 'pild-unified' ); ?></a><?php endif; ?>
                <?php if ($t['verify_url']): ?><a href="<?php echo esc_url(pildcm_linkedin_add_cert_url($t['title'], $t['completed_at'], $t['verify_url'], $t['cert_code'])); ?>" target="_blank" rel="noopener" class="pp-linkedin-add"><?php esc_html_e( 'Add to LinkedIn', 'pild-unified' ); ?></a><?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <?php if ($has_selfreported): ?>
      <div class="pp-zone pp-zone-self">
        <div class="pp-zone-head">
          <div>
            <div class="pp-zone-title pp-zone-title-self"><?php esc_html_e( 'About', 'pild-unified' ); ?></div>
            <div class="pp-zone-caption"><?php printf( esc_html__( 'Added by %s — not verified by PILD.', 'pild-unified' ), esc_html( $d['user']->display_name ) ); ?></div>
          </div>
        </div>

        <?php if (!empty($d['experience'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Experience', 'pild-unified' ); ?></div>
          <div class="pp-timeline">
            <?php foreach ($d['experience'] as $e):
                $e_title = pildcm_cv_pick($e->job_title, $e->job_title_en, $d['lang']);
                $e_company = pildcm_cv_pick($e->company, $e->company_en, $d['lang']);
                $e_desc = pildcm_cv_pick($e->description, $e->description_en, $d['lang']);
                if (!$e_title && !$e_company) continue; ?>
            <div class="pp-timeline-item">
              <div class="pp-timeline-dot"></div>
              <div class="pp-timeline-content">
                <?php if ($e_title): ?><strong><?php echo esc_html($e_title); ?></strong><?php endif; ?>
                <?php if ($e_company): ?><span class="pp-timeline-sub"><?php echo esc_html($e_company); ?></span><?php endif; ?>
                <?php if ($e->start_month || $e->is_current): ?><span class="pp-timeline-dates"><?php echo esc_html(pildcm_cv_format_month($e->start_month)); ?> — <?php echo $e->is_current ? esc_html__( 'Present', 'pild-unified' ) : esc_html(pildcm_cv_format_month($e->end_month)); ?></span><?php endif; ?>
                <?php if ($e_desc): ?><p class="pp-timeline-desc"><?php echo esc_html($e_desc); ?></p><?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($d['education'])): ?>
        <div class="pp-block">
          <div class="pp-block-label"><?php esc_html_e( 'Education', 'pild-unified' ); ?></div>
          <div class="pp-timeline">
            <?php foreach ($d['education'] as $ed):
                $ed_degree = pildcm_cv_pick($ed->degree, $ed->degree_en, $d['lang']);
                $ed_inst = pildcm_cv_pick($ed->institution, $ed->institution_en, $d['lang']);
                $ed_field = pildcm_cv_pick($ed->field_of_study, $ed->field_of_study_en, $d['lang']);
                if (!$ed_degree && !$ed_inst) continue; ?>
            <div class="pp-timeline-item">
              <div class="pp-timeline-dot pp-timeline-dot-edu"></div>
              <div class="pp-timeline-content">
                <?php if ($ed_degree): ?><strong><?php echo esc_html($ed_degree); ?></strong><?php endif; ?>
                <?php if ($ed_inst || $ed_field): ?><span class="pp-timeline-sub"><?php echo esc_html($ed_inst); ?><?php if ($ed_field): ?> — <?php echo esc_html($ed_field); ?><?php endif; ?></span><?php endif; ?>
                <?php if ($ed->start_year || $ed->end_year): ?><span class="pp-timeline-dates"><?php echo esc_html($ed->start_year); ?><?php if ($ed->end_year): ?> — <?php echo esc_html($ed->end_year); ?><?php endif; ?></span><?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

    </div>
    <style>
    .pild-public-profile{max-width:760px;margin:0 auto;font-family:"DM Sans",sans-serif;}

    /* ---- Header ---- */
    .pp-header{text-align:center;padding:3rem 1rem 2rem}
    .pp-avatar{width:128px;height:128px;border-radius:50%;margin:0 auto 1.25rem;overflow:hidden;background:var(--cream);display:flex;align-items:center;justify-content:center;font-family:"Playfair Display",serif;font-size:2.6rem;font-weight:700;color:var(--teal);border:3px solid #fff;box-shadow:var(--shadow-md)}
    .pp-avatar img{width:100%;height:100%;object-fit:cover}
    .pp-name{font-family:"Playfair Display",serif;font-size:2.1rem;font-weight:700;color:var(--ink);margin:0 0 .3rem}
    .pp-title{color:var(--ink2);font-size:1.05rem;margin:0 0 .2rem}
    .pp-location{color:var(--ink3);font-size:.85rem;margin:0 0 1rem}
    .pp-bio{max-width:480px;margin:0 auto 1rem;color:var(--ink2);line-height:1.6}
    .pp-links{display:flex;justify-content:center;gap:1.25rem;margin-bottom:1.25rem}
    .pp-links a{color:var(--teal);font-size:.85rem;font-weight:600;text-decoration:none;border-bottom:1px solid transparent}
    .pp-links a:hover{border-color:var(--teal)}
    .pp-stats{display:flex;justify-content:center;gap:2.5rem;margin:1.5rem 0}
    .pp-stat{display:flex;flex-direction:column;align-items:center}
    .pp-stat .num{font-family:"Playfair Display",serif;font-size:1.6rem;font-weight:700;color:var(--ink)}
    .pp-stat .lbl{font-size:.72rem;color:var(--ink3);letter-spacing:.02em}
    .pp-actions{margin-top:1.25rem;display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap}
    .pp-btn{display:inline-block;text-decoration:none;font-size:.88rem;font-weight:600;padding:.6rem 1.4rem;border-radius:999px;cursor:pointer;border:1px solid var(--teal);transition:var(--transition)}
    .pp-btn-primary{background:var(--teal);color:#fff}
    .pp-btn-primary:hover{background:var(--teal2)}
    .pp-btn-ghost{background:transparent;color:var(--teal)}
    .pp-btn-ghost:hover{background:rgba(14,102,85,.08)}

    /* ---- Skills ---- */
    .pp-skills{display:flex;flex-wrap:wrap;justify-content:center;gap:.5rem;padding:0 1rem 2rem}
    .pp-skill-chip{background:var(--cream);color:var(--ink2);border-radius:999px;padding:.3rem .85rem;font-size:.8rem;font-weight:500}

    /* ---- Zones: shared ---- */
    .pp-zone{border-radius:var(--r-lg);padding:2rem 2.25rem;margin:0 1rem 1.5rem}
    .pp-zone-head{display:flex;align-items:flex-start;gap:.85rem;margin-bottom:1.5rem}
    .pp-zone-title{font-family:"Playfair Display",serif;font-size:1.15rem;font-weight:700;color:var(--ink)}
    .pp-zone-caption{font-size:.8rem;color:var(--ink3);margin-top:.15rem}
    .pp-block{margin-bottom:1.75rem}
    .pp-block:last-child{margin-bottom:0}
    .pp-block-label{font-size:.68rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ink3);margin-bottom:.75rem}
    .pp-chips{display:flex;flex-wrap:wrap;gap:.5rem}
    .pp-chip{background:#fff;border:1px solid var(--border);border-radius:999px;padding:.35rem .9rem;font-size:.83rem;color:var(--ink2)}

    /* ---- Verified zone ---- */
    .pp-zone-verified{background:rgba(14,102,85,.045);border:1px solid rgba(14,102,85,.18)}
    .pp-zone-seal{flex-shrink:0;width:34px;height:34px;border-radius:50%;background:var(--teal);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700}
    .pp-cert-list{display:flex;flex-direction:column;gap:.65rem}
    .pp-cert-row{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;background:#fff;border:1px solid var(--border);border-radius:10px;padding:.85rem 1.1rem}
    .pp-cert-date{display:block;font-size:.78rem;color:var(--ink3)}
    .pp-cert-links a{margin-inline-start:.75rem;font-size:.82rem;color:var(--teal);text-decoration:none;font-weight:600}
    .pp-cert-links a:hover{text-decoration:underline}
    .pp-linkedin-add{color:#0A66C2!important}

    /* ---- Self-reported zone ---- */
    .pp-zone-self{background:var(--parchment);border:1px solid var(--border)}
    .pp-zone-title-self{color:var(--ink)}
    .pp-timeline{position:relative;padding-inline-start:1.5rem;border-inline-start:2px solid var(--border)}
    .pp-timeline-item{position:relative;padding-bottom:1.5rem}
    .pp-timeline-item:last-child{padding-bottom:0}
    .pp-timeline-dot{position:absolute;inset-inline-start:-1.95rem;top:.3rem;width:10px;height:10px;border-radius:50%;background:var(--gold2);border:2px solid var(--parchment)}
    .pp-timeline-dot-edu{background:var(--teal2)}
    .pp-timeline-content strong{display:block;font-size:.98rem;color:var(--ink)}
    .pp-timeline-sub{display:block;font-size:.87rem;color:var(--ink2);margin-top:.1rem}
    .pp-timeline-dates{display:block;font-size:.76rem;color:var(--ink3);margin-top:.2rem}
    .pp-timeline-desc{font-size:.85rem;color:var(--ink2);margin:.5rem 0 0;max-width:56ch;line-height:1.6}

    @media (max-width:600px){
      .pp-zone{padding:1.5rem 1.25rem}
      .pp-stats{gap:1.5rem}
    }
    </style>
    <script>
    document.getElementById('pild-copy-profile-link')?.addEventListener('click', function(){
        var url = this.getAttribute('data-url');
        navigator.clipboard.writeText(url).then(() => { var t=this; var orig=t.textContent; t.textContent = <?php echo wp_json_encode( '✓ ' . __( 'Link Copied', 'pild-unified' ) ); ?>; setTimeout(() => { t.textContent = orig; }, 2000); });
    });
    </script>
    <?php
    get_footer();
    exit;
}

// ── 26.4 Downloadable CV — /profile/{slug}/cv/
// Rendered as a standalone, print-optimized HTML page (same approach
// the plugin already uses for certificates: no PDF library on this
// site, so "Download" means "Print → Save as PDF" via the browser's
// native print dialog, which produces an identical, clean result).
add_action('template_redirect', 'pildcm_render_profile_cv');
function pildcm_render_profile_cv() {
    if (!get_query_var('pild_profile_cv')) return;

    $username = sanitize_title(get_query_var('pild_profile_user'));
    $user     = pildcm_find_user_by_profile_slug($username);
    $viewer_is_owner = $user && is_user_logged_in() && get_current_user_id() === $user->ID;

    if (!$user || (!pildcm_is_profile_public($user->ID) && !$viewer_is_owner)) {
        wp_die( esc_html__( "This profile is private or doesn't exist.", 'pild-unified' ), esc_html__( 'Not available', 'pild-unified' ), ['response' => 404] );
    }

    $d = pildcm_get_public_profile_data($user->ID);
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo esc_attr( function_exists('pll_current_language') ? pll_current_language() : 'en' ); ?>" <?php echo (function_exists('pll_current_language') && pll_current_language() === 'ar') ? 'dir="rtl"' : ''; ?>>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php printf( esc_html__( '%s — CV', 'pild-unified' ), esc_html( $d['user']->display_name ) ); ?></title>
    <style>
    body{font-family:Georgia,'Times New Roman',serif;color:#222;max-width:760px;margin:0 auto;padding:3rem 2rem;line-height:1.5}
    h1{font-size:1.8rem;margin:0 0 .1rem}
    .cv-title{color:#555;font-size:1rem;margin:0 0 .25rem}
    .cv-meta{color:#777;font-size:.9rem;margin:0 0 1.5rem}
    .cv-bio{margin-bottom:1.5rem}
    h2{font-size:1rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:2px solid #222;padding-bottom:.25rem;margin:1.75rem 0 .75rem}
    .cv-row{display:flex;justify-content:space-between;margin-bottom:.5rem;font-size:.95rem}
    .cv-row .date{color:#777;font-size:.85rem;white-space:nowrap;margin-inline-start:1rem}
    .cv-entry{margin-bottom:.85rem}
    .cv-entry-desc{color:#444;font-size:.88rem;margin:.25rem 0 0}
    .cv-chips span{display:inline-block;background:#F2F0E9;border-radius:999px;padding:.25rem .8rem;margin:0 .4rem .4rem 0;font-size:.85rem}
    .cv-verified-note{color:#0E6655;font-size:.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin:2rem 0 .25rem}
    .cv-print-bar{position:fixed;top:1rem;right:1rem}
    .cv-print-bar button{background:#111;color:#fff;border:none;border-radius:8px;padding:.6rem 1.2rem;cursor:pointer;font-size:.9rem}
    @media print { .cv-print-bar{display:none} body{padding:0 1rem} }
    </style>
    </head>
    <body>
    <div class="cv-print-bar"><button onclick="window.print()">🖨️ <?php esc_html_e( 'Print / Save as PDF', 'pild-unified' ); ?></button></div>

    <h1><?php echo esc_html($d['user']->display_name); ?></h1>
    <?php if ($d['job_title']): ?><p class="cv-title"><?php echo esc_html($d['job_title']); ?></p><?php endif; ?>
    <p class="cv-meta">
      <?php
      $meta_bits = [];
      if ($d['country']) $meta_bits[] = esc_html($d['country']);
      $meta_bits[] = esc_html($d['user']->user_email);
      if ($d['linkedin_url']) $meta_bits[] = esc_html($d['linkedin_url']);
      if ($d['website_url']) $meta_bits[] = esc_html($d['website_url']);
      echo implode(' · ', $meta_bits);
      ?>
    </p>
    <?php if (!empty($d['experience']) || !empty($d['education']) || !empty($d['skills'])): ?>
    <p class="cv-meta" style="font-style:italic">* <?php esc_html_e( 'Experience, education, and skills below are self-reported by the profile owner.', 'pild-unified' ); ?></p>
    <?php endif; ?>
    <?php if ($d['bio']): ?><p class="cv-bio"><?php echo esc_html($d['bio']); ?></p><?php endif; ?>

    <?php if (!empty($d['experience'])): ?>
    <h2><?php esc_html_e( 'Experience', 'pild-unified' ); ?></h2>
    <?php foreach ($d['experience'] as $e):
        $e_title = pildcm_cv_pick($e->job_title, $e->job_title_en, $d['lang']);
        $e_company = pildcm_cv_pick($e->company, $e->company_en, $d['lang']);
        $e_desc = pildcm_cv_pick($e->description, $e->description_en, $d['lang']);
        if (!$e_title && !$e_company) continue; ?>
      <div class="cv-entry">
        <div class="cv-row"><span><?php if ($e_title): ?><strong><?php echo esc_html($e_title); ?></strong><?php endif; ?><?php if ($e_title && $e_company): ?> — <?php endif; ?><?php echo esc_html($e_company); ?></span><span class="date"><?php echo esc_html(function_exists('pildcm_cv_format_month') ? pildcm_cv_format_month($e->start_month) : $e->start_month); ?> – <?php echo $e->is_current ? esc_html__( 'Present', 'pild-unified' ) : esc_html(function_exists('pildcm_cv_format_month') ? pildcm_cv_format_month($e->end_month) : $e->end_month); ?></span></div>
        <?php if ($e_desc): ?><p class="cv-entry-desc"><?php echo esc_html($e_desc); ?></p><?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($d['education'])): ?>
    <h2><?php esc_html_e( 'Education', 'pild-unified' ); ?></h2>
    <?php foreach ($d['education'] as $ed):
        $ed_degree = pildcm_cv_pick($ed->degree, $ed->degree_en, $d['lang']);
        $ed_inst = pildcm_cv_pick($ed->institution, $ed->institution_en, $d['lang']);
        $ed_field = pildcm_cv_pick($ed->field_of_study, $ed->field_of_study_en, $d['lang']);
        if (!$ed_degree && !$ed_inst) continue; ?>
      <div class="cv-row"><span><?php if ($ed_degree): ?><strong><?php echo esc_html($ed_degree); ?></strong><?php endif; ?><?php if ($ed_degree && $ed_inst): ?> — <?php endif; ?><?php echo esc_html($ed_inst); ?><?php if ($ed_field): ?>, <?php echo esc_html($ed_field); ?><?php endif; ?></span><span class="date"><?php echo esc_html($ed->start_year); ?><?php if ($ed->end_year): ?> – <?php echo esc_html($ed->end_year); ?><?php endif; ?></span></div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($d['skills'])): ?>
    <h2><?php esc_html_e( 'Skills', 'pild-unified' ); ?></h2>
    <div class="cv-chips"><?php foreach ($d['skills'] as $skill): ?><span><?php echo esc_html($skill); ?></span><?php endforeach; ?></div>
    <?php endif; ?>

    <?php if (!empty($d['domains']) || !empty($d['domain_certs']) || !empty($d['tracks']) || !empty($d['badges_earned'])): ?>
    <p class="cv-verified-note">✓ <?php esc_html_e( 'Verified by PILD', 'pild-unified' ); ?></p>
    <?php endif; ?>

    <?php if (!empty($d['domains'])): ?>
    <h2><?php esc_html_e( 'Practice Areas', 'pild-unified' ); ?></h2>
    <div class="cv-chips"><?php foreach ($d['domains'] as $dom): ?><span><?php echo esc_html($dom); ?></span><?php endforeach; ?></div>
    <?php endif; ?>

    <?php if (!empty($d['domain_certs'])): ?>
    <h2><?php esc_html_e( 'Practice Area Professional Certificates', 'pild-unified' ); ?></h2>
    <?php foreach ($d['domain_certs'] as $c): ?>
      <div class="cv-row"><span><?php echo esc_html($c['title']); ?></span><span class="date"><?php echo esc_html(date_i18n('M Y', strtotime($c['completed_at']))); ?></span></div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($d['tracks'])): ?>
    <h2><?php esc_html_e( 'Track Certificates', 'pild-unified' ); ?></h2>
    <?php foreach ($d['tracks'] as $t): ?>
      <div class="cv-row"><span><?php echo esc_html($t['title']); ?></span><span class="date"><?php echo esc_html(date_i18n('M Y', strtotime($t['completed_at']))); ?></span></div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($d['badges_earned'])): ?>
    <h2><?php esc_html_e( 'Achievements', 'pild-unified' ); ?></h2>
    <div class="cv-chips">
      <?php foreach ($d['badges_earned'] as $b): $cfg = $d['badges_cfg'][$b->badge_key] ?? null; if (!$cfg) continue; ?>
        <span><?php echo $cfg['icon']; ?> <?php echo esc_html($cfg['label']); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <p class="cv-meta" style="margin-top:2.5rem"><?php printf( esc_html__( 'Verified profile: %s', 'pild-unified' ), esc_html( pildcm_get_public_profile_url( $user->ID ) ) ); ?></p>
    </body>
    </html>
    <?php
    exit;
}

// ── 26.5 Build a LinkedIn "Add to Profile" certification URL.
// See: https://www.linkedin.com/help/linkedin/answer/a566000 (Add to Profile button).
function pildcm_linkedin_add_cert_url($name, $completed_at, $verify_url, $cert_code) {
    $ts = strtotime($completed_at) ?: time();
    $params = [
        'startTask'        => 'CERTIFICATION_NAME',
        'name'             => $name,
        'organizationName' => get_bloginfo('name'),
        'issueYear'        => date('Y', $ts),
        'issueMonth'       => date('n', $ts),
        'certUrl'          => $verify_url,
        'certId'           => $cert_code,
    ];
    return 'https://www.linkedin.com/profile/add?' . http_build_query($params);
}
