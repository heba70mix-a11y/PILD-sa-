<?php
// ============================================================
// [pild_sector_explorer] — public interactive drill-down page
// Sector -> Practice Areas (domains) -> Tracks -> Programs -> Competencies
//
// v3 — Restructured drill-down + interaction flow per client request:
//   1) Clear, LABELED breadcrumb at every level:
//        القطاع / <sector>  ‹  المجال / <domain>  ‹  التراك / <track>
//   2) Removed the "level" concept entirely (Foundation / Professional /
//      Executive). Tracks are no longer grouped or badged by level —
//      there was never a real "levels" concept for tracks, so nothing
//      in the UI implies one anymore. (The track_level ACF field, if
//      still present on old data, is simply not read or shown here.)
//   3) New click flow:
//        Sector chosen -> grid of PRACTICE AREA cards (each card lists
//        its tracks by name + program count, plus a link to that
//        practice area's own certification exam when configured).
//        Card click -> Practice Area page: banner with "Enroll in this
//        practice area (get every track)" + a card per TRACK (track
//        name, its programs, "Enroll in track" + "More details").
//        "More details" -> Track page: a card per PROGRAM (name,
//        description, and an in-card accordion listing its
//        competencies — expands in place, never navigates away) plus
//        one certification/assessment card, and an "Enroll in track"
//        button repeated below the cards.
//
// Fields used (all already exist in the plugin):
//   domain_sector   (domain -> sector)
//   track_domain    (track  -> domain)
//   program_track   (program -> track)
//   playbook_program(playbook/competency -> program)
//   track_quiz_id   (track  -> Quiz Maker certification exam)
//   domain_quiz_id  (domain -> Quiz Maker practice-area exam, unlocked
//                     only once every track's exam in the domain is
//                     passed — see includes/15-domain-certification.php)
//
// Registration: every "Register/Enroll" button links to the correct
// Individual or Team WooCommerce product (real purchase flow) rather
// than creating a free pild_enrollments row directly. The old
// self-enrollment AJAX action that used to live at the bottom of this
// file (pild_ex_self_enroll) has been removed — see
// includes/22-registration-routing.php for the routing logic
// (pild_get_registration_context(), pild_get_product_link_for_post())
// and the small AJAX endpoints the script below calls to resolve the
// visitor's Individual/Team mode after the page has loaded.
// ============================================================

add_shortcode( 'pild_sector_explorer', 'pild_render_sector_explorer' );

// ── Sub-sectors field on the Sector CPT ─────────────────────────────
// Purely descriptive/informational — NOT a linked post type. Per client
// request: the sector card and the sector page banner should list the
// names of this sector's sub-sectors (e.g. "الصحة الأولية، المستشفيات،
// الرعاية الطويلة" under "القطاع الصحي") instead of the auto-generated
// list of its Practice Area (domain) names. One value per line in the
// admin textarea == one bullet/line in the front end.
add_action( 'acf/init', 'pild_ex_add_subsectors_field' );
function pild_ex_add_subsectors_field() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

    acf_add_local_field_group( [
        'key'    => 'group_pild_sector_subsectors',
        'title'  => 'Sector — Sub-sectors (display only)',
        'fields' => [
            [
                'key'          => 'field_pild_sector_subsectors',
                'label'        => 'Sub-sectors',
                'name'         => 'sector_subsectors',
                'type'         => 'textarea',
                'rows'         => 5,
                'new_lines'    => '',
                'instructions' => 'اكتب اسم كل قطاع فرعي/تابع في سطر منفصل. تظهر هذه القائمة في كارت القطاع وبانر صفحة القطاع بدلاً من أسماء المجالات. اتركه فارغًا لعرض قائمة المجالات كما هي حاليًا (سلوك مؤقت لحد ما تتعبى الحقل).',
                'required'     => 0,
            ],
        ],
        'location' => [
            [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'sector' ] ],
        ],
    ] );
}

// Splits a textarea's raw value into a clean array of non-empty, trimmed
// lines. Shared by the sub-sectors field above (kept as a standalone,
// file-scoped helper so it can be reused without touching the separate
// $to_lines closure already used for program goals/outcomes below).
function pild_ex_text_to_lines( $raw ) {
    $lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
    $lines = array_map( 'trim', $lines );
    return array_values( array_filter( $lines, function ( $l ) { return $l !== ''; } ) );
}

function pild_build_sector_explorer_data() {
    $user_id = get_current_user_id();

    $sectors_posts = get_posts( [
        'post_type' => 'sector', 'posts_per_page' => -1, 'post_status' => 'publish',
        'orderby' => 'menu_order title', 'order' => 'ASC',
    ] );

    $data = [];
    foreach ( $sectors_posts as $sector ) {
        $domains_posts = get_posts( [
            'post_type' => 'domain', 'posts_per_page' => -1, 'post_status' => 'publish',
            'meta_key' => 'domain_sector', 'meta_value' => $sector->ID,
            'orderby' => 'menu_order title', 'order' => 'ASC',
        ] );

        $domains = [];
        foreach ( $domains_posts as $domain ) {
            $tracks_posts = get_posts( [
                'post_type' => 'track', 'posts_per_page' => -1, 'post_status' => 'publish',
                'meta_key' => 'track_domain', 'meta_value' => $domain->ID,
                'orderby' => 'menu_order title', 'order' => 'ASC',
            ] );

            $tracks = [];
            foreach ( $tracks_posts as $track ) {
                $programs_posts = get_posts( [
                    'post_type' => 'program', 'posts_per_page' => -1, 'post_status' => 'publish',
                    'meta_key' => 'program_track', 'meta_value' => $track->ID,
                    'orderby' => 'menu_order title', 'order' => 'ASC',
                ] );

                $programs = [];
                foreach ( $programs_posts as $program ) {
                    $playbooks_posts = get_posts( [
                        'post_type' => 'playbook', 'posts_per_page' => -1, 'post_status' => 'publish',
                        'meta_key' => 'playbook_program', 'meta_value' => $program->ID,
                        'orderby' => 'menu_order title', 'order' => 'ASC',
                    ] );
                    $competencies = [];
                    foreach ( $playbooks_posts as $pb ) {
                        $competencies[] = [
                            'id'      => $pb->ID,
                            'title'   => $pb->post_title,
                            'excerpt' => wp_trim_words( $pb->post_excerpt ?: $pb->post_content, 18, '…' ),
                        ];
                    }

                    $goals_raw    = function_exists( 'get_field' ) ? (string) get_field( 'program_goals', $program->ID )    : '';
                    $outcomes_raw = function_exists( 'get_field' ) ? (string) get_field( 'program_outcomes', $program->ID ) : '';
                    $to_lines = function ( $raw ) {
                        $lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
                        $lines = array_map( 'trim', $lines );
                        return array_values( array_filter( $lines, function ( $l ) { return $l !== ''; } ) );
                    };

                    $programs[] = [
                        'id'       => $program->ID,
                        'title'    => $program->post_title,
                        // Full, untrimmed overview text for the details popup —
                        // the card itself still shows the short trimmed version.
                        'overview' => $program->post_excerpt ?: $program->post_content,
                        'excerpt'  => wp_trim_words( $program->post_excerpt ?: $program->post_content, 22, '…' ),
                        'goals'    => $to_lines( $goals_raw ),
                        'outcomes' => $to_lines( $outcomes_raw ),
                        'thumb'    => get_the_post_thumbnail_url( $program->ID, 'medium' ) ?: '',
                        'link'     => get_permalink( $program->ID ),
                        'competencies' => $competencies,
                    ];
                }

                $quiz_id = (int) get_post_meta( $track->ID, 'track_quiz_id', true );

                $tracks[] = [
                    'id'       => $track->ID,
                    'title'    => $track->post_title,
                    'desc'     => wp_trim_words( $track->post_excerpt ?: $track->post_content, 32, '…' ),
                    'thumb'    => get_the_post_thumbnail_url( $track->ID, 'medium' ) ?: '',
                    'link'     => get_permalink( $track->ID ),
                    'quizId'   => $quiz_id,
                    'programs' => $programs,
                    // Raw product URLs only — never a resolved "which one applies
                    // to this visitor" link, so this whole JSON blob (and the page
                    // it's embedded in) stays safe to cache. See includes/22-
                    // registration-routing.php for how these get picked client-side.
                    'regInd'   => function_exists( 'pild_get_product_link_for_post' ) ? pild_get_product_link_for_post( $track->ID, 'individual' ) : '',
                    'regTeam'  => function_exists( 'pild_get_product_link_for_post' ) ? pild_get_product_link_for_post( $track->ID, 'team' ) : '',
                    // Indicative BASE price only (never partner-specific — see
                    // pild_get_track_price_html()) shown on the register button
                    // itself so a visitor knows the cost before clicking.
                    'priceInd'  => function_exists( 'pild_get_track_price_html' ) ? pild_get_track_price_html( $track->ID, 'individual' ) : '',
                    'priceTeam' => function_exists( 'pild_get_track_price_html' ) ? pild_get_track_price_html( $track->ID, 'team' ) : '',
                ];
            }

            $domain_quiz_id = (int) get_post_meta( $domain->ID, 'domain_quiz_id', true );
            $cert_progress  = null;
            if ( $domain_quiz_id && function_exists( 'pildcm_get_domain_progress' ) ) {
                $prog = $user_id ? pildcm_get_domain_progress( $user_id, $domain->ID ) : [ 'total' => count( $tracks ), 'certified' => 0, 'complete' => false ];
                $cert_progress = $prog;
            }

            $domains[] = [
                'id'            => $domain->ID,
                'title'         => $domain->post_title,
                'desc'          => wp_trim_words( $domain->post_excerpt ?: $domain->post_content, 24, '…' ),
                'thumb'         => get_the_post_thumbnail_url( $domain->ID, 'medium' ) ?: '',
                'link'          => get_permalink( $domain->ID ),
                'quizId'        => $domain_quiz_id,
                'certProgress'  => $cert_progress,
                'tracks'        => $tracks,
                // Only set when this Practice Area is itself sold as a whole
                // bundle — see pild_get_product_link_for_post() for how a Track
                // with no product of its own falls back to these.
                'regInd'        => function_exists( 'pild_get_product_link_for_post' ) ? pild_get_product_link_for_post( $domain->ID, 'individual' ) : '',
                'regTeam'       => function_exists( 'pild_get_product_link_for_post' ) ? pild_get_product_link_for_post( $domain->ID, 'team' ) : '',
            ];
        }

        $subsectors_raw = function_exists( 'get_field' ) ? get_field( 'sector_subsectors', $sector->ID ) : '';

        $data[] = [
            'id'         => $sector->ID,
            'title'      => $sector->post_title,
            'desc'       => wp_trim_words( $sector->post_excerpt ?: $sector->post_content, 24, '…' ),
            'thumb'      => get_the_post_thumbnail_url( $sector->ID, 'medium' ) ?: '',
            'link'       => get_permalink( $sector->ID ),
            'domains'    => $domains,
            // Descriptive sub-sector names only (see pild_ex_add_subsectors_field
            // above) — empty array until the field is filled in per sector.
            'subsectors' => pild_ex_text_to_lines( $subsectors_raw ),
        ];
    }

    return $data;
}
function pild_render_sector_explorer() {
    // Cache the built catalog for GUESTS only — pild_build_sector_
    // explorer_data() embeds per-user progress (pildcm_get_domain_
    // progress()) for a logged-in visitor, so caching it globally would
    // leak one person's completion status into another's page. Guests
    // are both the safe case (nothing personalized to leak) and the
    // biggest win (they're most of the catalog-browsing traffic), so
    // this is where a transient actually pays for itself. Keyed per
    // language since prices/links resolve differently per Polylang
    // language (see pild_get_level_product_id()'s language-aware pick).
    // Invalidated by pild_flush_sector_explorer_cache() (26.12 below)
    // whenever catalog content, pricing levels, or level products change.
    if ( ! is_user_logged_in() ) {
        $lang       = function_exists( 'pll_current_language' ) ? pll_current_language() : 'default';
        $cache_key  = 'pild_sxd_' . $lang;
        $data       = get_transient( $cache_key );
        if ( $data === false ) {
            $data = pild_build_sector_explorer_data();
            set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );
        }
    } else {
        $data = pild_build_sector_explorer_data();
    }
    $json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );

    // ---- Bilingual UI chrome -------------------------------------------
    $lang = null;
    $queried_id = get_queried_object_id();
    if ( function_exists( 'pll_get_post_language' ) && $queried_id ) {
        $lang = pll_get_post_language( $queried_id );
    }
    if ( ! $lang && function_exists( 'pll_current_language' ) ) {
        $lang = pll_current_language();
    }
    if ( ! $lang ) {
        $lang = function_exists( 'pll_default_language' ) ? pll_default_language() : 'en';
    }
    $is_en = ( $lang === 'en' );
    $dir   = $is_en ? 'ltr' : 'rtl';

    // Totals for the hero stat strip
    $totals = [ 'domains' => 0, 'tracks' => 0, 'programs' => 0, 'competencies' => 0 ];
    foreach ( $data as $sector ) {
        $totals['domains'] += count( $sector['domains'] );
        foreach ( $sector['domains'] as $domain ) {
            $totals['tracks'] += count( $domain['tracks'] );
            foreach ( $domain['tracks'] as $track ) {
                $totals['programs'] += count( $track['programs'] );
                foreach ( $track['programs'] as $program ) {
                    $totals['competencies'] += count( $program['competencies'] );
                }
            }
        }
    }

    $strings = [
        'ar' => [
            'org_name'          => 'المعهد المهني للتعلم والتطوير',
            'hero_title_1'      => 'قطاعاتك،',
            'hero_title_2'      => 'ومجالاتك، وتراكاتك المهنية.',
            'hero_desc'         => 'منظومة تطوير مهني متكاملة لبناء القادة وتأهيل الكفاءات المؤسسية بمنهجية علمية دقيقة عبر قطاعات ومجالات ممارسة متعددة.',
            'hero_cta_explore'  => 'استكشف المجالات',
            'hero_cta_browse'   => 'تصفّح كل التراكات',
            'stat_domains'      => 'مجال',
            'stat_tracks'       => 'تراك',
            'stat_programs'     => 'برنامج',
            'stat_competencies' => 'قدرة',
            'brand_sub'         => 'تطوير مهني',
            'search_ph'         => 'ابحث عن مجال…',
            'current_sector'    => 'القطاع الحالي',
            'no_sectors'        => 'لا توجد قطاعات منشورة بعد.',
            'no_results'        => 'لا توجد نتائج',
            'browse_all'        => 'استعراض',
            'section_title'     => 'مجالات الممارسة',
            'section_desc'      => 'اختر أي مجال لاستعراض تراكاته وبرامجه بالكامل. كل تراك مسار تطوير مهني منظم.',
            'tracks_suffix'     => 'تراك',
            'programs_suffix'   => 'برنامج',
            'competencies_suffix' => 'قدرة',
            'more_tracks'       => 'تراكات أخرى — اضغط للعرض',
            'expand_all'        => 'عرض كل التراكات',
            'hide_tracks'       => 'إخفاء التراكات',
            'open_full_area'    => 'فتح صفحة المجال كاملة',
            'no_tracks'         => 'لا توجد تراكات منشورة في هذا المجال بعد.',
            // labeled breadcrumb
            'crumb_sector'      => 'القطاع',
            'crumb_domain'      => 'المجال',
            'crumb_track'       => 'التراك',
            'all_areas'         => 'كل المجالات',
            'all_sectors'       => 'كل القطاعات',
            'choose_sector_title' => 'اختر القطاع',
            'choose_sector_desc'  => 'اختر القطاع الذي يناسب مجال عملك لاستعراض مجالاته وتراكاته وبرامجه المهنية.',
            'subsectors_label'    => 'يضم هذا القطاع القطاعات التابعة التالية:',
            // Shown instead of the line above ONLY when a sector has no
            // sub-sectors entered yet in field_pild_sector_subsectors —
            // keeps the old domain-based summary visible during the
            // transition instead of leaving the banner/card blank.
            'subsectors_label_fallback' => 'يضم هذا القطاع المجالات التالية:',
            // domain detail
            'practice_area'     => 'مجال ممارسة',
            'visit_area_page'   => 'صفحة المجال',
            'enroll_domain_btn' => 'سجّل في المجال — احصل على كل تراكاته',
            'track_n_of'        => 'تراك %1$d من %2$d',
            'track_programs_preview' => 'برامج التراك',
            // track card actions (on domain page)
            'enroll_track_btn'  => 'سجّل في التراك',
            'more_details_btn'  => 'التفاصيل',
            // track page
            'all_programs'      => 'كل البرامج',
            'competencies_tab'  => 'القدرات',
            'explore_track'     => 'صفحة التراك',
            'track_programs'    => 'برامج التراك',
            'no_programs'       => 'برامج هذا التراك قيد الإعداد — ستُضاف فور اعتمادها.',
            'competencies_count'=> 'قدرة',
            // program card + details popup
            'program_details_btn'   => 'تفاصيل البرنامج',
            'no_competencies'       => 'لا توجد قدرات مضافة لهذا البرنامج بعد.',
            'modal_close'           => 'إغلاق',
            'modal_overview_title'  => 'نبذة عن البرنامج',
            'modal_goals_title'     => 'أهداف البرنامج',
            'modal_outcomes_title'  => 'مخرجات البرنامج',
            'modal_competencies_title' => 'القدرات المستهدفة',
            'comp_card_label' => 'الكتاب التشغيلي',
            'modal_no_overview'     => 'لا توجد نبذة مضافة لهذا البرنامج بعد.',
            'modal_no_goals'        => 'لا توجد أهداف مضافة بعد.',
            'modal_no_outcomes'     => 'لا توجد مخرجات مضافة بعد.',
            // certification banners
            'area_milestone'    => 'المحطة الختامية',
            'area_cert_title'   => 'أنهِ %1$d تراك، ثم اجتز اختبار %2$s النهائي',
            'area_cert_desc'    => 'بعد إنهاء كل تراك في هذا المجال، هتدخل اختبار تقييم شامل. لو اجتزته، هتحصل على شهادة %s المهنية المعتمدة.',
            'area_cert_no_quiz' => 'اختبار شهادة هذا المجال قيد الإعداد — هيُتاح فور اعتماده.',
            'track_milestone'   => 'محطة التراك',
            'track_cert_title'  => 'أنهِ كل البرامج، ثم اجتز اختبار %s',
            'track_cert_desc'   => 'بعد إنهاء كل برنامج وكل قدرة في هذا التراك، هتدخل اختبار قصير لتأكيد إتقانك. لو اجتزته، هتحصل على شهادة %s.',
            'track_cert_no_quiz'=> 'اختبار شهادة هذا التراك قيد الإعداد — هيُتاح فور اعتماده.',
            'step_tracks'       => 'تراكات',
            'step_programs'     => 'برامج',
            'step_area_assess'  => 'اختبار المجال',
            'step_track_assess' => 'اختبار التراك',
            'step_locked'       => '(مقفول حتى إتمام كل التراكات)',
            'cert_step'         => 'شهادة',
            'start_exam_btn'    => 'ابدأ الاختبار الآن',
            // enrollment feedback
            'enrolling'         => 'جارٍ التسجيل…',
            'enroll_success'    => '✔ تم تسجيلك بنجاح',
            'enroll_already'    => 'أنت مسجّل بالفعل',
            'enroll_error'      => 'تعذّر التسجيل، حاول مرة أخرى',
            'login_required'    => 'يجب تسجيل الدخول أولًا للتسجيل',
            // register-button routing
            'register_btn'      => 'سجّل',
            'reg_unavailable'   => 'التسجيل غير متاح حاليًا',
            'switch_audience'   => 'مش الفئة دي؟ بدّل لـ %s',
            'switch_to_individual' => 'فرد',
            'switch_to_team'    => 'فريق',
            // dual register buttons (track page) — replaced the single
            // button + "switch audience" text link per client request.
            'reg_org_btn'       => 'تسجيل مؤسسي',
            'reg_ind_btn'       => 'تسجيل فردي',
            // audience toggle chips (domain/area page) — replaced the
            // "switch audience" text link per client request.
            'audience_org_chip' => 'اشتراك مؤسسي',
            'audience_ind_chip' => 'اشتراك أفراد',
            // inline add-to-cart flow (replaces navigating to the product page)
            'reg_adding'        => 'جارٍ الإضافة…',
            'reg_added_title'   => 'تم التسجيل وإضافة التراك للسلة بنجاح',
            'reg_go_checkout'   => 'الذهاب إلى الدفع',
            'reg_another'       => 'سجل في تراك آخر',
            'reg_already_in_cart' => 'التراك ده أصلاً في سلتك',
            'reg_error_generic' => 'حصل خطأ — حاول تاني',
            'reg_need_login'    => 'لازم تسجّل دخول الأول',
            'reg_seats_title'   => 'عدد المقاعد',
            'reg_seats_note'    => 'الحد الأدنى %d مقاعد',
            'reg_seats_confirm' => 'إضافة للسلة',
            'reg_seats_cancel'  => 'إلغاء',
            'reg_starting_from' => 'يبدأ من',
            'reg_per_seat_short' => 'للمقعد',
            // Training Partner audience (Sep 2026)
            'reg_partner_cta'   => 'سجل كشريك',
            'reg_partner_chip'  => 'تسجيل مركز تدريب',
            'audience_tc_chip'  => 'مركز تدريب',
            'reg_pending_chip'  => 'طلبك قيد المراجعة',
            'reg_pending_banner_title' => 'طلب الشراكة بتاعك قيد المراجعة',
            'reg_pending_banner_body'  => 'هنراجع طلبك ونفعّل حسابك كمركز تدريب معتمد قريبًا — التسجيل هيتفتح تلقائي بمجرد الموافقة.',
            // Organization quick-registration modal (Sep 2026)
            'org_reg_title'     => 'بيانات المنظمة',
            'org_reg_name'      => 'اسم المنظمة',
            'org_reg_responsible' => 'اسم المسؤول',
            'org_reg_phone'     => 'رقم الهاتف',
            'org_reg_website'   => 'الموقع الإلكتروني (اختياري)',
            'org_reg_address'   => 'العنوان (اختياري)',
            'org_reg_note'      => 'تقدر تكمّل الشعار وباقي البيانات بعدين من داشبورد المنظمة.',
            'org_reg_confirm'   => 'متابعة',
            'org_reg_cancel'    => 'إلغاء',
            'org_reg_required'  => 'اسم المنظمة، اسم المسؤول، والهاتف حقول إجبارية.',
        ],
        'en' => [
            'org_name'          => 'Professional Institute for Learning & Development',
            'hero_title_1'      => 'Your sectors,',
            'hero_title_2'      => 'practice areas & professional tracks.',
            'hero_desc'         => 'A comprehensive professional development ecosystem designed to build leaders and qualify institutional competencies with a rigorous methodology across sectors and practice areas.',
            'hero_cta_explore'  => 'Explore Practice Areas',
            'hero_cta_browse'   => 'Browse All Tracks',
            'stat_domains'      => 'Areas',
            'stat_tracks'       => 'Tracks',
            'stat_programs'     => 'Programs',
            'stat_competencies' => 'Competencies',
            'brand_sub'         => 'Professional Development',
            'search_ph'         => 'Search practice areas…',
            'current_sector'    => 'Current Sector',
            'no_sectors'        => 'No sectors published yet.',
            'no_results'        => 'No results found',
            'browse_all'        => 'Browse All',
            'section_title'     => 'Practice Areas',
            'section_desc'      => 'Select any area to explore its full track structure. Each track is a structured development pathway.',
            'tracks_suffix'     => 'tracks',
            'programs_suffix'   => 'programs',
            'competencies_suffix' => 'competencies',
            'more_tracks'       => 'more tracks — click to expand',
            'expand_all'        => 'Expand all tracks',
            'hide_tracks'       => 'Hide tracks',
            'open_full_area'    => 'Open Full Practice Area Page',
            'no_tracks'         => 'No tracks published in this area yet.',
            'crumb_sector'      => 'Sector',
            'crumb_domain'      => 'Practice Area',
            'crumb_track'       => 'Track',
            'all_areas'         => 'All Practice Areas',
            'all_sectors'       => 'All Sectors',
            'choose_sector_title' => 'Choose a Sector',
            'choose_sector_desc'  => 'Select the sector that matches your field to explore its practice areas, tracks, and professional programs.',
            'subsectors_label'    => 'This sector includes the following sub-sectors:',
            'subsectors_label_fallback' => 'This sector includes the following areas:',
            'practice_area'     => 'Practice Area',
            'visit_area_page'   => 'About This Area',
            'enroll_domain_btn' => 'Enroll in This Area',
            'track_n_of'        => 'Track %1$d of %2$d',
            'track_programs_preview' => 'Track programs',
            'enroll_track_btn'  => 'Enroll in Track',
            'more_details_btn'  => 'Details',
            'all_programs'      => 'All Programs',
            'competencies_tab'  => 'Competencies',
            'explore_track'     => 'Explore Track & Features',
            'track_programs'    => 'Track Programs',
            'no_programs'       => 'Programs for this track are coming soon.',
            'competencies_count'=> 'competencies',
            // program card + details popup
            'program_details_btn'   => 'Program Details',
            'no_competencies'       => 'No competencies added to this program yet.',
            'modal_close'           => 'Close',
            'modal_overview_title'  => 'Program Overview',
            'modal_goals_title'     => 'Program Goals',
            'modal_outcomes_title'  => 'Program Outcomes',
            'modal_competencies_title' => 'Target Competencies',
            'comp_card_label' => 'Operational Playbook',
            'modal_no_overview'     => 'No overview added for this program yet.',
            'modal_no_goals'        => 'No goals added yet.',
            'modal_no_outcomes'     => 'No outcomes added yet.',
            'area_milestone'    => 'Final Milestone',
            'area_cert_title'   => 'Complete all %1$d tracks, then take the %2$s Final Assessment',
            'area_cert_desc'    => "Once every track in this practice area is finished, you'll sit a comprehensive final evaluation. Pass it, and you'll be awarded the official %s Professional Certificate.",
            'area_cert_no_quiz' => "This area's certification exam is being prepared — it will be available once configured.",
            'track_milestone'   => 'Track Milestone',
            'track_cert_title'  => 'Finish all programs, then take the %s Assessment',
            'track_cert_desc'   => "After completing every program and competency in this track, you'll take a short assessment to confirm your mastery. Pass it, and you'll earn the %s Certificate.",
            'track_cert_no_quiz'=> "This track's certification exam is being prepared — it will be available once configured.",
            'step_tracks'       => 'Tracks',
            'step_programs'     => 'Programs',
            'step_area_assess'  => 'Area Assessment',
            'step_track_assess' => 'Track Assessment',
            'step_locked'       => '(locked until every track is complete)',
            'cert_step'         => 'Certificate',
            'start_exam_btn'    => 'Start the Exam Now',
            'enrolling'         => 'Enrolling…',
            'enroll_success'    => '✔ Enrolled successfully',
            'enroll_already'    => 'You are already enrolled',
            'enroll_error'      => 'Could not enroll, please try again',
            'login_required'    => 'Please log in first to enroll',
            // register-button routing
            'register_btn'      => 'Register',
            'reg_unavailable'   => 'Registration is not available right now',
            'switch_audience'   => "Not the right category? Switch to %s",
            'switch_to_individual' => 'Individual',
            'switch_to_team'    => 'Team',
            // dual register buttons (track page)
            'reg_org_btn'       => 'Corporate Registration',
            'reg_ind_btn'       => 'Individual Registration',
            // audience toggle chips (domain/area page)
            'audience_org_chip' => 'Corporate Subscription',
            'audience_ind_chip' => 'Individual Subscription',
            // inline add-to-cart flow (replaces navigating to the product page)
            'reg_adding'        => 'Adding…',
            'reg_added_title'   => 'Registered — track added to your cart',
            'reg_go_checkout'   => 'Go to Checkout',
            'reg_another'       => 'Register another track',
            'reg_already_in_cart' => 'This track is already in your cart',
            'reg_error_generic' => 'Something went wrong — please try again',
            'reg_need_login'    => 'Please log in first',
            'reg_seats_title'   => 'Number of seats',
            'reg_seats_note'    => 'Minimum %d seats',
            'reg_seats_confirm' => 'Add to cart',
            'reg_seats_cancel'  => 'Cancel',
            'reg_starting_from' => 'From',
            'reg_per_seat_short' => 'per seat',
            // Training Partner audience (Sep 2026)
            'reg_partner_cta'   => 'Apply as a Training Partner',
            'reg_partner_chip'  => 'Training Center Registration',
            'audience_tc_chip'  => 'Training Center',
            'reg_pending_chip'  => 'Application under review',
            'reg_pending_banner_title' => 'Your partnership application is under review',
            'reg_pending_banner_body'  => 'We will review your application and activate your Training Center account soon — registration will unlock automatically once approved.',
            // Organization quick-registration modal (Sep 2026)
            'org_reg_title'     => 'Organization details',
            'org_reg_name'      => 'Organization name',
            'org_reg_responsible' => 'Responsible person',
            'org_reg_phone'     => 'Phone number',
            'org_reg_website'   => 'Website (optional)',
            'org_reg_address'   => 'Address (optional)',
            'org_reg_note'      => 'You can add the logo and complete the rest later from the organization dashboard.',
            'org_reg_confirm'   => 'Continue',
            'org_reg_cancel'    => 'Cancel',
            'org_reg_required'  => 'Organization name, responsible person, and phone are required.',
        ],
    ];
    $t = $strings[ $is_en ? 'en' : 'ar' ];
    $i18n_json = wp_json_encode( $t, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );

    $ajax_url     = esc_url( admin_url( 'admin-ajax.php' ) );
    $reg_nonce    = wp_create_nonce( 'pild_reg_ctx' ); // for pild_reg_get_context / pild_reg_set_context (includes/22-registration-routing.php)
    $login_url    = esc_url( wp_login_url( home_url( add_query_arg( [] ) ) ) );
    $is_logged_in = is_user_logged_in() ? 1 : 0;
    // Client decision (Sep 2026, includes/35-purchase-category.php): a
    // logged-in visitor with no fixed role (no team, not an approved
    // partner) still gets the explicit Individual/Organization/Training-
    // Center selector, same as a guest — only a real team owner/member or
    // an approved partner has their category fixed by their account.
    $has_fixed_role = 0;
    if ( $is_logged_in ) {
        $uid = get_current_user_id();
        if ( ( function_exists('pild_user_is_team_owner') && pild_user_is_team_owner($uid) )
          || ( function_exists('pild_user_is_team_member') && pild_user_is_team_member($uid) )
          || ( function_exists('pild_is_approved_partner') && pild_is_approved_partner($uid) ) ) {
            $has_fixed_role = 1;
        }
    }
    $heading_font = $is_en ? "'Playfair Display',serif" : "'El Messiri',serif";
    $body_font    = $is_en ? "'Inter',sans-serif" : "'IBM Plex Sans Arabic',sans-serif";

    ob_start();
    ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=El+Messiri:wght@500;600;700&family=Inter:wght@300;400;500;600&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
#pild-app{
  --bg:#F5F4F0;--bg2:#FFFFFF;--sidebar:#FAFAF7;--ink:#1A1A1A;--ink2:#3D3D3D;--ink3:#7A7A7A;
  --line:#E5E2DA;--line2:#EFECE5;--gold:#B8892E;--gold-bg:#FBF5E8;--gold-bd:#E8D5A3;--r:12px;
}
#pild-app,#pild-app *,#pild-app *::before,#pild-app *::after{margin:0;padding:0;box-sizing:border-box;}
#pild-app{-webkit-font-smoothing:antialiased;direction:<?php echo esc_attr( $dir ); ?>;text-align:start;}
#pild-app{font-family:<?php echo $body_font; ?>;background:var(--bg);color:var(--ink);overflow-x:hidden;}
#pild-app button{border:none;cursor:pointer;font-family:inherit;background:none;}
#pild-app a,#pild-app a:link,#pild-app a:visited{color:inherit;text-decoration:none;}
#pild-app .serif{font-family:<?php echo $heading_font; ?>!important;font-weight:700;}

/* HERO */
#pild-app .hero{position:relative;min-height:560px;background:#0F0F0E;overflow:hidden;display:flex;align-items:center;}
#pild-app .hero-grid-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(184,137,46,.07) 1px,transparent 1px),linear-gradient(90deg,rgba(184,137,46,.07) 1px,transparent 1px);background-size:60px 60px;mask-image:radial-gradient(ellipse 80% 80% at 50% 50%,black 30%,transparent 100%);}
#pild-app .hero-glow{position:absolute;width:600px;height:400px;background:radial-gradient(ellipse,rgba(184,137,46,.12) 0%,transparent 70%);top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none;}
#pild-app .hero-content{position:relative;z-index:2;max-width:1200px;margin:0 auto;padding:72px 40px;display:grid;grid-template-columns:1fr 380px;gap:50px;align-items:center;width:100%;}
#pild-app .hero-badge{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:20px;border:1px solid rgba(184,137,46,.35);background:rgba(184,137,46,.08);color:#D4A040;font-size:11px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:22px;}
#pild-app .hero-badge span{width:5px;height:5px;border-radius:50%;background:#D4A040;flex-shrink:0;}
#pild-app .hero-h1{font-size:clamp(30px,3.6vw,50px);font-weight:700;color:#F5F4F0;line-height:1.16;margin-bottom:18px;}
#pild-app .hero-h1 em{color:#D4A040;font-style:italic;}
#pild-app .hero-desc{font-size:15px;color:rgba(245,244,240,.6);font-weight:300;line-height:1.8;max-width:520px;margin-bottom:32px;}
#pild-app .hero-cta-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:40px;}
#pild-app .hero-btn{padding:13px 26px;border-radius:8px;font-size:13.5px;font-weight:500;cursor:pointer;transition:all .2s;}
#pild-app .hero-btn-primary{background:#D4A040;color:#1A1A1A;}
#pild-app .hero-btn-primary:hover{background:#E6B050;transform:translateY(-1px);}
#pild-app .hero-btn-secondary{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);color:rgba(245,244,240,.85);}
#pild-app .hero-btn-secondary:hover{background:rgba(255,255,255,.1);}
#pild-app .hero-stats{display:flex;border:1px solid rgba(255,255,255,.1);border-radius:10px;overflow:hidden;background:rgba(255,255,255,.04);}
#pild-app .hero-stat{flex:1;padding:14px 12px;text-align:center;border-inline-end:1px solid rgba(255,255,255,.08);}
#pild-app .hero-stat:last-child{border-inline-end:none;}
#pild-app .hero-stat-n{font-size:24px;font-weight:700;color:#D4A040;line-height:1;}
#pild-app .hero-stat-l{font-size:9.5px;color:rgba(245,244,240,.45);letter-spacing:1.2px;text-transform:uppercase;margin-top:4px;}
#pild-app .hero-mosaic{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;}
#pild-app .hm-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:14px 10px;transition:all .2s;cursor:pointer;text-align:center;}
#pild-app .hm-card:hover{background:rgba(212,160,64,.08);border-color:rgba(212,160,64,.25);}
#pild-app .hm-icon{font-size:19px;margin-bottom:7px;}
#pild-app .hm-name{font-size:10px;color:rgba(245,244,240,.6);line-height:1.3;font-weight:500;}
#pild-app .hero-empty{padding:36px 20px;text-align:center;color:rgba(245,244,240,.5);font-size:13px;}

/* LAYOUT */
#pild-app .layout{display:grid;grid-template-columns:280px 1fr;min-height:100vh;}

/* SIDEBAR */
#pild-app .sidebar{background:var(--sidebar);border-inline-end:1px solid var(--line);position:sticky;top:0;height:100vh;overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;}
#pild-app .sb-top{padding:18px 16px 12px;border-bottom:1px solid var(--line);flex-shrink:0;}
#pild-app .sb-switch{display:flex;align-items:center;gap:10px;padding:8px;border-radius:9px;cursor:pointer;margin-bottom:14px;transition:background .15s;}
#pild-app .sb-switch:hover{background:var(--line2);}
#pild-app .sb-logo{width:30px;height:30px;border-radius:7px;background:var(--ink);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
#pild-app .sb-logo svg{width:14px;height:14px;fill:none;stroke:#fff;stroke-width:1.8;}
#pild-app .sb-brand-text{font-size:13.5px;font-weight:700;color:var(--ink);}
#pild-app .sb-brand-sub{font-size:9px;color:var(--ink3);letter-spacing:.4px;margin-top:1px;}
#pild-app .sb-search{width:100%;padding:8px 10px;background:var(--bg2);border:1px solid var(--line);border-radius:7px;color:var(--ink);font-size:12.5px;outline:none;transition:border-color .2s;}
#pild-app .sb-search::placeholder{color:var(--ink3);}
#pild-app .sb-search:focus{border-color:var(--gold);}
#pild-app .sb-list{padding:6px 0 24px;flex:1;}
#pild-app .sb-cat-label{padding:10px 16px 4px;font-size:9px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--ink3);}
#pild-app .sb-item{width:100%;display:flex;align-items:center;gap:9px;padding:9px 16px;color:var(--ink2);font-size:12px;font-weight:400;text-align:start;transition:all .15s;cursor:pointer;border-inline-start:2px solid transparent;}
#pild-app .sb-item:hover{background:var(--line2);color:var(--ink);}
#pild-app .sb-item.active{background:var(--gold-bg);color:var(--gold);border-inline-start-color:var(--gold);font-weight:500;}
#pild-app .sb-item-icon{width:24px;height:24px;border-radius:6px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:12px;background:var(--line2);}
#pild-app .sb-item.active .sb-item-icon{background:var(--gold-bd);}
#pild-app .sb-item-name{flex:1;line-height:1.3;}
#pild-app .sb-item-cnt{font-size:9px;color:var(--ink3);background:var(--line2);padding:2px 6px;border-radius:7px;flex-shrink:0;}
#pild-app .sb-item.active .sb-item-cnt{color:var(--gold);background:var(--gold-bd);}

/* MAIN */
#pild-app .main{background:var(--bg);min-height:100vh;}
#pild-app .areas-section,#pild-app .area-detail,#pild-app .track-page{padding:28px 32px;}
#pild-app .section-label{font-size:9.5px;letter-spacing:1.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px;}
#pild-app .section-title{font-size:21px;font-weight:700;color:var(--ink);margin-bottom:4px;}
#pild-app .section-desc{font-size:13px;color:var(--ink3);font-weight:300;line-height:1.6;margin-bottom:20px;max-width:640px;}
#pild-app .areas-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px;}

/* labeled breadcrumb */
#pild-app .breadcrumb{display:flex;align-items:center;gap:8px;font-size:11.5px;color:var(--ink3);margin-bottom:18px;flex-wrap:wrap;}
#pild-app .breadcrumb .crumb{display:inline-flex;align-items:baseline;gap:4px;cursor:pointer;}
#pild-app .breadcrumb .crumb.static{cursor:default;}
#pild-app .breadcrumb .crumb-label{font-size:9px;letter-spacing:.5px;color:var(--ink3);opacity:.8;}
#pild-app .breadcrumb .crumb-val{color:var(--gold);font-weight:500;}
#pild-app .breadcrumb .crumb.static .crumb-val{color:var(--ink);}
#pild-app .breadcrumb .crumb:hover .crumb-val{text-decoration:underline;}
#pild-app .breadcrumb .crumb-sep{color:var(--line);}

/* AREA CARD (domain card in the grid) */
#pild-app .area-card{background:var(--bg2);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;transition:all .22s;box-shadow:0 1px 3px rgba(0,0,0,.04);}
#pild-app .area-card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.09);border-color:#D4CEBF;}
#pild-app .ac-top{padding:16px 16px 13px;display:flex;align-items:flex-start;gap:12px;position:relative;cursor:pointer;}
#pild-app .ac-accent{position:absolute;top:0;left:0;right:0;height:3px;}
#pild-app .ac-icon{width:38px;height:38px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;}
#pild-app .ac-info{flex:1;min-width:0;}
#pild-app .ac-name{font-size:14.5px;font-weight:700;color:var(--ink);line-height:1.25;margin-bottom:2px;}
#pild-app .ac-sub{font-size:10px;color:var(--ink3);}
#pild-app .ac-badge{font-size:9px;font-weight:600;padding:2.5px 7px;border-radius:7px;background:var(--gold-bg);color:var(--gold);border:1px solid var(--gold-bd);letter-spacing:.3px;flex-shrink:0;margin-top:2px;white-space:nowrap;}
#pild-app .ac-tracks-preview{padding:0 16px 4px;border-top:1px solid var(--line2);}
#pild-app .ac-track-row{display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid var(--line2);font-size:11px;color:var(--ink2);}
#pild-app .ac-track-row:last-child{border-bottom:none;}
#pild-app .ac-track-dot{width:5px;height:5px;border-radius:50%;flex-shrink:0;}
#pild-app .ac-track-name{flex:1;line-height:1.3;}
#pild-app .ac-track-progs{font-size:9px;color:var(--ink3);flex-shrink:0;}
#pild-app .ac-track-more{color:var(--gold);font-weight:500;justify-content:center;}
#pild-app .ac-reg-row{padding:0 16px 12px;}
#pild-app .ac-reg-btn{width:100%;justify-content:center;padding:8px 10px;font-size:11.5px;}
#pild-app .pe-reg-disabled{opacity:.5;cursor:default;}
#pild-app .pe-switch-audience{display:inline-block;font-size:11px;color:var(--ink3);text-decoration:underline;margin-top:6px;flex-basis:100%;text-align:end;}
#pild-app .pe-switch-audience:hover{color:var(--gold);}
#pild-app .ac-expand-btn{width:100%;padding:10px 16px;display:flex;align-items:center;justify-content:space-between;font-size:11.5px;color:var(--ink3);border-top:1px solid var(--line2);background:var(--bg);transition:all .18s;cursor:pointer;}
#pild-app .ac-expand-btn:hover{color:var(--ink2);background:var(--line2);}
#pild-app .ac-expand-btn svg{width:13px;height:13px;transition:transform .2s;flex-shrink:0;}
#pild-app .ac-expand-btn.open svg{transform:rotate(180deg);}
#pild-app .ac-tracks-panel{display:none;border-top:1px solid var(--line);}
#pild-app .ac-tracks-panel.open{display:block;}
#pild-app .ac-tracks-panel-inner{padding:12px 16px;}
#pild-app .track-chip{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;margin-bottom:6px;border-radius:8px;cursor:pointer;border:1px solid var(--line2);background:var(--bg);transition:all .18s;}
#pild-app .track-chip:hover{border-color:#C8C3B5;background:var(--bg2);transform:translateX(2px);}
#pild-app [dir="rtl"] .track-chip:hover{transform:translateX(-2px);}
#pild-app .track-chip-left{display:flex;align-items:center;gap:8px;min-width:0;}
#pild-app .track-chip-n{font-size:9px;color:var(--ink3);min-width:18px;flex-shrink:0;}
#pild-app .track-chip-name{font-size:11.5px;color:var(--ink2);font-weight:500;line-height:1.3;}
#pild-app .track-chip-arrow{font-size:11px;color:var(--ink3);flex-shrink:0;}
#pild-app .ac-goto-btn{width:100%;padding:11px 16px;display:flex;align-items:center;justify-content:center;gap:7px;font-size:12px;font-weight:500;color:var(--gold);border-top:1px solid var(--line);background:var(--gold-bg);transition:all .18s;cursor:pointer;}
#pild-app .ac-goto-btn:hover{background:#F5EDD5;}
#pild-app .ac-goto-btn svg{width:14px;height:14px;stroke:currentColor;fill:none;stroke-width:2;}

/* SECTOR CARD (sector-picker grid) */
#pild-app .sector-card{cursor:pointer;}

/* SECTOR BANNER (top of a sector's practice-area grid) */
#pild-app .sector-banner{position:relative;display:flex;align-items:flex-start;gap:16px;padding:22px 24px;border-radius:var(--r);border:1px solid var(--line);background:var(--bg2);overflow:hidden;margin-bottom:20px;box-shadow:0 1px 4px rgba(0,0,0,.04);}
#pild-app .sbnr-accent{position:absolute;top:0;left:0;right:0;height:3px;}
#pild-app .sbnr-icon{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:19px;flex-shrink:0;}
#pild-app .sbnr-body{flex:1;min-width:0;}
#pild-app .sbnr-eyebrow{font-size:9px;letter-spacing:1.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px;}
#pild-app .sbnr-title{font-size:19px;font-weight:700;color:var(--ink);margin-bottom:5px;}
#pild-app .sbnr-desc{font-size:12px;color:var(--ink2);font-weight:300;line-height:1.6;margin-bottom:8px;max-width:640px;}
#pild-app .sbnr-sub{font-size:11.5px;color:var(--ink2);line-height:1.7;}
#pild-app .sbnr-sub-list{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:4px;}
#pild-app .sbnr-sub-list li{position:relative;padding-inline-start:14px;font-size:12.5px;color:var(--ink2);line-height:1.6;}
#pild-app .sbnr-sub-list li::before{content:'';position:absolute;inset-inline-start:0;top:8px;width:5px;height:5px;border-radius:50%;background:currentColor;opacity:.55;}
#pild-app .sbnr-sub-label{font-weight:600;color:var(--ink);margin-inline-end:4px;}

/* AREA DETAIL (domain page) */
#pild-app .area-detail{animation:fadeUp .25s ease;}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
#pild-app .back-btn{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--ink3);padding:6px 12px;border-radius:7px;border:1px solid var(--line);background:var(--bg2);margin-bottom:18px;transition:all .15s;cursor:pointer;}
#pild-app .back-btn:hover{color:var(--ink);border-color:var(--ink3);}
#pild-app .back-btn svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2;}
#pild-app .ad-header{display:flex;align-items:flex-start;gap:18px;padding:24px 26px;border-radius:var(--r);margin-bottom:20px;border:1px solid var(--line);background:var(--bg2);position:relative;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.04);flex-wrap:wrap;}
#pild-app .ad-header-accent{position:absolute;top:0;left:0;right:0;height:3px;}
#pild-app .ad-icon{width:48px;height:48px;border-radius:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:21px;}
#pild-app .ad-body{flex:1;min-width:260px;}
#pild-app .ad-eyebrow{font-size:9px;letter-spacing:1.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px;}
#pild-app .ad-title{font-size:clamp(18px,2vw,24px);font-weight:700;color:var(--ink);margin-bottom:5px;}
#pild-app .ad-desc{font-size:12.5px;color:var(--ink2);font-weight:300;line-height:1.7;max-width:480px;margin-bottom:14px;}
#pild-app .ad-stats{display:flex;gap:22px;padding-top:12px;border-top:1px solid var(--line);flex-wrap:wrap;align-items:center;}
#pild-app .ads-num{font-size:20px;font-weight:700;color:var(--ink);line-height:1;}
#pild-app .ads-lbl{font-size:9px;color:var(--ink3);letter-spacing:.4px;text-transform:uppercase;margin-top:2px;}
#pild-app .ad-cta-row{display:flex;gap:10px;margin-inline-start:auto;flex-wrap:wrap;}
#pild-app .ad-btn{padding:9px 18px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;transition:all .18s;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
#pild-app .ad-btn svg{width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2;flex-shrink:0;}
#pild-app .ad-btn-ghost{background:var(--bg);border:1px solid var(--line);color:var(--ink2);}
#pild-app .ad-btn-ghost:hover{border-color:var(--ink3);color:var(--ink);}
#pild-app .ad-btn-solid{background:var(--gold);border:1px solid var(--gold);color:#fff;}
#pild-app .ad-btn-solid:hover{background:#A67A28;border-color:#A67A28;}
#pild-app .ad-btn:disabled{opacity:.6;cursor:default;}
#pild-app .detail-tracks-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px;margin-bottom:22px;}
#pild-app .detail-track-card{border-radius:9px;padding:16px 16px 14px;border:1px solid var(--line);background:var(--bg2);position:relative;overflow:hidden;transition:all .2s;display:flex;flex-direction:column;gap:8px;}
#pild-app .detail-track-card:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.08);border-color:#D0CBBE;}
#pild-app .dtc-bar-top{position:absolute;top:0;left:0;right:0;height:2px;}
#pild-app .dtc-n{font-size:9px;color:var(--ink3);letter-spacing:1.2px;text-transform:uppercase;}
#pild-app .dtc-name{font-size:14px;font-weight:700;color:var(--ink);line-height:1.3;cursor:pointer;}
#pild-app .dtc-name:hover{color:var(--gold);}
#pild-app .dtc-progs{border-top:1px solid var(--line2);padding-top:8px;margin-top:2px;}
#pild-app .dtc-progs-label{font-size:9px;color:var(--ink3);letter-spacing:.5px;text-transform:uppercase;margin-bottom:5px;}
#pild-app .dtc-prog-item{font-size:11px;color:var(--ink2);padding:2px 0;display:flex;align-items:center;gap:6px;}
#pild-app .dtc-prog-item::before{content:'';width:4px;height:4px;border-radius:50%;background:var(--gold);flex-shrink:0;}
#pild-app .dtc-prog-more{font-size:10px;color:var(--ink3);margin-top:2px;}
#pild-app .dtc-actions{display:flex;flex-wrap:wrap;gap:7px;margin-top:auto;padding-top:4px;}
#pild-app .dtc-actions .ad-btn{flex:1 1 120px;justify-content:center;padding:8px 10px;font-size:11px;white-space:nowrap;}

/* CERTIFICATION BANNER (area-level + track-level) */
#pild-app .cert-banner{position:relative;border-radius:var(--r);overflow:hidden;border:1px solid #2A2A26;background:#141311;padding:26px 24px;margin-top:6px;}
#pild-app .cert-banner-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(184,137,46,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(184,137,46,.06) 1px,transparent 1px);background-size:34px 34px;mask-image:radial-gradient(ellipse 90% 100% at 30% 0%,black 20%,transparent 100%);}
#pild-app .cert-banner-inner{position:relative;z-index:2;display:flex;align-items:center;gap:20px;flex-wrap:wrap;}
#pild-app .cert-badge-icon{width:52px;height:52px;border-radius:50%;background:rgba(212,160,64,.12);border:1px solid rgba(212,160,64,.35);display:flex;align-items:center;justify-content:center;font-size:21px;flex-shrink:0;}
#pild-app .cert-body{flex:1;min-width:220px;}
#pild-app .cert-eyebrow{font-size:9px;letter-spacing:1.8px;text-transform:uppercase;color:#D4A040;font-weight:600;margin-bottom:6px;display:flex;align-items:center;gap:8px;}
#pild-app .cert-eyebrow-line{flex:1;height:1px;background:rgba(212,160,64,.2);max-width:60px;}
#pild-app .cert-title{font-size:18px;font-weight:700;color:#F5F4F0;line-height:1.3;margin-bottom:6px;}
#pild-app .cert-title em{color:#D4A040;font-style:italic;}
#pild-app .cert-desc{font-size:12px;color:rgba(245,244,240,.55);font-weight:300;line-height:1.65;max-width:540px;}
#pild-app .cert-steps{display:flex;align-items:center;gap:8px;margin-top:14px;flex-wrap:wrap;}
#pild-app .cert-step{display:flex;align-items:center;gap:7px;padding:6px 12px;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);font-size:10.5px;color:rgba(245,244,240,.7);}
#pild-app .cert-step-n{width:16px;height:16px;border-radius:50%;background:rgba(212,160,64,.18);color:#D4A040;font-size:8.5px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
#pild-app .cert-step-arrow{color:rgba(245,244,240,.25);font-size:11px;}
#pild-app .cert-step.is-cert{background:rgba(212,160,64,.1);border-color:rgba(212,160,64,.3);color:#E6B050;font-weight:500;}
#pild-app .cert-step.is-locked{opacity:.55;}
#pild-app .cert-cta{flex-shrink:0;padding:11px 22px;border-radius:8px;background:#D4A040;color:#1A1A1A!important;font-size:12.5px;font-weight:600;white-space:nowrap;transition:all .18s;display:inline-block;}
#pild-app .cert-cta:hover{background:#E6B050;transform:translateY(-1px);}
#pild-app .cert-locked-note{font-size:11px;color:rgba(245,244,240,.5);margin-top:12px;}

/* TRACK PAGE */
#pild-app .track-page{animation:fadeUp .25s ease;}
#pild-app .track-header{padding:26px 28px;border-radius:var(--r);margin-bottom:22px;border:1px solid var(--line);background:var(--bg2);position:relative;overflow:hidden;}
#pild-app .th-accent{position:absolute;top:0;left:0;right:0;height:4px;}
#pild-app .th-top{display:flex;align-items:flex-start;gap:16px;margin-bottom:14px;flex-wrap:wrap;}
#pild-app .th-icon{width:52px;height:52px;border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:23px;}
#pild-app .th-meta{flex:1;min-width:200px;}
#pild-app .th-area{font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px;}
#pild-app .th-name{font-size:clamp(18px,2.2vw,26px);font-weight:700;color:var(--ink);line-height:1.2;}
#pild-app .th-desc{font-size:12.5px;color:var(--ink2);font-weight:300;line-height:1.7;margin-top:10px;max-width:600px;}
#pild-app .th-enroll{flex-shrink:0;}
#pild-app .track-toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:16px;padding-top:14px;border-top:1px solid var(--line2);}
#pild-app .track-toolbar--reg{justify-content:space-between;}
#pild-app .tf-pill{padding:5px 13px;border-radius:15px;font-size:11px;font-weight:500;border:1px solid var(--line);color:var(--ink3);background:var(--bg2);}
#pild-app .tf-pill.active{background:var(--ink);border-color:var(--ink);color:#fff;}
/* dual register buttons — track page (سجّل في التراك chip + تسجيل مؤسسي/فردي) */
#pild-app .reg-dual-group{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start;}
#pild-app .reg-dual-btn{padding:8px 16px;}
/* Inline add-to-cart register buttons (replace the old plain <a> links) */
#pild-app .pild-reg-btn{border:none;font-family:inherit;}
#pild-app .pild-reg-busy{opacity:.7;cursor:progress;}
#pild-app .pild-reg-error{font-size:10.5px;color:#B91C1C;margin-top:5px;}
#pild-app .pild-reg-done{background:var(--bg2);border:1px solid var(--gold-bd,var(--line));border-radius:10px;padding:10px 14px;display:flex;flex-direction:column;gap:8px;min-width:220px;}
#pild-app .pild-reg-done-msg{font-size:11.5px;font-weight:700;color:var(--ink);}
#pild-app .pild-reg-done-actions{display:flex;gap:8px;flex-wrap:wrap;}
#pild-app .pild-reg-done-actions .ad-btn{padding:7px 12px;font-size:11px;}
#pild-app .pild-seat-track-name{font-size:13px;font-weight:600;color:var(--ink);margin-bottom:14px;}
#pild-app .pild-seat-input{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:8px;font-size:14px;margin-bottom:6px;}
#pild-app .pild-seat-note{font-size:11px;color:var(--ink3);margin-bottom:18px;}
#pild-app .pild-seat-actions{display:flex;gap:10px;}
#pild-app .pild-seat-actions .ad-btn{flex:1;justify-content:center;}
/* audience toggle chips — domain/area page (اشتراك مؤسسي / اشتراك أفراد) */
#pild-app .audience-toggle{display:inline-flex;border:1px solid var(--line);border-radius:20px;padding:3px;gap:2px;background:var(--bg2);}
#pild-app .audience-chip{padding:7px 16px;border-radius:17px;font-size:11.5px;font-weight:600;border:none;background:transparent;color:var(--ink3);cursor:pointer;transition:all .15s;font-family:inherit;}
#pild-app .audience-chip:hover{color:var(--ink);}
#pild-app .audience-chip.active{background:var(--ink);color:#fff;}
#pild-app .tf-explore-btn{margin-inline-start:auto;padding:6px 15px;border-radius:15px;font-size:11px;font-weight:600;border:1px solid var(--gold-bd);color:var(--gold);background:var(--gold-bg);cursor:pointer;display:inline-flex;align-items:center;gap:6px;}
#pild-app .tf-explore-btn:hover{background:#F5EDD5;}
#pild-app .tf-explore-btn svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2;}
#pild-app .programs-section{margin-bottom:26px;}
#pild-app .prog-header{display:flex;align-items:center;gap:8px;margin-bottom:14px;}
#pild-app .prog-icon{font-size:18px;}
#pild-app .prog-title{font-size:16.5px;font-weight:700;color:var(--ink);}
#pild-app .prog-count{font-size:10px;color:var(--ink3);background:var(--line2);padding:2px 8px;border-radius:7px;}
#pild-app .programs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:12px;}
#pild-app .programs-grid .program-card{margin-bottom:0;display:flex;flex-direction:column;transition:all .2s;}
#pild-app .programs-grid .program-card:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.08);border-color:#D0CBBE;}
#pild-app .pgc-accent{height:3px;width:100%;}
#pild-app .pgc-top{display:flex;align-items:flex-start;gap:12px;padding:16px 16px 8px;}
#pild-app .pgc-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;}
#pild-app .pgc-info{flex:1;min-width:0;}
#pild-app .pgc-num{font-size:9px;color:var(--ink3);letter-spacing:.5px;text-transform:uppercase;margin-bottom:3px;}
#pild-app .pgc-name{font-size:14px;font-weight:700;color:var(--ink);line-height:1.3;}
#pild-app .pgc-desc{font-size:11.5px;color:var(--ink2);font-weight:300;line-height:1.6;padding:0 16px 16px;}
#pild-app .program-card{background:var(--bg2);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;margin-bottom:12px;}

/* Program card: competencies chips + details button */
#pild-app .pgc-comp-block{padding:0 16px 14px;}
#pild-app .pgc-comp-label{font-size:9px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:7px;}
#pild-app .pgc-comp-chips{display:flex;flex-wrap:wrap;gap:6px;}
#pild-app .pgc-comp-chip{font-size:10.5px;color:var(--gold);background:var(--gold-bg);border:1px solid var(--gold-bd);padding:3px 9px;border-radius:20px;line-height:1.5;}
#pild-app .pgc-actions{margin-top:auto;padding:12px 16px 16px;border-top:1px solid var(--line2);}
#pild-app .pgc-details-btn{width:100%;display:flex;align-items:center;justify-content:center;gap:7px;padding:9px 12px;border-radius:8px;border:1px solid var(--line);background:var(--bg2);color:var(--ink2);font-size:12px;font-weight:500;transition:all .15s;}
#pild-app .pgc-details-btn:hover{background:var(--gold-bg);border-color:var(--gold-bd);color:var(--gold);}
#pild-app .pgc-details-btn svg{width:14px;height:14px;flex-shrink:0;}

/* Program details popup */
#pild-app .pild-modal-overlay{position:fixed;inset:0;background:rgba(15,15,14,.6);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center;z-index:9999;padding:24px;opacity:0;transition:opacity .2s;}
#pild-app .pild-modal-overlay.open{opacity:1;}
#pild-app .pild-modal{background:var(--bg2);border-radius:16px;max-width:720px;width:100%;max-height:88vh;overflow-y:auto;position:relative;transform:translateY(14px) scale(.98);transition:transform .22s cubic-bezier(.2,.8,.2,1);box-shadow:0 30px 70px rgba(0,0,0,.35);}
#pild-app .pild-modal-overlay.open .pild-modal{transform:translateY(0) scale(1);}
#pild-app .pm-close{position:absolute;top:16px;inset-inline-end:16px;width:34px;height:34px;border-radius:50%;background:rgba(0,0,0,.05);display:flex;align-items:center;justify-content:center;color:var(--ink2);z-index:2;transition:all .15s;}
#pild-app .pm-close:hover{background:rgba(0,0,0,.1);color:var(--ink);}
#pild-app .pm-close svg{width:16px;height:16px;}
#pild-app .pm-header{position:relative;padding:34px 32px 22px;background:#0F0F0E;overflow:hidden;border-radius:16px 16px 0 0;}
#pild-app .pm-header-accent{position:absolute;inset:0;background:radial-gradient(ellipse 70% 100% at 20% 0%,rgba(184,137,46,.22) 0%,transparent 70%);}
#pild-app .pm-eyebrow{position:relative;font-size:10px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:#D4A040;margin-bottom:10px;}
#pild-app .pm-title{position:relative;font-size:23px;font-weight:700;color:#F5F4F0;line-height:1.3;}
#pild-app .pm-body{padding:26px 32px 32px;}
#pild-app .pm-section{margin-bottom:22px;}
#pild-app .pm-section:last-child{margin-bottom:0;}
#pild-app .pm-section-title{display:flex;align-items:center;gap:8px;font-size:13.5px;font-weight:700;color:var(--ink);margin-bottom:10px;}
#pild-app .pm-section-icon{font-size:15px;}
#pild-app .pm-overview{font-size:13px;color:var(--ink2);line-height:1.85;font-weight:300;}
#pild-app .pm-empty{font-size:12px;color:var(--ink3);font-style:italic;}
#pild-app .pm-list{list-style:none;display:flex;flex-direction:column;gap:8px;}
#pild-app .pm-list li{position:relative;font-size:12.5px;color:var(--ink2);line-height:1.6;padding-inline-start:20px;}
#pild-app .pm-list li::before{content:"";position:absolute;inset-inline-start:0;top:7px;width:7px;height:7px;border-radius:2px;background:var(--gold);transform:rotate(45deg);}
#pild-app .pm-section-cols{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:22px;}
#pild-app .pm-comp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;}
#pild-app .pm-comp-card{background:var(--gold-bg);border:1px solid var(--gold-bd);border-radius:10px;padding:12px 14px;}
#pild-app .pm-comp-kicker{display:flex;align-items:center;gap:6px;margin-bottom:8px;}
#pild-app .pm-comp-dot{width:7px;height:7px;border-radius:50%;background:var(--gold);flex-shrink:0;}
#pild-app .pm-comp-kicker-text{font-size:10px;font-weight:700;color:var(--gold);letter-spacing:.02em;}
#pild-app .pm-comp-name{font-size:12.5px;font-weight:600;color:var(--ink);line-height:1.4;margin-bottom:4px;}
#pild-app .pm-comp-desc{font-size:11px;color:var(--ink2);font-weight:300;line-height:1.5;}
@media(max-width:640px){
  #pild-app .pm-section-cols{grid-template-columns:1fr;gap:16px;}
  #pild-app .pild-modal{max-height:92vh;}
  #pild-app .pm-header{padding:28px 20px 18px;}
  #pild-app .pm-body{padding:20px 20px 26px;}
}
#pild-app .prog-card-top{padding:16px 18px;display:flex;align-items:flex-start;gap:14px;border-bottom:1px solid var(--line2);cursor:pointer;transition:background .15s;}
#pild-app .prog-card-top:hover{background:var(--line2);}
#pild-app .prog-num{font-size:9px;color:var(--ink3);background:var(--line2);padding:3px 7px;border-radius:6px;flex-shrink:0;font-weight:600;letter-spacing:.4px;margin-top:2px;white-space:nowrap;}
#pild-app .prog-info{flex:1;}
#pild-app .prog-name{font-size:14px;font-weight:700;color:var(--ink);margin-bottom:3px;}
#pild-app .prog-sub{font-size:11px;color:var(--ink3);font-weight:300;line-height:1.5;}
#pild-app .prog-expand{width:26px;height:26px;border-radius:6px;border:1px solid var(--line);background:var(--bg);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
#pild-app .prog-expand svg{width:12px;height:12px;stroke:var(--ink3);fill:none;stroke-width:2;transition:transform .2s;}
#pild-app .prog-card-top.open .prog-expand svg{transform:rotate(180deg);}
#pild-app .prog-books{padding:10px 18px 14px;display:none;}
#pild-app .prog-books.open{display:block;}
#pild-app .book-row{display:flex;align-items:flex-start;gap:12px;padding:10px 12px;margin-bottom:6px;border-radius:8px;border:1px solid var(--line2);background:var(--bg);}
#pild-app .book-num{width:24px;height:24px;border-radius:6px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:9.5px;font-weight:700;}
#pild-app .book-content{flex:1;min-width:0;}
#pild-app .book-title{font-size:12px;font-weight:600;color:var(--ink);margin-bottom:2px;line-height:1.3;}
#pild-app .book-tagline{font-size:10.5px;color:var(--ink3);font-weight:300;line-height:1.4;}
#pild-app .book-badge{flex-shrink:0;font-size:9px;font-weight:600;padding:2px 7px;border-radius:6px;background:var(--gold-bg);color:var(--gold);border:1px solid var(--gold-bd);margin-top:2px;white-space:nowrap;}
#pild-app .prog-link{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:600;color:var(--gold);margin-top:6px;}
#pild-app .prog-link:hover{text-decoration:underline;}

#pild-app .empty{text-align:center;padding:60px 20px;background:var(--bg2);border-radius:var(--r);border:1px dashed var(--line);}
#pild-app .empty-icon{font-size:26px;margin-bottom:10px;}
#pild-app .empty h3{font-size:13px;color:var(--ink3);font-weight:500;}

@media(max-width:900px){
#pild-app .layout{grid-template-columns:1fr;}
#pild-app .sidebar{position:static;height:auto;border-inline-end:none;border-bottom:1px solid var(--line);}
#pild-app .areas-section,#pild-app .area-detail,#pild-app .track-page{padding:20px 16px;}
#pild-app .hero-content{grid-template-columns:1fr;padding:48px 24px;}
#pild-app .hero-mosaic{display:none;}
#pild-app .ad-cta-row{margin-inline-start:0;width:100%;}
#pild-app .ad-btn{flex:1;justify-content:center;}
#pild-app .tf-explore-btn{margin-inline-start:0;}
#pild-app .audience-toggle{width:100%;}
#pild-app .audience-chip{flex:1;}
#pild-app .track-toolbar--reg{flex-direction:column;align-items:flex-start;gap:12px;}
#pild-app .reg-dual-group{width:100%;}
#pild-app .reg-dual-btn{flex:1;justify-content:center;}
}
@media(max-width:600px){
#pild-app .areas-grid,#pild-app .detail-tracks-grid,#pild-app .programs-grid{grid-template-columns:1fr;}
}
</style>

<div id="pild-app" dir="<?php echo esc_attr( $dir ); ?>" lang="<?php echo esc_attr( $lang ); ?>">
<section class="hero" id="peHero">
  <div class="hero-grid-bg"></div>
  <div class="hero-glow"></div>
  <div class="hero-content">
    <div>
      <div class="hero-badge"><span></span><?php echo esc_html( $t['org_name'] ); ?></div>
      <h1 class="hero-h1 serif"><?php echo esc_html( $t['hero_title_1'] ); ?><br><em><?php echo esc_html( $t['hero_title_2'] ); ?></em></h1>
      <p class="hero-desc"><?php echo esc_html( $t['hero_desc'] ); ?></p>
      <div class="hero-cta-row">
        <button class="hero-btn hero-btn-primary" id="peHeroExplore"><?php echo esc_html( $t['hero_cta_explore'] ); ?></button>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><div class="hero-stat-n"><?php echo (int) $totals['domains']; ?></div><div class="hero-stat-l"><?php echo esc_html( $t['stat_domains'] ); ?></div></div>
        <div class="hero-stat"><div class="hero-stat-n"><?php echo (int) $totals['tracks']; ?></div><div class="hero-stat-l"><?php echo esc_html( $t['stat_tracks'] ); ?></div></div>
        <div class="hero-stat"><div class="hero-stat-n"><?php echo (int) $totals['programs']; ?></div><div class="hero-stat-l"><?php echo esc_html( $t['stat_programs'] ); ?></div></div>
        <div class="hero-stat"><div class="hero-stat-n"><?php echo (int) $totals['competencies']; ?></div><div class="hero-stat-l"><?php echo esc_html( $t['stat_competencies'] ); ?></div></div>
      </div>
    </div>
    <div class="hero-mosaic" id="peHeroMosaic"></div>
  </div>
</section>

<div class="layout" id="peLayout" style="display:none;">
  <aside class="sidebar">
    <div class="sb-top">
      <div class="sb-switch" id="peSectorSwitch">
        <div class="sb-logo"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></div>
        <div><div class="sb-brand-text" id="peSswName">PILD</div><div class="sb-brand-sub"><?php echo esc_html( $t['brand_sub'] ); ?></div></div>
      </div>
      <input class="sb-search" type="text" placeholder="<?php echo esc_attr( $t['search_ph'] ); ?>" id="peSearch" autocomplete="off">
    </div>
    <div class="sb-list" id="peSbList"></div>
  </aside>
  <main class="main" id="peMain"></main>
</div>
</div>

<script>
(function(){
  var DATA = <?php echo $json ?: '[]'; ?>;
  var I18N = <?php echo $i18n_json ?: '{}'; ?>;
  var AJAX_URL = <?php echo wp_json_encode( $ajax_url ); ?>;
  var REG_NONCE = <?php echo wp_json_encode( $reg_nonce ); ?>;
  var LOGIN_URL = <?php echo wp_json_encode( $login_url ); ?>;
  var IS_LOGGED_IN = <?php echo (int) $is_logged_in; ?>;
  var HAS_FIXED_ROLE = <?php echo (int) $has_fixed_role; ?>;
  var IS_RTL = <?php echo $is_en ? 'false' : 'true'; ?>;
  var PARTNER_APPLY_URL = <?php echo function_exists('pild_partner_apply_url') ? wp_json_encode( pild_partner_apply_url() ) : "''"; ?>;

  // ---------------------------------------------------------------
  // Register-button audience routing (individual vs team product).
  // The page's own HTML never bakes in a resolved link — REG_MODE
  // starts at the safe default and is corrected via a small, always-
  // fresh AJAX call right after load (see fetchRegContext() below),
  // which is what keeps this whole page cacheable. See includes/22-
  // registration-routing.php for the server-side logic.
  // ---------------------------------------------------------------
  var REG_MODE = 'individual';
  var REG_SWITCHABLE = !HAS_FIXED_ROLE;

  function regHref(ind, team){
    var primary = (REG_MODE === 'team') ? team : ind;
    var fallback = (REG_MODE === 'team') ? ind : team;
    return primary || fallback || '';
  }

  function regButtonHTML(ind, team, label, extraClass){
    var href = regHref(ind, team);
    if(!href){
      return '<span class="ad-btn ad-btn-solid pe-reg-disabled'+(extraClass?(' '+extraClass):'')+'" title="'+esc(I18N.reg_unavailable)+'">'+esc(label)+'</span>';
    }
    return '<a class="ad-btn ad-btn-solid'+(extraClass?(' '+extraClass):'')+'" href="'+esc(href)+'">'+esc(label)+'</a>';
  }

  // Secondary "not this category? switch to Individual/Team" link —
  // per spec, only ever shown to visitors who are NOT logged in.
  // NOTE: no longer called anywhere (superseded by the dual-button /
  // audience-toggle designs below per client request) — kept defined,
  // unused, in case a future page still needs the old single-link style.
  function switchLinkHTML(idPrefix){
    if(HAS_FIXED_ROLE || !REG_SWITCHABLE) return '';
    var targetLabel = (REG_MODE === 'team') ? I18N.switch_to_individual : I18N.switch_to_team;
    return '<a href="#" class="pe-switch-audience" id="'+idPrefix+'SwitchAudience">'+fmt(I18N.switch_audience, targetLabel)+'</a>';
  }
  function bindSwitchLink(idPrefix){
    var link = el(idPrefix+'SwitchAudience');
    if(!link) return;
    link.addEventListener('click', function(e){
      e.preventDefault();
      switchRegContext(REG_MODE === 'team' ? 'individual' : 'team');
    });
  }

  // Track page: "سجّل في التراك" label chip + two DIRECT action buttons
  // (تسجيل مؤسسي / تسجيل فردي) — each is its own real link straight to
  // that product, independent of REG_MODE. A variant with no linked
  // product renders disabled (greyed, with the "not available" tooltip)
  // instead of silently falling back to the other one, since here the
  // visitor is explicitly choosing which product they want.
  function dualRegButtonsHTML(ind, team){
    var orgHtml = team
      ? '<a class="ad-btn ad-btn-solid reg-dual-btn" href="'+esc(team)+'">'+esc(I18N.reg_org_btn)+'</a>'
      : '<span class="ad-btn ad-btn-solid reg-dual-btn pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.reg_org_btn)+'</span>';
    var indHtml = ind
      ? '<a class="ad-btn ad-btn-ghost reg-dual-btn" href="'+esc(ind)+'">'+esc(I18N.reg_ind_btn)+'</a>'
      : '<span class="ad-btn ad-btn-ghost reg-dual-btn pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.reg_ind_btn)+'</span>';
    return '<div class="reg-dual-group">'+orgHtml+indHtml+'</div>';
  }

  // ---------------------------------------------------------------
  // TRACK registration — inline add-to-cart (client decision, replaces
  // navigating to a WooCommerce product page). Individual clicks add
  // straight away; Team/Partner clicks first ask for a seat count. On
  // success the button is replaced in place by a small panel: success
  // message + "Go to checkout" + "Register another track" (which sends
  // the visitor back to the sectors list — the track just added stays
  // in the cart, so several tracks can accumulate before one checkout).
  // Uses the SAME renderMain() re-render this file already relies on
  // for REG_MODE changes — button state just lives in TRACK_UI_STATE /
  // CART_TRACKS and is read back in on every render.
  // ---------------------------------------------------------------
  var CART_TRACKS = {};      // trackId -> { individual:true, team:true }
  var TRACK_UI_STATE = {};   // trackId -> { individual:'idle'|'busy'|'done', team:... }
  var TRACK_DONE_KIND = {};  // "trackId|variant" -> 'added' | 'already'
  var TRACK_UI_ERROR = {};   // "trackId|variant" -> last error message
  var CART_CHECKOUT_URL = '';

  function trackInCart(trackId, variant){ return !!(CART_TRACKS[trackId] && CART_TRACKS[trackId][variant]); }
  function trackState(trackId, variant){
    if (trackInCart(trackId, variant)) return 'done';
    return (TRACK_UI_STATE[trackId] && TRACK_UI_STATE[trackId][variant]) || 'idle';
  }
  function setTrackState(trackId, variant, state){
    TRACK_UI_STATE[trackId] = TRACK_UI_STATE[trackId] || {};
    TRACK_UI_STATE[trackId][variant] = state;
  }
  function markInCart(trackId, variant, kind){
    CART_TRACKS[trackId] = CART_TRACKS[trackId] || {};
    CART_TRACKS[trackId][variant] = true;
    TRACK_DONE_KIND[trackId+'|'+variant] = kind || 'added';
  }
  function findTrackById(trackId){
    for (var si=0; si<DATA.length; si++){
      var domains = DATA[si].domains || [];
      for (var di=0; di<domains.length; di++){
        var tracks = domains[di].tracks || [];
        for (var ti=0; ti<tracks.length; ti++){
          if (tracks[ti].id === trackId) return tracks[ti];
        }
      }
    }
    return null;
  }

  // The stateful control itself: idle button (w/ price) -> busy label ->
  // success panel. `btnClass` is the FULL class string for the idle/busy
  // button (caller decides solid vs ghost — see trackDualRegButtonsHTML,
  // which picks emphasis based on the visitor's real REG_MODE).
  function trackRegAreaHTML(tr, variant, label, btnClass){
    var state = trackState(tr.id, variant);
    if (state === 'done'){
      var kind = TRACK_DONE_KIND[tr.id+'|'+variant] || 'added';
      var msg = (kind === 'already') ? I18N.reg_already_in_cart : I18N.reg_added_title;
      return '<div class="pild-reg-done">'+
        '<div class="pild-reg-done-msg">✔ '+esc(msg)+'</div>'+
        '<div class="pild-reg-done-actions">'+
          '<a class="ad-btn ad-btn-solid" href="'+esc(CART_CHECKOUT_URL || '#')+'">'+esc(I18N.reg_go_checkout)+'</a>'+
          '<button type="button" class="ad-btn ad-btn-ghost pild-reg-another">'+esc(I18N.reg_another)+'</button>'+
        '</div>'+
      '</div>';
    }
    var cls = btnClass + ' pild-reg-btn';
    if (state === 'busy'){
      return '<span class="'+cls+' pild-reg-busy" aria-busy="true">'+esc(I18N.reg_adding)+'</span>';
    }
    var price = (variant === 'team') ? tr.priceTeam : tr.priceInd;
    // Kept deliberately to ONE compact line per client request — no
    // "starting from" wording and no separate minimum-seats note here;
    // the seat modal (openSeatModal) still states the minimum plainly
    // once the visitor actually clicks through.
    var priceHtml = price ? (' — '+price+(variant === 'team' ? ' '+esc(I18N.reg_per_seat_short) : '')) : '';
    var err = TRACK_UI_ERROR[tr.id+'|'+variant];
    return '<button type="button" class="'+cls+'" data-track="'+tr.id+'" data-variant="'+variant+'">'+esc(label)+priceHtml+'</button>'+
      (err ? '<div class="pild-reg-error">'+esc(err)+'</div>' : '');
  }

  // "سجل كشريك" CTA — replaces the normal register control entirely
  // whenever REG_MODE is 'partner_gate' (anyone, logged in or not,
  // currently on the Partners tab who isn't an approved partner yet).
  // No price, no individual/team choice — just the application link.
  function partnerApplyCtaHTML(extraClass){
    return '<a class="ad-btn ad-btn-solid'+(extraClass?(' '+extraClass):'')+'" href="'+esc(PARTNER_APPLY_URL)+'" target="_blank" rel="noopener">'+esc(I18N.reg_partner_cta)+'</a>';
  }
  // The actual "under review" lock (pendingLockHTML below) is triggered
  // server-side by a REAL Fluent Forms submission of the partnership
  // form (form ID 20 — see pild_ff_partnership_submitted() in
  // includes/35-purchase-category.php), matched by the submitter's
  // contact_email — not by clicking this link, since a click alone
  // doesn't mean the form was actually filled in and submitted.
  // Locked state for a pending Training-Partner application — replaces
  // any register control entirely (individual OR team), matching the
  // audience-toggle's own 'partner_pending' lock above.
  function pendingLockHTML(extraClass){
    return '<span class="ad-btn ad-btn-solid pe-reg-disabled'+(extraClass?(' '+extraClass):'')+'" title="'+esc(I18N.reg_pending_banner_body)+'">'+esc(I18N.reg_pending_chip)+'</span>';
  }

  // Single-button variant (grid preview cards / track-list cards) —
  // audience picked the same way regButtonHTML always has (REG_MODE,
  // falling back to whichever variant actually has a product).
  function trackRegButtonHTML(tr){
    if (REG_MODE === 'partner_pending') return pendingLockHTML('');
    if (REG_MODE === 'partner_gate') return partnerApplyCtaHTML('');
    // An approved partner always registers through the Team product —
    // their own per-seat price is applied automatically — never the
    // Individual option, regardless of which variant would otherwise
    // have been picked for a guest/individual/org.
    var variant = (REG_MODE === 'team' || REG_MODE === 'partner') ? 'team' : 'individual';
    var hasProduct = (variant === 'team') ? !!tr.regTeam : !!tr.regInd;
    if (!hasProduct && REG_MODE !== 'partner'){
      variant = (variant === 'team') ? 'individual' : 'team';
      hasProduct = (variant === 'team') ? !!tr.regTeam : !!tr.regInd;
    }
    if (!hasProduct){
      return '<span class="ad-btn ad-btn-solid pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.enroll_track_btn)+'</span>';
    }
    return trackRegAreaHTML(tr, variant, I18N.enroll_track_btn, 'ad-btn ad-btn-solid');
  }

  // Track detail page: two independent controls (Corporate / Individual).
  // Whichever one matches the visitor's REAL registration context
  // (REG_MODE — their actual role, or a guest's chosen audience tab) is
  // the emphasized/solid one; the other renders as the secondary/ghost
  // option, still fully clickable — not hidden, since a visitor can
  // always deliberately register the other way (e.g. an org buying an
  // individual seat for themselves too).
  //
  // An approved partner ('partner') never gets this dual choice at all —
  // just the one Team-priced button, since Individual registration isn't
  // a partner's actual relationship with PILD. 'partner_gate' replaces
  // both buttons with the "Apply as a Training Partner" CTA.
  function trackDualRegButtonsHTML(tr){
    if (REG_MODE === 'partner_pending') return '<div class="reg-dual-group">'+pendingLockHTML('reg-dual-btn')+'</div>';
    if (REG_MODE === 'partner_gate') return '<div class="reg-dual-group">'+partnerApplyCtaHTML('reg-dual-btn')+'</div>';
    if (REG_MODE === 'partner'){
      var soloHtml = tr.regTeam
        ? trackRegAreaHTML(tr, 'team', I18N.enroll_track_btn, 'ad-btn ad-btn-solid reg-dual-btn')
        : '<span class="ad-btn ad-btn-solid reg-dual-btn pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.enroll_track_btn)+'</span>';
      return '<div class="reg-dual-group">'+soloHtml+'</div>';
    }
    var teamCls = (REG_MODE === 'team') ? 'ad-btn ad-btn-solid reg-dual-btn' : 'ad-btn ad-btn-ghost reg-dual-btn';
    var indCls  = (REG_MODE === 'team') ? 'ad-btn ad-btn-ghost reg-dual-btn' : 'ad-btn ad-btn-solid reg-dual-btn';
    var orgHtml = tr.regTeam
      ? trackRegAreaHTML(tr, 'team', I18N.reg_org_btn, teamCls)
      : '<span class="'+teamCls+' pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.reg_org_btn)+'</span>';
    var indHtml = tr.regInd
      ? trackRegAreaHTML(tr, 'individual', I18N.reg_ind_btn, indCls)
      : '<span class="'+indCls+' pe-reg-disabled" title="'+esc(I18N.reg_unavailable)+'">'+esc(I18N.reg_ind_btn)+'</span>';
    return '<div class="reg-dual-group">'+orgHtml+indHtml+'</div>';
  }

  function bindTrackRegButtons(root){
    Array.prototype.forEach.call(root.querySelectorAll('.pild-reg-btn[data-track]'), function(btn){
      btn.addEventListener('click', function(){
        onRegisterClick(parseInt(btn.dataset.track,10), btn.dataset.variant);
      });
    });
    Array.prototype.forEach.call(root.querySelectorAll('.pild-reg-another'), function(btn){
      btn.addEventListener('click', function(){ showSectorsGrid(); });
    });
  }

  // Asked once per visit, not once per track — an org buyer adding several
  // tracks in a row shouldn't retype their details each time.
  var ORG_QUICK_REGISTERED = false;

  function onRegisterClick(trackId, variant){
    if (variant === 'team'){
      // Only for an explicit "Organizations" selection by someone with no
      // fixed role yet (client decision, includes/35-purchase-category.php)
      // — a real team owner/member already has an org profile on file, so
      // they skip straight to the seat prompt exactly as before.
      if (!HAS_FIXED_ROLE && !ORG_QUICK_REGISTERED){
        openOrgQuickRegModal(function(){ ORG_QUICK_REGISTERED = true; openSeatModal(trackId); });
        return;
      }
      openSeatModal(trackId);
      return;
    }
    doAddToCart(trackId, 'individual', 1);
  }

  // ---- Organization quick-registration modal (Sep 2026) ----------------
  function openOrgQuickRegModal(onDone){
    closeOrgQuickRegModal();
    var wrap = document.createElement('div');
    wrap.className = 'pild-modal-overlay';
    wrap.id = 'pildOrgRegModal';
    wrap.innerHTML =
      '<div class="pild-modal pild-org-modal" role="dialog" aria-modal="true">'+
        '<button class="pm-close" id="pildOrgRegClose" aria-label="'+esc(I18N.modal_close)+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>'+
        '<div class="pm-header"><div class="pm-header-accent"></div><div class="pm-title serif">'+esc(I18N.org_reg_title)+'</div></div>'+
        '<div class="pm-body">'+
          '<input type="text" id="pildOrgName" placeholder="'+esc(I18N.org_reg_name)+'" class="pild-seat-input">'+
          '<input type="text" id="pildOrgResponsible" placeholder="'+esc(I18N.org_reg_responsible)+'" class="pild-seat-input">'+
          '<input type="tel" id="pildOrgPhone" placeholder="'+esc(I18N.org_reg_phone)+'" class="pild-seat-input">'+
          '<input type="url" id="pildOrgWebsite" placeholder="'+esc(I18N.org_reg_website)+'" class="pild-seat-input">'+
          '<input type="text" id="pildOrgAddress" placeholder="'+esc(I18N.org_reg_address)+'" class="pild-seat-input">'+
          '<div class="pild-seat-note">'+esc(I18N.org_reg_note)+'</div>'+
          '<div class="pild-reg-error" id="pildOrgRegError" style="display:none;"></div>'+
          '<div class="pild-seat-actions">'+
            '<button type="button" class="ad-btn ad-btn-solid" id="pildOrgRegConfirm">'+esc(I18N.org_reg_confirm)+'</button>'+
            '<button type="button" class="ad-btn ad-btn-ghost" id="pildOrgRegCancel">'+esc(I18N.org_reg_cancel)+'</button>'+
          '</div>'+
        '</div>'+
      '</div>';
    (el('pild-app') || document.body).appendChild(wrap);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function(){ wrap.classList.add('open'); });
    wrap.addEventListener('click', function(e){ if (e.target === wrap) closeOrgQuickRegModal(); });
    el('pildOrgRegClose').addEventListener('click', closeOrgQuickRegModal);
    el('pildOrgRegCancel').addEventListener('click', closeOrgQuickRegModal);
    el('pildOrgRegConfirm').addEventListener('click', function(){
      var name        = el('pildOrgName').value.trim();
      var responsible = el('pildOrgResponsible').value.trim();
      var phone       = el('pildOrgPhone').value.trim();
      var website     = el('pildOrgWebsite').value.trim();
      var address      = el('pildOrgAddress').value.trim();
      var errBox = el('pildOrgRegError');
      if (!name || !responsible || !phone){
        errBox.textContent = I18N.org_reg_required;
        errBox.style.display = 'block';
        return;
      }
      errBox.style.display = 'none';
      var fd = new FormData();
      fd.append('action', 'pild_org_quick_register');
      fd.append('nonce', REG_NONCE);
      fd.append('org_name', name);
      fd.append('responsible', responsible);
      fd.append('phone', phone);
      if (website) fd.append('website', website);
      if (address) fd.append('address', address);
      fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
        .then(function(r){ return r.json(); })
        .then(function(res){
          if (res && res.success){
            closeOrgQuickRegModal();
            if (onDone) onDone();
          } else {
            errBox.textContent = (res && res.data && res.data.message) || I18N.reg_error_generic;
            errBox.style.display = 'block';
          }
        })
        .catch(function(){
          errBox.textContent = I18N.reg_error_generic;
          errBox.style.display = 'block';
        });
    });
    document.addEventListener('keydown', orgRegModalEscHandler);
  }
  function orgRegModalEscHandler(e){ if (e.key === 'Escape') closeOrgQuickRegModal(); }
  function closeOrgQuickRegModal(){
    var existing = document.getElementById('pildOrgRegModal');
    if (existing){
      existing.parentNode.removeChild(existing);
      document.body.style.overflow = '';
      document.removeEventListener('keydown', orgRegModalEscHandler);
    }
  }

  function doAddToCart(trackId, variant, seats){
    delete TRACK_UI_ERROR[trackId+'|'+variant];
    setTrackState(trackId, variant, 'busy');
    renderMain();

    var fd = new FormData();
    fd.append('action', 'pild_reg_add_to_cart');
    fd.append('nonce', REG_NONCE);
    fd.append('track_id', trackId);
    fd.append('variant', variant);
    if (seats) fd.append('seats', seats);

    fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(res){
        if (res && res.success && res.data){
          if (res.data.checkout_url) CART_CHECKOUT_URL = res.data.checkout_url;
          markInCart(trackId, variant, res.data.already_in_cart ? 'already' : 'added');
        } else {
          setTrackState(trackId, variant, 'idle');
          var data = (res && res.data) ? res.data : {};
          if (data.need_login){ window.location.href = LOGIN_URL; return; }
          TRACK_UI_ERROR[trackId+'|'+variant] = data.message || I18N.reg_error_generic;
        }
        renderMain();
      })
      .catch(function(){
        setTrackState(trackId, variant, 'idle');
        TRACK_UI_ERROR[trackId+'|'+variant] = I18N.reg_error_generic;
        renderMain();
      });
  }

  // ---- Seat-count prompt (Team/Partner registration) -------------------
  function openSeatModal(trackId){
    closeSeatModal();
    var tr = findTrackById(trackId);
    if (!tr) return;
    var min = 5; // server enforces the product's real minimum regardless
    var wrap = document.createElement('div');
    wrap.className = 'pild-modal-overlay';
    wrap.id = 'pildSeatModal';
    wrap.innerHTML =
      '<div class="pild-modal pild-seat-modal" role="dialog" aria-modal="true">'+
        '<button class="pm-close" id="pildSeatModalClose" aria-label="'+esc(I18N.modal_close)+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>'+
        '<div class="pm-header"><div class="pm-header-accent"></div><div class="pm-title serif">'+esc(I18N.reg_seats_title)+'</div></div>'+
        '<div class="pm-body">'+
          '<div class="pild-seat-track-name">'+esc(tr.title)+'</div>'+
          '<input type="number" id="pildSeatInput" min="'+min+'" step="1" value="'+min+'" class="pild-seat-input">'+
          '<div class="pild-seat-note">'+fmt(I18N.reg_seats_note, min)+'</div>'+
          '<div class="pild-seat-actions">'+
            '<button type="button" class="ad-btn ad-btn-solid" id="pildSeatConfirm">'+esc(I18N.reg_seats_confirm)+'</button>'+
            '<button type="button" class="ad-btn ad-btn-ghost" id="pildSeatCancel">'+esc(I18N.reg_seats_cancel)+'</button>'+
          '</div>'+
        '</div>'+
      '</div>';
    (el('pild-app') || document.body).appendChild(wrap);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function(){ wrap.classList.add('open'); });
    wrap.addEventListener('click', function(e){ if (e.target === wrap) closeSeatModal(); });
    el('pildSeatModalClose').addEventListener('click', closeSeatModal);
    el('pildSeatCancel').addEventListener('click', closeSeatModal);
    el('pildSeatConfirm').addEventListener('click', function(){
      var seats = parseInt(el('pildSeatInput').value, 10);
      if (!seats || seats < min) seats = min;
      closeSeatModal();
      doAddToCart(trackId, 'team', seats);
    });
    document.addEventListener('keydown', seatModalEscHandler);
  }
  function seatModalEscHandler(e){ if (e.key === 'Escape') closeSeatModal(); }
  function closeSeatModal(){
    var existing = document.getElementById('pildSeatModal');
    if (existing){
      existing.parentNode.removeChild(existing);
      document.body.style.overflow = '';
      document.removeEventListener('keydown', seatModalEscHandler);
    }
  }

  // Domain/area page: two toggle chips (اشتراك مؤسسي / اشتراك أفراد) that
  // replace the old text-link. Exactly one is ever "active" (REG_MODE),
  // and clicking the other one re-resolves EVERY "سجّل في التراك" button
  // on the page (each track card) to that audience's product — same
  // switchRegContext()+renderMain() flow the old link used, just a
  // different presentation. Hidden for logged-in visitors, same rule the
  // old link followed (their context is fixed by their real account).
  function audienceToggleHTML(idPrefix){
    // An approved partner: no toggle, just a static label confirming
    // which "mode" they're in (per client request) — never clickable,
    // since there's nothing to switch to.
    if (REG_MODE === 'partner'){
      return '<div class="audience-toggle" id="'+idPrefix+'AudienceToggle"><span class="audience-chip active">'+esc(I18N.reg_partner_chip)+'</span></div>';
    }
    // Pending Training-Partner application: no toggle, no buttons anywhere
    // — a static "under review" state (see trackRegButtonHTML /
    // dualRegButtonsHTML for the matching lock on the actual buttons).
    if (REG_MODE === 'partner_pending'){
      return '<div class="audience-toggle" id="'+idPrefix+'AudienceToggle"><span class="audience-chip active">'+esc(I18N.reg_pending_chip)+'</span></div>';
    }
    // Partners tab, not-yet-a-partner: no toggle at all — the "Apply as
    // a Training Partner" CTA (trackRegButtonHTML/trackDualRegButtonsHTML)
    // already makes the state clear on its own.
    if (REG_MODE === 'partner_gate') return '';
    if(HAS_FIXED_ROLE || !REG_SWITCHABLE) return '';
    var orgActive = REG_MODE === 'team';
    var tcActive  = REG_MODE === 'partner_gate';
    return '<div class="audience-toggle" id="'+idPrefix+'AudienceToggle">'+
      '<button type="button" class="audience-chip'+(orgActive?' active':'')+'" data-mode="team">'+esc(I18N.audience_org_chip)+'</button>'+
      '<button type="button" class="audience-chip'+(!orgActive&&!tcActive?' active':'')+'" data-mode="individual">'+esc(I18N.audience_ind_chip)+'</button>'+
      '<button type="button" class="audience-chip'+(tcActive?' active':'')+'" data-mode="partner">'+esc(I18N.audience_tc_chip)+'</button>'+
    '</div>';
  }
  function bindAudienceToggle(idPrefix){
    var box = el(idPrefix+'AudienceToggle');
    if(!box) return;
    Array.prototype.forEach.call(box.querySelectorAll('[data-mode]'), function(btn){
      btn.addEventListener('click', function(){
        var mode = btn.dataset.mode;
        if((mode === 'partner' ? 'partner_gate' : mode) === REG_MODE) return;
        switchRegContext(mode);
      });
    });
  }

  function fetchRegContext(){
    var fd = new FormData();
    fd.append('action', 'pild_reg_get_context');
    fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(res){
        if(res && res.success && res.data){
          REG_MODE = res.data.mode;
          REG_SWITCHABLE = !!res.data.switchable;
          if (res.data.checkout_url) CART_CHECKOUT_URL = res.data.checkout_url;
          if (res.data.partner_apply_url) PARTNER_APPLY_URL = res.data.partner_apply_url;
          if (res.data.cart_tracks && res.data.cart_tracks.length){
            res.data.cart_tracks.forEach(function(row){
              if (row && row.track_id && row.variant) markInCart(row.track_id, row.variant, 'added');
            });
          }
          renderMain(); // refresh whichever view is on screen with the real links
        }
      })
      .catch(function(){ /* keep the safe 'individual' default on failure */ });
  }

  function switchRegContext(newMode){
    var ctx = (newMode === 'team') ? 'organizations' : (newMode === 'partner' ? 'partners' : 'individuals');
    var fd = new FormData();
    fd.append('action', 'pild_reg_set_context');
    fd.append('nonce', REG_NONCE);
    fd.append('context', ctx);
    fetch(AJAX_URL, {method:'POST', body:fd, credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(res){
        if(res && res.success && res.data){
          REG_MODE = res.data.mode;
          REG_SWITCHABLE = !!res.data.switchable;
        } else {
          REG_MODE = (newMode === 'partner') ? 'partner_gate' : newMode;
        }
        renderMain();
      })
      .catch(function(){ REG_MODE = (newMode === 'partner') ? 'partner_gate' : newMode; renderMain(); });
  }

  var ICONS=['⭐','📊','💬','🖥️','🛡️','👥','📋','📈','✅','📐','🏛️','❤️','📦','🔒','📡','🌱','💰','⚙️','🗄️','💡','🎭','📚','🧭','🎯'];
  var PAL=[
    {bg:'#FEF3C7',icon:'#92400E',bar:'#F59E0B',grad:'#D97706,#F59E0B'},
    {bg:'#CCFBF1',icon:'#0F5132',bar:'#0D9488',grad:'#0D9488,#14B8A6'},
    {bg:'#DBEAFE',icon:'#1E3A5F',bar:'#3B82F6',grad:'#2563EB,#3B82F6'},
    {bg:'#EDE9FE',icon:'#4C1D95',bar:'#7C3AED',grad:'#6D28D9,#7C3AED'},
    {bg:'#CFFAFE',icon:'#164E63',bar:'#0891B2',grad:'#0891B2,#06B6D4'},
    {bg:'#FFEDD5',icon:'#7C2D12',bar:'#EA580C',grad:'#C2410C,#EA580C'},
    {bg:'#FFE4E6',icon:'#881337',bar:'#F43F5E',grad:'#BE123C,#F43F5E'},
    {bg:'#DCFCE7',icon:'#14532D',bar:'#16A34A',grad:'#15803D,#22C55E'},
    {bg:'#E0E7FF',icon:'#312E81',bar:'#4F46E5',grad:'#4338CA,#6366F1'},
    {bg:'#F3E8FF',icon:'#581C87',bar:'#9333EA',grad:'#7E22CE,#A855F7'},
    {bg:'#ECFCCB',icon:'#365314',bar:'#65A30D',grad:'#4D7C0F,#84CC16'},
    {bg:'#FEF9EC',icon:'#7C5200',bar:'#CA8A04',grad:'#B45309,#CA8A04'},
  ];
  function icon(i){ return ICONS[i % ICONS.length]; }
  function pal(i){ return PAL[i % PAL.length]; }
  function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}
  function fmt(str){ var args=Array.prototype.slice.call(arguments,1); return str.replace(/%(\d)\$[ds]|%[ds]/g, function(m,idx){ return idx ? args[idx-1] : args.shift(); }); }
  var uidSeq=0; function uid(){ uidSeq++; return 'pe-u'+uidSeq; }
  function el(id){return document.getElementById(id);}

  var activeSector=null, activeDomain=null, activeTrack=null, searchQ='', view='domains';

  function buildHeroMosaic(){
    var all=[]; DATA.forEach(function(s){ s.domains.forEach(function(d){ all.push({s:s,d:d}); }); });
    var m = el('peHeroMosaic');
    if(!all.length){ m.outerHTML='<div class="hero-empty">'+I18N.no_sectors+'</div>'; return; }
    m.innerHTML = all.slice(0,9).map(function(x,i){
      return '<div class="hm-card" data-sector="'+x.s.id+'" data-domain="'+x.d.id+'"><div class="hm-icon">'+icon(i)+'</div><div class="hm-name">'+esc(x.d.title)+'</div></div>';
    }).join('');
    Array.prototype.forEach.call(m.querySelectorAll('.hm-card'), function(c){
      c.addEventListener('click', function(){
        var sIdx = DATA.findIndex(function(s){return s.id===parseInt(c.dataset.sector,10);});
        if(sIdx<0) return;
        enterSector(sIdx);
        var d = activeSector.domains.filter(function(x){return x.id===parseInt(c.dataset.domain,10);})[0];
        if(d) selectDomain(d.id);
      });
    });
  }

  function enterSector(i){
    activeSector = DATA[i];
    activeDomain=null; activeTrack=null; view='domains'; searchQ=''; el('peSearch').value='';
    el('peHero').style.display='none';
    el('peLayout').style.display='grid';
    el('peSswName').textContent = activeSector.title;
    renderSidebar(); renderMain();
    el('peLayout').scrollIntoView({behavior:'smooth'});
  }

  function showSectorsGrid(){
    activeSector=null; activeDomain=null; activeTrack=null; view='sectors'; searchQ=''; el('peSearch').value='';
    el('peHero').style.display='none';
    el('peLayout').style.display='grid';
    el('peSswName').textContent = 'PILD';
    renderSidebar(); renderMain();
  }

  el('peHeroExplore').addEventListener('click', function(){
    showSectorsGrid();
  });
  el('peSectorSwitch').addEventListener('click', function(){
    el('peHero').style.display='flex';
    el('peLayout').style.display='none';
    activeSector=null;
    window.scrollTo({top:0,behavior:'smooth'});
  });
  el('peSearch').addEventListener('input', function(){
    searchQ = this.value.trim().toLowerCase();
    activeDomain=null; activeTrack=null; view='domains';
    renderSidebar(); renderMain();
  });

  function filteredDomains(){
    if(!activeSector) return [];
    return activeSector.domains.filter(function(d){ return !searchQ || d.title.toLowerCase().indexOf(searchQ)>-1; });
  }

  function renderSidebar(){
    var list = el('peSbList');

    if(!activeSector){
      if(!DATA.length){ list.innerHTML='<div style="padding:24px 12px;text-align:center;font-size:12px;color:var(--ink3);">'+I18N.no_sectors+'</div>'; return; }
      list.innerHTML = '<div class="sb-cat-label">'+esc(I18N.all_sectors)+'</div>' + DATA.map(function(s,si){
        return '<button class="sb-item" data-sector-idx="'+si+'"><span class="sb-item-icon">'+icon(si)+'</span><span class="sb-item-name">'+esc(s.title)+'</span><span class="sb-item-cnt">'+s.domains.length+'</span></button>';
      }).join('');
      Array.prototype.forEach.call(list.querySelectorAll('.sb-item'), function(b){
        b.addEventListener('click', function(){ enterSector(parseInt(b.dataset.sectorIdx,10)); });
      });
      return;
    }

    var domains = filteredDomains();
    var backBtn = '<button class="sb-item" id="peSbAllSectors"><span class="sb-item-icon">↩</span><span class="sb-item-name">'+esc(I18N.all_sectors)+'</span></button>';
    if(!domains.length){
      list.innerHTML = backBtn + '<div class="sb-cat-label">'+esc(activeSector.title)+'</div><div style="padding:24px 12px;text-align:center;font-size:12px;color:var(--ink3);">'+I18N.no_results+'</div>';
      el('peSbAllSectors').addEventListener('click', showSectorsGrid);
      return;
    }
    list.innerHTML = backBtn + '<div class="sb-cat-label">'+esc(activeSector.title)+'</div>' + domains.map(function(d){
      var gi = activeSector.domains.indexOf(d);
      var isActive = activeDomain && activeDomain.id===d.id;
      return '<button class="sb-item'+(isActive?' active':'')+'" data-id="'+d.id+'"><span class="sb-item-icon">'+icon(gi)+'</span><span class="sb-item-name">'+esc(d.title)+'</span><span class="sb-item-cnt">'+d.tracks.length+'</span></button>';
    }).join('');
    el('peSbAllSectors').addEventListener('click', showSectorsGrid);
    Array.prototype.forEach.call(list.querySelectorAll('.sb-item[data-id]'), function(b){
      b.addEventListener('click', function(){ selectDomain(parseInt(b.dataset.id,10)); });
    });
  }

  function selectDomain(id){
    activeDomain = activeSector.domains.filter(function(d){return d.id===id;})[0];
    activeTrack=null; view='domain';
    renderSidebar(); renderMain();
    el('peLayout').scrollIntoView({behavior:'smooth'});
  }
  function clearDomain(){ activeDomain=null; activeTrack=null; view='domains'; renderSidebar(); renderMain(); }
  function openTrack(domainId, trackId){
    var d = activeSector.domains.filter(function(x){return x.id===domainId;})[0];
    if(!d) return;
    var tr = d.tracks.filter(function(x){return x.id===trackId;})[0];
    if(!tr) return;
    activeDomain=d; activeTrack=tr; view='track';
    renderSidebar(); renderMain();
    el('peLayout').scrollIntoView({behavior:'smooth'});
  }

  function renderMain(){
    var m = el('peMain');
    if(view==='track' && activeTrack){ renderTrackPage(m); return; }
    if(view==='domain' && activeDomain){ renderAreaDetail(m); return; }
    if(view==='domains' && activeSector){ renderAreasGrid(m); return; }
    renderSectorsGrid(m);
  }

  // Labeled breadcrumb: كل القطاعات › القطاع/Sector › المجال/Practice Area › التراك/Track
  function crumbHTML(depth){
    var parts=[];
    parts.push({label:'', val:I18N.all_sectors, clickable:true});
    parts.push({label:I18N.crumb_sector, val:activeSector.title, clickable:depth>1});
    if(depth>=2 && activeDomain) parts.push({label:I18N.crumb_domain, val:activeDomain.title, clickable:depth>2});
    if(depth>=3 && activeTrack) parts.push({label:I18N.crumb_track, val:activeTrack.title, clickable:false});
    return '<nav class="breadcrumb">'+parts.map(function(p,idx){
      return (idx>0?'<span class="crumb-sep">›</span>':'')+
        '<span class="crumb'+(p.clickable?'':' static')+'" data-idx="'+idx+'">'+
          (p.label ? '<span class="crumb-label">'+esc(p.label)+' /</span> ' : '')+
          '<span class="crumb-val">'+esc(p.val)+'</span>'+
        '</span>';
    }).join('')+'</nav>';
  }
  function bindCrumbs(root, depth){
    var crumbs = root.querySelectorAll('.crumb:not(.static)');
    Array.prototype.forEach.call(crumbs, function(c){
      var idx = parseInt(c.dataset.idx,10);
      c.addEventListener('click', function(){
        if(idx===0) showSectorsGrid();
        else if(idx===1) clearDomain();
        else if(idx===2) selectDomain(activeDomain.id);
      });
    });
  }

  // ---- Level 0: sector picker ----------------------------------------
  function renderSectorsGrid(m){
    if(!DATA.length){
      m.innerHTML = '<div class="areas-section"><div class="empty"><div class="empty-icon">🗂️</div><h3>'+I18N.no_sectors+'</h3></div></div>';
      return;
    }
    m.innerHTML = '<div class="areas-section">'+
      '<div class="section-label">'+esc(I18N.org_name)+'</div>'+
      '<div class="section-title serif">'+esc(I18N.choose_sector_title)+'</div>'+
      '<div class="section-desc">'+esc(I18N.choose_sector_desc)+'</div>'+
      '<div class="areas-grid" id="peSectorsGrid"></div>'+
    '</div>';
    var grid = el('peSectorsGrid');
    grid.innerHTML = DATA.map(function(s,si){ return sectorCardHTML(s,si); }).join('');
    Array.prototype.forEach.call(grid.querySelectorAll('.sector-card'), function(card){
      var idx = parseInt(card.dataset.idx,10);
      card.addEventListener('click', function(){ enterSector(idx); });
    });
  }

  function sectorCardHTML(s, si){
    var p = pal(si);
    var domCount = s.domains.length;
    var hasSubsectors = s.subsectors && s.subsectors.length;
    var listSource = hasSubsectors ? s.subsectors : s.domains.map(function(d){ return d.title; });
    // Descriptive names only (sub-sectors) — no track-count column, since
    // sub-sectors aren't clickable/linked posts, just informational text.
    // Falls back to domain names (old behavior) only until the sector's
    // "Sub-sectors" ACF field is filled in — see pild_ex_add_subsectors_field.
    var preview = listSource.slice(0,4);
    var rest = listSource.length - 4;
    var domRows = preview.map(function(name){
      return '<div class="ac-track-row"><div class="ac-track-dot" style="background:'+p.bar+';"></div><span class="ac-track-name">'+esc(name)+'</span></div>';
    }).join('');
    var moreRow = rest > 0 ? '<div class="ac-track-row ac-track-more">+'+rest+'</div>' : '';
    return '<div class="area-card sector-card" data-idx="'+si+'">'+
      '<div class="ac-top">'+
        '<div class="ac-accent" style="background:linear-gradient(90deg,'+p.grad+');"></div>'+
        '<div class="ac-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(si)+'</div>'+
        '<div class="ac-info"><div class="ac-name">'+esc(s.title)+'</div><div class="ac-sub">'+esc(s.desc)+'</div></div>'+
        '<div class="ac-badge">'+domCount+' '+I18N.stat_domains+'</div>'+
      '</div>'+
      (listSource.length ? '<div class="ac-tracks-preview">'+domRows+moreRow+'</div>' : '<div class="ac-tracks-preview" style="padding:10px 16px;color:var(--ink3);font-size:11px;">'+I18N.no_tracks+'</div>')+
    '</div>';
  }

  // ---- Level 1: sector banner + practice-area grid --------------------
  function sectorBannerHTML(){
    var gi = DATA.indexOf(activeSector); var p = pal(gi);
    var hasSubsectors = activeSector.subsectors && activeSector.subsectors.length;
    var names = hasSubsectors ? activeSector.subsectors : activeSector.domains.map(function(d){ return d.title; });
    var label = hasSubsectors ? I18N.subsectors_label : I18N.subsectors_label_fallback;
    // One name per line (not comma-joined) per client request.
    var namesHTML = names.length ? '<ul class="sbnr-sub-list">'+names.map(function(n){ return '<li>'+esc(n)+'</li>'; }).join('')+'</ul>' : '';
    return '<div class="sector-banner">'+
      '<div class="sbnr-accent" style="background:linear-gradient(90deg,'+p.grad+');"></div>'+
      '<div class="sbnr-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(gi)+'</div>'+
      '<div class="sbnr-body">'+
        '<div class="sbnr-eyebrow">'+esc(I18N.crumb_sector)+'</div>'+
        '<div class="sbnr-title serif">'+esc(activeSector.title)+'</div>'+
        (activeSector.desc ? '<div class="sbnr-desc">'+esc(activeSector.desc)+'</div>' : '')+
        (namesHTML ? '<div class="sbnr-sub"><span class="sbnr-sub-label">'+esc(label)+'</span>'+namesHTML+'</div>' : '')+
      '</div>'+
    '</div>';
  }

  function renderAreasGrid(m){
    var domains = filteredDomains();
    var crumb = crumbHTML(1);
    var banner = sectorBannerHTML();
    if(!domains.length){
      m.innerHTML = '<div class="areas-section">'+crumb+banner+'<div class="empty"><div class="empty-icon">🔍</div><h3>'+I18N.no_results+'</h3></div></div>';
      bindCrumbs(m,1); return;
    }
    m.innerHTML = '<div class="areas-section">'+crumb+banner+
      '<div class="section-label">'+esc(activeSector.title)+'</div>'+
      '<div class="section-title serif">'+domains.length+' '+I18N.section_title+'</div>'+
      '<div class="section-desc">'+I18N.section_desc+'</div>'+
      '<div class="areas-grid" id="peAreasGrid"></div>'+
    '</div>';
    bindCrumbs(m,1);
    var grid = el('peAreasGrid');
    grid.innerHTML = domains.map(function(d){ return areaCardHTML(d); }).join('');
    Array.prototype.forEach.call(grid.querySelectorAll('.area-card'), function(card){
      var id = parseInt(card.dataset.id,10);
      card.querySelector('.ac-top').addEventListener('click', function(){ selectDomain(id); });
      var expandBtn = card.querySelector('.ac-expand-btn');
      expandBtn.addEventListener('click', function(e){ e.stopPropagation(); toggleExpand(id); });
      var gotoBtn = card.querySelector('.ac-goto-btn');
      if(gotoBtn) gotoBtn.addEventListener('click', function(e){ e.stopPropagation(); selectDomain(id); });
      Array.prototype.forEach.call(card.querySelectorAll('[data-open-track]'), function(chip){
        chip.addEventListener('click', function(e){ e.stopPropagation(); openTrack(id, parseInt(chip.dataset.openTrack,10)); });
      });
    });
  }

  function areaCardHTML(d){
    var gi = activeSector.domains.indexOf(d); var p = pal(gi);
    var preview = d.tracks.slice(0,4);
    var rest = d.tracks.length - 4;
    var trackRows = preview.map(function(tr){
      return '<div class="ac-track-row"><div class="ac-track-dot" style="background:'+p.bar+';"></div><span class="ac-track-name">'+esc(tr.title)+'</span><span class="ac-track-progs">'+tr.programs.length+' '+I18N.programs_suffix+'</span></div>';
    }).join('');
    var allChips = d.tracks.map(function(tr,i){
      return '<div class="track-chip" data-open-track="'+tr.id+'"><div class="track-chip-left"><span class="track-chip-n">'+(i+1)+'</span><span class="track-chip-name">'+esc(tr.title)+'</span></div><span class="track-chip-arrow">'+(IS_RTL?'‹':'›')+'</span></div>';
    }).join('');
    // Single "Register" button per grid card (per spec — never more than
    // one), only shown when this Practice Area actually has a product of
    // its own configured (i.e. it's sold as a whole bundle).
    var regHrefNow = regHref(d.regInd, d.regTeam);
    var regRow = regHrefNow ? '<div class="ac-reg-row">'+regButtonHTML(d.regInd, d.regTeam, I18N.register_btn, 'ac-reg-btn')+'</div>' : '';
    return '<div class="area-card" data-id="'+d.id+'">'+
      '<div class="ac-top">'+
        '<div class="ac-accent" style="background:linear-gradient(90deg,'+p.grad+');"></div>'+
        '<div class="ac-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(gi)+'</div>'+
        '<div class="ac-info"><div class="ac-name">'+esc(d.title)+'</div><div class="ac-sub">'+esc(d.desc)+'</div></div>'+
        '<div class="ac-badge">'+d.tracks.length+' '+I18N.tracks_suffix+'</div>'+
      '</div>'+
      regRow+
      (d.tracks.length ? '<div class="ac-tracks-preview">'+trackRows+'</div>' : '')+
      (d.tracks.length ? (
        '<button class="ac-expand-btn" id="expand-btn-'+d.id+'"><span id="expand-txt-'+d.id+'">'+(rest>0 ? '+'+rest+' '+I18N.more_tracks : I18N.expand_all)+'</span>'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>'+
        '</button>'+
        '<div class="ac-tracks-panel" id="tracks-panel-'+d.id+'"><div class="ac-tracks-panel-inner">'+allChips+'</div>'+
          '<button class="ac-goto-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>'+I18N.open_full_area+'</button>'+
        '</div>'
      ) : '<div class="ac-tracks-preview" style="padding:10px 16px;color:var(--ink3);font-size:11px;">'+I18N.no_tracks+'</div>')+
    '</div>';
  }

  function toggleExpand(id){
    var panel = el('tracks-panel-'+id);
    var btn = el('expand-btn-'+id);
    var txt = el('expand-txt-'+id);
    var isOpen = panel.classList.contains('open');
    panel.classList.toggle('open', !isOpen);
    btn.classList.toggle('open', !isOpen);
    if(!isOpen){ txt.textContent = I18N.hide_tracks; }
    else {
      var d = activeSector.domains.filter(function(x){return x.id===id;})[0];
      var rest = d.tracks.length-4;
      txt.textContent = rest>0 ? '+'+rest+' '+I18N.more_tracks : I18N.expand_all;
    }
  }

  function renderAreaDetail(m){
    var d = activeDomain; var gi = activeSector.domains.indexOf(d); var p = pal(gi);
    var crumb = crumbHTML(2);
    var progTotal = 0; d.tracks.forEach(function(tr){ progTotal += tr.programs.length; });
    var compTotal = 0; d.tracks.forEach(function(tr){ tr.programs.forEach(function(pr){ compTotal += pr.competencies.length; }); });

    var tracksGrid = d.tracks.length ? ('<div class="detail-tracks-grid">'+d.tracks.map(function(tr,i){
      var progNames = tr.programs.slice(0,3).map(function(pr){ return '<div class="dtc-prog-item">'+esc(pr.title)+'</div>'; }).join('');
      var progMore = tr.programs.length>3 ? '<div class="dtc-prog-more">+'+(tr.programs.length-3)+' '+I18N.programs_suffix+'</div>' : '';
      return '<div class="detail-track-card">'+
        '<div class="dtc-bar-top" style="background:'+p.bar+';"></div>'+
        '<div class="dtc-n">'+fmt(I18N.track_n_of,(i+1),d.tracks.length)+'</div>'+
        '<div class="dtc-name" data-open-track="'+tr.id+'">'+esc(tr.title)+'</div>'+
        (tr.programs.length ? '<div class="dtc-progs"><div class="dtc-progs-label">'+I18N.track_programs_preview+'</div>'+progNames+progMore+'</div>' : '')+
        '<div class="dtc-actions">'+
          trackRegButtonHTML(tr)+
          '<button class="ad-btn ad-btn-ghost" data-open-track="'+tr.id+'">'+I18N.more_details_btn+'</button>'+
        '</div>'+
      '</div>';
    }).join('')+'</div>') : ('<div class="empty"><div class="empty-icon">📂</div><h3>'+I18N.no_tracks+'</h3></div>');

    var certHTML;
    if(d.quizId){
      if(d.certProgress && d.certProgress.complete){
        certHTML = '<div class="cert-banner"><div class="cert-banner-grid"></div><div class="cert-banner-inner">'+
          '<div class="cert-badge-icon">🎓</div><div class="cert-body">'+
          '<div class="cert-eyebrow">'+I18N.area_milestone+'<span class="cert-eyebrow-line"></span></div>'+
          '<div class="cert-title serif">'+fmt(I18N.area_cert_title, d.tracks.length, '<em>'+esc(d.title)+'</em>')+'</div>'+
          '<div class="cert-desc">'+fmt(I18N.area_cert_desc, esc(d.title))+'</div>'+
          '<div class="cert-steps">'+
            '<div class="cert-step"><span class="cert-step-n">✓</span>'+d.tracks.length+' '+I18N.step_tracks+'</div><span class="cert-step-arrow">→</span>'+
            '<div class="cert-step is-cert"><span class="cert-step-n">🏆</span>'+I18N.cert_step+'</div>'+
          '</div></div>'+
          '<a class="cert-cta" data-domain-quiz="'+d.id+'">'+I18N.start_exam_btn+'</a>'+
        '</div></div>';
      } else {
        var cp = d.certProgress || {total:d.tracks.length, certified:0};
        certHTML = '<div class="cert-banner"><div class="cert-banner-grid"></div><div class="cert-banner-inner">'+
          '<div class="cert-badge-icon">🎓</div><div class="cert-body">'+
          '<div class="cert-eyebrow">'+I18N.area_milestone+'<span class="cert-eyebrow-line"></span></div>'+
          '<div class="cert-title serif">'+fmt(I18N.area_cert_title, d.tracks.length, '<em>'+esc(d.title)+'</em>')+'</div>'+
          '<div class="cert-desc">'+fmt(I18N.area_cert_desc, esc(d.title))+'</div>'+
          '<div class="cert-locked-note">🔒 '+cp.certified+'/'+cp.total+' '+I18N.step_tracks+' '+I18N.step_locked+'</div>'+
          '</div></div></div>';
      }
    } else {
      certHTML = '<div class="cert-banner"><div class="cert-banner-grid"></div><div class="cert-banner-inner">'+
        '<div class="cert-badge-icon">🎓</div><div class="cert-body">'+
        '<div class="cert-eyebrow">'+I18N.area_milestone+'<span class="cert-eyebrow-line"></span></div>'+
        '<div class="cert-desc">'+I18N.area_cert_no_quiz+'</div>'+
        '</div></div></div>';
    }

    m.innerHTML = '<div class="area-detail">'+
      '<button class="back-btn" id="peBackDomains"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="'+(IS_RTL?'M5 12h14M12 5l7 7-7 7':'M19 12H5M12 19l-7-7 7-7')+'"/></svg>'+I18N.all_areas+'</button>'+
      crumb+
      '<div class="ad-header">'+
        '<div class="ad-header-accent" style="background:linear-gradient(90deg,'+p.grad+');"></div>'+
        '<div class="ad-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(gi)+'</div>'+
        '<div class="ad-body">'+
          '<div class="ad-eyebrow">'+I18N.practice_area+'</div>'+
          '<div class="ad-title serif">'+esc(d.title)+'</div>'+
          '<div class="ad-desc">'+esc(d.desc)+'</div>'+
          '<div class="ad-stats">'+
            '<div><div class="ads-num">'+d.tracks.length+'</div><div class="ads-lbl">'+I18N.tracks_suffix+'</div></div>'+
            '<div><div class="ads-num">'+progTotal+'</div><div class="ads-lbl">'+I18N.programs_suffix+'</div></div>'+
            '<div><div class="ads-num">'+compTotal+'</div><div class="ads-lbl">'+I18N.competencies_suffix+'</div></div>'+
            '<div class="ad-cta-row">'+
              // "صفحة المجال" (visit_area_page) and "سجّل في المجال —
              // احصل على كل تراكاته" (enroll_domain_btn) buttons removed
              // from the domain banner per client request — registration
              // still happens from each individual track card below.
              audienceToggleHTML('peDomain')+
            '</div>'+
          '</div>'+
        '</div>'+
      '</div>'+
      tracksGrid+
      certHTML+
    '</div>';

    bindCrumbs(m,2);
    el('peBackDomains').addEventListener('click', clearDomain);
    Array.prototype.forEach.call(m.querySelectorAll('[data-open-track]'), function(node){
      node.addEventListener('click', function(){ openTrack(d.id, parseInt(node.dataset.openTrack,10)); });
    });
    bindTrackRegButtons(m);
    bindAudienceToggle('peDomain');
    var domainQuizA = m.querySelector('[data-domain-quiz]');
    if(domainQuizA){ domainQuizA.addEventListener('click', function(e){ e.preventDefault(); domainQuizA.closest('.cert-banner').scrollIntoView({behavior:'smooth'}); }); }
  }

  function renderTrackPage(m){
    var d = activeDomain, tr = activeTrack;
    var gi = activeSector.domains.indexOf(d); var p = pal(gi);
    var crumb = crumbHTML(3);

    var progHTML;
    if(tr.programs && tr.programs.length){
      progHTML = '<div class="programs-grid">'+tr.programs.map(function(prog,pi){
        var compChips = (prog.competencies||[]).map(function(c){
          return '<span class="pgc-comp-chip">'+esc(c.title)+'</span>';
        }).join('');
        var compBlock = (prog.competencies && prog.competencies.length)
          ? '<div class="pgc-comp-block"><div class="pgc-comp-label">'+esc(I18N.competencies_tab)+'</div><div class="pgc-comp-chips">'+compChips+'</div></div>'
          : '';
        return '<div class="program-card">'+
          '<div class="pgc-accent" style="background:'+p.bar+';"></div>'+
          '<div class="pgc-top">'+
            '<div class="pgc-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(pi)+'</div>'+
            '<div class="pgc-info">'+
              '<div class="pgc-num">'+I18N.track_programs+' '+(pi+1)+'</div>'+
              '<div class="pgc-name">'+esc(prog.title)+'</div>'+
            '</div>'+
          '</div>'+
          (prog.excerpt ? '<div class="pgc-desc">'+esc(prog.excerpt)+'</div>' : '')+
          compBlock+
          '<div class="pgc-actions">'+
            '<button class="pgc-details-btn" data-open-program="'+prog.id+'">'+
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg>'+
              esc(I18N.program_details_btn)+
            '</button>'+
          '</div>'+
        '</div>';
      }).join('')+'</div>';
    } else {
      progHTML = '<div class="empty"><div class="empty-icon">📚</div><h3>'+I18N.no_programs+'</h3></div>';
    }

    var certHTML;
    if(tr.quizId){
      certHTML = '<div class="cert-banner"><div class="cert-banner-grid"></div><div class="cert-banner-inner">'+
        '<div class="cert-badge-icon">📝</div><div class="cert-body">'+
        '<div class="cert-eyebrow">'+I18N.track_milestone+'<span class="cert-eyebrow-line"></span></div>'+
        '<div class="cert-title serif">'+fmt(I18N.track_cert_title, '<em>'+esc(tr.title)+'</em>')+'</div>'+
        '<div class="cert-desc">'+fmt(I18N.track_cert_desc, esc(tr.title))+'</div>'+
        '<div class="cert-steps">'+
          '<div class="cert-step"><span class="cert-step-n">✓</span>'+(tr.programs?tr.programs.length:0)+' '+I18N.step_programs+'</div><span class="cert-step-arrow">→</span>'+
          '<div class="cert-step"><span class="cert-step-n">✓</span>'+I18N.step_track_assess+'</div><span class="cert-step-arrow">→</span>'+
          '<div class="cert-step is-cert"><span class="cert-step-n">🏆</span>'+I18N.cert_step+'</div>'+
        '</div></div>'+
      '</div></div>';
    } else {
      certHTML = '<div class="cert-banner"><div class="cert-banner-grid"></div><div class="cert-banner-inner">'+
        '<div class="cert-badge-icon">📝</div><div class="cert-body">'+
        '<div class="cert-eyebrow">'+I18N.track_milestone+'<span class="cert-eyebrow-line"></span></div>'+
        '<div class="cert-desc">'+I18N.track_cert_no_quiz+'</div>'+
        '</div></div></div>';
    }

    m.innerHTML = '<div class="track-page">'+
      '<button class="back-btn" id="peBackTrack"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="'+(IS_RTL?'M5 12h14M12 5l7 7-7 7':'M19 12H5M12 19l-7-7 7-7')+'"/></svg>'+esc(d.title)+'</button>'+
      crumb+
      '<div class="track-header">'+
        '<div class="th-accent" style="background:linear-gradient(90deg,'+p.grad+');"></div>'+
        '<div class="th-top">'+
          '<div class="th-icon" style="background:'+p.bg+';color:'+p.icon+';">'+icon(gi)+'</div>'+
          '<div class="th-meta"><div class="th-area">'+esc(d.title)+' — '+fmt(I18N.track_n_of, d.tracks.indexOf(tr)+1, d.tracks.length)+'</div>'+
          '<div class="th-name serif">'+esc(tr.title)+'</div>'+
          (tr.desc?'<div class="th-desc">'+esc(tr.desc)+'</div>':'')+
          '</div>'+
        '</div>'+
        '<div class="track-toolbar track-toolbar--reg">'+
          '<span class="tf-pill active">'+I18N.enroll_track_btn+'</span>'+
          trackDualRegButtonsHTML(tr)+
          // "كل البرامج" (all_programs) pill and "صفحة التراك"
          // (explore_track) button removed from the track banner per
          // client request — replaced by the dual register buttons above.
        '</div>'+
      '</div>'+
      '<div class="programs-section">'+
        '<div class="prog-header"><span class="prog-icon">🎯</span><span class="prog-title serif">'+I18N.track_programs+'</span><span class="prog-count">'+(tr.programs?tr.programs.length:0)+' '+I18N.programs_suffix+'</span></div>'+
        progHTML+
      '</div>'+
      certHTML+
    '</div>';

    bindCrumbs(m,3);
    el('peBackTrack').addEventListener('click', function(){ selectDomain(d.id); });
    Array.prototype.forEach.call(m.querySelectorAll('[data-open-program]'), function(btn){
      btn.addEventListener('click', function(){
        var pid = parseInt(btn.dataset.openProgram,10);
        var prog = (tr.programs||[]).filter(function(x){ return x.id===pid; })[0];
        if(prog) openProgramModal(prog);
      });
    });
    bindTrackRegButtons(m);
  }

  // ---- Program details popup ------------------------------------------
  function linesHTML(lines, emptyText){
    if(!lines || !lines.length) return '<div class="pm-empty">'+esc(emptyText)+'</div>';
    return '<ul class="pm-list">'+lines.map(function(l){ return '<li>'+esc(l)+'</li>'; }).join('')+'</ul>';
  }

  function openProgramModal(prog){
    closeProgramModal();
    var wrap = document.createElement('div');
    wrap.className = 'pild-modal-overlay';
    wrap.id = 'pildProgramModal';
    var compHTML = (prog.competencies && prog.competencies.length)
      ? '<div class="pm-comp-grid">'+prog.competencies.map(function(c){
          return '<div class="pm-comp-card"><div class="pm-comp-kicker"><span class="pm-comp-dot"></span><span class="pm-comp-kicker-text">'+esc(I18N.comp_card_label)+'</span></div><div class="pm-comp-name">'+esc(c.title)+'</div>'+(c.excerpt?'<div class="pm-comp-desc">'+esc(c.excerpt)+'</div>':'')+'</div>';
        }).join('')+'</div>'
      : '<div class="pm-empty">'+esc(I18N.no_competencies)+'</div>';

    wrap.innerHTML =
      '<div class="pild-modal" role="dialog" aria-modal="true">'+
        '<button class="pm-close" id="pmCloseBtn" aria-label="'+esc(I18N.modal_close)+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>'+
        '<div class="pm-header">'+
          '<div class="pm-header-accent"></div>'+
          '<div class="pm-eyebrow">'+esc(I18N.program_details_btn)+'</div>'+
          '<div class="pm-title serif">'+esc(prog.title)+'</div>'+
        '</div>'+
        '<div class="pm-body">'+
          '<div class="pm-section">'+
            '<div class="pm-section-title"><span class="pm-section-icon">📋</span>'+esc(I18N.modal_overview_title)+'</div>'+
            (prog.overview ? '<div class="pm-overview">'+esc(prog.overview)+'</div>' : '<div class="pm-empty">'+esc(I18N.modal_no_overview)+'</div>')+
          '</div>'+
          '<div class="pm-section-cols">'+
            '<div class="pm-section">'+
              '<div class="pm-section-title"><span class="pm-section-icon">🎯</span>'+esc(I18N.modal_goals_title)+'</div>'+
              linesHTML(prog.goals, I18N.modal_no_goals)+
            '</div>'+
            '<div class="pm-section">'+
              '<div class="pm-section-title"><span class="pm-section-icon">🏁</span>'+esc(I18N.modal_outcomes_title)+'</div>'+
              linesHTML(prog.outcomes, I18N.modal_no_outcomes)+
            '</div>'+
          '</div>'+
          '<div class="pm-section">'+
            '<div class="pm-section-title"><span class="pm-section-icon">⭐</span>'+esc(I18N.modal_competencies_title)+'</div>'+
            compHTML+
          '</div>'+
        '</div>'+
      '</div>';

    // Bug fix: this modal's CSS is scoped under "#pild-app ..." (see the
    // .pild-modal-overlay/.pild-modal rules above), so it MUST live inside
    // the #pild-app root to actually be styled. Appending it to
    // document.body (the old code) put it outside that scope, so it
    // rendered completely unstyled/invisible — which is why the "تفاصيل
    // البرنامج" button looked like it "did nothing".
    (el('pild-app') || document.body).appendChild(wrap);
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(function(){ wrap.classList.add('open'); });

    wrap.addEventListener('click', function(e){ if(e.target === wrap) closeProgramModal(); });
    el('pmCloseBtn').addEventListener('click', closeProgramModal);
    document.addEventListener('keydown', escCloseHandler);
  }

  function escCloseHandler(e){ if(e.key === 'Escape') closeProgramModal(); }

  function closeProgramModal(){
    var existing = document.getElementById('pildProgramModal');
    if(existing){
      existing.parentNode.removeChild(existing);
      document.body.style.overflow = '';
      document.removeEventListener('keydown', escCloseHandler);
    }
  }

  buildHeroMosaic();
  fetchRegContext();
})();
</script>
    <?php
    return ob_get_clean();
}
// ============================================================
// NOTE: the old self-service enrollment AJAX action
// (wp_ajax[_nopriv]_pild_ex_self_enroll), which used to write a free
// pild_enrollments row directly from these "Enroll" buttons, has been
// removed entirely and replaced by the product-routing logic in
// includes/22-registration-routing.php. Every "Register" click above
// now lands on a real WooCommerce product page (Individual or Team)
// instead of silently enrolling the visitor for free.
// ============================================================