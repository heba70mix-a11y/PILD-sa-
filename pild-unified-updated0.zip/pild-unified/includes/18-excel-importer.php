<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 26. EXCEL BULK IMPORTER — Sectors → Domains → Tracks → Programs → Books
// ------------------------------------------------------------
// Lets an admin upload one .xlsx workbook (5 sheets: Sectors, Domains,
// Tracks, Programs, Books) and bulk-create/update the matching CPTs
// (sector, domain, track, program, playbook), wiring up their ACF
// relationship fields (domain_sector, track_domain, program_track,
// playbook_program) and optional Quiz Maker IDs (domain_quiz_id,
// track_quiz_id) automatically.
//
// Bilingual (v2): every sheet accepts an optional "..._EN" column next
// to each title/content column. When a row has an English value AND
// Polylang is active, the importer creates a REAL linked English post
// (not just a field) via pll_set_post_language() + pll_save_post_translations(),
// so switching the site language shows the English post. Rows without
// English data behave exactly as before (Arabic-only) — fully backward
// compatible with earlier (Arabic-only) template files.
//
// Design goals:
//  - No external library (PhpSpreadsheet, etc.) — .xlsx is just a zip
//    of XML, read here with ZipArchive + SimpleXML only.
//  - Two-step flow: PREVIEW (validates everything, writes nothing) then
//    CONFIRM (only runs if preview had zero errors) — so a bad file
//    never partially imports.
//  - Idempotent: every created post gets a 'pild_import_code' meta. Re-
//    uploading the same file (even with only some rows changed, e.g. an
//    improved name) updates existing posts by code instead of duplicating.
// ============================================================

add_action('admin_menu', 'pildcm_excel_import_menu');
function pildcm_excel_import_menu() {
    add_submenu_page('pild-settings', 'Import Sector', 'Import Sector',
        'manage_options', 'pild-excel-import', 'pildcm_excel_import_page');
}

// ── 26.1 Sheet specs: source columns, target CPT, target ACF fields ──
// Every col ending in _en is OPTIONAL and only used if present + non-empty + Polylang active.
function pildcm_import_specs() {
    return [
        'Sectors' => [
            'post_type'      => 'sector',
            'code_col'       => 'كود_القطاع',
            'title_col'      => 'اسم_القطاع',
            'title_en_col'   => 'اسم_القطاع_EN',
            'content_col'    => 'الوصف',
            'content_en_col' => 'الوصف_EN',
            'parent_col'     => null,
            'parent_sheet'   => null,
            'parent_field'   => null,
        ],
        'Domains' => [
            'post_type'      => 'domain',
            'code_col'       => 'كود_المجال',
            'title_col'      => 'اسم_المجال',
            'title_en_col'   => 'اسم_المجال_EN',
            'parent_col'     => 'كود_القطاع_الأب',
            'parent_sheet'   => 'Sectors',
            'parent_field'   => 'domain_sector',
            'quiz_col'       => 'رقم_اختبار_المجال',
            'quiz_field'     => 'domain_quiz_id',
        ],
        'Tracks' => [
            'post_type'      => 'track',
            'code_col'       => 'كود_التراك',
            'title_col'      => 'اسم_التراك',
            'title_en_col'   => 'اسم_التراك_EN',
            'content_col'    => 'القدرات',
            'content_en_col' => 'القدرات_EN',
            'parent_col'     => 'كود_المجال_الأب',
            'parent_sheet'   => 'Domains',
            'parent_field'   => 'track_domain',
            'quiz_col'       => 'رقم_اختبار_التراك',
            'quiz_field'     => 'track_quiz_id',
            // PHASE 15: Assessment link — sets the Track's "Quiz Page URL"
            // field (name: quiz_url). Reuses the generic acf_text_fields
            // mechanism already used for program_goals/program_outcomes above.
            'acf_text_fields' => [
                'quiz_url' => [ 'ar' => 'Assessment', 'en' => 'Assessment_EN' ],
                // PILD pricing-level model (Aug 2026): tags each track with
                // an ADMINISTRATIVE pricing category only — أساسي / متقدم /
                // متخصص — used purely to route "Register" to one of the 6
                // shared level products (includes/22-registration-
                // routing.php). Not a difficulty/content rating and never
                // shown publicly. Value in the sheet must be exactly one of
                // أساسي / متقدم / متخصص (leave the cell empty for a track
                // that still uses a dedicated product instead).
                'track_pricing_level' => [ 'ar' => 'المستوى_السعري', 'en' => 'المستوى_السعري' ],
            ],
        ],
        'Programs' => [
            'post_type'      => 'program',
            'code_col'       => 'كود_البرنامج',
            'title_col'      => 'اسم_البرنامج',
            'title_en_col'   => 'اسم_البرنامج_EN',
            'excerpt_col'    => 'النبذة',
            'excerpt_en_col' => 'النبذة_EN',
            'parent_col'     => 'كود_التراك_الأب',
            'parent_sheet'   => 'Tracks',
            'parent_field'   => 'program_track',
            // Free-text ACF fields, one line per bullet — shown in the
            // "Program Details" popup on the public sector-explorer page.
            // Key = ACF field name, value = [ar column, en column].
            'acf_text_fields' => [
                'program_goals'    => [ 'ar' => 'الأهداف',  'en' => 'الأهداف_EN' ],
                'program_outcomes' => [ 'ar' => 'المخرجات', 'en' => 'المخرجات_EN' ],
            ],
        ],
        'Books' => [
            'post_type'      => 'playbook',
            'code_col'       => 'كود_الكتاب',
            'title_col'      => 'اسم_الكتاب',
            'title_en_col'   => 'اسم_الكتاب_EN',
            'content_col'    => 'المحتوى',
            'content_en_col' => 'المحتوى_EN',
            'parent_col'     => 'كود_البرنامج_الأب',
            'parent_sheet'   => 'Programs',
            'parent_field'   => 'playbook_program',
        ],
    ];
}

function pildcm_import_sheet_order() {
    return ['Sectors', 'Domains', 'Tracks', 'Programs', 'Books'];
}

function pildcm_import_level_labels() {
    return [
        'Sectors'  => 'القطاعات',
        'Domains'  => 'المجالات',
        'Tracks'   => 'التراكات',
        'Programs' => 'البرامج',
        'Books'    => 'الكتب / البلايبوكس',
    ];
}

// ── 26.2 Minimal .xlsx reader (ZipArchive + SimpleXML, no dependencies) ──
// PHASE 13: modern libxml (2.9+, bundled with PHP 7.0+) already disables
// external entity resolution by default, so this isn't fixing an active
// exploit on typical hosting — but explicitly disabling it here removes
// any dependency on that default being in place (older/custom PHP builds,
// or a future libxml change), which costs nothing and closes the door for
// good on XXE via a crafted .xlsx file uploaded through this importer.
function pildcm_safe_simplexml($xml_str) {
    // libxml_disable_entity_loader() is deprecated (and a no-op — always
    // disabled) on PHP 8+; only call it on the older versions where it's
    // still meaningful, to avoid a deprecation notice for no benefit.
    $needs_legacy_guard = PHP_VERSION_ID < 80000;
    if ($needs_legacy_guard) $prev = libxml_disable_entity_loader(true);
    $xml = @simplexml_load_string($xml_str, 'SimpleXMLElement', LIBXML_NONET);
    if ($needs_legacy_guard) libxml_disable_entity_loader($prev);
    return $xml;
}

function pildcm_xlsx_col_to_index($cell_ref) {
    preg_match('/^([A-Z]+)/', $cell_ref, $m);
    $letters = isset($m[1]) ? $m[1] : 'A';
    $index = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $index = $index * 26 + (ord($letters[$i]) - ord('A') + 1);
    }
    return $index - 1;
}

function pildcm_xlsx_parse_sheet_xml($xml_str, $shared) {
    $xml = pildcm_safe_simplexml($xml_str);
    if (!$xml || !isset($xml->sheetData->row)) return [];

    $rows_raw = [];
    foreach ($xml->sheetData->row as $row) {
        $cells = [];
        foreach ($row->c as $c) {
            $ref  = (string) $c['r'];
            if ($ref === '') continue;
            $col  = pildcm_xlsx_col_to_index($ref);
            $type = (string) $c['t'];
            if ($type === 's') {
                $vi = (int) $c->v;
                $value = isset($shared[$vi]) ? $shared[$vi] : '';
            } elseif ($type === 'inlineStr') {
                $value = isset($c->is->t) ? (string) $c->is->t : '';
            } else {
                $value = isset($c->v) ? (string) $c->v : '';
            }
            $cells[$col] = trim($value);
        }
        $rows_raw[] = $cells;
    }
    if (empty($rows_raw)) return [];

    $header_row = array_shift($rows_raw);
    if (empty($header_row)) return [];
    $max_col = max(array_keys($header_row));
    $headers = [];
    for ($i = 0; $i <= $max_col; $i++) {
        $headers[$i] = isset($header_row[$i]) ? $header_row[$i] : '';
    }

    $rows = [];
    foreach ($rows_raw as $cells) {
        $all_empty = true;
        foreach ($cells as $v) { if ($v !== '') { $all_empty = false; break; } }
        if ($all_empty) continue;

        $assoc = [];
        foreach ($headers as $i => $h) {
            if ($h === '') continue;
            $assoc[$h] = isset($cells[$i]) ? $cells[$i] : '';
        }
        $rows[] = $assoc;
    }
    return $rows;
}

function pildcm_xlsx_extract($file_path) {
    if (!class_exists('ZipArchive')) {
        return new WP_Error('no_zip', 'السيرفر مش متاح عليه ZipArchive (لازم تفعيل PHP Zip extension) — كلم الاستضافة.');
    }
    $zip = new ZipArchive();
    if ($zip->open($file_path) !== true) {
        return new WP_Error('xlsx_open_failed', 'تعذر فتح الملف. تأكد إنه ملف Excel (.xlsx) سليم ومش تالف.');
    }

    $shared = [];
    $ss_xml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ss_xml !== false) {
        $ss = pildcm_safe_simplexml($ss_xml);
        if ($ss && isset($ss->si)) {
            foreach ($ss->si as $si) {
                if (isset($si->t)) {
                    $shared[] = (string) $si->t;
                } else {
                    $text = '';
                    if (isset($si->r)) {
                        foreach ($si->r as $r) { $text .= (string) $r->t; }
                    }
                    $shared[] = $text;
                }
            }
        }
    }

    $wb_xml = $zip->getFromName('xl/workbook.xml');
    $sheet_rids = [];
    if ($wb_xml !== false) {
        $wb = pildcm_safe_simplexml($wb_xml);
        if ($wb && isset($wb->sheets->sheet)) {
            foreach ($wb->sheets->sheet as $sheet) {
                $name = (string) $sheet['name'];
                $rid_attrs = $sheet->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships');
                $rid = isset($rid_attrs['id']) ? (string) $rid_attrs['id'] : '';
                if ($name !== '' && $rid !== '') $sheet_rids[$name] = $rid;
            }
        }
    }

    $rels_xml = $zip->getFromName('xl/_rels/workbook.xml.rels');
    $rid_targets = [];
    if ($rels_xml !== false) {
        $rels = pildcm_safe_simplexml($rels_xml);
        if ($rels && isset($rels->Relationship)) {
            foreach ($rels->Relationship as $rel) {
                $rid_targets[(string) $rel['Id']] = (string) $rel['Target'];
            }
        }
    }

    $sheets_data = [];
    foreach ($sheet_rids as $name => $rid) {
        if (!isset($rid_targets[$rid])) continue;
        $target = ltrim($rid_targets[$rid], '/');
        if (strpos($target, 'worksheets/') !== 0) $target = 'worksheets/' . basename($target);
        $sheet_xml = $zip->getFromName('xl/' . $target);
        if ($sheet_xml === false) continue;
        $sheets_data[$name] = pildcm_xlsx_parse_sheet_xml($sheet_xml, $shared);
    }
    $zip->close();
    return $sheets_data;
}

// ── 26.3 Build + validate the import plan (no DB writes) ──
function pildcm_import_build_plan($sheets_raw) {
    $specs  = pildcm_import_specs();
    $order  = pildcm_import_sheet_order();
    $errors = [];
    $code_exists = []; // sheet_key => [code => true]  (existing DB codes + new rows in this file)
    $plan = [];

    foreach ($order as $key) {
        $spec = $specs[$key];

        $existing_ids = get_posts([
            'post_type'      => $spec['post_type'],
            'posts_per_page' => -1,
            'post_status'    => 'any',
            'meta_key'       => 'pild_import_code',
            'fields'         => 'ids',
        ]);
        $known_codes = [];
        foreach ($existing_ids as $pid) {
            $code = get_post_meta($pid, 'pild_import_code', true);
            if ($code !== '') $known_codes[$code] = true;
        }

        $rows = isset($sheets_raw[$key]) ? $sheets_raw[$key] : [];
        $seen_in_sheet = [];
        $plan_rows = [];

        foreach ($rows as $i => $row) {
            $line = $i + 2;
            $code  = isset($row[$spec['code_col']])  ? trim($row[$spec['code_col']])  : '';
            $title = isset($row[$spec['title_col']]) ? trim($row[$spec['title_col']]) : '';

            if ($code === '' || $title === '') {
                $errors[] = "[$key] صف $line: لازم يتحدد كود واسم.";
                continue;
            }
            if (isset($seen_in_sheet[$code])) {
                $errors[] = "[$key] صف $line: الكود '$code' مكرر في نفس الشيت.";
                continue;
            }
            $seen_in_sheet[$code] = true;

            $parent_code = null;
            if (!empty($spec['parent_col'])) {
                $parent_code = isset($row[$spec['parent_col']]) ? trim($row[$spec['parent_col']]) : '';
                if ($parent_code === '') {
                    $errors[] = "[$key] صف $line: لازم يتحدد {$spec['parent_col']}.";
                    continue;
                }
                if (!isset($code_exists[$spec['parent_sheet']][$parent_code])) {
                    $errors[] = "[$key] صف $line: كود الأب '$parent_code' مش موجود في شيت {$spec['parent_sheet']}.";
                    continue;
                }
            }

            $plan_rows[] = [
                'line' => $line, 'code' => $code, 'title' => $title,
                'parent_code' => $parent_code, 'raw' => $row,
            ];
            $known_codes[$code] = true;
        }

        $code_exists[$key] = $known_codes;
        $plan[$key] = $plan_rows;
    }

    return ['plan' => $plan, 'errors' => $errors, 'specs' => $specs, 'order' => $order];
}

// PHASE 14: bulk-imported posts were reported as rendering unstyled (raw
// text, no CSS) until someone manually opened and re-saved them in
// wp-admin — the plugin's own display code (pild_display_programs_on_track()
// etc. in pild-unified.php) doesn't depend on post_excerpt or anything else
// that would explain that, so a stale page/object cache or a per-post CSS
// file (Elementor generates one on save) that's never generated for a post
// created via wp_insert_post() directly (bypassing the normal save flow)
// is the most likely explanation. This purges every cache layer this
// plugin can detect for a given post, right after the import writes it —
// standing in for the "open it and click Update once" workaround.
function pildcm_purge_post_cache($post_id) {
    if (!$post_id) return;
    clean_post_cache($post_id); // WordPress's own object cache for this post

    if (function_exists('rocket_clean_post')) rocket_clean_post($post_id);                 // WP Rocket
    if (function_exists('w3tc_flush_post')) w3tc_flush_post($post_id);                       // W3 Total Cache
    if (class_exists('LiteSpeed\Purge') && method_exists('LiteSpeed\Purge', 'purge_post')) \LiteSpeed\Purge::purge_post($post_id); // LiteSpeed Cache
    if (function_exists('wp_cache_post_change')) wp_cache_post_change($post_id);             // WP Super Cache
    if (function_exists('sg_cachepress_purge_cache')) sg_cachepress_purge_cache();           // SiteGround Optimizer (site-wide only, no per-post API)

    // Elementor regenerates a post's own CSS file when it's saved through
    // the editor; a raw wp_insert_post()/wp_update_post() call (what the
    // importer does) skips that. Deleting its cached CSS meta makes
    // Elementor regenerate the file the next time the post is viewed.
    if (function_exists('get_post_meta') && get_post_meta($post_id, '_elementor_css', true)) {
        delete_post_meta($post_id, '_elementor_css');
    }
}

// PHASE 18: the fix above only runs for content created/updated THROUGH
// the importer going forward — it does nothing for content that already
// existed on the site before this fix shipped (exactly what was reported:
// existing Sector/Track pages still unstyled, only fixed by manually
// re-saving each one). This is the retroactive, one-click version of the
// same fix, swept across every PILD post already on the site.
add_action('admin_menu', function () {
    add_submenu_page('pild-settings', 'Purge Content Cache', 'Purge Content Cache',
        'manage_options', 'pild-purge-cache', 'pildcm_purge_all_cache_page');
});

function pildcm_purge_all_cache_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>🧹 تنضيف كاش كل محتوى PILD</h1>';
    echo '<p>لو صفحات القطاعات/المجالات/التراكات/البرامج/الكتب شكلها غير منظّم (من غير تنسيق) على الموقع الحي، دوس الزرار ده — بيعمل نفس تأثير "فتح كل بوست وحفظه" لكل المحتوى الموجود دلوقتي، مرة واحدة.</p>';

    if (isset($_POST['pildcm_purge_confirm']) && check_admin_referer('pildcm_purge_all_cache')) {
        $post_types = ['sector', 'domain', 'track', 'program', 'playbook'];
        $ids = get_posts(['post_type' => $post_types, 'posts_per_page' => -1, 'post_status' => 'any', 'fields' => 'ids']);
        foreach ($ids as $id) pildcm_purge_post_cache($id);
        echo '<div class="notice notice-success"><p><strong>✅ تم — ' . count($ids) . ' صفحة اتنضّف الكاش بتاعها.</strong> جرّب تفتح صفحة كانت متبوظة وشوف.</p></div>';
    }

    echo '<form method="post">';
    wp_nonce_field('pildcm_purge_all_cache');
    echo '<input type="hidden" name="pildcm_purge_confirm" value="1">';
    submit_button('🧹 نضّف الكاش دلوقتي');
    echo '</form></div>';
}

// ── 26.4 Execute the plan: create/update posts, wire ACF relationships + Polylang translations ──
function pildcm_import_execute($plan_data) {
    global $wpdb;
    $specs  = $plan_data['specs'];
    $order  = $plan_data['order'];
    $plan   = $plan_data['plan'];
    $polylang_active = function_exists('pll_set_post_language') && function_exists('pll_save_post_translations');

    $id_maps = []; // sheet_key => [code => ['ar' => post_id, 'en' => post_id|null]]
    $results = [];

    foreach ($order as $key) {
        $spec = $specs[$key];
        $created = 0; $updated = 0; $created_en = 0;
        $assessment_rows = []; // Tracks only — see PHASE 19 block below

        // Seed maps from anything already tagged in the DB (any language).
        $existing_ids = get_posts([
            'post_type' => $spec['post_type'], 'posts_per_page' => -1, 'post_status' => 'any',
            'meta_key' => 'pild_import_code', 'fields' => 'ids',
        ]);
        $map = [];
        foreach ($existing_ids as $pid) {
            $code = get_post_meta($pid, 'pild_import_code', true);
            if ($code === '') continue;
            $lang = $polylang_active && function_exists('pll_get_post_language') ? pll_get_post_language($pid) : 'ar';
            if (!isset($map[$code])) $map[$code] = ['ar' => 0, 'en' => 0];
            $map[$code][$lang === 'en' ? 'en' : 'ar'] = $pid;
        }

        foreach ($plan[$key] as $row) {
            $code  = $row['code'];
            $title = $row['title'];
            $raw   = $row['raw'];
            if (!isset($map[$code])) $map[$code] = ['ar' => 0, 'en' => 0];

            // English title is read here (moved up from below) because the
            // slug needs it at CREATE time — see PHASE 14 note below.
            $title_en = !empty($spec['title_en_col']) && isset($raw[$spec['title_en_col']]) ? trim($raw[$spec['title_en_col']]) : '';

            // ---- Arabic post (always) ----
            $postarr = ['post_type' => $spec['post_type'], 'post_title' => $title, 'post_status' => 'publish'];
            if (!empty($spec['content_col']) && isset($raw[$spec['content_col']])) $postarr['post_content'] = $raw[$spec['content_col']];
            if (!empty($spec['excerpt_col']) && isset($raw[$spec['excerpt_col']])) $postarr['post_excerpt'] = $raw[$spec['excerpt_col']];

            // PHASE 14: slug (post_name) should be the English name, not
            // WordPress's default auto-generated-from-Arabic-title slug
            // (which produces long %-encoded Arabic URLs). Only set on
            // CREATE — an existing post keeps whatever slug it already has,
            // so re-running the import never changes a URL that might
            // already be shared/bookmarked/indexed. Requires the _EN title
            // column to be filled in for this row; if it's empty, there's
            // no English text to slug from and WordPress falls back to its
            // normal (Arabic) auto-slug behaviour, same as before this fix.
            if (empty($map[$code]['ar']) && $title_en !== '') {
                $postarr['post_name'] = sanitize_title($title_en);
            }

            if (!empty($map[$code]['ar'])) {
                $postarr['ID'] = $map[$code]['ar'];
                wp_update_post($postarr);
                $ar_id = $map[$code]['ar'];
                $updated++;
            } else {
                $ar_id = wp_insert_post($postarr);
                $created++;
            }
            if (is_wp_error($ar_id) || !$ar_id) continue;
            update_post_meta($ar_id, 'pild_import_code', $code);
            $map[$code]['ar'] = $ar_id;
            if ($polylang_active) pll_set_post_language($ar_id, 'ar');

            // ---- Optional linked English post ----
            $en_id = 0;
            if ($polylang_active && $title_en !== '') {
                $postarr_en = ['post_type' => $spec['post_type'], 'post_title' => $title_en, 'post_status' => 'publish'];
                if (!empty($spec['content_en_col']) && isset($raw[$spec['content_en_col']])) $postarr_en['post_content'] = $raw[$spec['content_en_col']];
                if (!empty($spec['excerpt_en_col']) && isset($raw[$spec['excerpt_en_col']])) $postarr_en['post_excerpt'] = $raw[$spec['excerpt_en_col']];

                if (!empty($map[$code]['en'])) {
                    $postarr_en['ID'] = $map[$code]['en'];
                    wp_update_post($postarr_en);
                    $en_id = $map[$code]['en'];
                } else {
                    $en_id = wp_insert_post($postarr_en);
                    $created_en++;
                }
                if (!is_wp_error($en_id) && $en_id) {
                    update_post_meta($en_id, 'pild_import_code', $code);
                    $map[$code]['en'] = $en_id;
                    pll_set_post_language($en_id, 'en');
                    pll_save_post_translations(['ar' => $ar_id, 'en' => $en_id]);
                }
            }

            // PHASE 20: force the Arabic and English posts of this code to
            // share the EXACT SAME slug (client requirement, Sep 2026 — "أي
            // slug موحد لكل شيء في النسختين العربي والإنجليزي"). Without
            // this, wp_insert_post()/wp_update_post() always runs post_name
            // through wp_unique_post_slug(), which treats the English post
            // as colliding with the Arabic one (same post_type, same
            // English-derived slug set on both — see PHASE 14 above) and
            // silently appends "-2" to whichever was inserted second —
            // e.g. one-week-before-license-renewal-2. A direct $wpdb
            // update bypasses that renaming. Guarded by a real collision
            // check against every OTHER post first, so two genuinely
            // different Books that happen to share an English title still
            // get safely disambiguated instead of colliding for real. Runs
            // on every import, not just creation, so simply re-uploading
            // the same file also repairs any slug that already drifted
            // apart from an earlier import (like the -2 example above).
            if ($en_id && $title_en !== '') {
                $unified_slug = sanitize_title($title_en);
                $conflict = $wpdb->get_var($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} WHERE post_name=%s AND post_type=%s AND post_status NOT IN ('trash','auto-draft') AND ID NOT IN (%d,%d) LIMIT 1",
                    $unified_slug, $spec['post_type'], $ar_id, $en_id
                ));
                if (!$conflict) {
                    $wpdb->update($wpdb->posts, ['post_name' => $unified_slug], ['ID' => $ar_id]);
                    $wpdb->update($wpdb->posts, ['post_name' => $unified_slug], ['ID' => $en_id]);
                    clean_post_cache($ar_id);
                    clean_post_cache($en_id);
                }
            }

            // ---- ACF parent relationship (per language) ----
            if (!empty($spec['parent_field']) && $row['parent_code'] !== null && function_exists('update_field')) {
                $parent_ids = isset($id_maps[$spec['parent_sheet']][$row['parent_code']])
                    ? $id_maps[$spec['parent_sheet']][$row['parent_code']] : ['ar' => 0, 'en' => 0];
                if (!empty($parent_ids['ar'])) {
                    update_field($spec['parent_field'], $parent_ids['ar'], $ar_id);
                }
                if ($en_id && function_exists('update_field')) {
                    $en_parent = !empty($parent_ids['en']) ? $parent_ids['en'] : $parent_ids['ar'];
                    if ($en_parent) update_field($spec['parent_field'], $en_parent, $en_id);
                }
            }

            // ---- Quiz Maker IDs (language-independent, set on both if present) ----
            if (!empty($spec['quiz_field']) && !empty($spec['quiz_col'])
                && isset($raw[$spec['quiz_col']]) && $raw[$spec['quiz_col']] !== ''
                && function_exists('update_field')) {
                $quiz_id = (int) $raw[$spec['quiz_col']];
                update_field($spec['quiz_field'], $quiz_id, $ar_id);
                if ($en_id) update_field($spec['quiz_field'], $quiz_id, $en_id);
            }

            // ---- Generic free-text ACF fields (e.g. program_goals / program_outcomes) ----
            // BUGFIX: this used to write even when the cell was BLANK
            // (isset() is true for an empty '' cell, only false when the
            // column header doesn't exist in the file at all) — so any
            // Tracks re-upload whose sheet happened to include the
            // "المستوى_السعري" (track_pricing_level) header with empty
            // cells would silently WIPE pricing set earlier via Import
            // Track Pricing, even though pricing lives in a completely
            // separate upload. Now requires a genuinely non-empty value,
            // same guard already used for quiz_field/quiz_col just above.
            if (!empty($spec['acf_text_fields']) && function_exists('update_field')) {
                foreach ($spec['acf_text_fields'] as $field_name => $cols) {
                    if (!empty($cols['ar']) && isset($raw[$cols['ar']]) && trim($raw[$cols['ar']]) !== '') {
                        update_field($field_name, $raw[$cols['ar']], $ar_id);
                    }
                    if ($en_id && !empty($cols['en']) && isset($raw[$cols['en']]) && trim($raw[$cols['en']]) !== '') {
                        update_field($field_name, $raw[$cols['en']], $en_id);
                    }
                }
            }

            // PHASE 19: auto-create the native Assessment (native quiz engine,
            // includes/28-quiz-engine.php) for every Track row, linked via the
            // 'assessment_track' ACF field — so tracks imported here immediately
            // have a real, stable Assessment ID to reference from the Questions
            // import file (includes/29-quiz-admin.php), without a manual step
            // in wp-admin per track. One Arabic Assessment always; a matching
            // English Assessment too when this row created a linked English
            // track. Idempotent like everything else here (matched by
            // 'pild_import_code' on the assessment post, re-running the same
            // file updates instead of duplicating). Only fires when the row
            // left the 'Assessment' (quiz_url) column empty — a track that
            // explicitly points at an external quiz page is left alone.
            if ($key === 'Tracks' && function_exists('update_field')) {
                $has_external_quiz_url = !empty($spec['acf_text_fields']['quiz_url']['ar'])
                    && !empty($raw[$spec['acf_text_fields']['quiz_url']['ar']]);

                if (!$has_external_quiz_url) {
                    $assess_code = $code . '::assessment';
                    $existing_assess = get_posts([
                        'post_type' => 'assessment', 'posts_per_page' => -1, 'post_status' => 'any',
                        'meta_key' => 'pild_import_code', 'meta_value' => $assess_code, 'fields' => 'ids',
                    ]);
                    $ar_assess_id = 0; $en_assess_id = 0;
                    foreach ($existing_assess as $aid) {
                        $alang = $polylang_active && function_exists('pll_get_post_language') ? pll_get_post_language($aid) : 'ar';
                        if ($alang === 'en') $en_assess_id = $aid; else $ar_assess_id = $aid;
                    }

                    $assess_postarr = [
                        'post_type' => 'assessment', 'post_status' => 'publish',
                        'post_title' => $title . ' — التقييم النهائي',
                    ];
                    if ($ar_assess_id) { $assess_postarr['ID'] = $ar_assess_id; wp_update_post($assess_postarr); }
                    else { $ar_assess_id = wp_insert_post($assess_postarr); }
                    if (!is_wp_error($ar_assess_id) && $ar_assess_id) {
                        update_post_meta($ar_assess_id, 'pild_import_code', $assess_code);
                        update_field('assessment_track', $ar_id, $ar_assess_id);
                        if ($polylang_active) pll_set_post_language($ar_assess_id, 'ar');
                        pildcm_purge_post_cache($ar_assess_id);
                    } else {
                        $ar_assess_id = 0;
                    }

                    if ($en_id) {
                        $assess_postarr_en = [
                            'post_type' => 'assessment', 'post_status' => 'publish',
                            'post_title' => ($title_en !== '' ? $title_en : $title) . ' — Final Assessment',
                        ];
                        if ($en_assess_id) { $assess_postarr_en['ID'] = $en_assess_id; wp_update_post($assess_postarr_en); }
                        else { $en_assess_id = wp_insert_post($assess_postarr_en); }
                        if (!is_wp_error($en_assess_id) && $en_assess_id) {
                            update_post_meta($en_assess_id, 'pild_import_code', $assess_code);
                            update_field('assessment_track', $en_id, $en_assess_id);
                            if ($polylang_active) {
                                pll_set_post_language($en_assess_id, 'en');
                                pll_save_post_translations(['ar' => $ar_assess_id, 'en' => $en_assess_id]);
                            }
                            pildcm_purge_post_cache($en_assess_id);
                        } else {
                            $en_assess_id = 0;
                        }
                    }

                    $assessment_rows[] = [
                        'code' => $code, 'title' => $title,
                        'ar_id' => $ar_assess_id, 'en_id' => $en_id ? $en_assess_id : 0,
                    ];
                }
            }

            // PHASE 14/15: see pildcm_purge_post_cache() above.
            pildcm_purge_post_cache($ar_id);
            if ($en_id) pildcm_purge_post_cache($en_id);
        }

        $id_maps[$key] = $map;
        $results[$key] = ['created' => $created, 'updated' => $updated, 'created_en' => $created_en];
        if ($key === 'Tracks') $results[$key]['assessments'] = $assessment_rows;
    }

    return ['results' => $results, 'id_maps' => $id_maps];
}

// ── 26.5 Admin page: upload -> preview -> confirm ──
function pildcm_excel_import_page() {
    if (!current_user_can('manage_options')) return;
    $labels = pildcm_import_level_labels();
    $polylang_active = function_exists('pll_set_post_language');

    echo '<div class="wrap"><h1>📥 استيراد قطاع</h1>';
    if (!$polylang_active) {
        echo '<div class="notice notice-warning"><p>Polylang مش شغّال حالياً على الموقع — أي عمود اسم إنجليزي (_EN) هيتجاهله الاستيراد ويتم إنشاء المحتوى بالعربي فقط.</p></div>';
    }

    $step = isset($_POST['pildcm_step']) ? sanitize_text_field(wp_unslash($_POST['pildcm_step'])) : '';
    $tkey = 'pildcm_import_plan_' . get_current_user_id();

    if ($step === 'confirm' && check_admin_referer('pildcm_import_confirm')) {
        $plan_data = get_transient($tkey);
        if (!$plan_data) {
            echo '<div class="notice notice-error"><p>انتهت صلاحية بيانات المعاينة (بعد ساعة). ارفع الملف تاني.</p></div>';
        } else {
            $exec    = pildcm_import_execute($plan_data);
            $results = $exec['results'];
            delete_transient($tkey);
            echo '<div class="notice notice-success"><p><strong>تم الاستيراد بنجاح ✅</strong></p></div>';
            if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
            echo '<table class="widefat striped" style="max-width:700px"><thead><tr><th>المستوى</th><th>عناصر عربي جديدة</th><th>عناصر تم تحديثها</th><th>عناصر إنجليزي جديدة</th></tr></thead><tbody>';
            foreach ($results as $k => $r) {
                echo '<tr><td>' . esc_html($labels[$k]) . '</td><td>' . (int) $r['created'] . '</td><td>' . (int) $r['updated'] . '</td><td>' . (int) $r['created_en'] . '</td></tr>';
            }
            echo '</tbody></table>';

            // PHASE 19: show the auto-created Assessment IDs for every track,
            // ready to paste straight into the Questions import file's
            // رقم_الاختبار column (includes/29-quiz-admin.php).
            if (!empty($results['Tracks']['assessments'])) {
                echo '<h2 style="margin-top:28px">🧾 أرقام الاختبارات (للاستخدام في ملف الأسئلة)</h2>';
                echo '<p style="color:#666;max-width:700px">كل تراك دلوقتي ليه Assessment مربوط تلقائيًا. انسخ الأرقام دي وحطها في عمود <code>رقم_الاختبار</code> بملف استيراد الأسئلة — العمود العربي للأسئلة العربية، والإنجليزي للأسئلة الإنجليزية.</p>';
                echo '<table class="widefat striped" style="max-width:800px"><thead><tr><th>كود التراك</th><th>اسم التراك</th><th>رقم الاختبار (عربي)</th><th>رقم الاختبار (إنجليزي)</th></tr></thead><tbody>';
                foreach ($results['Tracks']['assessments'] as $a) {
                    echo '<tr><td>' . esc_html($a['code']) . '</td><td>' . esc_html($a['title']) . '</td><td>' . ($a['ar_id'] ?: '—') . '</td><td>' . ($a['en_id'] ?: '—') . '</td></tr>';
                }
                echo '</tbody></table>';
            }

            // PHASE 16: optional Products sheet, saved alongside the main
            // plan in the same transient — see the preview branch below.
            if (!empty($plan_data['products_rows']) && function_exists('pildcm_products_execute')) {
                $presult = pildcm_products_execute($plan_data['products_rows'], $exec['id_maps']);
                echo '<p style="margin-top:12px;"><strong>المنتجات:</strong> جديدة: ' . (int) $presult['created'] . '، تم تحديثها: ' . (int) $presult['updated'] . '، إنجليزي جديد: ' . (int) $presult['created_en'] . '</p>';
            }
        }
    } elseif ($step === 'preview' && check_admin_referer('pildcm_import_preview') && !empty($_FILES['pildcm_file']['tmp_name'])) {
        $tmp_name  = $_FILES['pildcm_file']['tmp_name'];
        $orig_name = isset($_FILES['pildcm_file']['name']) ? sanitize_file_name($_FILES['pildcm_file']['name']) : '';

        if (strtolower(pathinfo($orig_name, PATHINFO_EXTENSION)) !== 'xlsx') {
            echo '<div class="notice notice-error"><p>لازم يكون الملف بصيغة .xlsx (نفس نموذج القالب).</p></div>';
        } else {
            $sheets_raw = pildcm_xlsx_extract($tmp_name);
            if (is_wp_error($sheets_raw)) {
                echo '<div class="notice notice-error"><p>' . esc_html($sheets_raw->get_error_message()) . '</p></div>';
            } else {
                $missing = array_diff(pildcm_import_sheet_order(), array_keys($sheets_raw));
                if (!empty($missing)) {
                    echo '<div class="notice notice-error"><p>الشيتات دي ناقصة من الملف (لازم تكون بنفس الاسم بالظبط): ' . esc_html(implode('، ', $missing)) . '</p></div>';
                } else {
                    $build = pildcm_import_build_plan($sheets_raw);

                    echo '<h2>📋 معاينة قبل الاستيراد</h2>';
                    echo '<table class="widefat striped" style="max-width:600px;margin-bottom:20px"><thead><tr><th>المستوى</th><th>عدد الصفوف الصالحة</th></tr></thead><tbody>';
                    foreach ($build['order'] as $k) {
                        echo '<tr><td>' . esc_html($labels[$k]) . '</td><td>' . count($build['plan'][$k]) . '</td></tr>';
                    }
                    echo '</tbody></table>';

                    if (!empty($build['errors'])) {
                        echo '<div class="notice notice-error"><p><strong>فيه أخطاء لازم تتصلح جوه الإكسيل الأول (لسه مفيش أي حاجة اتحفظت):</strong></p><ul style="list-style:disc;margin-inline-start:20px">';
                        foreach ($build['errors'] as $err) echo '<li>' . esc_html($err) . '</li>';
                        echo '</ul></div>';
                    } else {
                        // PHASE 16: optional "Products" sheet — same file,
                        // one upload. Not in pildcm_import_sheet_order() so
                        // its absence never blocks a Sectors-only re-upload;
                        // if present, its rows may reference Tracks being
                        // created by THIS SAME file (not yet in the DB), so
                        // pass their codes through as known-valid.
                        $products_rows = [];
                        if (!empty($sheets_raw['Products']) && function_exists('pildcm_products_build_plan')) {
                            $known_track_codes = array_column($build['plan']['Tracks'], 'code');
                            $pbuild = pildcm_products_build_plan($sheets_raw['Products'], $known_track_codes);
                            if (!empty($pbuild['errors'])) {
                                echo '<div class="notice notice-error"><p><strong>فيه أخطاء في شيت Products:</strong></p><ul style="list-style:disc;margin-inline-start:20px">';
                                foreach ($pbuild['errors'] as $err) echo '<li>' . esc_html($err) . '</li>';
                                echo '</ul></div>';
                            } else {
                                echo '<p>📦 شيت Products: <strong>' . count($pbuild['rows']) . '</strong> منتج جاهز للاستيراد.</p>';
                                $products_rows = $pbuild['rows'];
                            }
                        }

                        if (!empty($sheets_raw['Products']) && empty($products_rows)) {
                            // Products sheet was present but had errors — don't
                            // silently proceed with the taxonomy-only half.
                        } else {
                            $build['products_rows'] = $products_rows;
                            set_transient($tkey, $build, HOUR_IN_SECONDS);
                            echo '<div class="notice notice-success"><p>مفيش أخطاء ✅ — دوس "تأكيد الاستيراد" عشان تتنفذ العملية فعلياً على الموقع.</p></div>';
                            echo '<form method="post">';
                            wp_nonce_field('pildcm_import_confirm');
                            echo '<input type="hidden" name="pildcm_step" value="confirm">';
                            submit_button('✅ تأكيد الاستيراد الآن');
                            echo '</form>';
                        }
                    }
                }
            }
        }
    }

    echo '<hr><h2>ارفع ملف الإكسيل</h2>';
    echo '<form method="post" enctype="multipart/form-data">';
    wp_nonce_field('pildcm_import_preview');
    echo '<input type="hidden" name="pildcm_step" value="preview">';
    echo '<p><input type="file" name="pildcm_file" accept=".xlsx" required></p>';
    submit_button('🔍 معاينة الملف (بدون حفظ)');
    echo '</form>';

    echo '<p style="color:#666;max-width:600px">الملف لازم يحتوي على 5 شيتات بنفس الأسماء بالظبط: <code>Sectors</code>, <code>Domains</code>, <code>Tracks</code>, <code>Programs</code>, <code>Books</code>. أعمدة الاسم الإنجليزي (تنتهي بـ <code>_EN</code>) اختيارية — لو موجودة وPolylang شغّال، هيتعمل بوست إنجليزي مرتبط تلقائياً.</p>';
    echo '<p style="color:#666;max-width:600px">شيت <code>Programs</code> فيه كمان عمودي <code>الأهداف</code> و<code>المخرجات</code> (وأزواجهم <code>_EN</code>) — دول بيظهروا في نافذة "تفاصيل البرنامج" في صفحة استكشاف القطاعات. اكتب كل هدف/مخرج في سطر منفصل داخل الخلية (Alt+Enter في إكسيل) وهيتحول تلقائياً لنقاط. أما "القدرات" اللي بتظهر تحت كل برنامج، فهي صفوف شيت <code>Books</code> المرتبطة بكود البرنامج (مش عمود نصي).</p>';
    echo '<p style="color:#666;max-width:600px">شيت <code>Tracks</code> فيه كمان عمود <code>Assessment</code> (وزوجه <code>Assessment_EN</code>) — رابط صفحة التقييم بتاع التراك ده.</p>';
    echo '<p style="color:#666;max-width:600px"><strong>🧾 ربط تلقائي بالأسئلة:</strong> لو سيبت عمود <code>Assessment</code> فاضي (الوضع الطبيعي)، هيتعمل تلقائيًا Assessment خاص بمحرك الاختبارات الداخلي لكل تراك (عربي، وإنجليزي لو التراك له نسخة إنجليزية) — وهتلاقي أرقامهم في جدول بعد الاستيراد مباشرة، جاهزة تلصقها في عمود <code>رقم_الاختبار</code> بملف استيراد الأسئلة. لو حطيت رابط في عمود <code>Assessment</code>، معناها التراك ده بيستخدم صفحة اختبار خارجية، فمش هيتعملّه Assessment داخلي.</p>';
    echo '<p style="color:#666;max-width:600px">وعمود اختياري تاني اسمه <code>المستوى_السعري</code> — قيمته لازم تطابق حرفيًا نص "المستوى" المكتوب على أحد الـ6 منتجات المشتركة (شوف Import Track Pricing → ملف Products، هو اللي بيحدد النصوص دي). سيبها فاضية لو التراك لسه مربوط بمنتج خاص بيه. ده تصنيف سعري إداري بس بيحدد أي منتج من الـ6 منتجات المشتركة هيتربط بزرار "سجل في التراك" — مش وصف لصعوبة التراك. (فيه أداة استيراد تسعير منفصلة — Import Track Pricing — بتظبط العمود ده تلقائي من ملف التسعير بتاعكم، مش لازم تعبّيه هنا يدويًا.)</p>';
    echo '<p style="color:#666;max-width:600px"><strong>📦 شيت Products (اختياري):</strong> لو ضفته لنفس الملف، هيتعمل منتجات ووكوميرس مربوطة بالتراكات تلقائياً بعد ما القطاعات تتعمل — من غير ما تحتاج ترفعه في ملف منفصل. نفس الأعمدة المستخدمة في أداة "Import Products" المستقلة: <code>كود_المنتج، اسم_المنتج، اسم_المنتج_EN (اختياري)، النوع، السعر، كود_التراك، سعر_الشريك، الحد_الأدنى_للمقاعد</code>.</p>';
    echo '</div>';
}
