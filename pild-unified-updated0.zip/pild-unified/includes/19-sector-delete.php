<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 27. DELETE A SECTOR (cascade) — Sector → Domains → Tracks → Programs → Books
// ------------------------------------------------------------
// Lets an admin wipe a whole sector and everything under it in one go —
// useful after testing an import, or to redo a sector from scratch.
// Follows the same ACF relationship graph used by the importer
// (domain_sector -> track_domain -> program_track -> playbook_program),
// so it correctly deletes BOTH language versions of every post created
// via Polylang (Arabic + linked English), without needing any special
// Polylang-specific lookup — it just walks the real relationships.
//
// Two-step flow, same spirit as the importer: PREVIEW (counts only, no
// deletion) then CONFIRM (requires an explicit checkbox) — a sector can
// never be wiped by a single accidental click.
// ============================================================

add_action('admin_menu', 'pildcm_sector_delete_menu');
function pildcm_sector_delete_menu() {
    add_submenu_page('pild-settings', 'Delete a Sector', '🗑 Delete a Sector',
        'manage_options', 'pild-sector-delete', 'pildcm_sector_delete_page');
}

// ── 27.1 List every sector currently in the DB (any language), grouped by code ──
function pildcm_list_sectors_grouped() {
    $ids = get_posts([
        'post_type' => 'sector', 'posts_per_page' => -1, 'post_status' => 'any',
        'meta_key' => 'pild_import_code', 'fields' => 'ids',
    ]);
    $grouped = []; // code => ['titles' => [...], 'ids' => [...]]
    foreach ($ids as $pid) {
        $code = get_post_meta($pid, 'pild_import_code', true);
        if ($code === '') continue;
        if (!isset($grouped[$code])) $grouped[$code] = ['titles' => [], 'ids' => []];
        $grouped[$code]['titles'][] = get_the_title($pid);
        $grouped[$code]['ids'][] = $pid;
    }
    ksort($grouped);
    return $grouped;
}

// ── 27.2 Walk the relationship graph from a set of sector IDs down to playbooks ──
function pildcm_cascade_collect($sector_ids) {
    $chain = [
        ['type' => 'domain',   'field' => 'domain_sector',   'parents' => $sector_ids],
        ['type' => 'track',    'field' => 'track_domain',    'parents' => null],
        ['type' => 'program',  'field' => 'program_track',   'parents' => null],
        ['type' => 'playbook', 'field' => 'playbook_program','parents' => null],
    ];
    $collected = ['domain' => [], 'track' => [], 'program' => [], 'playbook' => []];
    $prev_ids = $sector_ids;

    foreach ($chain as $level) {
        if (empty($prev_ids)) { $prev_ids = []; continue; }
        $ids = get_posts([
            'post_type'      => $level['type'],
            'posts_per_page' => -1,
            'post_status'    => 'any',
            'fields'         => 'ids',
            'meta_query'      => [[
                'key'     => $level['field'],
                'value'   => $prev_ids,
                'compare' => 'IN',
            ]],
        ]);
        $collected[$level['type']] = $ids;
        $prev_ids = $ids;
    }
    return $collected;
}

// ── 27.3 Admin page: pick sector -> preview counts -> confirm delete ──
function pildcm_sector_delete_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>🗑 حذف قطاع بالكامل</h1>';
    echo '<p style="color:#900;max-width:600px"><strong>تحذير:</strong> ده بيحذف القطاع وكل المجالات/التراكات/البرامج/الكتب اللي جواه (باللغتين لو موجودة) — نهائياً، مفيش استرجاع.</p>';

    $sectors = pildcm_list_sectors_grouped();
    if (empty($sectors)) {
        echo '<p>مفيش أي قطاع متعمَّل استيراد له لحد دلوقتي.</p></div>';
        return;
    }

    $step = isset($_POST['pildcm_del_step']) ? sanitize_text_field(wp_unslash($_POST['pildcm_del_step'])) : '';
    $tkey = 'pildcm_delete_plan_' . get_current_user_id();

    if ($step === 'confirm' && check_admin_referer('pildcm_delete_confirm') && !empty($_POST['pildcm_confirmed'])) {
        $plan = get_transient($tkey);
        if (!$plan) {
            echo '<div class="notice notice-error"><p>انتهت صلاحية المعاينة. اختار القطاع تاني.</p></div>';
        } else {
            $counts = ['playbook' => 0, 'program' => 0, 'track' => 0, 'domain' => 0, 'sector' => 0];
            foreach (['playbook', 'program', 'track', 'domain'] as $type) {
                foreach ($plan['collected'][$type] as $pid) {
                    if (wp_delete_post($pid, true)) $counts[$type]++;
                }
            }
            foreach ($plan['sector_ids'] as $pid) {
                if (wp_delete_post($pid, true)) $counts['sector']++;
            }
            delete_transient($tkey);
            echo '<div class="notice notice-success"><p><strong>تم الحذف ✅</strong></p></div>';
            echo '<table class="widefat striped" style="max-width:500px"><tbody>';
            $labels = ['sector' => 'القطاع', 'domain' => 'المجالات', 'track' => 'التراكات', 'program' => 'البرامج', 'playbook' => 'الكتب/البلايبوكس'];
            foreach ($labels as $k => $l) {
                echo '<tr><td>' . esc_html($l) . '</td><td>' . (int) $counts[$k] . ' اتحذفوا</td></tr>';
            }
            echo '</tbody></table>';
        }
    } elseif ($step === 'preview' && check_admin_referer('pildcm_delete_preview') && !empty($_POST['pildcm_sector_code'])) {
        $code = sanitize_text_field(wp_unslash($_POST['pildcm_sector_code']));
        if (!isset($sectors[$code])) {
            echo '<div class="notice notice-error"><p>القطاع ده مش موجود.</p></div>';
        } else {
            $sector_ids = $sectors[$code]['ids'];
            $collected = pildcm_cascade_collect($sector_ids);
            $plan = ['sector_ids' => $sector_ids, 'collected' => $collected, 'code' => $code];
            set_transient($tkey, $plan, HOUR_IN_SECONDS);

            echo '<h2>📋 معاينة الحذف — ' . esc_html(implode(' / ', $sectors[$code]['titles'])) . '</h2>';
            echo '<table class="widefat striped" style="max-width:500px;margin-bottom:20px"><tbody>';
            echo '<tr><td>القطاع نفسه (كل اللغات)</td><td>' . count($sector_ids) . '</td></tr>';
            echo '<tr><td>المجالات</td><td>' . count($collected['domain']) . '</td></tr>';
            echo '<tr><td>التراكات</td><td>' . count($collected['track']) . '</td></tr>';
            echo '<tr><td>البرامج</td><td>' . count($collected['program']) . '</td></tr>';
            echo '<tr><td>الكتب/البلايبوكس</td><td>' . count($collected['playbook']) . '</td></tr>';
            echo '</tbody></table>';

            echo '<form method="post">';
            wp_nonce_field('pildcm_delete_confirm');
            echo '<input type="hidden" name="pildcm_del_step" value="confirm">';
            echo '<p><label><input type="checkbox" name="pildcm_confirmed" value="1" required> أنا متأكد وعاوز أحذف القطاع ده وكل محتواه نهائياً</label></p>';
            submit_button('🗑 تأكيد الحذف النهائي', 'delete');
            echo '</form>';
        }
    }

    echo '<hr><h2>اختار القطاع</h2>';
    echo '<form method="post">';
    wp_nonce_field('pildcm_delete_preview');
    echo '<input type="hidden" name="pildcm_del_step" value="preview">';
    echo '<select name="pildcm_sector_code" required>';
    echo '<option value="">-- اختار --</option>';
    foreach ($sectors as $code => $info) {
        $label = $code . ' — ' . implode(' / ', $info['titles']);
        echo '<option value="' . esc_attr($code) . '">' . esc_html($label) . '</option>';
    }
    echo '</select> ';
    submit_button('🔍 معاينة قبل الحذف', 'secondary', 'submit', false);
    echo '</form>';
    echo '</div>';
}
