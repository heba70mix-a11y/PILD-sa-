<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 28. ADMIN LIST FILTERS — Sector / Domain / Track / Program dropdowns
// ------------------------------------------------------------
// Adds filter dropdowns to the top of the admin list screens so a large
// catalog (hundreds of tracks/programs/books across many sectors) stays
// browsable:
//   - Domains screen  → filter by Sector
//   - Tracks screen   → filter by Sector, Domain
//   - Programs screen → filter by Sector, Domain, Track
//   - Books screen    → filter by Sector, Domain, Track, Program
//
// A filter on an INDIRECT ancestor (e.g. filtering Tracks by Sector,
// two hops away via Domain) is resolved by first collecting the set of
// matching direct-parent IDs, then querying WHERE direct_parent IN (...).
// Uses the same ACF relationship fields as the importer:
//   domain_sector, track_domain, program_track, playbook_program.
// ============================================================

// NOTE: the Domains screen already has its own native Sector filter
// dropdown + "Sector" column (see pild_domain_sector_filter_dropdown()
// and pild_domain_sector_column() in pild-unified.php) — not duplicated here.

add_action('restrict_manage_posts', 'pildcm_filters_render', 10, 2);
function pildcm_filters_render($post_type, $which) {
    if ($which !== 'top') return; // avoid rendering twice (top + bottom)

    switch ($post_type) {
        case 'track':
            pildcm_filters_dropdown('sector', 'pild_filter_sector', 'كل القطاعات');
            pildcm_filters_dropdown('domain', 'pild_filter_domain', 'كل المجالات');
            break;
        case 'program':
            pildcm_filters_dropdown('sector', 'pild_filter_sector', 'كل القطاعات');
            pildcm_filters_dropdown('domain', 'pild_filter_domain', 'كل المجالات');
            pildcm_filters_dropdown('track', 'pild_filter_track', 'كل التراكات');
            break;
        case 'playbook':
            pildcm_filters_dropdown('sector', 'pild_filter_sector', 'كل القطاعات');
            pildcm_filters_dropdown('domain', 'pild_filter_domain', 'كل المجالات');
            pildcm_filters_dropdown('track', 'pild_filter_track', 'كل التراكات');
            pildcm_filters_dropdown('program', 'pild_filter_program', 'كل البرامج');
            break;
    }
}

function pildcm_filters_dropdown($source_post_type, $get_key, $placeholder) {
    $selected = isset($_GET[$get_key]) ? (int) $_GET[$get_key] : 0;
    $posts = get_posts([
        'post_type'      => $source_post_type,
        'posts_per_page' => -1,
        'post_status'    => 'any',
        'orderby'        => 'title',
        'order'          => 'ASC',
    ]);
    if (empty($posts)) return;

    echo '<select name="' . esc_attr($get_key) . '">';
    echo '<option value="0">' . esc_html($placeholder) . '</option>';
    foreach ($posts as $p) {
        echo '<option value="' . (int) $p->ID . '" ' . selected($selected, $p->ID, false) . '>'
            . esc_html(get_the_title($p)) . '</option>';
    }
    echo '</select>';
}

// ── Resolve an indirect (grandparent+) filter into a set of direct-child IDs ──
function pildcm_filters_children_ids($child_post_type, $meta_key, $parent_ids) {
    $parent_ids = array_values(array_filter(array_map('intval', (array) $parent_ids)));
    if (empty($parent_ids)) return [0]; // nothing matches -> force an empty result set safely
    $ids = get_posts([
        'post_type'      => $child_post_type,
        'posts_per_page' => -1,
        'post_status'    => 'any',
        'fields'         => 'ids',
        'meta_query'     => [[ 'key' => $meta_key, 'value' => $parent_ids, 'compare' => 'IN' ]],
    ]);
    return !empty($ids) ? $ids : [0];
}

add_action('pre_get_posts', 'pildcm_filters_apply_query');
function pildcm_filters_apply_query($query) {
    if (!is_admin() || !$query->is_main_query()) return;
    $post_type = $query->get('post_type');
    if (!in_array($post_type, ['track', 'program', 'playbook'], true)) return;

    $sector_id  = !empty($_GET['pild_filter_sector'])  ? (int) $_GET['pild_filter_sector']  : 0;
    $domain_id  = !empty($_GET['pild_filter_domain'])  ? (int) $_GET['pild_filter_domain']  : 0;
    $track_id   = !empty($_GET['pild_filter_track'])   ? (int) $_GET['pild_filter_track']   : 0;
    $program_id = !empty($_GET['pild_filter_program']) ? (int) $_GET['pild_filter_program'] : 0;

    if (!$sector_id && !$domain_id && !$track_id && !$program_id) return;

    $extra_meta_query = [];

    switch ($post_type) {
        case 'track':
            if ($domain_id) {
                $extra_meta_query[] = ['key' => 'track_domain', 'value' => $domain_id];
            } elseif ($sector_id) {
                $domain_ids = pildcm_filters_children_ids('domain', 'domain_sector', [$sector_id]);
                $extra_meta_query[] = ['key' => 'track_domain', 'value' => $domain_ids, 'compare' => 'IN'];
            }
            break;

        case 'program':
            if ($track_id) {
                $extra_meta_query[] = ['key' => 'program_track', 'value' => $track_id];
            } elseif ($domain_id) {
                $track_ids = pildcm_filters_children_ids('track', 'track_domain', [$domain_id]);
                $extra_meta_query[] = ['key' => 'program_track', 'value' => $track_ids, 'compare' => 'IN'];
            } elseif ($sector_id) {
                $domain_ids = pildcm_filters_children_ids('domain', 'domain_sector', [$sector_id]);
                $track_ids  = pildcm_filters_children_ids('track', 'track_domain', $domain_ids);
                $extra_meta_query[] = ['key' => 'program_track', 'value' => $track_ids, 'compare' => 'IN'];
            }
            break;

        case 'playbook':
            if ($program_id) {
                $extra_meta_query[] = ['key' => 'playbook_program', 'value' => $program_id];
            } elseif ($track_id) {
                $program_ids = pildcm_filters_children_ids('program', 'program_track', [$track_id]);
                $extra_meta_query[] = ['key' => 'playbook_program', 'value' => $program_ids, 'compare' => 'IN'];
            } elseif ($domain_id) {
                $track_ids   = pildcm_filters_children_ids('track', 'track_domain', [$domain_id]);
                $program_ids = pildcm_filters_children_ids('program', 'program_track', $track_ids);
                $extra_meta_query[] = ['key' => 'playbook_program', 'value' => $program_ids, 'compare' => 'IN'];
            } elseif ($sector_id) {
                $domain_ids  = pildcm_filters_children_ids('domain', 'domain_sector', [$sector_id]);
                $track_ids   = pildcm_filters_children_ids('track', 'track_domain', $domain_ids);
                $program_ids = pildcm_filters_children_ids('program', 'program_track', $track_ids);
                $extra_meta_query[] = ['key' => 'playbook_program', 'value' => $program_ids, 'compare' => 'IN'];
            }
            break;
    }

    if (empty($extra_meta_query)) return;

    $meta_query = (array) $query->get('meta_query');
    $meta_query = array_merge($meta_query, $extra_meta_query);
    if (count($meta_query) > 1) $meta_query['relation'] = 'AND';
    $query->set('meta_query', $meta_query);
}

// ── Parent-name column on each screen (Domain / Track / Program), same
//    pattern as the existing "Sector" column on the Domains screen — makes
//    it easy to eyeball that a filter result is correct. ──
function pildcm_filters_add_column($columns, $key, $label) {
    $new = [];
    foreach ($columns as $k => $v) {
        $new[$k] = $v;
        if ($k === 'title') $new[$key] = $label;
    }
    return $new;
}
function pildcm_filters_render_column($post_id, $acf_field) {
    $parent_id = function_exists('get_field') ? (int) get_field($acf_field, $post_id) : 0;
    echo $parent_id ? esc_html(get_the_title($parent_id)) : '—';
}

add_filter('manage_track_posts_columns', function ($columns) {
    return pildcm_filters_add_column($columns, 'pild_domain', 'Domain');
});
add_action('manage_track_posts_custom_column', function ($column, $post_id) {
    if ($column === 'pild_domain') pildcm_filters_render_column($post_id, 'track_domain');
}, 10, 2);

add_filter('manage_program_posts_columns', function ($columns) {
    return pildcm_filters_add_column($columns, 'pild_track', 'Track');
});
add_action('manage_program_posts_custom_column', function ($column, $post_id) {
    if ($column === 'pild_track') pildcm_filters_render_column($post_id, 'program_track');
}, 10, 2);

add_filter('manage_playbook_posts_columns', function ($columns) {
    return pildcm_filters_add_column($columns, 'pild_program', 'Program');
});
add_action('manage_playbook_posts_custom_column', function ($column, $post_id) {
    if ($column === 'pild_program') pildcm_filters_render_column($post_id, 'playbook_program');
}, 10, 2);
