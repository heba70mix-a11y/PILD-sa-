<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 27. EXCEL EXPORTER — Sectors → Domains → Tracks → Programs → Books
// ------------------------------------------------------------
// The counterpart to includes/18-excel-importer.php. Produces one
// .xlsx workbook with the SAME 5 sheets and SAME column headers the
// importer reads (pildcm_import_specs()), built straight from the
// live CPT data (sector/domain/track/program/playbook) + their ACF
// relationship fields. Two uses:
//   1. A ready-made, pre-filled TEMPLATE — download it, edit rows in
//      Excel, re-upload through "Import from Excel" to update content.
//   2. A full backup/export of everything currently under a Sector.
//
// Every post gets a stable 'pild_import_code' (same meta key the
// importer already uses for idempotent re-import). If a post doesn't
// have one yet (created by hand in wp-admin, never imported), the
// exporter generates one on the fly and SAVES it back to the post —
// so the code stays identical on every future export/import round-trip.
//
// No external library — same as the importer, this hand-builds the
// .xlsx (a zip of small XML parts) with ZipArchive only.
// ============================================================

add_action('admin_menu', 'pildcm_excel_export_menu');
function pildcm_excel_export_menu() {
    add_submenu_page('pild-settings', 'Export to Excel', 'Export to Excel',
        'manage_options', 'pild-excel-export', 'pildcm_excel_export_page');
}

// ── 27.1 Stable code getter: reuse existing 'pild_import_code', else mint + save one ──
function pildcm_export_get_or_make_code($post_id, $prefix) {
    $code = get_post_meta($post_id, 'pild_import_code', true);
    if ($code !== '' && $code !== false) return $code;
    $code = $prefix . $post_id;
    update_post_meta($post_id, 'pild_import_code', $code);
    return $code;
}

// ── 27.2 English title/content via Polylang, if active + a translation exists ──
function pildcm_export_get_en_post($post_id) {
    if (!function_exists('pll_get_post')) return null;
    $en_id = pll_get_post($post_id, 'en');
    return $en_id ? get_post($en_id) : null;
}

// ── 27.3 Build the 5 sheets (header row + one row per post) from live data ──
function pildcm_export_build_sheets() {
    $type_map_rev = ['book' => 'كتاب', 'activity' => 'نشاط', 'exercise' => 'تمرين'];

    $sheets = [
        'Sectors'  => [['كود_القطاع', 'اسم_القطاع', 'اسم_القطاع_EN', 'الوصف', 'الوصف_EN']],
        'Domains'  => [['كود_المجال', 'اسم_المجال', 'اسم_المجال_EN', 'كود_القطاع_الأب', 'رقم_اختبار_المجال']],
        'Tracks'   => [['كود_التراك', 'اسم_التراك', 'اسم_التراك_EN', 'القدرات', 'القدرات_EN', 'كود_المجال_الأب', 'رقم_اختبار_التراك']],
        'Programs' => [['كود_البرنامج', 'اسم_البرنامج', 'اسم_البرنامج_EN', 'النبذة', 'النبذة_EN', 'الأهداف', 'الأهداف_EN', 'المخرجات', 'المخرجات_EN', 'كود_التراك_الأب']],
        'Books'    => [['كود_الكتاب', 'اسم_الكتاب', 'اسم_الكتاب_EN', 'المحتوى', 'المحتوى_EN', 'كود_البرنامج_الأب', 'النوع']],
    ];

    // code lookup tables, filled as we walk the hierarchy top-down so
    // children can resolve their parent's code.
    $sector_code = []; // sector_id => code
    $domain_code = [];
    $track_code  = [];
    $program_code = [];

    $sectors = get_posts(['post_type' => 'sector', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC']);
    foreach ($sectors as $sector) {
        $code = pildcm_export_get_or_make_code($sector->ID, 'S');
        $sector_code[$sector->ID] = $code;
        $en = pildcm_export_get_en_post($sector->ID);
        $sheets['Sectors'][] = [
            $code, $sector->post_title, $en ? $en->post_title : '',
            $sector->post_excerpt ?: $sector->post_content, $en ? ($en->post_excerpt ?: $en->post_content) : '',
        ];
    }

    $domains = get_posts(['post_type' => 'domain', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC']);
    foreach ($domains as $domain) {
        $code = pildcm_export_get_or_make_code($domain->ID, 'D');
        $domain_code[$domain->ID] = $code;
        $en = pildcm_export_get_en_post($domain->ID);
        $parent_id = (int) get_post_meta($domain->ID, 'domain_sector', true);
        $quiz_id   = (int) get_post_meta($domain->ID, 'domain_quiz_id', true);
        $sheets['Domains'][] = [
            $code, $domain->post_title, $en ? $en->post_title : '',
            isset($sector_code[$parent_id]) ? $sector_code[$parent_id] : '',
            $quiz_id ?: '',
        ];
    }

    $tracks = get_posts(['post_type' => 'track', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC']);
    foreach ($tracks as $track) {
        $code = pildcm_export_get_or_make_code($track->ID, 'T');
        $track_code[$track->ID] = $code;
        $en = pildcm_export_get_en_post($track->ID);
        $parent_id = (int) get_post_meta($track->ID, 'track_domain', true);
        $quiz_id   = (int) get_post_meta($track->ID, 'track_quiz_id', true);
        $sheets['Tracks'][] = [
            $code, $track->post_title, $en ? $en->post_title : '',
            $track->post_excerpt ?: $track->post_content, $en ? ($en->post_excerpt ?: $en->post_content) : '',
            isset($domain_code[$parent_id]) ? $domain_code[$parent_id] : '',
            $quiz_id ?: '',
        ];
    }

    $programs = get_posts(['post_type' => 'program', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC']);
    foreach ($programs as $program) {
        $code = pildcm_export_get_or_make_code($program->ID, 'P');
        $program_code[$program->ID] = $code;
        $en = pildcm_export_get_en_post($program->ID);
        $parent_id = (int) get_post_meta($program->ID, 'program_track', true);
        $goals    = function_exists('get_field') ? (string) get_field('program_goals', $program->ID)    : '';
        $outcomes = function_exists('get_field') ? (string) get_field('program_outcomes', $program->ID) : '';
        $goals_en    = ($en && function_exists('get_field')) ? (string) get_field('program_goals', $en->ID)    : '';
        $outcomes_en = ($en && function_exists('get_field')) ? (string) get_field('program_outcomes', $en->ID) : '';
        $sheets['Programs'][] = [
            $code, $program->post_title, $en ? $en->post_title : '',
            $program->post_excerpt, $en ? $en->post_excerpt : '',
            $goals, $goals_en, $outcomes, $outcomes_en,
            isset($track_code[$parent_id]) ? $track_code[$parent_id] : '',
        ];
    }

    $books = get_posts(['post_type' => 'playbook', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC']);
    foreach ($books as $book) {
        $code = pildcm_export_get_or_make_code($book->ID, 'B');
        $en = pildcm_export_get_en_post($book->ID);
        $parent_id = (int) get_post_meta($book->ID, 'playbook_program', true);
        $ptype = function_exists('get_field') ? get_field('playbook_type', $book->ID) : get_post_meta($book->ID, 'playbook_type', true);
        $sheets['Books'][] = [
            $code, $book->post_title, $en ? $en->post_title : '',
            $book->post_content, $en ? $en->post_content : '',
            isset($program_code[$parent_id]) ? $program_code[$parent_id] : '',
            isset($type_map_rev[$ptype]) ? $type_map_rev[$ptype] : 'كتاب',
        ];
    }

    return $sheets;
}

// ── 27.4 Minimal .xlsx writer (ZipArchive only, inline strings — no sharedStrings table needed) ──
function pildcm_xlsx_col_letter($idx) {
    $idx++; $letters = '';
    while ($idx > 0) {
        $rem = ($idx - 1) % 26;
        $letters = chr(65 + $rem) . $letters;
        $idx = intdiv($idx - 1, 26);
    }
    return $letters;
}

function pildcm_xlsx_escape($s) {
    $s = (string) $s;
    // strip control chars invalid in XML 1.0 (keep tab/newline/CR)
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s);
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function pildcm_xlsx_sheet_xml($rows) {
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
    $xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
    foreach ($rows as $r => $row) {
        $rowNum = $r + 1;
        $xml .= '<row r="' . $rowNum . '">';
        foreach ($row as $c => $val) {
            if ($val === '' || $val === null) continue;
            $ref = pildcm_xlsx_col_letter($c) . $rowNum;
            $xml .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . pildcm_xlsx_escape($val) . '</t></is></c>';
        }
        $xml .= '</row>';
    }
    $xml .= '</sheetData></worksheet>';
    return $xml;
}

/**
 * Builds the .xlsx file on disk (temp file) and returns its path.
 * $sheets = ['Sheet Name' => [ [header,...], [row,...], ... ], ... ]
 */
function pildcm_xlsx_build($sheets) {
    if (!class_exists('ZipArchive')) {
        return new WP_Error('no_zip', 'السيرفر مش متاح عليه ZipArchive (لازم تفعيل PHP Zip extension) — كلم الاستضافة.');
    }

    $tmp_path = wp_tempnam('pild-export.xlsx');
    $zip = new ZipArchive();
    if ($zip->open($tmp_path, ZipArchive::OVERWRITE) !== true) {
        return new WP_Error('xlsx_write_failed', 'تعذر إنشاء ملف الإكسيل.');
    }

    $names = array_keys($sheets);
    $n = count($names);

    // [Content_Types].xml
    $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
    for ($i = 1; $i <= $n; $i++) {
        $ct .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
    }
    $ct .= '</Types>';
    $zip->addFromString('[Content_Types].xml', $ct);

    // _rels/.rels
    $zip->addFromString('_rels/.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>'
    );

    // xl/workbook.xml
    $wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
    foreach ($names as $i => $name) {
        $sid = $i + 1;
        $wb .= '<sheet name="' . pildcm_xlsx_escape($name) . '" sheetId="' . $sid . '" r:id="rId' . $sid . '"/>';
    }
    $wb .= '</sheets></workbook>';
    $zip->addFromString('xl/workbook.xml', $wb);

    // xl/_rels/workbook.xml.rels (sheets rId1..rIdN, styles rId(N+1))
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    foreach ($names as $i => $name) {
        $sid = $i + 1;
        $rels .= '<Relationship Id="rId' . $sid . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $sid . '.xml"/>';
    }
    $rels .= '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
    $rels .= '</Relationships>';
    $zip->addFromString('xl/_rels/workbook.xml.rels', $rels);

    // xl/styles.xml (minimal, required by strict readers)
    $zip->addFromString('xl/styles.xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
        . '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
        . '<borders count="1"><border/></borders>'
        . '<cellStyleXfs count="1"><xf/></cellStyleXfs>'
        . '<cellXfs count="1"><xf/></cellXfs>'
        . '</styleSheet>'
    );

    // xl/worksheets/sheetN.xml
    foreach (array_values($sheets) as $i => $rows) {
        $sid = $i + 1;
        $zip->addFromString('xl/worksheets/sheet' . $sid . '.xml', pildcm_xlsx_sheet_xml($rows));
    }

    $zip->close();
    return $tmp_path;
}

// ── 27.5 Admin page: one button, streams the .xlsx straight to the browser ──
function pildcm_excel_export_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['pildcm_export_now']) && check_admin_referer('pildcm_export_action')) {
        $sheets = pildcm_export_build_sheets();
        $file = pildcm_xlsx_build($sheets);
        if (is_wp_error($file)) {
            echo '<div class="wrap"><div class="notice notice-error"><p>' . esc_html($file->get_error_message()) . '</p></div></div>';
        } else {
            nocache_headers();
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="pild-sectors-export-' . gmdate('Y-m-d') . '.xlsx"');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            @unlink($file);
            exit;
        }
    }

    echo '<div class="wrap"><h1>📤 تصدير بيانات القطاعات إلى إكسيل</h1>';
    echo '<p style="max-width:640px;color:#555;">بيصدّر ملف <code>.xlsx</code> فيه كل القطاعات والمجالات والتراكات والبرامج والكتب الموجودة حالياً على الموقع — بنفس الشيتات والأعمدة اللي شاشة "استيراد من إكسيل" بتفهمها بالظبط. تقدر تستخدمه كـ:</p>';
    echo '<ul style="list-style:disc;margin-inline-start:24px;max-width:640px;color:#555;">'
        . '<li>نسخة احتياطية كاملة من بيانات القطاعات.</li>'
        . '<li>قالب جاهز اتعبّى بالبيانات الحالية — تعدّل فيه في إكسيل وترفعه تاني من "استيراد من إكسيل" عشان يحدّث نفس العناصر (مش يكرّرها).</li>'
        . '</ul>';
    echo '<form method="post">';
    wp_nonce_field('pildcm_export_action');
    echo '<input type="hidden" name="pildcm_export_now" value="1">';
    submit_button('📤 تصدير الآن (.xlsx)');
    echo '</form></div>';
}
