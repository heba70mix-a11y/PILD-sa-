<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 26. "REGISTER" BUTTON AUDIENCE ROUTING
// ------------------------------------------------------------
// Sends every "سجل / Register" button (Sector Explorer cards + the
// single track/domain detail pages) to the correct WooCommerce
// product — the Individual version or the Team version — instead of
// the old direct-to-database self-enrollment flow that used to live
// in 17-sector-explorer.php (wp_ajax_pild_ex_self_enroll). That old
// AJAX action, and its two handlers, have been removed from this
// codebase: a click on "Register" must always end on a real product
// page so the visitor actually pays for/claims a seat, never a free
// silent enrollment row.
//
// Priority used to pick Individual vs Team (see pild_get_registration_
// context() below):
//   1. Logged-in user's REAL role — Team Owner or Team Member (or an
//      approved Training Partner, who gets the team product priced
//      through their tier via includes/14-partner-pricing.php,
//      untouched) -> Team. Everyone else logged in -> Individual.
//   2. Guest: whichever audience tab ("For Individuals" / "For
//      Organizations") they most recently landed on in the site
//      header, persisted for the rest of the browser session via a
//      cookie (see pild_get/set_audience_session_context()).
//   3. Default: Individual.
//
// ASSUMPTIONS MADE (flagged as open questions in the original spec —
// proceeding with these rather than blocking; revisit if wrong):
//   - Session storage: a plain, session-length cookie (setcookie(),
//     expires=0 -> cleared when the browser closes) rather than
//     $_SESSION or a transient. Cookies are what a full-page-cache
//     layer can actually see and vary on; PHP sessions generally
//     aren't started on a cached front end and a transient would
//     need a stable per-guest key we don't have pre-login.
//   - Single track/domain detail pages: this file assumes the site
//     already has real singular templates for the 'track' and
//     'domain' post types (is_singular('track'/'domain') resolves to
//     an actual page) — that's what pild_reg_maybe_bypass_full_page_
//     cache() below hooks into. If those templates don't exist yet,
//     the "secondary switch link" behavior described in the spec has
//     nowhere to render outside of the Sector Explorer's own in-page
//     track/domain detail views, which this file also wires up.
//   - Shortcode file: confirmed as includes/17-sector-explorer.php,
//     shortcode 'pild_sector_explorer' — the file named in the spec
//     matches what's actually in the plugin.
// ============================================================

// ── 26.1 ACF fields: product links on Track AND Domain ─────────────
// Same two fields on both post types (a Domain only needs them filled
// in when it's sold as a whole bundle — see the fallback logic in
// pild_get_product_link_for_post() below). No third field for
// Training Partners: they resolve to the same Team product, priced
// via includes/14-partner-pricing.php.
add_action('acf/init', 'pild_reg_add_product_link_fields');
function pild_reg_add_product_link_fields() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'      => 'group_pild_registration_products',
        'title'    => 'Registration — Linked Products',
        'fields'   => [
            [
                'key'          => 'field_pild_product_individual',
                'label'        => 'Individual Product',
                'name'         => 'pild_product_individual',
                'type'         => 'post_object',
                'post_type'    => ['product'],
                'multiple'     => 0,
                'return_format'=> 'id',
                'instructions' => 'The WooCommerce product an individual visitor is sent to when they click "Register". For a Track, leave blank to fall back to the parent Practice Area\'s Individual Product (if that is sold as a whole bundle).',
                'required'     => 0,
            ],
            [
                'key'          => 'field_pild_product_team',
                'label'        => 'Team Product',
                'name'         => 'pild_product_team',
                'type'         => 'post_object',
                'post_type'    => ['product'],
                'multiple'     => 0,
                'return_format'=> 'id',
                'instructions' => 'The WooCommerce product (with seat-count selection) a Team Owner, Team Member, or approved Training Partner is sent to when they click "Register". For a Track, leave blank to fall back to the parent Practice Area\'s Team Product.',
                'required'     => 0,
            ],
        ],
        'location' => [
            [['param' => 'post_type', 'operator' => '==', 'value' => 'track']],
            [['param' => 'post_type', 'operator' => '==', 'value' => 'domain']],
        ],
    ]);
}

// ── 26.1b PRICING LEVEL (6-product model) ───────────────────────────
// Client decision (Aug 2026): instead of a dedicated WooCommerce product
// per track (600+ products), tracks are tagged with a PRICING LEVEL only,
// and 6 shared products cover every track — one Individual + one Team
// product per level. "Level" here is an ADMINISTRATIVE PRICING CATEGORY
// ONLY: it says nothing about a track's real difficulty or content depth
// (there is no such concept in this catalog), so this field must never
// be shown to the public or used anywhere except resolving which of the
// 6 products to sell.
//
// PLAIN TEXT, not a fixed dropdown: the exact wording of the 3 levels is
// the client's own call (seen so far as both "متخصص" and "تنفيذي" for the
// top tier across different files) and is set by uploading
// includes/31-pricing-importer.php's Products sheet — not hardcoded here.
// A track's value just has to match, character-for-character, whatever
// _pild_level a product was tagged with; pild_pricing_levels() (used for
// validation/warnings only) reads the live, real set from the products
// that actually exist rather than a fixed list.
//
// The 6 products themselves are tagged via _pild_level / _pild_variant
// product meta (see 26.1c below) instead of being linked one-by-one from
// every track. pild_get_product_id_for_post() (26.5) tries this level
// lookup FIRST, and only falls back to the explicit Individual/Team
// Product fields above (26.1) when a track has no pricing level set —
// this keeps any track/domain that was already wired to its own
// dedicated product working exactly as before, so nothing already
// configured breaks.
function pild_pricing_levels() {
    global $wpdb;
    static $levels = null;
    if ($levels !== null) return $levels;
    $levels = $wpdb->get_col(
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_pild_level' AND meta_value != ''"
    );
    return $levels;
}

add_action('acf/init', 'pild_reg_add_track_pricing_level_field');
function pild_reg_add_track_pricing_level_field() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'    => 'group_pild_track_pricing_level',
        'title'  => 'Pricing Level (internal — for product routing only)',
        'fields' => [
            [
                'key'          => 'field_pild_track_pricing_level',
                'label'        => 'المستوى السعري',
                'name'         => 'track_pricing_level',
                'type'         => 'text',
                'instructions' => 'تصنيف سعري إداري بس — مش وصف لصعوبة أو مضمون التراك، ومش هيظهر للزوار في أي مكان. القيمة لازم تطابق حرفيًا "المستوى" المكتوب على أحد الـ6 منتجات المشتركة (شوف Import Track Pricing لملء الحقل ده تلقائي بدل الكتابة اليدوية). سيبه فاضي لو التراك لسه مرتبط بمنتج مخصص له في الحقول اللي فوق.',
                'required'     => 0,
            ],
        ],
        'location' => [
            [['param' => 'post_type', 'operator' => '==', 'value' => 'track']],
        ],
    ]);
}

// ── 26.1c The 6 shared level products: admin tagging fields ─────────
// Mirrors the pattern in includes/24-team-purchase.php (min-seats field
// on the product edit screen). Level is free text for the same reason as
// track_pricing_level above (wording is the client's own file, not
// hardcoded here) — Variant stays a fixed dropdown since "individual" vs
// "team" is a real code-level distinction the rest of the plugin branches
// on, not just a label.
add_action('woocommerce_product_options_pricing', 'pild_level_product_fields');
function pild_level_product_fields() {
    global $post;
    if (!$post) return;
    echo '<div class="options_group">';
    woocommerce_wp_text_input([
        'id'          => '_pild_level',
        'label'       => __('PILD — Pricing level', 'pild-unified'),
        'description' => __('Set this on the 6 shared level products only (matches the "المستوى" text used for this level — see Import Track Pricing). Leave blank for any other (e.g. legacy per-track) product.', 'pild-unified'),
        'desc_tip'    => true,
    ]);
    woocommerce_wp_select([
        'id'          => '_pild_variant',
        'label'       => __('PILD — Variant', 'pild-unified'),
        'options'     => [
            ''           => __('— none —', 'pild-unified'),
            'individual' => __('Individual', 'pild-unified'),
            'team'       => __('Team (org / partner)', 'pild-unified'),
        ],
    ]);
    echo '</div>';
}
add_action('woocommerce_process_product_meta', 'pild_level_product_fields_save');
function pild_level_product_fields_save($post_id) {
    // sanitize_text_field, NOT sanitize_key — the level is Arabic text
    // (e.g. "أساسي"), and sanitize_key() would silently strip it to an
    // empty string (it only keeps [a-z0-9_-]).
    $level   = isset($_POST['_pild_level'])   ? sanitize_text_field(wp_unslash($_POST['_pild_level'])) : '';
    $variant = isset($_POST['_pild_variant']) ? sanitize_key(wp_unslash($_POST['_pild_variant'])) : '';
    update_post_meta($post_id, '_pild_level', $level);
    update_post_meta($post_id, '_pild_variant', in_array($variant, ['individual','team'], true) ? $variant : '');
    delete_transient('pild_level_product_map');
    delete_transient('pild_team_product_ids'); // 24-team-purchase.php's cache — variant=team may have just changed
    pild_flush_sector_explorer_cache(); // a product's price/level changing invalidates every cached catalog page
}

// ── 26.12 Catalog-cache invalidation ─────────────────────────────────
// Clears every language's cached Sector Explorer payload (see
// pild_render_sector_explorer() in includes/17-sector-explorer.php).
// A direct wildcard DELETE rather than looping known languages, since
// this only runs on an edit/import (rare), not per page view, and it
// works regardless of which Polylang languages exist on a given site.
function pild_flush_sector_explorer_cache() {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_pild\_sxd\_%' OR option_name LIKE '\_transient\_timeout\_pild\_sxd\_%'" );
}
// Any edit to a catalog post type invalidates it — covers manual admin
// edits; includes/18-excel-importer.php and includes/31-pricing-
// importer.php also call this directly at the end of their own
// bulk-import runs (a save_post per row would otherwise fire hundreds
// of times during one import).
add_action('save_post', function ($post_id) {
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
    if (in_array(get_post_type($post_id), ['sector', 'domain', 'track', 'program', 'playbook'], true)) {
        pild_flush_sector_explorer_cache();
    }
});

// Resolve (level, variant) -> the one shared product ID, or 0. Cached
// as a single small map (6 entries) rather than one transient per
// lookup — cheap to rebuild, rebuilt whenever any product is saved.
// Resolves to the right product for (level, variant), and — when a
// Polylang translation pair both got tagged with the SAME level/variant
// (see includes/31-pricing-importer.php's Products import) — to the one
// matching the visitor's current front-end language, falling back to
// whichever exists if there's no language match or Polylang isn't active.
function pild_get_level_product_id($level, $variant) {
    if (!in_array($level, pild_pricing_levels(), true)) return 0;
    if (!in_array($variant, ['individual', 'team'], true)) return 0;

    $map = get_transient('pild_level_product_map');
    if ($map === false) {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT p.ID, lvl.meta_value AS level, var.meta_value AS variant
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} lvl ON lvl.post_id = p.ID AND lvl.meta_key = '_pild_level'
             INNER JOIN {$wpdb->postmeta} var ON var.post_id = p.ID AND var.meta_key = '_pild_variant'
             WHERE p.post_type = 'product' AND p.post_status = 'publish'
               AND lvl.meta_value != '' AND var.meta_value != ''"
        );
        // Every matching product id per (level,variant) key — not just
        // one — since an AR/EN translation pair legitimately share the
        // same level+variant tags.
        $map = [];
        foreach ($rows as $r) {
            $map[$r->level . '|' . $r->variant][] = (int) $r->ID;
        }
        set_transient('pild_level_product_map', $map, 5 * MINUTE_IN_SECONDS);
    }

    $candidates = isset($map[$level . '|' . $variant]) ? $map[$level . '|' . $variant] : [];
    if (empty($candidates)) return 0;
    if (count($candidates) === 1) return (int) $candidates[0];

    if (function_exists('pll_current_language') && function_exists('pll_get_post_language')) {
        $current_lang = pll_current_language();
        foreach ($candidates as $pid) {
            if (pll_get_post_language($pid) === $current_lang) return (int) $pid;
        }
    }
    return (int) $candidates[0];
}

// ── 26.1d Single source of truth for the 3 audience tabs ────────────
// The nav header (a separate WPCode snippet, outside this plugin) reads
// this list via PHP at render time instead of keeping its own hardcoded
// copy — so adding a 4th audience someday only means changing it HERE,
// not hunting through the nav snippet too (that's exactly how "partners"
// went missing in 3 different spots in the nav snippet before). The
// snippet keeps a small hardcoded fallback of its own for the rare case
// this plugin is deactivated, but normally always uses this list.
function pild_get_audience_tabs() {
    return apply_filters('pild_audience_tabs', [
        ['key' => 'individuals',   'ar' => 'للأفراد',            'en' => 'For Individuals',       'slug' => 'for-individuals/'],
        ['key' => 'organizations', 'ar' => 'للمنظمات',           'en' => 'For Organizations',     'slug' => 'for-organizations/'],
        ['key' => 'partners',      'ar' => 'لشركاء التدريب',      'en' => 'For Training Partners',  'slug' => 'for-training-center/'],
    ]);
}
function pild_get_audience_values() {
    return wp_list_pluck(pild_get_audience_tabs(), 'key');
}

// ── 26.2 Role checks ────────────────────────────────────────────────
// PHASE 4: this used to duplicate a DB-then-API-fallback check against
// the WC Memberships for Teams extension in three places (see the old
// comment this replaces). Now that includes/23-teams-core.php is the
// single source of truth for team ownership, all three collapse to the
// same one straightforward query — no more fallback API call needed
// since there is no external extension left to fall back to.
function pild_user_is_team_owner($user_id) {
    return function_exists('pildcm_is_team_manager') && pildcm_is_team_manager((int) $user_id);
}

function pild_user_is_team_member($user_id) {
    $user_id = (int) $user_id;
    if (!$user_id) return false;

    global $wpdb;
    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id=%d AND role='member' LIMIT 1", $user_id
    ));
}

// ── 26.3 Guest audience-session context (cookie) ───────────────────
if (!defined('PILD_AUDIENCE_COOKIE')) define('PILD_AUDIENCE_COOKIE', 'pild_audience_ctx');

// Reads the header's "For Individuals" / "For Organizations" / "For
// Training Partners" tab the visitor last landed on. Returns
// 'organizations', 'individuals', 'partners', or '' (never set yet).
function pild_get_audience_session_context() {
    if (!empty($_COOKIE[PILD_AUDIENCE_COOKIE])) {
        $val = sanitize_key(wp_unslash($_COOKIE[PILD_AUDIENCE_COOKIE]));
        if (in_array($val, pild_get_audience_values(), true)) return $val;
    }
    return '';
}

function pild_set_audience_session_context($value) {
    $value = in_array($value, pild_get_audience_values(), true) ? $value : 'individuals';
    // expires=0 -> session cookie, so the context lasts "for the rest
    // of the visit" (per spec) and nothing longer than that.
    setcookie(PILD_AUDIENCE_COOKIE, $value, 0, (defined('COOKIEPATH') && COOKIEPATH) ? COOKIEPATH : '/', defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '', is_ssl(), false);
    $_COOKIE[PILD_AUDIENCE_COOKIE] = $value; // reflect immediately within this same request
}

// Client decision (Sep 2026): an approved Training Partner is the one
// role check that's never affected by which of the three header tabs a
// visitor happens to be on — see pild_get_registration_context() below.
function pild_is_approved_partner($user_id = 0) {
    $user_id = $user_id ?: get_current_user_id();
    return $user_id && function_exists('pildcm_is_training_partner') && pildcm_is_training_partner((int) $user_id);
}

// The Training Partner application form — used by the "سجل كشريك" CTA
// (see includes/17-sector-explorer.php) shown to anyone browsing the
// Partners tab who isn't an approved partner yet. Swaps /ar/ for /en/
// on the English site, matching this site's own URL convention; adjust
// here (or filter 'pild_partner_apply_url') if English uses a different
// path entirely.
function pild_partner_apply_url() {
    $url = 'https://pild.org/ksa/ar/for-training-center/partnership-application/';
    if (function_exists('pll_current_language') && pll_current_language() === 'en') {
        $url = str_replace('/ar/', '/en/', $url);
    }
    return apply_filters('pild_partner_apply_url', $url);
}

// ── 26.4 The central priority function from the spec ───────────────
// Returns one of:
//   'partner'      — an approved Training Partner: ALWAYS one button,
//                     their own per-seat price (applied automatically
//                     by includes/14-partner-pricing.php), never the
//                     individual/team choice — regardless of which
//                     header tab they're on.
//   'partner_gate' — anyone (logged in or not) currently on the
//                     Partners tab who ISN'T an approved partner: no
//                     price, no individual/team choice, just the
//                     "Apply as a Training Partner" CTA.
//   'team' / 'individual' — unchanged from before.
function pild_get_registration_context() {
    if (pild_is_approved_partner()) {
        return 'partner';
    }

    // Client decision (Sep 2026, includes/35-purchase-category.php): a user
    // who applied as a Training Partner but hasn't been approved yet is
    // locked out of buying ANYTHING (individual or team) until an admin
    // grants pild_training_partner — checked before the role check below
    // so it also catches an existing team owner/member who applied.
    if (is_user_logged_in() && function_exists('pild_is_partner_pending') && pild_is_partner_pending(get_current_user_id())) {
        return 'partner_pending';
    }

    if (pild_get_audience_session_context() === 'partners') {
        return 'partner_gate';
    }

    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        if (pild_user_is_team_owner($user_id) || pild_user_is_team_member($user_id)) {
            return 'team';
        }
        // Client decision (Sep 2026): a logged-in visitor with no team yet
        // is NOT forced to "individual" anymore — they get the same
        // explicit Individual/Organization/Training-Center choice a guest
        // gets (the card-level selector in 17-sector-explorer.php), instead
        // of being silently locked to the individual price. Falls through
        // to the same audience-session-context check guests use below.
    }

    if (pild_get_audience_session_context() === 'organizations') {
        return 'team';
    }
    return 'individual';
}

// ── 26.5 Resolve a Track/Domain post -> the right product URL ──────
// $variant is 'individual' or 'team'. Resolution order:
//   1. Level-based lookup (26.1b/26.1c): if this Track has a Pricing
//      Level set, use the matching one of the 6 shared products.
//   2. Legacy explicit product field (26.1) on the Track itself.
//   3. Legacy explicit product field on the parent Domain (the "sold
//      as a whole practice area" bundle fallback).
// Returns 0 when nothing is configured at all.
function pild_get_product_id_for_post($post_id, $variant) {
    $post_id = (int) $post_id;
    if (!$post_id || !in_array($variant, ['individual', 'team'], true)) return 0;

    if (get_post_type($post_id) === 'track' && function_exists('get_field')) {
        $level = get_field('track_pricing_level', $post_id);
        if ($level) {
            $product_id = pild_get_level_product_id($level, $variant);
            if ($product_id) return $product_id;
            // Level is set but no matching product exists yet (the 6
            // products haven't all been tagged) — don't silently fall
            // through to a possibly-unrelated legacy product; treat as
            // "not available" so the gap is visible instead of hidden.
            return 0;
        }
    }

    if (!function_exists('get_field')) return 0;
    $field = ($variant === 'team') ? 'pild_product_team' : 'pild_product_individual';
    $product_id = (int) get_field($field, $post_id);

    if (!$product_id && get_post_type($post_id) === 'track') {
        $domain_id = (int) get_post_meta($post_id, 'track_domain', true);
        if ($domain_id) {
            $product_id = (int) get_field($field, $domain_id);
        }
    }

    return ($product_id && get_post_status($product_id) === 'publish') ? $product_id : 0;
}

function pild_get_product_link_for_post($post_id, $variant) {
    $product_id = pild_get_product_id_for_post($post_id, $variant);
    if (!$product_id) return '';
    $link = get_permalink($product_id);
    return $link ? $link : '';
}

// Formatted price (WooCommerce HTML, e.g. "150 ر.س") for a Track's
// resolved product of the given variant, or '' when unavailable. This
// is the visitor's BASE price — an approved Training Partner's own
// reduced tier (includes/14-partner-pricing.php) still overrides it
// automatically once they're actually looking at the cart/product, so
// this is shown as an indicative "starting" price only.
function pild_get_track_price_html($post_id, $variant) {
    $product_id = pild_get_product_id_for_post($post_id, $variant);
    if (!$product_id) return '';
    $product = function_exists('wc_get_product') ? wc_get_product($product_id) : null;
    return $product ? $product->get_price_html() : '';
}

// Convenience wrapper matching the spec's exact function name/shape —
// resolves both the audience context AND the product link in one
// call. Not used by the (cache-safe) Sector Explorer JSON, which
// instead ships both the Individual and Team URLs and lets the
// browser pick client-side (see 26.7) — kept here for any other,
// non-cached, server-rendered spot that wants the resolved link
// directly (e.g. a future single track/domain PHP template).
function pild_get_registration_link($track_or_domain_id) {
    $context = pild_get_registration_context();
    $link = pild_get_product_link_for_post($track_or_domain_id, $context);
    if ($link) return $link;

    // Nothing configured for the preferred variant — better to send
    // the visitor to whatever IS configured than to a dead link.
    $other = ($context === 'team') ? 'individual' : 'team';
    return pild_get_product_link_for_post($track_or_domain_id, $other);
}

// ── 26.6 AJAX: read + switch the audience context ───────────────────
// These are the "AJAX Fragment" the caching note below refers to —
// the Sector Explorer's own HTML never bakes in a visitor-specific
// register link, so the page itself stays perfectly cacheable; only
// these two small, explicitly non-cached calls carry per-visitor
// state, fired after the page has already loaded.
add_action('wp_ajax_pild_reg_get_context', 'pild_ajax_reg_get_context');
add_action('wp_ajax_nopriv_pild_reg_get_context', 'pild_ajax_reg_get_context');
function pild_ajax_reg_get_context() {
    nocache_headers(); // never let a reverse proxy / page cache store this response

    $cart_tracks = [];
    if (function_exists('WC') && WC()->cart) {
        foreach (WC()->cart->get_cart() as $item) {
            if (!empty($item['pild_track_id'])) {
                $cart_tracks[] = [
                    'track_id' => (int) $item['pild_track_id'],
                    'variant'  => isset($item['pild_variant']) ? $item['pild_variant'] : '',
                ];
            }
        }
    }

    wp_send_json_success([
        'mode'       => pild_get_registration_context(),
        // Only a guest can move between Individual/Team via the switch
        // link — a logged-in visitor's mode is their real role. (An
        // approved partner or the partner-gate view never show the
        // toggle at all regardless of this flag — see bindAudienceToggle
        // in includes/17-sector-explorer.php.)
        'switchable'       => !is_user_logged_in(),
        'cart_tracks'      => $cart_tracks,
        'checkout_url'     => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : '',
        'partner_apply_url'=> pild_partner_apply_url(),
    ]);
}

// ── 26.9 AJAX: "سجل في التراك" — add straight to cart, no product page ──
// Replaces the old "click -> navigate to product page -> add to cart
// there" flow. Individual clicks add one seat immediately; Team/Partner
// clicks are expected to have already collected a seat count (the
// front-end shows a seat-count prompt before calling this — see
// includes/17-sector-explorer.php) enforced again here server-side.
//
// The resolved product is one of the 6 shared level products (or a
// legacy dedicated one) — either way we tag the CART LINE itself with
// which track it was for (pild_track_id / pild_variant), since the
// product alone no longer identifies the track once it's shared across
// many tracks. This is what lets pild_team_create_from_purchase() (see
// includes/24-team-purchase.php) and pild_auto_enroll_tracks_from_
// purchase() (see pild-unified.php) know which track an order line was
// actually for. WooCommerce naturally keeps cart lines with different
// custom data on separate rows, so two different tracks that happen to
// share the same level product never merge into one line/quantity.
add_action('wp_ajax_pild_reg_add_to_cart', 'pild_ajax_reg_add_to_cart');
add_action('wp_ajax_nopriv_pild_reg_add_to_cart', 'pild_ajax_reg_add_to_cart');
function pild_ajax_reg_add_to_cart() {
    nocache_headers();
    check_ajax_referer('pild_reg_ctx', 'nonce');

    $track_id = isset($_POST['track_id']) ? (int) $_POST['track_id'] : 0;
    $variant  = isset($_POST['variant'])  ? sanitize_key(wp_unslash($_POST['variant'])) : '';
    $seats    = isset($_POST['seats'])    ? (int) $_POST['seats'] : 0;

    // Client decision (Sep 2026): a pending-but-not-yet-approved Training
    // Partner application locks the account out of purchasing entirely —
    // enforced here too (not just in the button HTML) since this is the
    // real point of sale.
    if (is_user_logged_in() && function_exists('pild_is_partner_pending') && pild_is_partner_pending(get_current_user_id())) {
        wp_send_json_error(['message' => __('طلب الشراكة بتاعك لسه قيد المراجعة — التسجيل هيتفتح تلقائي بمجرد الموافقة.', 'pild-unified'), 'pending' => true]);
    }

    if (!$track_id || get_post_type($track_id) !== 'track' || get_post_status($track_id) !== 'publish') {
        wp_send_json_error(['message' => __('التراك ده مش موجود.', 'pild-unified')]);
    }
    if (!in_array($variant, ['individual', 'team'], true)) {
        wp_send_json_error(['message' => __('نوع تسجيل غير صالح.', 'pild-unified')]);
    }
    // Client decision (Sep 2026): don't force login just to add to cart —
    // an org buyer browses/adds exactly like an individual. The team
    // still needs a real account to be OWNED BY once the order is
    // actually placed (a true anonymous guest order has no user to make
    // a team owner — see pild_team_create_from_purchase() in
    // includes/24-team-purchase.php), so that's enforced at CHECKOUT
    // instead (26.13 below), not here.
    if (!function_exists('WC') || !WC()->cart) {
        wp_send_json_error(['message' => __('الدفع غير متاح مؤقتًا.', 'pild-unified')]);
    }

    $product_id = pild_get_product_id_for_post($track_id, $variant);
    if (!$product_id) {
        wp_send_json_error(['message' => __('التسجيل غير متاح حاليًا لهذا التراك.', 'pild-unified'), 'unavailable' => true]);
    }

    // Already in the cart? Don't add a duplicate line — tell the front
    // end so it can show the same "already in cart" state as if this
    // had just been added, instead of erroring.
    foreach (WC()->cart->get_cart() as $item) {
        if (!empty($item['pild_track_id']) && (int) $item['pild_track_id'] === $track_id
            && isset($item['pild_variant']) && $item['pild_variant'] === $variant) {
            wp_send_json_success([
                'already_in_cart' => true,
                'checkout_url'    => wc_get_checkout_url(),
                'track_id'        => $track_id,
                'variant'         => $variant,
            ]);
        }
    }

    $qty = 1;
    if ($variant === 'team') {
        $min = function_exists('pild_team_min_seats') ? pild_team_min_seats($product_id) : 5;
        $qty = max($min, $seats ?: $min);
    }

    $cart_item_data = [
        'pild_track_id'    => $track_id,
        // BUGFIX: plain get_the_title() ignores the visitor's current
        // language entirely — it just returns whatever language that one
        // literal $track_id happens to be. Every other place in the
        // plugin that shows a track title uses pild_bilingual_title()
        // (includes/02-helpers.php) for exactly this reason; this was the
        // one spot still using the raw, language-blind call.
        'pild_track_title' => pild_bilingual_title($track_id),
        'pild_variant'     => $variant,
    ];

    $cart_item_key = WC()->cart->add_to_cart($product_id, $qty, 0, [], $cart_item_data);
    if (!$cart_item_key) {
        wp_send_json_error(['message' => __('حصل خطأ وإحنا بنضيف التراك للسلة — جرّب تاني.', 'pild-unified')]);
    }

    wp_send_json_success([
        'checkout_url' => wc_get_checkout_url(),
        'track_id'     => $track_id,
        'variant'      => $variant,
        'seats'        => $qty,
    ]);
}

// ── 26.10 Cart line -> shows which track it's for ────────────────────
add_filter('woocommerce_get_item_data', 'pild_cart_item_show_track', 10, 2);
function pild_cart_item_show_track($item_data, $cart_item) {
    if (!empty($cart_item['pild_track_title'])) {
        $item_data[] = [
            // BUGFIX: this was hardcoded as the Arabic literal 'التراك'
            // (not an English msgid translated to Arabic like every other
            // string in this plugin), so it always showed in Arabic even
            // on the English site — nothing in the languages/pild-unified-*
            // files could ever override it. Switched to the same
            // English-msgid-with-Arabic-.po-override pattern used
            // everywhere else in the codebase (see languages/pild-unified-ar.po).
            'name'  => __('Track', 'pild-unified'),
            'value' => $cart_item['pild_track_title'],
        ];
    }
    return $item_data;
}

// ── 26.11 Carry the track tag from cart line -> order line item ──────
// This is what pild_team_create_from_purchase() (24-team-purchase.php)
// and pild_auto_enroll_tracks_from_purchase() (pild-unified.php) read
// at order-completion time, instead of the product's own product_tracks
// field (which no longer identifies a single track once a product is
// shared across a whole pricing level).
add_action('woocommerce_checkout_create_order_line_item', 'pild_order_item_save_track', 10, 4);
function pild_order_item_save_track($item, $cart_item_key, $values, $order) {
    if (!empty($values['pild_track_id'])) {
        $item->add_meta_data('_pild_track_id', (int) $values['pild_track_id'], true);
    }
    if (!empty($values['pild_variant'])) {
        $item->add_meta_data('_pild_variant', $values['pild_variant'], true);
    }
}

// ── 26.13 Checkout-time safety net for team-variant cart items ───────
// A team/org (or partner) cart item still needs a real account to own
// the resulting team once the order completes (see
// pild_team_create_from_purchase(), includes/24-team-purchase.php,
// which silently does nothing for a true guest order — $order->
// get_user_id() is 0). Rather than forcing login before someone can
// even ADD the track to their cart (26.9 above lets that through same
// as an individual purchase), this is enforced at the one point it
// actually matters: checkout. A logged-in buyer, or a guest who ticks
// WooCommerce's own "create an account" box, both pass; a true
// anonymous guest checkout is blocked with an explanatory message
// instead of silently losing the seats/team after payment.
add_action('woocommerce_checkout_process', 'pild_require_account_for_team_cart_items');
function pild_require_account_for_team_cart_items() {
    if (is_user_logged_in()) return;
    if (!function_exists('WC') || !WC()->cart) return;

    $has_team_item = false;
    foreach (WC()->cart->get_cart() as $item) {
        if (!empty($item['pild_variant']) && $item['pild_variant'] === 'team') { $has_team_item = true; break; }
    }
    if (!$has_team_item) return;

    if (empty($_POST['createaccount'])) {
        wc_add_notice(__('التسجيل المؤسسي محتاج حساب فعلي عشان الفريق يترتبط بيه — سجّل دخول، أو فعّل خيار "إنشاء حساب" هنا في صفحة الدفع، قبل ما تكمل.', 'pild-unified'), 'error');
    }
}

add_action('wp_ajax_pild_reg_set_context', 'pild_ajax_reg_set_context');
add_action('wp_ajax_nopriv_pild_reg_set_context', 'pild_ajax_reg_set_context');
function pild_ajax_reg_set_context() {
    nocache_headers();
    check_ajax_referer('pild_reg_ctx', 'nonce');

    $requested = isset($_POST['context']) ? sanitize_key(wp_unslash($_POST['context'])) : '';

    // Logged-in visitors can't switch between Individual/Team — their
    // mode is their real role — but the "Partners" tab is the one
    // exception, applying regardless of login (see
    // pild_get_registration_context()): it's what a logged-in individual
    // or org sees while THEY browse that tab too, not just guests.
    if (is_user_logged_in() && $requested !== 'partners') {
        wp_send_json_success(['mode' => pild_get_registration_context(), 'switchable' => false]);
    }

    pild_set_audience_session_context($requested);
    wp_send_json_success(['mode' => pild_get_registration_context(), 'switchable' => !is_user_logged_in()]);
}

// ── 26.7 Bridge: header audience tabs -> session cookie ─────────────
// window.PILD_AUDIENCE (set elsewhere, in the site's global nav
// template, per the brief) tells us which tab a visitor is currently
// on. This tiny fire-and-forget request is what actually makes that
// choice "stick for the rest of the session" as required, including
// on pages that don't carry a data-audience attribute themselves.
// Runs for logged-in visitors too now (not skipped outright) — needed
// so the "Partners" tab overrides even a logged-in individual/org's
// normal context; pild_ajax_reg_set_context() still refuses anything
// other than 'partners' for a logged-in visitor.
add_action('wp_footer', 'pild_reg_audience_bridge_script', 5);
function pild_reg_audience_bridge_script() {
    ?>
    <script>
    (function(){
      if (typeof window.PILD_AUDIENCE === 'undefined' || !window.PILD_AUDIENCE) return;
      var ctx = window.PILD_AUDIENCE;
      if (ctx !== 'organizations' && ctx !== 'partners') ctx = 'individuals';
      var isLoggedIn = <?php echo is_user_logged_in() ? 'true' : 'false'; ?>;
      if (isLoggedIn && ctx !== 'partners') return; // real role still wins for individuals/organizations
      try {
        var fd = new FormData();
        fd.append('action', 'pild_reg_set_context');
        fd.append('nonce', <?php echo wp_json_encode( wp_create_nonce( 'pild_reg_ctx' ) ); ?>);
        fd.append('context', ctx);
        fetch(<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, {method:'POST', body: fd, credentials:'same-origin'});
      } catch (e) { /* best-effort only */ }
    })();
    </script>
    <?php
}

// ── 26.7b Server-side override: ?pild_audience=... on the link itself ──
// The 26.7 bridge above sets the cookie via a fire-and-forget AJAX call
// AFTER the page has already loaded — which races against the Sector
// Explorer page's own "read my context" AJAX call (26.6), also fired on
// load. There is no guaranteed order between two independent fetch()
// calls, so in practice the read can (and did, in testing) finish first
// and pick up the stale cookie, making the "Explore Tracks" nav links
// send everyone to the Individual product regardless of which audience
// tab they came from.
//
// Fix: audience-specific entry links (see the nav snippet) carry
// ?pild_audience=organizations|individuals in the URL itself. We apply
// that HERE, on template_redirect — synchronously, in PHP, before the
// page (and therefore before either of that page's own AJAX calls) is
// even sent to the browser. That removes the race entirely: by the time
// any client-side script runs, the cookie this pageview needs is already
// set. The 26.7 bridge script still runs too (harmless/redundant here,
// still useful on plain pages that don't carry the query param, so the
// audience choice keeps "sticking" while browsing other pages in the tab).
add_action('template_redirect', 'pild_reg_apply_audience_query_param', 1);
function pild_reg_apply_audience_query_param() {
    if (empty($_GET['pild_audience'])) return;
    $val = sanitize_key(wp_unslash($_GET['pild_audience']));
    if (!in_array($val, pild_get_audience_values(), true)) return;
    // "Individuals"/"Organizations" still defer to the visitor's real
    // role when logged in — only "Partners" applies regardless of login,
    // since being logged in as an ordinary individual/org is exactly the
    // case this tab needs to override (see pild_get_registration_context()).
    if (is_user_logged_in() && $val !== 'partners') return;
    pild_set_audience_session_context($val); // updates the cookie AND $_COOKIE for this same request
}

// ── 26.8 Cache-safety net ────────────────────────────────────────────
// Belt-and-suspenders on top of 26.6's AJAX-fragment approach: if a
// full-page-cache plugin is active and somehow still decides to cache
// a track/domain singular or the Sector Explorer page for a guest who
// already has an audience cookie set, explicitly tell the common
// caching plugins not to store that particular response. The primary
// defense is still that the initial HTML never contains a resolved
// register link — this only guards against unexpected server-side
// personalization being added here later.
add_action('template_redirect', 'pild_reg_maybe_bypass_full_page_cache');
function pild_reg_maybe_bypass_full_page_cache() {
    global $post;

    $is_relevant = is_singular(['track', 'domain']);
    if (!$is_relevant && $post instanceof WP_Post && has_shortcode($post->post_content, 'pild_sector_explorer')) {
        $is_relevant = true;
    }
    if (!$is_relevant) return;
    if (empty($_COOKIE[PILD_AUDIENCE_COOKIE])) return; // nothing personalized to protect

    if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true); // WP Rocket, WP Super Cache, W3TC, etc.
    if (!defined('LSCACHE_NO_CACHE')) define('LSCACHE_NO_CACHE', true); // LiteSpeed Cache
    nocache_headers();
}
