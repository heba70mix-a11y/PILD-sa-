<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 27. TEAMS CORE — independent replacement for
//     "WooCommerce Memberships for Teams" data layer.
// ------------------------------------------------------------
// PHASE 1 of the replacement plan. This file only creates the new
// tables and the core read/write functions on top of them. It does
// NOT yet touch pildcm_ajax_assign_track(), pildcm_ajax_invite_member(),
// pildcm_get_team_members(), or the product-purchase hook — those
// still call the old wc_memberships_for_teams_*() functions and the
// legacy wp_wc_memberships_teams mirror tables from 09-admin.php.
// Rewiring them is Phase 2+, done only after this schema is reviewed
// and the seat-purchase model below is confirmed.
//
// Tables created here use PILD's own names — deliberately NOT
// wp_wc_memberships_teams / wp_wc_memberships_team_members, to avoid
// the ID/schema collision risk flagged earlier with the real
// "WooCommerce Memberships for Teams" extension tables.
//
// ASSUMPTION (flagged, not yet confirmed): seat purchase model is
// "quantity = seats". A team product's normal WooCommerce quantity
// field is reused directly as the seat count — no custom "number of
// members" input needed. This is the simplest option and reuses
// WooCommerce's native cart/quantity handling instead of custom JS,
// but it means the buyer sets quantity like any other product. If a
// different model is wanted (a dedicated "seats" field separate from
// quantity, e.g. for multi-track bundles bought as qty 1), Phase 2
// (product-fields + cart/order wiring) needs to reflect that instead.
// ============================================================

// ── 27.1 Schema ─────────────────────────────────────────────
add_action('plugins_loaded', 'pild_teams_core_maybe_upgrade');
function pild_teams_core_maybe_upgrade() {
    if (get_option('pild_teams_core_schema_version') === PILD_VERSION) return;
    pild_teams_core_install();
    update_option('pild_teams_core_schema_version', PILD_VERSION);
}

// Runs on every load (cheap idempotent check) rather than only on the
// version-gated path above, so it applies immediately without needing a
// plugin version bump — same reasoning as any other additive column change.
add_action('plugins_loaded', 'pild_enrollments_add_expiry_column', 5);
function pild_enrollments_add_expiry_column() {
    global $wpdb;
    $table = $wpdb->prefix . 'pild_enrollments';
    $col   = $wpdb->get_results("SHOW COLUMNS FROM {$table} LIKE 'access_expires'");
    if (empty($col)) {
        $wpdb->query("ALTER TABLE {$table} ADD COLUMN access_expires datetime DEFAULT NULL AFTER enrolled_at");
    }
}

function pild_teams_core_install() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();

    // One row per purchased team (one WooCommerce order line = one team).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_teams (
        id           int(11)      NOT NULL AUTO_INCREMENT,
        owner_id     int(11)      NOT NULL,
        product_id   int(11)      DEFAULT 0,
        order_id     int(11)      DEFAULT 0,
        name         varchar(200) DEFAULT '',
        seat_count   int(11)      NOT NULL DEFAULT 1,
        status       varchar(20)  DEFAULT 'active',
        date_created datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY owner_idx (owner_id),
        KEY order_idx (order_id)
    ) $c;");

    // Membership in a team. role: 'owner' (the buyer/manager) or 'member'.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_team_members (
        id           int(11)      NOT NULL AUTO_INCREMENT,
        team_id      int(11)      NOT NULL,
        user_id      int(11)      NOT NULL,
        role         varchar(20)  DEFAULT 'member',
        date_created datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY   team_user (team_id, user_id),
        KEY          user_idx (user_id)
    ) $c;");

    // Which tracks a team's seats cover — direct replacement for a
    // Membership Plan's Content Restriction Rules.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_team_tracks (
        id       int(11) NOT NULL AUTO_INCREMENT,
        team_id  int(11) NOT NULL,
        track_id int(11) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY team_track (team_id, track_id),
        KEY track_idx (track_id)
    ) $c;");

    // Pending invitations — replaces the single 'pildcm_pending_invites'
    // option (fixes the race-condition-on-concurrent-invite and the
    // unbounded-option-growth issues flagged earlier).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_invites (
        id          int(11)      NOT NULL AUTO_INCREMENT,
        token       varchar(64)  NOT NULL,
        email       varchar(200) NOT NULL,
        manager_id  int(11)      NOT NULL,
        team_id     int(11)      DEFAULT 0,
        status      varchar(20)  DEFAULT 'pending',
        expires_at  datetime     NOT NULL,
        date_created datetime    DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY  token_idx (token),
        KEY         manager_idx (manager_id),
        KEY         email_idx (email)
    ) $c;");

    // PHASE 10: audit trail — who did what to which seat/track, and when.
    // action is a short code: 'team_created', 'seat_assigned',
    // 'seat_removed', 'track_assigned', 'track_unassigned'.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_audit_log (
        id              int(11)      NOT NULL AUTO_INCREMENT,
        actor_id        int(11)      NOT NULL,
        subject_user_id int(11)      DEFAULT 0,
        team_id         int(11)      DEFAULT 0,
        track_id        int(11)      DEFAULT 0,
        action          varchar(30)  NOT NULL,
        details         varchar(255) DEFAULT '',
        created_at      datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY actor_idx (actor_id),
        KEY team_idx (team_id),
        KEY action_idx (action)
    ) $c;");

    // Purchase/top-up ledger — one row per order that added seats to a
    // team, whether that created the team or topped up an existing one.
    // Exists so a billing question ("who paid for which seats, when?")
    // can be answered even after several purchases have piled onto the
    // same team (see pild_team_get_or_create_for_purchase()).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_team_seat_purchases (
        id           int(11)      NOT NULL AUTO_INCREMENT,
        team_id      int(11)      NOT NULL,
        order_id     int(11)      DEFAULT 0,
        product_id   int(11)      DEFAULT 0,
        seats_added  int(11)      NOT NULL DEFAULT 0,
        created_at   datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY team_idx (team_id),
        KEY order_idx (order_id)
    ) $c;");
}

// Centralized logger — every seat/track mutation in this file and in
// includes/03-ajax.php's assign/unassign handler calls this instead of
// writing to the table directly, so the log format never drifts.
function pild_log_action($actor_id, $action, $args = []) {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'pild_audit_log', [
        'actor_id'        => (int) $actor_id,
        'subject_user_id' => (int) ($args['subject_user_id'] ?? 0),
        'team_id'         => (int) ($args['team_id'] ?? 0),
        'track_id'        => (int) ($args['track_id'] ?? 0),
        'action'          => sanitize_key($action),
        'details'         => isset($args['details']) ? sanitize_text_field($args['details']) : '',
        'created_at'      => current_time('mysql'),
    ]);
}

// Also run on plugin activation, alongside the existing tables in
// pild_unified_activate() — belt and braces for fresh installs.
add_action('activated_plugin', function ($plugin) {
    if (strpos($plugin, 'pild-unified.php') !== false) pild_teams_core_install();
});

// ── 27.2 Core read/write functions ─────────────────────────
// These are the new equivalents of the wc_memberships_for_teams_*()
// calls currently used in 02-helpers.php / 03-ajax.php. Nothing calls
// these yet (Phase 1) — they are additive.

/**
 * Create a team from a completed order line. One call per order item
 * that is a "team" product (mirrors how pild_auto_enroll_tracks_from_purchase
 * handles solo products today).
 */
function pild_team_create($owner_id, $product_id, $order_id, $seat_count, $track_ids = [], $name = '') {
    global $wpdb;
    $owner_id   = (int) $owner_id;
    $product_id = (int) $product_id;
    $seat_count = max(1, (int) $seat_count);
    if (!$owner_id) return 0;

    if ($name === '') {
        // Prefer the TRACK's own title over the product's — under the
        // shared pricing-level model (includes/22-registration-routing.php)
        // several different tracks can share one product ("Basic — Team"),
        // so naming the team after the product would make every team for
        // that level look identical on the manager's dashboard.
        $single_track = (count((array) $track_ids) === 1) ? (int) reset($track_ids) : 0;
        if ($single_track && get_post_status($single_track)) {
            $name = get_the_title($single_track);
        } elseif ($product_id) {
            $name = get_the_title($product_id);
        } else {
            $name = 'Team ' . $owner_id;
        }
    }

    $wpdb->insert($wpdb->prefix . 'pild_teams', [
        'owner_id'     => $owner_id,
        'product_id'   => $product_id,
        'order_id'     => (int) $order_id,
        'name'         => $name,
        'seat_count'   => $seat_count,
        'status'       => 'active',
        'date_created' => current_time('mysql'),
    ]);
    $team_id = (int) $wpdb->insert_id;
    if (!$team_id) return 0;

    if (function_exists('pild_log_action')) {
        pild_log_action($owner_id, 'team_created', ['team_id' => $team_id, 'details' => "{$seat_count} seats, product #{$product_id}, order #{$order_id}"]);
    }

    // Owner always occupies a seat as 'owner' role (consistent with the
    // legacy mirror table behaviour in 09-admin.php).
    pild_team_add_member($team_id, $owner_id, 'owner', true);

    foreach ((array) $track_ids as $track_id) {
        $track_id = (int) $track_id;
        if (!$track_id) continue;
        $wpdb->insert($wpdb->prefix . 'pild_team_tracks', [
            'team_id'  => $team_id,
            'track_id' => $track_id,
        ]);
    }

    return $team_id;
}

/**
 * Add tracks to an existing team (e.g. owner buys another track later —
 * same team, more coverage, no re-invite needed for existing members).
 */
function pild_team_add_tracks($team_id, $track_ids) {
    global $wpdb;
    $team_id = (int) $team_id;
    if (!$team_id) return;
    foreach ((array) $track_ids as $track_id) {
        $track_id = (int) $track_id;
        if (!$track_id) continue;
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_team_tracks WHERE team_id=%d AND track_id=%d",
            $team_id, $track_id
        ));
        if (!$exists) {
            $wpdb->insert($wpdb->prefix . 'pild_team_tracks', ['team_id' => $team_id, 'track_id' => $track_id]);
        }
    }
}

/**
 * Find an existing ACTIVE team this owner already has to top up, for the
 * same WooCommerce product they're buying again.
 *
 * Client decision (see project notes): repeat purchases of the same
 * track/product top up the SAME team's seat_count, because the manager
 * tracks one roster per track over time — they should NOT end up with
 * several disconnected teams for what is, to them, one ongoing group.
 * An EXPIRED/cancelled team is deliberately excluded (status != 'active')
 * so a fresh purchase after expiry starts a new team rather than silently
 * reviving an old one — but the expired team and its members' certificates
 * stay permanently viewable in the "Ended Teams" dashboard section (see
 * includes/04-dashboard-company.php), never deleted or hidden from history.
 *
 * $track_id: pass this whenever the purchase is for exactly ONE track
 * (the normal case since the pricing-level model in includes/22-
 * registration-routing.php — 6 shared products, each one sold across many
 * different tracks). Matching on product_id ALONE would then wrongly top
 * up a completely unrelated track's team just because it happens to share
 * the same "Basic — Team" product. When $track_id is given, the candidate
 * team must actually be linked to that track (via pild_team_tracks) too.
 * $track_id=0 keeps the old product_id-only matching, for a genuine
 * multi-track bundle product (product_tracks with several tracks) where
 * "same product" IS "same cohort" with no ambiguity.
 */
function pild_team_find_active_by_owner_product($owner_id, $product_id, $track_id = 0) {
    global $wpdb;
    $owner_id   = (int) $owner_id;
    $product_id = (int) $product_id;
    $track_id   = (int) $track_id;
    if (!$owner_id || !$product_id) return 0;

    if ($track_id) {
        $candidates = $wpdb->get_results($wpdb->prepare(
            "SELECT t.* FROM {$wpdb->prefix}pild_teams t
             INNER JOIN {$wpdb->prefix}pild_team_tracks tt ON tt.team_id = t.id AND tt.track_id = %d
             WHERE t.owner_id=%d AND t.product_id=%d AND t.status='active'
             ORDER BY t.id DESC",
            $track_id, $owner_id, $product_id
        ));
    } else {
        $candidates = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pild_teams WHERE owner_id=%d AND product_id=%d AND status='active' ORDER BY id DESC",
            $owner_id, $product_id
        ));
    }
    foreach ($candidates as $team) {
        // The status column alone isn't enough here — see pild_team_is_expired():
        // nothing in this codebase ever flips status away from 'active', so an
        // expired-by-date team would otherwise still match and get silently
        // reactivated, which is exactly what the client asked NOT to happen.
        if (!pild_team_is_expired($team)) return (int) $team->id;
    }
    return 0;
}

/**
 * Single entry point a purchase hook should call instead of pild_team_create()
 * directly: tops up seats on a matching active team if one exists, or creates
 * a new one otherwise. Either way, logs the purchase to
 * pild_team_seat_purchases so multi-purchase billing history is traceable.
 * Returns the (possibly pre-existing) team_id.
 */
function pild_team_get_or_create_for_purchase($owner_id, $product_id, $order_id, $seats, $track_ids = [], $name = '') {
    global $wpdb;
    $seats = max(1, (int) $seats);

    // Exactly one track -> the normal case under the shared-product
    // pricing-level model; pass it through so the lookup below doesn't
    // top up an unrelated track's team just because it shares a product.
    $single_track = (count((array) $track_ids) === 1) ? (int) reset($track_ids) : 0;
    $team_id = pild_team_find_active_by_owner_product($owner_id, $product_id, $single_track);

    if ($team_id) {
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}pild_teams SET seat_count = seat_count + %d WHERE id=%d",
            $seats, $team_id
        ));
        if (function_exists('pild_log_action')) {
            pild_log_action($owner_id, 'seats_added', [
                'team_id' => $team_id, 'details' => "+{$seats} seats, product #{$product_id}, order #{$order_id}",
            ]);
        }
        // A repeat purchase might list a track that, for some reason, isn't
        // linked on the existing team yet (e.g. the product's track list
        // changed since the team was first created) — make sure it is.
        pild_team_add_tracks($team_id, $track_ids);
    } else {
        $team_id = pild_team_create($owner_id, $product_id, $order_id, $seats, $track_ids, $name);
    }

    if ($team_id) {
        $wpdb->insert($wpdb->prefix . 'pild_team_seat_purchases', [
            'team_id'     => $team_id,
            'order_id'    => (int) $order_id,
            'product_id'  => (int) $product_id,
            'seats_added' => $seats,
            'created_at'  => current_time('mysql'),
        ]);
    }

    return $team_id;
}

/** Current seats used (member rows, owner included) for a team. */
function pild_team_seats_used($team_id) {
    global $wpdb;
    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}pild_team_members WHERE team_id=%d",
        (int) $team_id
    ));
}

/** Seats still free on a team. */
function pild_team_seats_available($team_id) {
    global $wpdb;
    $team = $wpdb->get_row($wpdb->prepare(
        "SELECT seat_count FROM {$wpdb->prefix}pild_teams WHERE id=%d", (int) $team_id
    ));
    if (!$team) return 0;
    return max(0, (int) $team->seat_count - pild_team_seats_used($team_id));
}

/**
 * Add a member to a team if there's room. Returns true/false.
 * $bypass_seat_check is only for the owner's own auto-add in
 * pild_team_create() above — the owner isn't subject to the seat limit.
 */
function pild_team_add_member($team_id, $user_id, $role = 'member', $bypass_seat_check = false, $actor_id = null) {
    global $wpdb;
    $team_id = (int) $team_id;
    $user_id = (int) $user_id;
    if (!$team_id || !$user_id) return false;

    $already = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE team_id=%d AND user_id=%d",
        $team_id, $user_id
    ));
    if ($already) return true; // idempotent

    if (!$bypass_seat_check && pild_team_seats_available($team_id) <= 0) return false;

    $wpdb->insert($wpdb->prefix . 'pild_team_members', [
        'team_id'      => $team_id,
        'user_id'      => $user_id,
        'role'         => $role,
        'date_created' => current_time('mysql'),
    ]);

    // PHASE 10: audit trail. Defaults the actor to the team's owner when the
    // caller doesn't pass one explicitly (covers pild_team_create()'s
    // owner-auto-add and invite-acceptance, both effectively the owner's
    // own action); pildcm_ajax_assign_track() in 03-ajax.php passes the
    // acting manager explicitly since that's the real actor there.
    if (function_exists('pild_log_action') && $role === 'member') {
        if ($actor_id === null) {
            $actor_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT owner_id FROM {$wpdb->prefix}pild_teams WHERE id=%d", $team_id
            ));
        }
        pild_log_action($actor_id, 'seat_assigned', ['subject_user_id' => $user_id, 'team_id' => $team_id]);
    }

    // PHASE 4: award the "Team Player" badge here, once, centrally — this
    // used to be triggered by the WC Memberships for Teams extension's own
    // wc_memberships_for_teams_team_member_added/_saved action hooks
    // (includes/03-ajax.php), which no longer fire now that team membership
    // is granted by this function directly instead of the extension.
    if ($role === 'member' && function_exists('pildcm_award_team_player_badge')) {
        pildcm_award_team_player_badge($user_id);
    }

    return true;
}

function pild_team_remove_member($team_id, $user_id) {
    global $wpdb;
    $result = $wpdb->delete($wpdb->prefix . 'pild_team_members', [
        'team_id' => (int) $team_id,
        'user_id' => (int) $user_id,
    ]);
    if ($result && function_exists('pild_log_action')) {
        $owner_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT owner_id FROM {$wpdb->prefix}pild_teams WHERE id=%d", (int) $team_id
        ));
        pild_log_action($owner_id, 'seat_removed', ['subject_user_id' => (int) $user_id, 'team_id' => (int) $team_id]);
    }
    return $result;
}

/** All teams a given user owns. */
function pild_get_owner_teams($owner_id) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_teams WHERE owner_id=%d AND status='active'",
        (int) $owner_id
    ));
}

/**
 * Single source of truth for "has this team's access period ended?" —
 * a 1-year window anchored to date_created (see the note in
 * 04-dashboard-company.php's Billing section, where this rule was first
 * introduced for display only). Centralized here so the purchase-time
 * top-up check (pild_team_find_active_by_owner_product()) and every
 * dashboard display use exactly the same rule and can never drift apart.
 * Accepts either a team row (object, from a query you already ran) or a
 * team_id (int, fetches it).
 */
function pild_team_is_expired($team) {
    if (is_numeric($team)) {
        global $wpdb;
        $team = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pild_teams WHERE id=%d", (int) $team));
    }
    if (!$team || !$team->date_created) return false;
    return strtotime($team->date_created . ' +1 year') <= time();
}

/**
 * The owner's teams whose 1-year access window has passed — for the
 * read-only "Ended Teams" dashboard section. Deliberately still queryable
 * (never deleted/hidden) so a manager — or, via each member's own
 * certificate/profile pages, an individual employee — can always look
 * back at who was on a past cohort, per the client's explicit
 * requirement that this history must stay reachable indefinitely.
 */
function pild_get_owner_teams_expired($owner_id) {
    $all = pild_get_owner_teams($owner_id);
    return array_values(array_filter($all, 'pild_team_is_expired'));
}

/** Active (non-expired) subset — the counterpart used where the dashboard
 *  should only show teams that are still within their access window. */
function pild_get_owner_teams_current($owner_id) {
    $all = pild_get_owner_teams($owner_id);
    return array_values(array_filter($all, function ($t) { return !pild_team_is_expired($t); }));
}

/** All member rows (with user objects) across every team a manager owns. */
function pild_get_team_members_v2($owner_id) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT tm.user_id
         FROM {$wpdb->prefix}pild_team_members tm
         INNER JOIN {$wpdb->prefix}pild_teams t ON t.id = tm.team_id
         WHERE t.owner_id = %d AND tm.role = 'member' AND t.status = 'active'",
        (int) $owner_id
    ));
    $members = [];
    foreach ($rows as $row) {
        $u = get_userdata($row->user_id);
        if ($u) $members[$row->user_id] = $u;
    }
    return $members;
}

/**
 * Direct replacement for pild_get_covering_teams_for_track(): which of
 * this owner's teams cover $track_id AND still have a free seat.
 */
function pild_get_covering_teams_for_track_v2($owner_id, $track_id) {
    global $wpdb;
    $team_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT t.id FROM {$wpdb->prefix}pild_teams t
         INNER JOIN {$wpdb->prefix}pild_team_tracks tt ON tt.team_id = t.id
         WHERE t.owner_id = %d AND tt.track_id = %d AND t.status = 'active'",
        (int) $owner_id, (int) $track_id
    ));
    $covering = [];
    foreach ($team_ids as $team_id) {
        if (pild_team_seats_available($team_id) > 0) $covering[] = (int) $team_id;
    }
    return $covering;
}

// ── 27.3 Invite cleanup cron ────────────────────────────────
// Expired invites used to sit forever in a single global option until
// someone happened to click that exact link (see includes/03-ajax.php).
// Now that they're rows in their own table this isn't a site-wide
// performance problem any more, but a daily sweep still keeps the table
// tidy and the manager's "Pending Invitations" list honest.
add_action('init', function () {
    if (!wp_next_scheduled('pild_cleanup_expired_invites')) {
        wp_schedule_event(time(), 'daily', 'pild_cleanup_expired_invites');
    }
});
add_action('pild_cleanup_expired_invites', function () {
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->prefix}pild_invites WHERE status='pending' AND expires_at < NOW()"
    );
});
