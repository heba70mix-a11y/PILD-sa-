<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 28. TEAM PURCHASE — Phase 2 of the Teams-extension replacement.
// ------------------------------------------------------------
// Builds on includes/23-teams-core.php. This file:
//   1. Defines what makes a WooCommerce product a "Team product"
//      (reverse-lookup: is this product referenced as pild_product_team
//      on any published Track/Domain — the field added in
//      includes/22-registration-routing.php).
//   2. Enforces the minimum-seats rule (5 by default, overridable per
//      product) on Team products, and locks Individual products to
//      quantity 1 (an Individual product is a single access license —
//      buying "2" of it made no sense before and enrolled the buyer
//      once regardless; this makes that explicit instead of silent).
//   3. Extends the purchase hook (pild_auto_enroll_tracks_from_purchase
//      in pild-unified.php) so a completed order for a Team product
//      creates a team (pild_team_create) with seat_count = quantity
//      purchased, instead of a single enrollment row.
//
// Per-member price = the product's normal WooCommerce price field.
// No separate "per-member price" custom field is needed: WooCommerce
// already multiplies unit price × quantity, and quantity IS the seat
// count here. Partner pricing (single reduced tier) still applies on
// top via includes/14-partner-pricing.php — untouched by this file.
// ============================================================

// ── 28.1 Is this product a Team product? ───────────────────
// Cached per-request in a static var (avoids repeat queries when the
// purchase hook loops over several order items) and in a short
// transient (product edit / order processing are the only callers,
// so a 5-minute cache is safe and avoids a DB hit on every page load
// that touches a product this is called on).
function pild_get_team_product_ids() {
    static $ids = null;
    if ($ids !== null) return $ids;

    $cached = get_transient('pild_team_product_ids');
    if ($cached !== false) return $ids = $cached;

    global $wpdb;
    // Two sources, unioned: (1) legacy per-track/domain "Team Product"
    // links (includes/22-registration-routing.php, 26.1), and (2) the
    // 6 shared level products tagged _pild_variant=team directly on the
    // product (26.1c) — the new model, where one product is shared
    // across many tracks instead of being linked from each one.
    $legacy = $wpdb->get_col(
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta}
         WHERE meta_key = 'pild_product_team' AND meta_value != ''"
    );
    $level = $wpdb->get_col(
        "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
         WHERE meta_key = '_pild_variant' AND meta_value = 'team'"
    );
    $ids = array_values(array_unique(array_map('intval', array_merge($legacy, $level))));
    set_transient('pild_team_product_ids', $ids, 5 * MINUTE_IN_SECONDS);
    return $ids;
}

function pild_is_team_product($product_id) {
    return in_array((int) $product_id, pild_get_team_product_ids(), true);
}

// Bust the cache whenever a Track/Domain is saved (their pild_product_team
// field may have just changed).
add_action('acf/save_post', function ($post_id) {
    if (in_array(get_post_type($post_id), ['track', 'domain'], true)) {
        delete_transient('pild_team_product_ids');
    }
}, 20);

// ── 28.2 Minimum-seats field on the product edit screen ────
// Mirrors the existing pattern in includes/14-partner-pricing.php
// (same hooks: woocommerce_product_options_pricing / _process_product_meta).
add_action('woocommerce_product_options_pricing', 'pild_team_min_seats_field');
function pild_team_min_seats_field() {
    global $post;
    if (!$post || !pild_is_team_product($post->ID)) return;
    echo '<div class="options_group">';
    woocommerce_wp_text_input([
        'id'                => '_pild_min_seats',
        'label'             => __('Minimum seats', 'pild-unified'),
        'description'       => __('Smallest quantity a buyer can purchase for this Team product. Leave blank for the default (5).', 'pild-unified'),
        'desc_tip'          => true,
        'type'              => 'number',
        'custom_attributes' => ['step' => '1', 'min' => '1'],
    ]);
    echo '</div>';
}

add_action('woocommerce_process_product_meta', 'pild_team_min_seats_save');
function pild_team_min_seats_save($post_id) {
    if (isset($_POST['_pild_min_seats'])) {
        $val = (int) $_POST['_pild_min_seats'];
        update_post_meta($post_id, '_pild_min_seats', $val > 0 ? $val : '');
    }
}

function pild_team_min_seats($product_id) {
    $val = (int) get_post_meta($product_id, '_pild_min_seats', true);
    return $val > 0 ? $val : 5; // default minimum agreed: 5
}

// ── 28.2b Frontend note: "Minimum N seats" ──────────────────
// The quantity box already opens pre-filled at the minimum (28.3 sets
// min_value/input_value), but that alone doesn't tell a buyer WHY, or
// that they can't go lower. This adds a one-line note right under the
// Add to Cart button, Team products only.
add_action('woocommerce_single_product_summary', 'pild_team_min_seats_notice', 35);
function pild_team_min_seats_notice() {
    global $product;
    if (!$product || !pild_is_team_product($product->get_id())) return;

    $min   = pild_team_min_seats($product->get_id());
    $is_en = function_exists('pll_current_language') && pll_current_language('slug') === 'en';

    if ($is_en) {
        $text = sprintf(
            _n('Minimum purchase: %d seat.', 'Minimum purchase: %d seats.', $min, 'pild-unified'),
            $min
        );
    } else {
        $unit = ($min === 1) ? 'مقعد' : 'مقاعد';
        $text = "الحد الأدنى للشراء: {$min} {$unit}.";
    }

    echo '<p class="pild-min-seats-notice" style="margin:-4px 0 16px;font-size:13px;color:#6B6350;">'
        . esc_html($text) . '</p>';
}

// ── 28.3 Enforce quantity rules on product page + cart ─────
add_filter('woocommerce_quantity_input_args', 'pild_team_quantity_args', 10, 2);
function pild_team_quantity_args($args, $product) {
    $product_id = $product->get_id();

    if (pild_is_team_product($product_id)) {
        $min = pild_team_min_seats($product_id);
        $args['min_value']   = $min;
        $args['input_value'] = max($min, (int) $args['input_value']);
        return $args;
    }

    // Individual product (has product_tracks but is not a Team product):
    // single access license, quantity is meaningless — lock to 1.
    if (function_exists('get_field') && get_field('product_tracks', $product_id)) {
        $args['min_value']   = 1;
        $args['max_value']   = 1;
        $args['input_value'] = 1;
    }

    return $args;
}

// Defence in depth: also reject/clamp at add-to-cart time, in case the
// quantity field was bypassed (custom theme, direct add-to-cart URL, etc).
add_filter('woocommerce_add_to_cart_validation', 'pild_team_validate_add_to_cart_qty', 10, 3);
function pild_team_validate_add_to_cart_qty($passed, $product_id, $quantity) {
    if (pild_is_team_product($product_id)) {
        $min = pild_team_min_seats($product_id);
        if ($quantity < $min) {
            wc_add_notice(sprintf(
                __('This is a Team product — minimum %d seats.', 'pild-unified'), $min
            ), 'error');
            return false;
        }
    } elseif (function_exists('get_field') && get_field('product_tracks', $product_id) && $quantity > 1) {
        wc_add_notice(__('This product grants one individual access license — quantity is fixed at 1.', 'pild-unified'), 'error');
        return false;
    }
    return $passed;
}

// ── 28.4 Purchase hook: create a Team instead of a plain enrollment ─
// Hooks at priority 5 — BEFORE pild_auto_enroll_tracks_from_purchase's
// own priority 20 — and, for Team products only, does the enrollment
// itself (owner gets personal access + a team is created for seats),
// then flags the item as handled so the priority-20 function skips it.
add_action('woocommerce_order_status_completed', 'pild_team_create_from_purchase', 5);
add_action('woocommerce_payment_complete',       'pild_team_create_from_purchase', 5);

function pild_team_create_from_purchase($order_id) {
    if (!function_exists('get_field') || !function_exists('pild_team_create')) {
        if (function_exists('pild_alert_acf_missing')) pild_alert_acf_missing($order_id); // PHASE 8
        return;
    }

    $order = wc_get_order($order_id);
    if (!$order) return;
    $user_id = $order->get_user_id();
    if (!$user_id) return; // guest checkout — no account to own a team

    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        if (!$product_id || !pild_is_team_product($product_id)) continue;

        // Which track(s) this LINE was for. Preferred source: the
        // _pild_track_id meta carried over from the cart line (see
        // includes/22-registration-routing.php, 26.11) — required once
        // a product is one of the 6 shared level products, since
        // product_tracks on the product itself can no longer identify
        // a single track. Falls back to the legacy product_tracks field
        // for any order still going through a dedicated per-track
        // product with no cart-line tag.
        $item_track_id = (int) $item->get_meta('_pild_track_id', true);
        $track_ids = $item_track_id ? [$item_track_id] : (array) get_field('product_tracks', $product_id);
        if (empty($track_ids)) continue;

        // Idempotency key includes the track now too — the same shared
        // product can legitimately create a separate team per track
        // within one order, so keying on product_id alone would wrongly
        // treat the second track's line as "already handled".
        $idem_key = '_pild_team_created_' . $product_id . '_' . ($item_track_id ?: 'legacy');
        $already  = get_post_meta($order_id, $idem_key, true);
        if ($already) continue;

        $seats   = max(pild_team_min_seats($product_id), (int) $item->get_quantity());
        // Tops up a matching active team if the owner already has one for
        // this exact product, otherwise creates a new one — see the client
        // decision documented on pild_team_get_or_create_for_purchase()
        // in includes/23-teams-core.php.
        $team_id = function_exists('pild_team_get_or_create_for_purchase')
            ? pild_team_get_or_create_for_purchase($user_id, $product_id, $order_id, $seats, $track_ids)
            : pild_team_create($user_id, $product_id, $order_id, $seats, $track_ids);

        if ($team_id) {
            update_post_meta($order_id, $idem_key, $team_id);

            // Owner also gets personal learner access (same as an Individual
            // purchase) so their own dashboard shows progress too — matches
            // the legacy behaviour where the manager occupied a seat.
            foreach ((array) $track_ids as $track_id) {
                $track_id = (int) $track_id;
                if (!$track_id || get_post_status($track_id) !== 'publish') continue;
                $program_id = 0;
                $programs = get_posts([
                    'post_type' => 'program', 'posts_per_page' => 1,
                    'meta_key' => 'program_track', 'meta_value' => $track_id, 'fields' => 'ids',
                ]);
                if (!empty($programs)) $program_id = (int) $programs[0];
                pildcm_enroll_user($user_id, $track_id, $program_id, $user_id, null);
            }
            if (function_exists('pild_bust_track_cache')) pild_bust_track_cache($user_id);

            error_log("PILD: Team #$team_id created for owner #$user_id ($seats seats) from product #$product_id (order #$order_id).");

            // Mark this item as handled so the existing individual-enrollment
            // hook (priority 20) doesn't ALSO run its own per-track loop for
            // this same item and duplicate/confuse things.
            add_filter('pild_skip_individual_enroll_for_item_' . $order_id . '_' . $product_id, '__return_true');
        }
    }
}
