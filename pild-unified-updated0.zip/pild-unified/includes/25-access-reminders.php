<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 29. ACCESS-EXPIRY REMINDERS
// ------------------------------------------------------------
// Daily cron: finds every enrollment whose access_expires falls exactly
// 7 days or exactly 1 day from now, and emails the right person:
//   - Individual buyer  → direct renewal link to their own product.
//   - Team member       → told to contact their manager (they can't
//                          renew their own seat), same rule as the
//                          in-content "Access Expired" message
//                          (pild_restricted_html() in pild-unified.php).
//   - Team manager      → ONE aggregated email per team (not one per
//                          member) listing how many seats are about to
//                          lapse, with a renewal link to the product.
//
// Matching by exact DATE(access_expires) = today+N means each row is
// only ever caught once per bucket (the cron runs once a day), so no
// "already sent" tracking column is needed.
// ============================================================

add_action('init', function () {
    if (!wp_next_scheduled('pild_check_access_expiry')) {
        wp_schedule_event(time(), 'daily', 'pild_check_access_expiry');
    }
});
add_action('pild_check_access_expiry', 'pild_send_expiry_reminders');

function pild_send_expiry_reminders() {
    global $wpdb;

    foreach ([7, 1] as $days_left) {
        $target_date = date('Y-m-d', strtotime("+{$days_left} days"));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT user_id, track_id, access_expires FROM {$wpdb->prefix}pild_enrollments
             WHERE status = 'active' AND access_expires IS NOT NULL
               AND DATE(access_expires) = %s",
            $target_date
        ));
        if (empty($rows)) continue;

        $manager_alerts = []; // manager_id => [ ['track_title'=>, 'member_name'=>, 'expires'=>], ... ]

        foreach ($rows as $row) {
            $user = get_userdata($row->user_id);
            if (!$user) continue;
            $track_title = get_the_title($row->track_id) ?: __('your track', 'pild-unified');
            $manager_id  = function_exists('pildcm_get_member_manager') ? pildcm_get_member_manager($row->user_id) : null;
            $expires_fmt = date_i18n('d M Y', strtotime($row->access_expires));

            if ($manager_id) {
                // Team member: notify them (no renewal link — see rationale above),
                // and queue an aggregated line for their manager's summary email.
                pild_send_member_expiry_email($user, $track_title, $expires_fmt, $days_left, false);
                $manager_alerts[$manager_id][] = [
                    'track_title' => $track_title,
                    'member_name' => $user->display_name,
                    'expires_fmt' => $expires_fmt,
                ];
            } else {
                // Individual buyer: direct renewal link.
                pild_send_member_expiry_email($user, $track_title, $expires_fmt, $days_left, true, $row->track_id);
            }
        }

        foreach ($manager_alerts as $manager_id => $items) {
            pild_send_manager_expiry_summary($manager_id, $items, $days_left);
        }
    }
}

function pild_send_member_expiry_email($user, $track_title, $expires_fmt, $days_left, $can_renew_directly, $track_id = 0) {
    $subject = $days_left === 1
        ? sprintf(__('⏳ Your access to "%s" expires tomorrow', 'pild-unified'), $track_title)
        : sprintf(__('⏳ Your access to "%s" expires in %d days', 'pild-unified'), $track_title, $days_left);

    $body = '<p>Dear ' . esc_html($user->display_name) . ',</p>'
          . '<p>Your one-year access to <strong>' . esc_html($track_title) . '</strong> ends on <strong>' . esc_html($expires_fmt) . '</strong>.</p>';

    $cta_label = ''; $cta_url = '';
    if ($can_renew_directly) {
        if ($track_id && function_exists('get_field')) {
            $product = get_field('pild_product_individual', $track_id);
            $product_id = is_object($product) ? $product->ID : (is_array($product) ? ($product['ID'] ?? 0) : (int) $product);
            if ($product_id) { $cta_url = get_permalink($product_id); $cta_label = 'Renew Access →'; }
        }
    } else {
        $body .= '<p>This access was provided through your organization. Please contact your manager if you\'d like your team\'s access renewed.</p>';
    }

    wp_mail($user->user_email, $subject, pild_email_html('Access Expiring Soon', $body, $cta_label, $cta_url), pild_email_headers());
}

function pild_send_manager_expiry_summary($manager_id, $items, $days_left) {
    $manager = get_userdata($manager_id);
    if (!$manager) return;

    $count = count($items);
    $subject = $days_left === 1
        ? sprintf(__('⏳ %d team seat(s) expire tomorrow', 'pild-unified'), $count)
        : sprintf(__('⏳ %d team seat(s) expire in %d days', 'pild-unified'), $count, $days_left);

    $rows = '';
    foreach ($items as $item) {
        $rows .= '<li>' . esc_html($item['member_name']) . ' — ' . esc_html($item['track_title']) . ' (ends ' . esc_html($item['expires_fmt']) . ')</li>';
    }
    $body = '<p>Dear ' . esc_html($manager->display_name) . ',</p>'
          . '<p>The one-year access period for <strong>' . (int) $count . '</strong> of your team members is ending soon:</p>'
          . '<ul style="padding-left:18px;margin:10px 0;">' . $rows . '</ul>'
          . '<p>Once access ends, these members won\'t be able to reach their track content until you purchase a new team package and reassign them.</p>';

    wp_mail($manager->user_email, $subject, pild_email_html('Team Access Expiring Soon', $body), pild_email_headers());
}
