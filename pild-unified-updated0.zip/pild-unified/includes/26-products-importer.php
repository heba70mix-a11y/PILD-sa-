<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 26. PRODUCTS IMPORTER
// ------------------------------------------------------------
// A SEPARATE tool from includes/18-excel-importer.php on purpose: that
// importer requires every sheet in pildcm_import_sheet_order() to be
// present in the uploaded file, so folding "Products" into it would mean
// every future Sectors/Domains/Tracks/Programs/Books re-upload also has
// to include a Products sheet. This is its own standalone .xlsx (just one
// sheet: "Products") and its own admin page, reusing the same safe XLSX
// parsing helpers from 18-excel-importer.php (pildcm_xlsx_extract() /
// pildcm_safe_simplexml()) — no duplicated parsing code.
//
// Two products per track (Individual + Team) is the norm here — Partner
// pricing is NOT a third product; it's a reduced price that automatically
// applies on top of whichever of these two an approved partner buys (see
// includes/14-partner-pricing.php). One row in this sheet = one
// WooCommerce product, linked to a track by the same track code already
// used in the main importer's Tracks sheet.
//
// Columns (Products sheet):
//   كود_المنتج            - unique code, used to update on re-upload (like every other sheet)
//   اسم_المنتج            - product title
//   اسم_المنتج_EN         - optional; English product title. Same pattern as the _EN columns
//                            in includes/18-excel-importer.php: when present + non-empty +
//                            Polylang active, a second, linked English WooCommerce product is
//                            created (same price/track/partner-price/min-seats), and the pair
//                            is registered as translations of each other via
//                            pll_set_post_language()/pll_save_post_translations(). Rows without
//                            English data behave exactly as before (Arabic-only) — fully
//                            backward compatible with earlier Arabic-only Products files.
//   النوع                  - "فردي" أو "منظمة"
//   السعر                  - regular price (number) — same price used for both language products
//   كود_التراك             - must match an existing Track's كود_التراك (looked up live from the DB, not from this file — the Tracks/Products files are independent uploads)
//   سعر_الشريك             - optional; partner price (applies to BOTH types, same product)
//   الحد_الأدنى_للمقاعد    - optional, only meaningful for "منظمة"; defaults to 5
// ============================================================

add_action('admin_menu', 'pildcm_products_import_menu');
function pildcm_products_import_menu() {
    add_submenu_page('pild-settings', 'Import Products', 'Import Products',
        'manage_options', 'pild-products-import', 'pildcm_products_import_page');
}

// Same code can tag two track posts (an Arabic one and its linked English
// translation). Returns ['ar' => id, 'en' => id] (0 when that language's
// post doesn't exist), read live from the DB via Polylang.
function pildcm_products_find_track_ids_by_code($code) {
    $ids = get_posts([
        'post_type' => 'track', 'posts_per_page' => -1, 'post_status' => 'any',
        'meta_key' => 'pild_import_code', 'meta_value' => $code, 'fields' => 'ids',
    ]);
    $out = ['ar' => 0, 'en' => 0];
    $polylang_active = function_exists('pll_get_post_language');
    foreach ($ids as $pid) {
        $lang = $polylang_active ? pll_get_post_language($pid) : 'ar';
        $out[$lang === 'en' ? 'en' : 'ar'] = (int) $pid;
    }
    return $out;
}

// BUGFIX: this used to run its own language-blind get_posts() query
// (posts_per_page=1, no language filter), so on a bilingual (Polylang)
// site with both an Arabic and an English track post sharing the same
// pild_import_code, it could silently return whichever one WordPress's
// default ordering happened to put first -- observed in practice
// linking products to the ENGLISH track post while the Arabic track
// (the one editors actually look at) was left with empty Registration
// fields. Now a thin, always-language-correct wrapper around the
// (already language-aware) plural lookup above -- single source of
// truth, no more chance of the two functions disagreeing.
function pildcm_products_find_track_id_by_code($code) {
    $ids = pildcm_products_find_track_ids_by_code($code);
    return !empty($ids['ar']) ? $ids['ar'] : 0;
}

// ── Validate the file, write nothing (mirrors 18-excel-importer.php's preview step) ──
function pildcm_products_build_plan($rows, $extra_track_codes = []) {
    $errors = [];
    $plan_rows = [];
    $seen = [];

    foreach ($rows as $i => $row) {
        $line = $i + 2;
        $code  = isset($row['كود_المنتج'])  ? trim($row['كود_المنتج'])  : '';
        $title = isset($row['اسم_المنتج'])  ? trim($row['اسم_المنتج']) : '';
        $title_en = isset($row['اسم_المنتج_EN']) ? trim($row['اسم_المنتج_EN']) : '';
        $type  = isset($row['النوع'])        ? trim($row['النوع'])       : '';
        $price = isset($row['السعر'])        ? trim($row['السعر'])       : '';
        $track_code = isset($row['كود_التراك']) ? trim($row['كود_التراك']) : '';
        $partner_price = isset($row['سعر_الشريك']) ? trim($row['سعر_الشريك']) : '';
        $min_seats     = isset($row['الحد_الأدنى_للمقاعد']) ? trim($row['الحد_الأدنى_للمقاعد']) : '';

        if ($code === '' || $title === '') { $errors[] = "صف $line: لازم يتحدد كود واسم منتج."; continue; }
        if (isset($seen[$code])) { $errors[] = "صف $line: الكود '$code' مكرر في نفس الشيت."; continue; }
        $seen[$code] = true;

        if (!in_array($type, ['فردي', 'منظمة'], true)) {
            $errors[] = "صف $line: عمود 'النوع' لازم يكون 'فردي' أو 'منظمة' بالظبط (اللي مكتوب: '$type').";
            continue;
        }
        if ($price === '' || !is_numeric($price) || (float) $price <= 0) {
            $errors[] = "صف $line: عمود 'السعر' لازم يكون رقم أكبر من صفر.";
            continue;
        }
        if ($track_code === '') { $errors[] = "صف $line: لازم يتحدد كود_التراك."; continue; }

        // PHASE 16: track may already exist in the DB, OR be brand new —
        // created by the SAME upload's Tracks sheet, in which case it has
        // no real post ID yet at preview time. track_id stays 0 (deferred)
        // for that case; pildcm_products_execute() resolves it after the
        // Tracks sheet has actually been created.
        $track_id = pildcm_products_find_track_id_by_code($track_code);
        if (!$track_id && !in_array($track_code, $extra_track_codes, true)) {
            $errors[] = "صف $line: كود التراك '$track_code' مش موجود في الموقع ولا في شيت Tracks بنفس الملف.";
            continue;
        }
        if ($partner_price !== '' && (!is_numeric($partner_price) || (float) $partner_price < 0)) {
            $errors[] = "صف $line: عمود 'سعر_الشريك' لازم يكون رقم (أو فاضي).";
            continue;
        }
        if ($min_seats !== '' && (!is_numeric($min_seats) || (int) $min_seats < 1)) {
            $errors[] = "صف $line: عمود 'الحد_الأدنى_للمقاعد' لازم يكون رقم صحيح 1 أو أكتر (أو فاضي).";
            continue;
        }

        $plan_rows[] = [
            'line' => $line, 'code' => $code, 'title' => $title, 'title_en' => $title_en, 'type' => $type,
            'price' => (float) $price, 'track_id' => $track_id, 'track_code' => $track_code,
            'partner_price' => $partner_price !== '' ? (float) $partner_price : null,
            'min_seats' => $min_seats !== '' ? (int) $min_seats : null,
        ];
    }

    return ['rows' => $plan_rows, 'errors' => $errors];
}

// Same 'pild_import_code' value tags both the Arabic product and its linked
// English translation, so a plain meta lookup returns both — filter down to
// the one post in the requested language (mirrors the map-building pattern
// in includes/18-excel-importer.php's pildcm_import_execute()).
function pildcm_products_find_existing_id($code, $lang, $polylang_active) {
    $ids = get_posts([
        'post_type' => 'product', 'posts_per_page' => -1, 'post_status' => 'any',
        'meta_key' => 'pild_import_code', 'meta_value' => $code, 'fields' => 'ids',
    ]);
    foreach ($ids as $pid) {
        $post_lang = $polylang_active && function_exists('pll_get_post_language') ? pll_get_post_language($pid) : 'ar';
        if (($post_lang === 'en' ? 'en' : 'ar') === $lang) return (int) $pid;
    }
    return 0;
}

// ── Product naming + slug rules ─────────────────────────────────────
// Client spec (confirmed): the product's DISPLAY NAME is derived from
// the linked TRACK's own title in that language -- not the free-text
// اسم_المنتج / اسم_المنتج_EN columns from the Products sheet (those are
// now only used as the "do we want an English product for this row at
// all" toggle -- see pildcm_products_execute()):
//   - Individual: "{Track title} — فردي"      / "{Track title} — Individual"
//   - Organization: "{Track title}" exactly, no suffix at all.
function pildcm_products_build_title($track_title, $type, $lang) {
    if ($type === 'منظمة') return $track_title;
    return $lang === 'en' ? ($track_title . ' — Individual') : ($track_title . ' — فردي');
}

// The slug is ALWAYS built from the Track's ENGLISH title (even for the
// Arabic product), then ind/org + ar/en are appended -- so an Arabic and
// an English product for the same track+type share the same English
// base and only their trailing language segment differs. Every track is
// expected to have an English name (اسم_التراك_EN is effectively
// required in practice); $track_title_ar is only ever used as a last-
// resort safety net so this never produces an empty slug.
function pildcm_products_build_slug($track_title_en, $track_title_ar, $type, $lang) {
    $base = sanitize_title($track_title_en !== '' ? $track_title_en : $track_title_ar);
    $type_seg = ($type === 'منظمة') ? 'org' : 'ind';
    return $base . '-' . $type_seg . '-' . $lang;
}

// Create/update ONE WooCommerce product (either language) and wire its
// common meta/ACF fields. $track_title is the linked Track's title IN
// THIS PRODUCT'S OWN LANGUAGE (used for the display name); $track_title_en
// is always the Track's English title regardless of $lang (used for the
// slug base only -- see pildcm_products_build_slug()). Returns the
// product ID, or 0 on failure.
function pildcm_products_save_one($code, $track_title, $track_title_en, $price, $track_id, $type, $partner_price, $min_seats, $lang, $polylang_active, &$created_count, &$updated_count) {
    $existing_id = pildcm_products_find_existing_id($code, $lang, $polylang_active);

    if ($existing_id) {
        $product = wc_get_product($existing_id);
        $updated_count++;
    } else {
        $product = new WC_Product_Simple();
        $created_count++;
    }
    if (!$product) return 0;

    $title = pildcm_products_build_title($track_title, $type, $lang);
    $slug  = pildcm_products_build_slug($track_title_en, $track_title, $type, $lang);

    $product->set_name($title);
    $product->set_slug($slug);
    $product->set_regular_price((string) $price);
    $product->set_status('publish');
    $product->set_catalog_visibility('visible');
    $product_id = $product->save();
    if (!$product_id) return 0;

    update_post_meta($product_id, 'pild_import_code', $code);
    if ($polylang_active) pll_set_post_language($product_id, $lang);

    if (function_exists('update_field') && $track_id) {
        update_field('product_tracks', [$track_id], $product_id);
    }

    if ($partner_price !== null) {
        update_post_meta($product_id, '_pild_partner_price', wc_format_decimal($partner_price));
    }

    if ($type === 'منظمة') {
        update_post_meta($product_id, '_pild_min_seats', $min_seats ?: 5);
        if (function_exists('update_field') && $track_id) update_field('pild_product_team', $product_id, $track_id);
    } else {
        if (function_exists('update_field') && $track_id) update_field('pild_product_individual', $product_id, $track_id);
    }

    if (function_exists('pildcm_purge_post_cache')) pildcm_purge_post_cache($product_id);

    return $product_id;
}

// ── Create/update the WooCommerce products + wire the track links ──
// Bilingual: when a row has a non-empty title_en AND Polylang is active, a
// second English product is created/updated alongside the Arabic one and
// the two are linked as translations — same opt-in pattern as every other
// sheet in includes/18-excel-importer.php. Rows without title_en stay
// Arabic-only, exactly as before.
function pildcm_products_execute($plan_rows, $tracks_id_map = null) {
    $created = 0; $updated = 0; $created_en = 0;
    $polylang_active = function_exists('pll_set_post_language') && function_exists('pll_save_post_translations');

    foreach ($plan_rows as $row) {
        // PHASE 16: track_id was deferred (0) if this row's track came from
        // the SAME upload's Tracks sheet and didn't have a real post ID yet
        // at preview time. Resolve it now: prefer the just-created id map
        // (passed in when this runs as part of the combined Sectors+Products
        // import), otherwise fall back to a fresh DB lookup (covers the
        // standalone Products-only import page, and the "same code, run
        // again" case where it exists by now either way).
        $track_id = $row['track_id'];
        if (!$track_id && $tracks_id_map && !empty($tracks_id_map['Tracks'][$row['track_code']]['ar'])) {
            $track_id = (int) $tracks_id_map['Tracks'][$row['track_code']]['ar'];
        }
        if (!$track_id) {
            $track_id = pildcm_products_find_track_id_by_code($row['track_code']);
        }
        if (!$track_id) continue; // shouldn't happen if build_plan validated correctly, but never link to nothing

        // ---- Resolve the linked Track's title in BOTH languages ----
        // Per the confirmed naming spec, the product's display name is
        // built from the TRACK's own title (not the free-text اسم_المنتج
        // columns below), and the slug is always keyed off the Track's
        // ENGLISH title regardless of which language product we're
        // saving. Link to the English track when one exists (created by
        // the same upload's Tracks sheet, or already on the site);
        // otherwise the slug helper falls back to the Arabic title so we
        // never end up with an empty slug.
        $track_id_en = 0;
        if ($tracks_id_map && !empty($tracks_id_map['Tracks'][$row['track_code']]['en'])) {
            $track_id_en = (int) $tracks_id_map['Tracks'][$row['track_code']]['en'];
        } else {
            $en_track_ids = pildcm_products_find_track_ids_by_code($row['track_code']);
            if (!empty($en_track_ids['en'])) $track_id_en = $en_track_ids['en'];
        }
        $track_title_ar = get_the_title($track_id);
        $track_title_en = $track_id_en ? get_the_title($track_id_en) : '';

        // ---- Arabic product (always) ----
        $ar_id = pildcm_products_save_one(
            $row['code'], $track_title_ar, $track_title_en, $row['price'], $track_id, $row['type'],
            $row['partner_price'], $row['min_seats'], 'ar', $polylang_active, $created, $updated
        );
        if (!$ar_id) continue;

        // ---- Optional linked English product ----
        // اسم_المنتج_EN is no longer used for the product's actual title
        // (that's always derived from the Track now) — it's kept purely
        // as the existing opt-in toggle: a non-empty value in that column
        // is still what decides whether an English product gets created
        // for this row at all.
        $title_en_toggle = isset($row['title_en']) ? $row['title_en'] : '';
        if ($polylang_active && $title_en_toggle !== '') {
            // Fall back to the Arabic track when no English track exists
            // yet — same fallback used for parent relationships elsewhere
            // in the combined importer.
            $track_id_for_en_product = $track_id_en ?: $track_id;

            $en_id = pildcm_products_save_one(
                $row['code'], $track_title_en !== '' ? $track_title_en : $track_title_ar, $track_title_en, $row['price'], $track_id_for_en_product, $row['type'],
                $row['partner_price'], $row['min_seats'], 'en', $polylang_active, $created_en, $updated
            );
            if ($en_id) {
                pll_save_post_translations(['ar' => $ar_id, 'en' => $en_id]);
            }
        }
    }

    // pild_is_team_product() (includes/24-team-purchase.php) caches the list
    // of Team-product IDs in a transient, normally busted by the 'acf/save_post'
    // hook — which update_field() alone does NOT trigger. Bust it once here so
    // newly-imported Team products are recognized immediately, not after 5 minutes.
    delete_transient('pild_team_product_ids');

    return ['created' => $created, 'updated' => $updated, 'created_en' => $created_en];
}

// ── Admin page: upload -> preview -> confirm (same two-step pattern as 18-excel-importer.php) ──
function pildcm_products_import_page() {
    if (!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>📦 استيراد المنتجات من إكسيل</h1>';
    echo '<p>ملف منفصل تمامًا عن ملف القطاعات — شيت واحد اسمه "Products" بس. كل صف = منتج ووكوميرس مربوط بتراك موجود بالفعل (بالكود).</p>';

    echo '<div class="notice notice-info" style="padding:12px 16px;"><p><strong>عناوين الأعمدة المطلوبة في الصف الأول (بالظبط بنفس الترتيب والتهجئة):</strong></p>'
       . '<code style="display:block;padding:8px;background:#f6f7f7;overflow-x:auto;">كود_المنتج | اسم_المنتج | اسم_المنتج_EN | النوع | السعر | كود_التراك | سعر_الشريك | الحد_الأدنى_للمقاعد</code>'
       . '<p style="margin-top:8px;">النوع لازم يكون <code>فردي</code> أو <code>منظمة</code> بالظبط. اسم_المنتج_EN، سعر_الشريك، والحد_الأدنى_للمقاعد اختياريين (سيب الخانة فاضية لو مش محتاجهم).</p>'
       . '<p style="margin-top:8px;">📦 <strong>ثنائي اللغة:</strong> لو عبّيت اسم_المنتج_EN وPolylang شغّال، هيتعمل منتج إنجليزي تاني مرتبط تلقائياً (نفس السعر ونفس التراك) — بالظبط زي شيتات Sectors/Domains/Tracks/Programs/Books. لو الخانة فاضية، المنتج بيفضل عربي بس زي ما كان.</p></div>';

    $step = isset($_POST['pildcm_step']) ? sanitize_text_field(wp_unslash($_POST['pildcm_step'])) : '';
    $tkey = 'pildcm_products_import_plan_' . get_current_user_id();

    if ($step === 'confirm' && check_admin_referer('pildcm_products_import_confirm')) {
        $plan_rows = get_transient($tkey);
        if ($plan_rows === false) {
            echo '<div class="notice notice-error"><p>انتهت صلاحية بيانات المعاينة (بعد ساعة). ارفع الملف تاني.</p></div>';
        } else {
            $result = pildcm_products_execute($plan_rows);
            delete_transient($tkey);
            echo '<div class="notice notice-success"><p><strong>تم الاستيراد بنجاح ✅</strong> — منتجات جديدة: ' . (int) $result['created'] . '، منتجات تم تحديثها: ' . (int) $result['updated'] . '، منتجات إنجليزي جديدة: ' . (int) $result['created_en'] . '</p></div>';
        }
    } elseif ($step === 'preview' && check_admin_referer('pildcm_products_import_preview') && !empty($_FILES['pildcm_products_file']['tmp_name'])) {
        $tmp_name  = $_FILES['pildcm_products_file']['tmp_name'];
        $orig_name = isset($_FILES['pildcm_products_file']['name']) ? sanitize_file_name($_FILES['pildcm_products_file']['name']) : '';

        if (strtolower(pathinfo($orig_name, PATHINFO_EXTENSION)) !== 'xlsx') {
            echo '<div class="notice notice-error"><p>لازم يكون الملف بصيغة .xlsx.</p></div>';
        } else {
            $sheets_raw = pildcm_xlsx_extract($tmp_name);
            if (is_wp_error($sheets_raw)) {
                echo '<div class="notice notice-error"><p>' . esc_html($sheets_raw->get_error_message()) . '</p></div>';
            } elseif (empty($sheets_raw['Products'])) {
                echo '<div class="notice notice-error"><p>لازم يكون فيه شيت اسمه "Products" بالظبط.</p></div>';
            } else {
                $build = pildcm_products_build_plan($sheets_raw['Products']);

                echo '<h2>📋 معاينة قبل الاستيراد</h2>';
                echo '<p>عدد الصفوف الصالحة: <strong>' . count($build['rows']) . '</strong></p>';

                if (!empty($build['errors'])) {
                    echo '<div class="notice notice-error"><p><strong>فيه أخطاء لازم تتصلح جوه الإكسيل الأول (لسه مفيش أي حاجة اتحفظت):</strong></p><ul style="list-style:disc;margin-inline-start:20px">';
                    foreach ($build['errors'] as $err) echo '<li>' . esc_html($err) . '</li>';
                    echo '</ul></div>';
                } else {
                    echo '<p style="color:#666;max-width:900px">اسم المنتج بقى بيتبني تلقائي من اسم التراك المرتبط (مش من عمود اسم_المنتج في الإكسيل) — عمودي اسم_المنتج/اسم_المنتج_EN لسه بيتقروا بس كـ "سويتش" لتحديد هل يتعمل منتج إنجليزي لنفس الصف ولا لأ. الاسم اللي هيتحفظ فعلياً هو ده في عمود "الاسم" تحت:</p>';
                    echo '<table class="widefat striped" style="max-width:900px;margin-bottom:20px"><thead><tr><th>الكود</th><th>الاسم (فعلي)</th><th>النوع</th><th>السعر</th><th>التراك</th><th>سعر الشريك</th><th>حد أدنى مقاعد</th></tr></thead><tbody>';
                    foreach ($build['rows'] as $r) {
                        $track_title_ar_preview = get_the_title($r['track_id']);
                        $built_title = pildcm_products_build_title($track_title_ar_preview, $r['type'], 'ar');
                        echo '<tr><td>' . esc_html($r['code']) . '</td><td>' . esc_html($built_title) . '</td><td>' . esc_html($r['type']) . '</td><td>' . esc_html($r['price']) . '</td><td>' . esc_html($track_title_ar_preview) . '</td><td>' . ($r['partner_price'] !== null ? esc_html($r['partner_price']) : '—') . '</td><td>' . ($r['min_seats'] !== null ? esc_html($r['min_seats']) : ($r['type'] === 'منظمة' ? '5 (افتراضي)' : '—')) . '</td></tr>';
                    }
                    echo '</tbody></table>';

                    set_transient($tkey, $build['rows'], HOUR_IN_SECONDS);
                    echo '<div class="notice notice-success"><p>مفيش أخطاء ✅ — دوس "تأكيد الاستيراد" عشان تتنفذ العملية فعلياً على الموقع.</p></div>';
                    echo '<form method="post">';
                    wp_nonce_field('pildcm_products_import_confirm');
                    echo '<input type="hidden" name="pildcm_step" value="confirm">';
                    submit_button('✅ تأكيد استيراد المنتجات الآن');
                    echo '</form>';
                }
            }
        }
    }

    echo '<h2 style="margin-top:32px;">رفع ملف جديد</h2>';
    echo '<form method="post" enctype="multipart/form-data">';
    wp_nonce_field('pildcm_products_import_preview');
    echo '<input type="hidden" name="pildcm_step" value="preview">';
    echo '<input type="file" name="pildcm_products_file" accept=".xlsx" required> ';
    submit_button('👁️ معاينة الملف');
    echo '</form>';

    echo '</div>';
}
