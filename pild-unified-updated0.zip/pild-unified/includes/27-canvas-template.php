<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 27. CANVAS TEMPLATE for Track / Program / Playbook pages
// ------------------------------------------------------------
// PHASE 17: these three post types are meant to show only the plugin's
// own generated content (hero, progress, program/book lists — all built
// by the_content filters in pild-unified.php), full-width, with no theme
// header/footer/navigation around it — "canvas" style, same idea as
// Elementor's own "Canvas" page template, but built as a plain WordPress
// template so it doesn't depend on Elementor being active.
//
// Priority 999 on template_include means this wins over anything a theme
// or another plugin might also try to set for these post types.
// ============================================================
// ============================================================
// 27. CANVAS TEMPLATE for Track / Program / Playbook / Book pages
// ------------------------------------------------------------
// PHASE 17: these post types are meant to show only the plugin's
// own generated content (hero, progress, program/book lists — all built
// by the_content filters in pild-unified.php), full-width, with no theme
// header/footer/navigation around it — "canvas" style, same idea as
// Elementor's own "Canvas" page template, but built as a plain WordPress
// template so it doesn't depend on Elementor being active.
//
// store_book (includes/34-book-store.php) joined this list so the book
// reading page is a real full-screen canvas too, instead of showing the
// theme's normal title/author/date header and Previous/Next post
// navigation around it — that theme chrome applied even when the book's
// own content (the fullscreen iframe reader, or its locked/plain-text
// fallback) was already meant to be the whole page.
//
// Priority 999 on template_include means this wins over anything a theme
// or another plugin might also try to set for these post types.
// ============================================================
add_filter('template_include', 'pild_canvas_template_include', 999);
function pild_canvas_template_include($template) {
    if (is_singular(['track', 'program', 'playbook', 'store_book'])) {
        $canvas = PILD_PATH . 'templates/canvas.php';
        if (file_exists($canvas)) return $canvas;
    }
    return $template;
}
