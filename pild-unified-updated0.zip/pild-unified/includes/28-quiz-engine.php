<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// 26. NATIVE QUIZ ENGINE
// ------------------------------------------------------------
// Replaces the Quiz Maker dependency for tracks that use it.
// Built on the CPTs that already exist in this plugin:
//   - 'assessment' (linked to a 'track' via 'assessment_track')
//   - 'question'    (linked to an 'assessment' via 'question_assessment')
//
// Design decisions (see project notes):
//   1. Session lock — the drawn question set is fixed to the attempt
//      row the moment it's created. A page refresh MUST return the
//      same questions, never a fresh draw.
//   2. Server-side scoring & timer — correct answers never reach the
//      browser before submission; expiry is checked against
//      started_at + time_limit on the server, not client JS.
//   3. Stratified draw — if questions carry a 'question_strand' tag,
//      the draw pulls evenly across strands instead of pure random,
//      so difficulty/coverage stays consistent between learners.
//   4. One attempt per user per assessment (mirrors the Quiz Maker
//      "Maximum attempts = 1 / User ID" setting already in use).
// ============================================================

// ------------------------------------------------------------
// ACF FIELDS — assessment settings + question bank fields
// ------------------------------------------------------------
add_action( 'acf/include_fields', function () {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

    // Assessment-level settings (question count, time limit, pass score)
    acf_add_local_field_group( [
        'key'    => 'group_assessment_quiz_settings',
        'title'  => 'Assessment Settings',
        'fields' => [
            [ 'key' => 'field_assessment_question_count', 'label' => 'Questions per attempt', 'name' => 'assessment_question_count', 'type' => 'number', 'default_value' => 20, 'min' => 1 ],
            [ 'key' => 'field_assessment_time_limit',     'label' => 'Time limit (seconds)',    'name' => 'assessment_time_limit',     'type' => 'number', 'default_value' => 3600, 'min' => 60 ],
            [ 'key' => 'field_assessment_pass_score',     'label' => 'Pass score (%)',          'name' => 'assessment_pass_score',     'type' => 'number', 'default_value' => 70, 'min' => 0, 'max' => 100 ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'assessment' ] ] ],
    ] );

    // Question bank fields: choices, correct answer(s), explanation, strand tag
    acf_add_local_field_group( [
        'key'    => 'group_question_bank_fields',
        'title'  => 'Question Content',
        'fields' => [
            [
                'key'          => 'field_question_choices',
                'label'        => 'Choices',
                'name'         => 'question_choices',
                'type'         => 'repeater',
                'min'          => 2,
                'max'          => 6,
                'layout'       => 'table',
                'button_label' => 'Add Choice',
                'sub_fields'   => [
                    [ 'key' => 'field_choice_text',    'label' => 'Choice text', 'name' => 'choice_text', 'type' => 'text', 'required' => 1 ],
                    [ 'key' => 'field_choice_correct',  'label' => 'Correct?',    'name' => 'is_correct',  'type' => 'true_false', 'ui' => 1 ],
                ],
            ],
            [ 'key' => 'field_question_explanation', 'label' => 'Explanation (shown after submission)', 'name' => 'question_explanation', 'type' => 'textarea', 'rows' => 2 ],
            [ 'key' => 'field_question_strand',       'label' => 'Strand / sub-topic (optional, used for balanced random draw)', 'name' => 'question_strand', 'type' => 'text' ],
            [ 'key' => 'field_question_points',       'label' => 'Points', 'name' => 'question_points', 'type' => 'number', 'default_value' => 1, 'min' => 1 ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'question' ] ] ],
    ] );
} );

// ------------------------------------------------------------
// HELPERS
// ------------------------------------------------------------

/**
 * All published questions belonging to an assessment's question bank.
 * Returns raw post IDs only — no answer data (caller decides what's
 * safe to expose to the browser).
 */
function pild_quiz_get_bank_question_ids( $assessment_id ) {
    return get_posts( [
        'post_type'      => 'question',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_query'     => [ [ 'key' => 'question_assessment', 'value' => (int) $assessment_id ] ],
        'fields'         => 'ids',
    ] );
}

/**
 * Stratified random draw: group the bank by 'question_strand' (questions
 * with no strand fall into a single "general" bucket), then round-robin
 * pull from each bucket until $count is reached. Falls back to a plain
 * shuffle when there's only one bucket (no strands defined yet) or the
 * bank is smaller than $count.
 */
function pild_quiz_draw_questions( $assessment_id, $count ) {
    $ids = pild_quiz_get_bank_question_ids( $assessment_id );
    if ( count( $ids ) <= $count ) {
        shuffle( $ids );
        return $ids;
    }

    $buckets = [];
    foreach ( $ids as $qid ) {
        $strand = trim( (string) get_field( 'question_strand', $qid ) );
        if ( $strand === '' ) $strand = '_general';
        $buckets[ $strand ][] = $qid;
    }

    if ( count( $buckets ) <= 1 ) {
        shuffle( $ids );
        return array_slice( $ids, 0, $count );
    }

    foreach ( $buckets as &$b ) shuffle( $b );
    unset( $b );

    $drawn = [];
    $bucket_keys = array_keys( $buckets );
    $i = 0;
    while ( count( $drawn ) < $count ) {
        $advanced = false;
        foreach ( $bucket_keys as $key ) {
            if ( count( $drawn ) >= $count ) break;
            if ( isset( $buckets[ $key ][ $i ] ) ) {
                $drawn[]  = $buckets[ $key ][ $i ];
                $advanced = true;
            }
        }
        if ( ! $advanced ) break; // exhausted every bucket
        $i++;
    }
    shuffle( $drawn ); // don't leave strand order predictable to the learner
    return $drawn;
}

/**
 * Question payload safe to send to the browser — no correct-answer flags.
 * Choice order is randomized once and stored so it stays stable across
 * page reloads of the same attempt.
 */
function pild_quiz_public_question_payload( $question_id, $shuffled_choice_order = null ) {
    $choices = get_field( 'question_choices', $question_id ) ?: [];
    $order   = $shuffled_choice_order ?: range( 0, count( $choices ) - 1 );
    if ( ! $shuffled_choice_order ) shuffle( $order );

    $public_choices = [];
    foreach ( $order as $idx ) {
        if ( ! isset( $choices[ $idx ] ) ) continue;
        $public_choices[] = [
            'index' => $idx, // original index, needed to score server-side
            'text'  => $choices[ $idx ]['choice_text'],
        ];
    }

    return [
        'id'      => $question_id,
        'text'    => get_the_title( $question_id ) ?: wp_strip_all_tags( get_post_field( 'post_content', $question_id ) ),
        'choices' => $public_choices,
        'order'   => $order,
    ];
}

/** Track this assessment belongs to. */
function pild_quiz_get_track_for_assessment( $assessment_id ) {
    return (int) get_post_meta( $assessment_id, 'assessment_track', true );
}

/**
 * The native assessment linked to a track (reverse of assessment_track),
 * for use on track/program templates that need to link to "Take the
 * Assessment" without hard-coding an assessment ID. Mirrors the pattern
 * of pildcm_get_track_for_quiz() in 10-quiz-certificate.php but in the
 * opposite direction.
 */
function pild_quiz_get_assessment_for_track( $track_id ) {
    $ids = get_posts( [
        'post_type'      => 'assessment',
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'meta_query'     => [ [ 'key' => 'assessment_track', 'value' => (int) $track_id ] ],
        'fields'         => 'ids',
    ] );
    return $ids ? (int) $ids[0] : 0;
}

// ------------------------------------------------------------
// AJAX: START (or resume) AN ATTEMPT
// ------------------------------------------------------------
// Saves the name the learner confirms on the pre-assessment screen as
// their real WordPress display_name — this is the same field every
// certificate (and the public profile) already reads, so no other code
// needs to change. Client note (Sep 2026): certificates only show one
// language at a time, so learners are asked to confirm their name in
// English right before starting, since it's what appears on the
// certificate. A soft client-side warning nudges them if the text looks
// Arabic, but this endpoint itself doesn't block or validate language —
// keeps this reusable for genuinely Arabic-only names too.
add_action( 'wp_ajax_pild_quiz_confirm_name', 'pild_quiz_ajax_confirm_name' );
function pild_quiz_ajax_confirm_name() {
    check_ajax_referer( 'pild_quiz_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( __( 'Not logged in', 'pild-unified' ) );

    $name = sanitize_text_field( wp_unslash( $_POST['full_name'] ?? '' ) );
    if ( $name === '' ) wp_send_json_error( __( 'Please enter your name.', 'pild-unified' ) );

    $user_id = get_current_user_id();
    wp_update_user( [ 'ID' => $user_id, 'display_name' => $name ] );

    wp_send_json_success( [ 'display_name' => $name ] );
}

add_action( 'wp_ajax_pild_quiz_start', 'pild_quiz_ajax_start' );
function pild_quiz_ajax_start() {
    check_ajax_referer( 'pild_quiz_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( 'Not logged in' );

    $assessment_id = isset( $_POST['assessment_id'] ) ? (int) $_POST['assessment_id'] : 0;
    $user_id       = get_current_user_id();
    if ( ! $assessment_id || get_post_type( $assessment_id ) !== 'assessment' ) {
        wp_send_json_error( 'Invalid assessment' );
    }

    $track_id = pild_quiz_get_track_for_assessment( $assessment_id );
    if ( ! $track_id ) wp_send_json_error( 'This assessment is not linked to a track' );

    // Access check — same rule as the Quiz Maker integration.
    if ( ! pildcm_is_enrolled( $user_id, $track_id ) ) {
        $has_access = function_exists( 'wc_memberships_user_can' )
            && wc_memberships_user_can( $user_id, 'view', [ 'post' => $track_id ] );
        if ( ! $has_access ) wp_send_json_error( 'You are not enrolled in this track' );
    }

    global $wpdb;
    $table = "{$wpdb->prefix}pild_quiz_attempts";

    // Already passed this track before? Don't allow a retake.
    $already_passed = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id=%d AND passed='yes' LIMIT 1",
        $user_id, $track_id
    ) );
    if ( $already_passed ) wp_send_json_error( [ 'code' => 'already_passed', 'message' => 'You already passed this assessment.' ] );

    // Resume an unfinished attempt if one exists (session lock —
    // never draw a new question set for an in-progress attempt).
    $attempt = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND assessment_id=%d AND submitted_at IS NULL ORDER BY id DESC LIMIT 1",
        $user_id, $assessment_id
    ) );

    if ( ! $attempt ) {
        // Block a second attempt if a previous one was submitted and failed,
        // unless the site wants to allow retakes (out of scope for MVP —
        // matches "Maximum attempts = 1" from the Quiz Maker settings).
        $prior_submitted = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE user_id=%d AND assessment_id=%d AND submitted_at IS NOT NULL LIMIT 1",
            $user_id, $assessment_id
        ) );
        if ( $prior_submitted ) wp_send_json_error( [ 'code' => 'no_attempts_left', 'message' => 'You have no attempts left for this assessment.' ] );

        $question_count = (int) ( get_field( 'assessment_question_count', $assessment_id ) ?: 20 );
        $time_limit     = (int) ( get_field( 'assessment_time_limit', $assessment_id ) ?: 3600 );

        $drawn = pild_quiz_draw_questions( $assessment_id, $question_count );
        if ( count( $drawn ) < 1 ) wp_send_json_error( 'This assessment has no questions yet' );

        // Lock in the choice order per question too, so a refresh
        // shows the same answer order, not a re-shuffled one.
        $locked = [];
        foreach ( $drawn as $qid ) {
            $choices = get_field( 'question_choices', $qid ) ?: [];
            $order   = range( 0, count( $choices ) - 1 );
            shuffle( $order );
            $locked[] = [ 'id' => $qid, 'order' => $order ];
        }

        // wp_json_encode() (→ json_encode()) returns false on invalid UTF-8
        // in the question/choice text. Inserting false into a NOT NULL
        // longtext column under strict SQL mode fails the whole row —
        // silently, unless we check for it here.
        $question_ids_json = wp_json_encode( $locked );
        if ( $question_ids_json === false ) {
            error_log( sprintf(
                '[PILD quiz] Start failed — wp_json_encode() of question set returned false for user %d, assessment %d. json_last_error=%d (%s). Likely invalid UTF-8 in a question or choice for one of these question IDs: %s',
                $user_id, $assessment_id, json_last_error(), json_last_error_msg(),
                implode( ',', $drawn )
            ) );
            wp_send_json_error( 'Could not start the assessment due to a data error. Please contact support.' );
        }

        $inserted = $wpdb->insert( $table, [
            'user_id'       => $user_id,
            'assessment_id' => $assessment_id,
            'track_id'      => $track_id,
            'question_ids'  => $question_ids_json,
            'time_limit'    => $time_limit,
            'started_at'    => current_time( 'mysql' ),
        ] );

        // Never silently pretend an attempt exists when the INSERT
        // failed — that's exactly what produced "Attempt not found"
        // on submit (a fake, never-persisted attempt_id sent back to
        // the browser). Log wpdb's actual error so we can see *why*
        // MySQL rejected the row.
        if ( ! $inserted ) {
            error_log( sprintf(
                '[PILD quiz] Start failed — INSERT into %s rejected for user %d, assessment %d. wpdb->last_error: %s',
                $table, $user_id, $assessment_id, $wpdb->last_error
            ) );
            wp_send_json_error( 'Could not start the assessment. Please try again or contact support.' );
        }

        // Force-commit this insert immediately. On this host, something
        // else running earlier in the same request (WooCommerce /
        // WooCommerce Memberships is the usual suspect) opens a DB
        // transaction that never gets an explicit COMMIT. InnoDB still
        // advances the auto_increment counter for our insert (that part
        // is never rolled back), but the row itself silently vanishes
        // when the request ends and MySQL rolls back the still-open
        // transaction — which is exactly what "insert succeeds, no
        // wpdb error, row is gone by submit time" looks like. A plain
        // manual INSERT from phpMyAdmin uses its own connection/
        // transaction, so it isn't affected and persists fine, which is
        // why that test looked healthy while real attempts kept
        // disappearing.
        $commit_result = $wpdb->query( 'COMMIT' );
        if ( false === $commit_result ) {
            error_log( sprintf(
                '[PILD quiz] COMMIT after insert returned an error for user %d, assessment %d, attempt %d. wpdb->last_error: %s',
                $user_id, $assessment_id, $wpdb->insert_id, $wpdb->last_error
            ) );
        }

        $attempt_id     = $wpdb->insert_id;

        // Read our own write back, in the same request, right after the
        // commit — proves whether the row genuinely persisted at the DB
        // level, independent of anything the browser does afterward.
        $self_check = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE id=%d", $attempt_id
        ) );
        error_log( sprintf(
            '[PILD quiz] Start OK — created attempt %d for user %d, assessment %d, db=%s. Self-check read-back: %s. wpdb->last_error after self-check: %s',
            $attempt_id, $user_id, $assessment_id, DB_NAME,
            $self_check ? "FOUND (id={$self_check})" : 'NOT FOUND',
            $wpdb->last_error ?: '(none)'
        ) );

        // Safety net, independent of whatever keeps deleting/losing this
        // row at the DB level (still under investigation) — a second,
        // disposable copy of everything needed to grade this attempt,
        // outside the pild_quiz_attempts table entirely (WordPress's own
        // options-based transient storage). If the DB row vanishes
        // before submit, pild_quiz_ajax_submit() below can rebuild it
        // from this instead of losing the learner's result outright.
        set_transient( 'pild_quiz_backup_' . $attempt_id, [
            'user_id' => $user_id, 'assessment_id' => $assessment_id, 'track_id' => $track_id,
            'question_ids' => $locked, 'time_limit' => $time_limit, 'started_at' => current_time( 'mysql' ),
        ], 2 * HOUR_IN_SECONDS );

        $started_at_ts  = current_time( 'timestamp' );
    } else {
        $locked        = json_decode( $attempt->question_ids, true ) ?: [];
        $attempt_id    = (int) $attempt->id;
        $time_limit    = (int) $attempt->time_limit;
        $started_at_ts = strtotime( $attempt->started_at );
    }

    $questions = [];
    foreach ( $locked as $entry ) {
        $questions[] = pild_quiz_public_question_payload( $entry['id'], $entry['order'] );
    }

    $elapsed          = current_time( 'timestamp' ) - $started_at_ts;
    $seconds_remaining = max( 0, $time_limit - $elapsed );

    wp_send_json_success( [
        'attempt_id'        => $attempt_id,
        'questions'         => $questions,
        'seconds_remaining' => $seconds_remaining,
        'total_questions'   => count( $questions ),
    ] );
}

// ------------------------------------------------------------
// AJAX: TAB-SWITCH / VISIBILITY-LOSS LOG (soft anti-cheat signal)
// ------------------------------------------------------------
add_action( 'wp_ajax_pild_quiz_flag', 'pild_quiz_ajax_flag' );
function pild_quiz_ajax_flag() {
    check_ajax_referer( 'pild_quiz_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( 'Not logged in' );

    $attempt_id = isset( $_POST['attempt_id'] ) ? (int) $_POST['attempt_id'] : 0;
    global $wpdb;
    $table = "{$wpdb->prefix}pild_quiz_attempts";
    $wpdb->query( $wpdb->prepare(
        "UPDATE $table SET tab_switches = tab_switches + 1 WHERE id=%d AND user_id=%d AND submitted_at IS NULL",
        $attempt_id, get_current_user_id()
    ) );
    wp_send_json_success();
}

// ------------------------------------------------------------
// AJAX: SUBMIT — server-side scoring, time check, cert/badge hookup
// ------------------------------------------------------------
add_action( 'wp_ajax_pild_quiz_submit', 'pild_quiz_ajax_submit' );
function pild_quiz_ajax_submit() {
    check_ajax_referer( 'pild_quiz_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( 'Not logged in' );

    $user_id    = get_current_user_id();
    $attempt_id = isset( $_POST['attempt_id'] ) ? (int) $_POST['attempt_id'] : 0;
    $assessment_id_hint = isset( $_POST['assessment_id'] ) ? (int) $_POST['assessment_id'] : 0;
    $answers    = isset( $_POST['answers'] ) ? (array) $_POST['answers'] : []; // { question_id: chosen_choice_index }

    global $wpdb;
    // If this DB layer does read/write splitting (HyperDB or similar,
    // common on managed WordPress hosting), force this read onto the
    // WRITE connection. A quick single-question attempt like the one
    // that surfaced this — insert the attempt, answer it, submit within
    // a couple of seconds — is exactly the timing most likely to hit a
    // replica that hasn't caught up yet, showing "Attempt not found" for
    // a row that genuinely exists. A no-op on a plain single-DB setup.
    if ( method_exists( $wpdb, 'send_reads_to_masters' ) ) $wpdb->send_reads_to_masters();

    $table   = "{$wpdb->prefix}pild_quiz_attempts";
    $attempt = $attempt_id ? $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM $table WHERE id=%d AND user_id=%d LIMIT 1", $attempt_id, $user_id
    ) ) : null;

    // Self-healing fallback: the id the browser sent doesn't match a row
    // (stale tab, a race at start, etc.) — instead of losing the learner's
    // answers, recover the most recent still-open attempt for this user
    // (narrowed to the right assessment when we have that hint) and submit
    // against that instead. Logged unconditionally (not just under
    // WP_DEBUG) — this failure is rare and loses a real result if it
    // isn't traceable, and production sites normally run with WP_DEBUG
    // off, which was silencing the only trail this had.
    if ( ! $attempt ) {
        $fallback_sql = "SELECT * FROM $table WHERE user_id=%d AND submitted_at IS NULL";
        $fallback_args = [ $user_id ];
        if ( $assessment_id_hint ) { $fallback_sql .= " AND assessment_id=%d"; $fallback_args[] = $assessment_id_hint; }
        $fallback_sql .= " ORDER BY id DESC LIMIT 1";
        $attempt = $wpdb->get_row( $wpdb->prepare( $fallback_sql, $fallback_args ) );

        if ( $attempt ) {
            error_log( sprintf(
                '[PILD quiz] Recovered mismatched attempt_id on submit — client sent %d, user %d, recovered attempt %d instead.',
                $attempt_id, $user_id, $attempt->id
            ) );
        }
    }

    if ( ! $attempt ) {
        // Last-resort recovery: rebuild the row from the disposable
        // backup written at start (pild_quiz_ajax_start() above) — a
        // safety net against whatever keeps removing this specific row
        // at the DB level (still under investigation as of Sep 2026;
        // see the [PILD quiz] Start OK / self-check log lines), so a
        // learner's completed attempt isn't lost outright even if that
        // mystery isn't resolved yet.
        $backup = $attempt_id ? get_transient( 'pild_quiz_backup_' . $attempt_id ) : false;
        if ( $backup && (int) $backup['user_id'] === $user_id ) {
            $recreated = $wpdb->insert( $table, [
                'user_id'       => $backup['user_id'],
                'assessment_id' => $backup['assessment_id'],
                'track_id'      => $backup['track_id'],
                'question_ids'  => wp_json_encode( $backup['question_ids'] ),
                'time_limit'    => $backup['time_limit'],
                'started_at'    => $backup['started_at'],
            ] );
            if ( $recreated ) {
                $wpdb->query( 'COMMIT' );
                $attempt = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $wpdb->insert_id ) );
                error_log( sprintf(
                    '[PILD quiz] Recovered attempt %d (originally %d) from the transient backup for user %d — the DB row was missing at submit time.',
                    $attempt ? $attempt->id : 0, $attempt_id, $user_id
                ) );
            }
        }
    }

    if ( ! $attempt ) {
        error_log( sprintf(
            '[PILD quiz] Submit failed — no attempt at all for user %d (client sent attempt_id=%d, assessment_id=%d), db=%s. No transient backup available either.',
            $user_id, $attempt_id, $assessment_id_hint, DB_NAME
        ) );
        wp_send_json_error( 'Attempt not found' );
    }
    if ( $attempt->submitted_at ) wp_send_json_error( 'This attempt was already submitted' );

    // ── Server-side expiry check — the client's timer is cosmetic only ──
    $started_at_ts = strtotime( $attempt->started_at );
    $deadline_ts   = $started_at_ts + (int) $attempt->time_limit;
    $now_ts        = current_time( 'timestamp' );
    $expired       = $now_ts > ( $deadline_ts + 15 ); // 15s grace for request latency

    // ── Server-side scoring — correct answers were never sent to the browser ──
    $locked        = json_decode( $attempt->question_ids, true ) ?: [];
    $total_points  = 0;
    $earned_points = 0;
    $review        = [];

    foreach ( $locked as $entry ) {
        $qid     = $entry['id'];
        $choices = get_field( 'question_choices', $qid ) ?: [];
        $points  = (int) ( get_field( 'question_points', $qid ) ?: 1 );
        $total_points += $points;

        $correct_index = null;
        foreach ( $choices as $i => $c ) {
            if ( ! empty( $c['is_correct'] ) ) { $correct_index = $i; break; }
        }

        $chosen    = isset( $answers[ $qid ] ) ? (int) $answers[ $qid ] : null;
        $is_right  = ( ! $expired && $correct_index !== null && $chosen === $correct_index );
        if ( $is_right ) $earned_points += $points;

        // Temporary diagnostic (Sep 2026) for a 0%-despite-correct-answer
        // report — pinpoints exactly which of the three possible causes it
        // is: (a) $answers never contained this qid at all (raw POST data
        // problem), (b) is_correct genuinely isn't set on any choice for
        // this question, or (c) expiry ($expired) forcing every answer
        // wrong regardless. Safe to remove once this is resolved.
        error_log( sprintf(
            '[PILD quiz] Score check — qid=%d, choices_found=%d, correct_index=%s, chosen=%s, expired=%s, raw_answers=%s',
            $qid, count( $choices ),
            $correct_index === null ? 'NULL' : $correct_index,
            $chosen === null ? 'NULL' : $chosen,
            $expired ? 'yes' : 'no',
            wp_json_encode( $answers )
        ) );

        $review[] = [
            'id'             => $qid,
            'correct'        => $is_right,
            'correct_index'  => $correct_index,
            'chosen_index'   => $chosen,
            'explanation'    => get_field( 'question_explanation', $qid ),
        ];
    }

    $score_pct  = $total_points > 0 ? round( ( $earned_points / $total_points ) * 100 ) : 0;
    $pass_score = (float) ( get_field( 'assessment_pass_score', $attempt->assessment_id ) ?: 70 );
    $is_passed  = ( ! $expired && $score_pct >= $pass_score );

    $wpdb->update( $table, [
        'answers'      => wp_json_encode( $answers ),
        'submitted_at' => current_time( 'mysql' ),
        'score'        => $score_pct,
        'passed'       => $is_passed ? 'yes' : 'no',
    ], [ 'id' => $attempt->id ] );
    // Same open-transaction issue as the insert on start — force this
    // through so a submitted result can't silently disappear either.
    $wpdb->query( 'COMMIT' );

    // ── Hand off to the same pild_results / certificate / badge logic
    //    already used for Quiz Maker tracks (includes/10-quiz-certificate.php) ──
    //
    // NOTE: pildcm_generate_branded_certificate() below writes an OLDER,
    // static "Professional Certificate" HTML file to disk (see
    // includes/10-quiz-certificate.php) and used to be returned directly
    // to the browser here. Every other surface in the plugin (solo/member
    // dashboards, public profile, the track page's certificate card) links
    // to pildcm_get_certificate_url() instead, which resolves to the
    // newer dynamic /certificate/{code} route rendered by
    // pildcm_show_certificate_html() in includes/12-cert-verify-acf.php —
    // a different, more polished template (level-colored seal, verification
    // footer). That mismatch is why two learners who both passed could see
    // two different-looking certificates depending on whether they clicked
    // "View Certificate" on this result screen (old file) or opened it
    // later from their dashboard (new /certificate/ route). We still
    // generate the legacy file for backward compatibility (older rows /
    // integrations may read the `certificate_url` column directly), but
    // the URL sent to THIS screen's button is now the same canonical
    // /certificate/{code} route everywhere else already uses, so every
    // learner sees the one current design regardless of entry point.
    $track_id = (int) $attempt->track_id;
    $cert_url = null;

    if ( $is_passed ) {
        $cert_code = strtoupper( wp_generate_password( 12, false ) );
        $existing  = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id=%d AND passed='yes' LIMIT 1",
            $user_id, $track_id
        ) );
        if ( $existing ) {
            $wpdb->update( "{$wpdb->prefix}pild_results", [
                'score' => $score_pct, 'passed' => 'yes', 'certificate_code' => $cert_code, 'completed_at' => current_time( 'mysql' ),
            ], [ 'id' => $existing ] );
        } else {
            $wpdb->insert( "{$wpdb->prefix}pild_results", [
                'user_id' => $user_id, 'track_id' => $track_id, 'score' => $score_pct,
                'total_questions' => count( $locked ), 'passed' => 'yes',
                'certificate_code' => $cert_code, 'completed_at' => current_time( 'mysql' ),
            ] );
        }

        if ( function_exists( 'pildcm_generate_branded_certificate' ) ) {
            $legacy_cert_url = pildcm_generate_branded_certificate(
                $user_id, $track_id, $attempt->assessment_id, $score_pct, $cert_code,
                [ 'questions_count' => count( $locked ) ]
            );
            if ( $legacy_cert_url ) {
                $wpdb->update( "{$wpdb->prefix}pild_results", [ 'certificate_url' => $legacy_cert_url ], [ 'user_id' => $user_id, 'track_id' => $track_id, 'passed' => 'yes' ] );
            }
        }

        // Canonical, current-design certificate link — same one every
        // other part of the plugin uses (see note above).
        $cert_url = home_url( '/certificate/' . $cert_code );

        if ( function_exists( 'pildcm_check_and_award_badges' ) ) {
            pildcm_check_and_award_badges( $user_id, $track_id, $score_pct, true );
        }
    } else {
        $already_has_pass = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id=%d AND passed='yes' LIMIT 1",
            $user_id, $track_id
        ) );
        if ( ! $already_has_pass ) {
            $wpdb->insert( "{$wpdb->prefix}pild_results", [
                'user_id' => $user_id, 'track_id' => $track_id, 'score' => $score_pct,
                'total_questions' => count( $locked ), 'passed' => 'no', 'completed_at' => current_time( 'mysql' ),
            ] );
        }
    }

    // Final commit covering the pild_results / certificate / badge
    // writes above, for the same reason as the two COMMITs earlier in
    // this file.
    $wpdb->query( 'COMMIT' );

    wp_send_json_success( [
        'score'         => $score_pct,
        'passed'        => $is_passed,
        'expired'       => $expired,
        'pass_score'    => $pass_score,
        'certificate_url' => $cert_url,
        'review'        => $review,
    ] );
}

// ------------------------------------------------------------
// AUTO-RENDER THE QUIZ ON THE ASSESSMENT'S OWN SINGLE PAGE
// ------------------------------------------------------------
// So pild_quiz_get_assessment_for_track() + get_permalink($assessment_id)
// (used in the track page's "Take the Assessment" button) lands on a
// working quiz, with no extra manual shortcode placement needed.
add_filter( 'the_content', 'pild_quiz_render_on_assessment_page', 20 );
function pild_quiz_render_on_assessment_page( $content ) {
    if ( ! is_singular( 'assessment' ) || ! in_the_loop() || ! is_main_query() ) return $content;
    return $content . do_shortcode( '[pild_quiz assessment_id="' . get_the_ID() . '"]' );
}

// ------------------------------------------------------------
// SHORTCODE + ENQUEUE
// ------------------------------------------------------------
add_shortcode( 'pild_quiz', 'pild_quiz_shortcode' );
function pild_quiz_shortcode( $atts ) {
    $atts = shortcode_atts( [ 'assessment_id' => 0 ], $atts );
    $assessment_id = (int) $atts['assessment_id'];
    if ( ! $assessment_id || get_post_type( $assessment_id ) !== 'assessment' ) {
        return '<p>' . esc_html__( 'Assessment not found.', 'pild-unified' ) . '</p>';
    }
    if ( ! is_user_logged_in() ) {
        return '<p>' . esc_html__( 'Please log in to take this assessment.', 'pild-unified' ) . '</p>';
    }

    $current_user = wp_get_current_user();

    wp_enqueue_script( 'pild-quiz-engine', PILD_URL . 'assets/quiz-engine.js', [], PILD_VERSION, true );
    wp_localize_script( 'pild-quiz-engine', 'pild_quiz_ajax', [
        'ajax_url'      => admin_url( 'admin-ajax.php' ),
        'nonce'         => wp_create_nonce( 'pild_quiz_nonce' ),
        'assessment_id' => $assessment_id,
        'display_name'  => $current_user->display_name,
        'user_email'    => $current_user->user_email,
        'i18n'          => [
            'start'        => __( 'Start Assessment', 'pild-unified' ),
            'next'         => __( 'Next', 'pild-unified' ),
            'prev'         => __( 'Previous', 'pild-unified' ),
            'finish'       => __( 'Finish', 'pild-unified' ),
            'pass'         => __( 'Congratulations, you passed!', 'pild-unified' ),
            'fail'         => __( 'You did not pass this time.', 'pild-unified' ),
            'expired'      => __( 'Time is up — your attempt was submitted automatically.', 'pild-unified' ),
            'confirm'      => __( 'Leaving this page will keep your progress, but are you sure you want to leave?', 'pild-unified' ),
            'certificate'  => __( 'View Certificate', 'pild-unified' ),
            'pass_mark'    => __( 'Pass mark', 'pild-unified' ),
            'your_score'   => __( 'Your score', 'pild-unified' ),
            'try_again'    => __( 'Review your answers and try again when you’re ready.', 'pild-unified' ),
            'name_confirm_title'  => __( 'Confirm your details', 'pild-unified' ),
            'name_confirm_note'   => __( 'This name will appear on your certificate. Your certificate will be issued in English — please make sure your name is correct, and we recommend writing it in English.', 'pild-unified' ),
            'full_name'           => __( 'Full Name (English)', 'pild-unified' ),
            'email'               => __( 'Email', 'pild-unified' ),
            'name_arabic_warning' => __( 'This looks like it contains Arabic letters — please write your name in English for the certificate.', 'pild-unified' ),
            'name_required'       => __( 'Please enter your name.', 'pild-unified' ),
            'continue'            => __( 'Continue', 'pild-unified' ),
        ],
    ] );

    return pild_quiz_inline_css() . '<div id="pild-quiz-root" data-loading="' . esc_attr__( 'Loading…', 'pild-unified' ) . '"></div>';
}

/** Minimal, self-contained styling so the shortcode works with no theme dependency. Printed once per page. */
function pild_quiz_inline_css() {
    static $printed = false;
    if ( $printed ) return '';
    $printed = true;
    return '<style>
    .pild-quiz-card{max-width:700px;margin:0 auto;padding:28px;border:1px solid #E5E7EB;border-radius:12px;font-family:inherit;background:#fff;}
    .pild-quiz-start{text-align:center;padding:60px 28px;}
    .pild-quiz-name-confirm{max-width:380px;margin:0 auto 24px;text-align:start;}
    .pild-quiz-name-title{margin:0 0 6px;font-size:1.1rem;}
    .pild-quiz-name-note{color:#6B7280;font-size:.85rem;margin:0 0 18px;line-height:1.5;}
    .pild-quiz-field{margin-bottom:14px;}
    .pild-quiz-field label{display:block;font-size:.8rem;color:#4B5563;margin-bottom:4px;}
    .pild-quiz-field input{width:100%;padding:9px 12px;border:1px solid #E5E7EB;border-radius:8px;font-size:.95rem;box-sizing:border-box;}
    .pild-quiz-field input:disabled{background:#F9FAFB;color:#9CA3AF;}
    .pild-quiz-name-warning{color:#B45309;font-size:.78rem;margin-top:6px;}
    .pild-quiz-name-error{color:#B91C1C;font-size:.82rem;display:block;margin-bottom:8px;}
    .pild-quiz-topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;font-size:.9rem;color:#6B7280;}
    .pild-quiz-timer{font-family:monospace;font-weight:600;unicode-bidi:isolate;}
    .pild-quiz-progress-bar{height:6px;background:#E5E7EB;border-radius:3px;overflow:hidden;margin-bottom:24px;}
    .pild-quiz-progress-bar > div{height:100%;background:#0D5C4E;transition:width .2s ease;}
    .pild-quiz-question{font-size:1.15rem;font-weight:600;margin-bottom:18px;}
    .pild-quiz-choices{display:flex;flex-direction:column;gap:10px;margin-bottom:26px;}
    .pild-quiz-choice{display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid #E5E7EB;border-radius:8px;cursor:pointer;}
    .pild-quiz-choice:hover{border-color:#0D5C4E;}
    .pild-quiz-nav{display:flex;justify-content:space-between;}
    .pild-quiz-btn{padding:10px 22px;border-radius:8px;border:1px solid #E5E7EB;background:#fff;cursor:pointer;font-size:.95rem;}
    .pild-quiz-btn-primary{background:#0D5C4E;color:#fff;border-color:#0D5C4E;}
    .pild-quiz-error{color:#B91C1C;text-align:center;}
    .pild-quiz-expired-note{background:#FEF3C7;color:#92400E;padding:10px 14px;border-radius:8px;font-size:.88rem;margin-bottom:20px;}

    /* ---------- Result screen ---------- */
    .pild-quiz-result{text-align:center;padding:12px 8px 4px;}
    .pild-quiz-result-ring-wrap{position:relative;width:148px;height:148px;margin:0 auto 22px;}
    .pild-quiz-result-ring-wrap svg{width:100%;height:100%;transform:rotate(-90deg);}
    .pild-quiz-result-ring-track{fill:none;stroke:#EEF2F1;stroke-width:10;}
    .pild-quiz-result-ring-value{fill:none;stroke-width:10;stroke-linecap:round;transition:stroke-dashoffset .8s cubic-bezier(.4,0,.2,1);}
    .pild-quiz-pass .pild-quiz-result-ring-value{stroke:#0D5C4E;}
    .pild-quiz-fail .pild-quiz-result-ring-value{stroke:#C2410C;}
    .pild-quiz-result-ring-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;}
    .pild-quiz-result-score{font-size:1.9rem;font-weight:700;line-height:1;color:#111827;unicode-bidi:isolate;direction:ltr;}
    .pild-quiz-result-score-label{font-size:.72rem;color:#9CA3AF;margin-top:4px;letter-spacing:.02em;}
    .pild-quiz-result-icon{width:26px;height:26px;border-radius:999px;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;}
    .pild-quiz-pass .pild-quiz-result-icon{background:#E6F4F1;color:#0D5C4E;}
    .pild-quiz-fail .pild-quiz-result-icon{background:#FDECE5;color:#C2410C;}
    .pild-quiz-result-icon svg{width:15px;height:15px;}
    .pild-quiz-result h3{margin:0 0 8px;font-size:1.28rem;font-weight:700;unicode-bidi:isolate;}
    .pild-quiz-pass h3{color:#0D5C4E;}
    .pild-quiz-fail h3{color:#C2410C;}
    .pild-quiz-result-sub{color:#6B7280;font-size:.92rem;margin:0 0 4px;max-width:420px;margin-inline:auto;unicode-bidi:isolate;}
    .pild-quiz-result-passmark{display:inline-flex;align-items:center;gap:6px;color:#9CA3AF;font-size:.82rem;margin:10px 0 24px;unicode-bidi:isolate;}
    .pild-quiz-result-passmark b{color:#4B5563;font-weight:600;direction:ltr;unicode-bidi:isolate;}
    .pild-quiz-cert-btn{display:inline-flex;align-items:center;gap:9px;padding:12px 26px;border-radius:999px;background:#0D5C4E;color:#fff;text-decoration:none;font-size:.95rem;font-weight:600;border:none;box-shadow:0 4px 14px rgba(13,92,78,.28);transition:transform .15s ease,box-shadow .15s ease;}
    .pild-quiz-cert-btn:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(13,92,78,.35);}
    .pild-quiz-cert-btn svg{width:18px;height:18px;flex-shrink:0;}

    [dir="rtl"] .pild-quiz-result-passmark b{direction:ltr;unicode-bidi:isolate;}
    </style>';
}
