<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// 27. QUIZ ADMIN TOOLS
// ------------------------------------------------------------
//  A) Bulk question importer — one .xlsx sheet named "Questions",
//     same preview-then-confirm safety pattern as 18-excel-importer.php
//     (reuses its pildcm_xlsx_extract() reader — no new file-parsing code).
//  B) Item exposure report — how many attempts saw each question and
//     what share got it right, so a question that leaked its answer
//     (near-100% correct, high exposure) can be spotted and swapped.
//  C) Demo data seeder — one click creates a demo Track + Assessment +
//     24 real multiple-choice questions (3 strands x 8) to try the
//     whole flow end to end immediately.
// ============================================================

add_action( 'admin_menu', 'pild_quiz_admin_menu' );
function pild_quiz_admin_menu() {
    add_submenu_page( 'pild-settings', 'Import Questions', 'Import Questions', 'manage_options', 'pild-quiz-import', 'pild_quiz_import_page' );
    add_submenu_page( 'pild-settings', 'Assessment Exposure Report', 'Assessment Exposure', 'manage_options', 'pild-quiz-exposure', 'pild_quiz_exposure_page' );
}

// ============================================================
// A) BULK QUESTION IMPORTER
// ============================================================

/** Columns expected on the single "Questions" sheet. */
function pild_quiz_import_columns() {
    return [
        'code'        => 'كود_السؤال',        // optional — idempotent re-upload key
        'assessment'  => 'رقم_الاختبار',       // one of assessment/track_code+lang is required — post ID of the target Assessment
        'track_code'  => 'كود_التراك',        // alternative to 'رقم_الاختبار' — same code used in the Tracks sheet (18-excel-importer.php)
        'lang'        => 'اللغة',              // goes with 'كود_التراك' — 'ar' or 'en' (or عربي/إنجليزي), which language's Assessment to target. Defaults to 'ar'.
        'text'        => 'نص_السؤال',          // required
        'strand'      => 'الفرع',              // optional
        'points'      => 'النقاط',             // optional, default 1
        'explanation' => 'الشرح',              // optional
        'correct'     => 'رقم_الاختيار_الصحيح', // required — 1-based index into the choice columns
        'choices'     => [ 'اختيار_1', 'اختيار_2', 'اختيار_3', 'اختيار_4', 'اختيار_5', 'اختيار_6' ],
    ];
}

/**
 * Normalize a free-text language value from the sheet ('ar', 'en',
 * 'عربي', 'إنجليزي'...) to Polylang's 'ar' / 'en' codes.
 */
function pild_quiz_normalize_lang( $val ) {
    $val = strtolower( trim( (string) $val ) );
    return in_array( $val, [ 'en', 'english', 'انجليزي', 'إنجليزي', 'en-us' ], true ) ? 'en' : 'ar';
}

/**
 * Resolve كود_التراك + اللغة to the matching Assessment ID that
 * 18-excel-importer.php auto-created for that track (tagged
 * pild_import_code = "{track_code}::assessment"). Lets a Questions
 * file reference tracks by the SAME human-readable code used when the
 * tracks themselves were imported, instead of a raw numeric post ID
 * copy-pasted from the results screen — so uploading the Tracks file
 * then the Questions file links the two with no manual step at all.
 */
function pild_quiz_resolve_assessment_by_track_code( $track_code, $lang ) {
    $lang = pild_quiz_normalize_lang( $lang );

    $found = get_posts( [
        'post_type'      => 'assessment',
        'posts_per_page' => -1,
        'post_status'    => 'any',
        'meta_query'     => [ [ 'key' => 'pild_import_code', 'value' => $track_code . '::assessment' ] ],
        'fields'         => 'ids',
    ] );
    if ( ! $found ) return 0;

    $polylang_active = function_exists( 'pll_get_post_language' );
    foreach ( $found as $aid ) {
        $post_lang = $polylang_active ? pll_get_post_language( $aid ) : 'ar';
        if ( ( $post_lang ?: 'ar' ) === $lang ) return (int) $aid;
    }
    // Polylang inactive, or this specific language variant doesn't exist
    // (e.g. the track has no English version) — fall back to whichever
    // one was found rather than failing outright.
    return (int) $found[0];
}

function pild_quiz_import_build_plan( $rows ) {
    $cols   = pild_quiz_import_columns();
    $plan   = [];
    $errors = [];

    foreach ( $rows as $i => $row ) {
        $line = $i + 2; // header is row 1

        $assessment_id = isset( $row[ $cols['assessment'] ] ) ? (int) $row[ $cols['assessment'] ] : 0;
        $track_code    = isset( $row[ $cols['track_code'] ] ) ? trim( $row[ $cols['track_code'] ] ) : '';
        $lang_val      = isset( $row[ $cols['lang'] ] ) ? $row[ $cols['lang'] ] : '';

        // رقم_الاختبار (a real Assessment ID) wins if given; otherwise
        // resolve automatically from كود_التراك + اللغة.
        if ( ! $assessment_id && $track_code !== '' ) {
            $assessment_id = pild_quiz_resolve_assessment_by_track_code( $track_code, $lang_val );
        }

        // The question's own language: from اللغة if given, otherwise
        // inferred from the resolved Assessment's own Polylang language
        // (so رقم_الاختبار-only rows still get tagged correctly), defaulting
        // to Arabic when Polylang isn't active.
        if ( $lang_val !== '' ) {
            $lang = pild_quiz_normalize_lang( $lang_val );
        } elseif ( $assessment_id && function_exists( 'pll_get_post_language' ) ) {
            $lang = pll_get_post_language( $assessment_id ) === 'en' ? 'en' : 'ar';
        } else {
            $lang = 'ar';
        }

        $text = isset( $row[ $cols['text'] ] ) ? trim( $row[ $cols['text'] ] ) : '';

        if ( ! $assessment_id || get_post_type( $assessment_id ) !== 'assessment' ) {
            if ( $track_code !== '' ) {
                $errors[] = "صف $line: كود_التراك ($track_code) مش لاقيله Assessment — تأكد إن ملف التراكات اتعمل له import قبل كده.";
            } else {
                $errors[] = "صف $line: لازم تحدد إما رقم_الاختبار أو كود_التراك.";
            }
            continue;
        }
        if ( $text === '' ) {
            $errors[] = "صف $line: نص_السؤال فاضي.";
            continue;
        }

        $choices = [];
        foreach ( $cols['choices'] as $col ) {
            $val = isset( $row[ $col ] ) ? trim( $row[ $col ] ) : '';
            if ( $val !== '' ) $choices[] = $val;
        }
        if ( count( $choices ) < 2 ) {
            $errors[] = "صف $line: لازم اختيارين على الأقل (اختيار_1، اختيار_2...).";
            continue;
        }

        $correct = isset( $row[ $cols['correct'] ] ) ? (int) $row[ $cols['correct'] ] : 0;
        if ( $correct < 1 || $correct > count( $choices ) ) {
            $errors[] = "صف $line: رقم_الاختيار_الصحيح ($correct) لازم يكون بين 1 و" . count( $choices ) . ".";
            continue;
        }

        $plan[] = [
            'code'          => isset( $row[ $cols['code'] ] ) ? trim( $row[ $cols['code'] ] ) : '',
            'lang'          => $lang,
            'assessment_id' => $assessment_id,
            'text'          => $text,
            'strand'        => isset( $row[ $cols['strand'] ] ) ? trim( $row[ $cols['strand'] ] ) : '',
            'points'        => isset( $row[ $cols['points'] ] ) && $row[ $cols['points'] ] !== '' ? (int) $row[ $cols['points'] ] : 1,
            'explanation'   => isset( $row[ $cols['explanation'] ] ) ? trim( $row[ $cols['explanation'] ] ) : '',
            'choices'       => $choices,
            'correct_index' => $correct - 1, // 0-based, matches ACF repeater row index
        ];
    }

    return [ 'plan' => $plan, 'errors' => $errors ];
}

function pild_quiz_import_execute( $plan ) {
    $created = 0;
    $updated = 0;
    $polylang_active = function_exists( 'pll_set_post_language' ) && function_exists( 'pll_get_post_language' );

    // code => ['ar' => post_id, 'en' => post_id] — same pattern as the
    // Tracks importer (18-excel-importer.php), so an Arabic and English
    // row sharing the same كود_السؤال become two SEPARATE posts, one per
    // language, instead of the second row overwriting the first.
    $code_lang_map = [];

    foreach ( $plan as $row ) {
        $lang = $row['lang'];

        $existing_id = 0;
        if ( $row['code'] !== '' ) {
            $found = get_posts( [
                'post_type' => 'question', 'posts_per_page' => -1, 'post_status' => 'any',
                'meta_query' => [ [ 'key' => 'pild_import_code', 'value' => $row['code'] ] ], 'fields' => 'ids',
            ] );
            foreach ( $found as $fid ) {
                $found_lang = $polylang_active ? ( pll_get_post_language( $fid ) ?: 'ar' ) : 'ar';
                if ( $found_lang === $lang ) { $existing_id = (int) $fid; break; }
            }
        }

        $postarr = [
            'post_type'   => 'question',
            'post_title'  => $row['text'],
            'post_status' => 'publish',
        ];

        if ( $existing_id ) {
            $postarr['ID'] = $existing_id;
            wp_update_post( $postarr );
            $qid = $existing_id;
            $updated++;
        } else {
            $qid = wp_insert_post( $postarr );
            if ( $row['code'] !== '' ) update_post_meta( $qid, 'pild_import_code', $row['code'] );
            if ( $polylang_active ) pll_set_post_language( $qid, $lang );
            $created++;
        }
        if ( is_wp_error( $qid ) || ! $qid ) continue;

        if ( $row['code'] !== '' ) {
            if ( ! isset( $code_lang_map[ $row['code'] ] ) ) $code_lang_map[ $row['code'] ] = [ 'ar' => 0, 'en' => 0 ];
            $code_lang_map[ $row['code'] ][ $lang ] = $qid;
        }

        update_field( 'question_assessment', $row['assessment_id'], $qid );
        update_field( 'question_strand', $row['strand'], $qid );
        update_field( 'question_points', $row['points'], $qid );
        update_field( 'question_explanation', $row['explanation'], $qid );

        $choice_rows = [];
        foreach ( $row['choices'] as $idx => $choice_text ) {
            $choice_rows[] = [ 'choice_text' => $choice_text, 'is_correct' => ( $idx === $row['correct_index'] ) ];
        }
        update_field( 'question_choices', $choice_rows, $qid );
    }

    // Link every Arabic/English pair that shares a كود_السؤال as real
    // Polylang translations of each other, so switching site language
    // shows the matching question, and the two stay associated in wp-admin.
    if ( $polylang_active && function_exists( 'pll_save_post_translations' ) ) {
        foreach ( $code_lang_map as $ids ) {
            if ( $ids['ar'] && $ids['en'] ) {
                pll_save_post_translations( [ 'ar' => $ids['ar'], 'en' => $ids['en'] ] );
            }
        }
    }

    return [ 'created' => $created, 'updated' => $updated ];
}

function pild_quiz_import_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    echo '<div class="wrap"><h1>📥 استيراد الأسئلة من إكسيل (استيراد جماعي)</h1>';

    $step = isset( $_POST['pild_quiz_step'] ) ? sanitize_text_field( wp_unslash( $_POST['pild_quiz_step'] ) ) : '';
    $tkey = 'pild_quiz_import_plan_' . get_current_user_id();

    if ( $step === 'confirm' && check_admin_referer( 'pild_quiz_import_confirm' ) ) {
        $plan = get_transient( $tkey );
        if ( ! $plan ) {
            echo '<div class="notice notice-error"><p>انتهت صلاحية بيانات المعاينة. ارفع الملف تاني.</p></div>';
        } else {
            $result = pild_quiz_import_execute( $plan );
            delete_transient( $tkey );
            echo '<div class="notice notice-success"><p><strong>تم الاستيراد ✅</strong> — أسئلة جديدة: ' . (int) $result['created'] . '، أسئلة اتحدّثت: ' . (int) $result['updated'] . '</p></div>';
        }
    } elseif ( $step === 'preview' && check_admin_referer( 'pild_quiz_import_preview' ) && ! empty( $_FILES['pild_quiz_file']['tmp_name'] ) ) {
        $orig_name = isset( $_FILES['pild_quiz_file']['name'] ) ? sanitize_file_name( $_FILES['pild_quiz_file']['name'] ) : '';
        if ( strtolower( pathinfo( $orig_name, PATHINFO_EXTENSION ) ) !== 'xlsx' ) {
            echo '<div class="notice notice-error"><p>لازم يكون الملف .xlsx</p></div>';
        } elseif ( ! function_exists( 'pildcm_xlsx_extract' ) ) {
            echo '<div class="notice notice-error"><p>موديول الاستيراد الأساسي (18-excel-importer) مش متحمّل.</p></div>';
        } else {
            $sheets = pildcm_xlsx_extract( $_FILES['pild_quiz_file']['tmp_name'] );
            if ( is_wp_error( $sheets ) ) {
                echo '<div class="notice notice-error"><p>' . esc_html( $sheets->get_error_message() ) . '</p></div>';
            } elseif ( empty( $sheets['Questions'] ) ) {
                echo '<div class="notice notice-error"><p>مفيش شيت اسمه <code>Questions</code> في الملف.</p></div>';
            } else {
                $build = pild_quiz_import_build_plan( $sheets['Questions'] );
                echo '<h2>معاينة: ' . count( $build['plan'] ) . ' سؤال صالح</h2>';
                if ( ! empty( $build['errors'] ) ) {
                    echo '<div class="notice notice-error"><p><strong>فيه أخطاء (لسه مفيش حاجة اتحفظت):</strong></p><ul style="list-style:disc;margin-inline-start:20px">';
                    foreach ( $build['errors'] as $e ) echo '<li>' . esc_html( $e ) . '</li>';
                    echo '</ul></div>';
                } elseif ( empty( $build['plan'] ) ) {
                    echo '<div class="notice notice-error"><p>مفيش صفوف صالحة في الشيت.</p></div>';
                } else {
                    set_transient( $tkey, $build['plan'], HOUR_IN_SECONDS );
                    echo '<div class="notice notice-success"><p>مفيش أخطاء ✅</p></div>';
                    echo '<form method="post">';
                    wp_nonce_field( 'pild_quiz_import_confirm' );
                    echo '<input type="hidden" name="pild_quiz_step" value="confirm">';
                    submit_button( '✅ تأكيد الاستيراد' );
                    echo '</form>';
                }
            }
        }
    }

    echo '<hr><h2>ارفع ملف الإكسيل</h2>';
    echo '<form method="post" enctype="multipart/form-data">';
    wp_nonce_field( 'pild_quiz_import_preview' );
    echo '<input type="hidden" name="pild_quiz_step" value="preview">';
    echo '<p><input type="file" name="pild_quiz_file" accept=".xlsx" required></p>';
    submit_button( '🔍 معاينة الملف (بدون حفظ)' );
    echo '</form>';

    echo '<p style="color:#666;max-width:700px">الملف لازم يحتوي على شيت واحد اسمه <code>Questions</code> بالأعمدة: <code>كود_السؤال</code> (اختياري — لإعادة الرفع بدون تكرار), <code>نص_السؤال</code>, <code>الفرع</code> (اختياري), <code>النقاط</code> (اختياري), <code>اختيار_1</code> إلى <code>اختيار_6</code>, <code>رقم_الاختيار_الصحيح</code> (1-6), <code>الشرح</code> (اختياري).</p>';
    echo '<p style="color:#666;max-width:700px"><strong>🔗 ربط السؤال بالتراك — طريقتين:</strong></p>';
    echo '<ul style="list-style:disc;margin-inline-start:24px;max-width:700px;color:#666">';
    echo '<li><code>كود_التراك</code> + <code>اللغة</code> (<em>الطريقة الموصى بها</em>): استخدم نفس كود التراك اللي كتبته في عمود <code>كود_التراك</code> بملف استيراد التراكات (18-excel-importer)، وحدد <code>اللغة</code> بـ <code>ar</code> أو <code>en</code> (لو سبتها فاضية بتاخد <code>ar</code>). الأداة بتلاقي الـ Assessment المرتبط بالتراك ده تلقائيًا — مش محتاج تعرف أو تنسخ أي رقم يدويًا، حتى لو الملفين (التراكات والأسئلة) اترفعوا في نفس الجلسة.</li>';
    echo '<li><code>رقم_الاختبار</code> (الطريقة القديمة): ID رقمي حقيقي لبوست Assessment — لو الاتنين موجودين في نفس الصف، <code>رقم_الاختبار</code> بياخد الأولوية.</li>';
    echo '</ul>';
    echo '</div>';
}

// ============================================================
// B) ITEM EXPOSURE REPORT
// ============================================================
function pild_quiz_exposure_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    global $wpdb;

    $assessment_id = isset( $_GET['assessment_id'] ) ? (int) $_GET['assessment_id'] : 0;

    echo '<div class="wrap"><h1>📊 تقرير معدل ظهور الأسئلة</h1>';
    echo '<p style="color:#666;max-width:700px">سؤال بمعدل ظهور عالي ونسبة إجابة صحيحة قريبة من 100% بشكل غير طبيعي مؤشر على تسرب الإجابة — راجعه أو استبدله.</p>';

    $assessments = get_posts( [ 'post_type' => 'assessment', 'posts_per_page' => -1, 'post_status' => 'publish' ] );
    echo '<form method="get"><input type="hidden" name="page" value="pild-quiz-exposure"><select name="assessment_id" onchange="this.form.submit()"><option value="0">— اختر Assessment —</option>';
    foreach ( $assessments as $a ) {
        echo '<option value="' . $a->ID . '" ' . selected( $assessment_id, $a->ID, false ) . '>' . esc_html( $a->post_title ) . ' (#' . $a->ID . ')</option>';
    }
    echo '</select></form><br>';

    if ( ! $assessment_id ) { echo '</div>'; return; }

    $question_ids = pild_quiz_get_bank_question_ids( $assessment_id );
    if ( empty( $question_ids ) ) {
        echo '<p>مفيش أسئلة في البنك ده.</p></div>';
        return;
    }

    // Pull every submitted attempt for this assessment and tally per-question exposure.
    $attempts = $wpdb->get_results( $wpdb->prepare(
        "SELECT question_ids, answers FROM {$wpdb->prefix}pild_quiz_attempts WHERE assessment_id=%d AND submitted_at IS NOT NULL",
        $assessment_id
    ) );

    $exposure = array_fill_keys( $question_ids, 0 );
    $correct  = array_fill_keys( $question_ids, 0 );

    foreach ( $attempts as $a ) {
        $locked  = json_decode( $a->question_ids, true ) ?: [];
        $answers = json_decode( $a->answers, true ) ?: [];
        foreach ( $locked as $entry ) {
            $qid = $entry['id'];
            if ( ! isset( $exposure[ $qid ] ) ) continue;
            $exposure[ $qid ]++;

            $choices = get_field( 'question_choices', $qid ) ?: [];
            $correct_index = null;
            foreach ( $choices as $i => $c ) { if ( ! empty( $c['is_correct'] ) ) { $correct_index = $i; break; } }
            if ( isset( $answers[ $qid ] ) && (int) $answers[ $qid ] === $correct_index ) $correct[ $qid ]++;
        }
    }

    echo '<table class="widefat striped"><thead><tr><th>السؤال</th><th>مرات الظهور</th><th>نسبة الإجابة الصحيحة</th></tr></thead><tbody>';
    foreach ( $question_ids as $qid ) {
        $exp = $exposure[ $qid ];
        $pct = $exp > 0 ? round( ( $correct[ $qid ] / $exp ) * 100 ) : 0;
        $warn = ( $exp >= 20 && $pct >= 95 ) ? ' style="background:#FEF3C7"' : '';
        echo '<tr' . $warn . '><td>' . esc_html( get_the_title( $qid ) ) . '</td><td>' . $exp . '</td><td>' . ( $exp > 0 ? $pct . '%' : '—' ) . '</td></tr>';
    }
    echo '</tbody></table></div>';
}
