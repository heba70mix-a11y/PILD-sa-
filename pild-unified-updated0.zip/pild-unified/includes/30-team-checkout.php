<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// ⚠️ DEPRECATED / NOT LOADED — client decision (Aug 2026): the
// [pild_team_multi_checkout] page is removed. Multi-track registration
// now happens inline in the Sector Explorer (includes/17-sector-explorer.php
// + the pild_reg_add_to_cart AJAX action in includes/22-registration-
// routing.php) — register one track, get an inline "register another
// track" option, everything accumulates in the same cart. This file is
// no longer in the $pild_modules load list in pild-unified.php, so
// nothing below actually runs. Left on disk for history only — do not
// re-add the require line.
// ============================================================

// ============================================================
// 30. MULTI-TRACK DIRECT CHECKOUT [DEPRECATED — SEE NOTE ABOVE]
// ------------------------------------------------------------
// The "تسجيل مؤسسي" button on a single track/domain (17-sector-explorer.php)
// already jumps straight to that one product's page. This module is the
// companion for the "I want more than one track" case (client note): a
// lightweight picker — track + seat count per row, independent quantities —
// that empties the cart, adds one cart line per selected track's Team
// product at its chosen quantity, and redirects straight to WooCommerce
// Checkout (skipping the cart page). Partner pricing (14-partner-pricing.php)
// still applies normally since these are ordinary cart lines underneath.
//
// Seat pooling for repeat purchases (same product, same still-active team)
// is handled where the order completes (24-team-purchase.php calling
// pild_team_get_or_create_for_purchase() in 23-teams-core.php) — this
// module only has to get the right (product_id, quantity) pairs into the
// cart; it doesn't need to know anything about existing teams itself.
// ============================================================

/** Resolve a Track/Domain's Team-variant product ID (not just its link —
 *  see pild_get_product_link_for_post() in 22-registration-routing.php,
 *  which this mirrors but returns the ID for cart use). */
function pild_get_team_product_id_for_track( $track_id ) {
    $track_id = (int) $track_id;
    if ( ! $track_id || ! function_exists( 'get_field' ) ) return 0;
    $product_id = (int) get_field( 'pild_product_team', $track_id );
    if ( ! $product_id ) {
        $domain_id = (int) get_post_meta( $track_id, 'track_domain', true );
        if ( $domain_id ) $product_id = (int) get_field( 'pild_product_team', $domain_id );
    }
    return ( $product_id && get_post_status( $product_id ) === 'publish' ) ? $product_id : 0;
}

add_shortcode( 'pild_team_multi_checkout', 'pild_team_multi_checkout_shortcode' );
function pild_team_multi_checkout_shortcode() {
    if ( ! is_user_logged_in() ) {
        return '<p>' . esc_html__( 'Please log in to register multiple tracks.', 'pild-unified' ) . '</p>';
    }
    if ( ! function_exists( 'WC' ) ) {
        return '<p>' . esc_html__( 'Checkout is temporarily unavailable.', 'pild-unified' ) . '</p>';
    }

    $sectors = get_posts( [ 'post_type' => 'sector', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC' ] );

    ob_start();
    ?>
    <div id="pild-mtc-root" class="pild-mtc">
      <div class="pild-mtc-head">
        <h3><?php esc_html_e( 'Register more than one track', 'pild-unified' ); ?></h3>
        <p><?php esc_html_e( 'Pick every track you need, set the seat count for each, then check out once — one order, one payment.', 'pild-unified' ); ?></p>
      </div>

      <?php foreach ( $sectors as $sector ):
        $domains = get_posts( [ 'post_type' => 'domain', 'posts_per_page' => -1, 'post_status' => 'publish', 'meta_key' => 'domain_sector', 'meta_value' => $sector->ID, 'orderby' => 'menu_order title', 'order' => 'ASC' ] );
        if ( ! $domains ) continue;
      ?>
      <div class="pild-mtc-sector">
        <div class="pild-mtc-sector-title"><?php echo esc_html( get_the_title( $sector ) ); ?></div>
        <?php foreach ( $domains as $domain ):
          $tracks = get_posts( [ 'post_type' => 'track', 'posts_per_page' => -1, 'post_status' => 'publish', 'meta_key' => 'track_domain', 'meta_value' => $domain->ID, 'orderby' => 'menu_order title', 'order' => 'ASC' ] );
          if ( ! $tracks ) continue;
        ?>
        <div class="pild-mtc-domain">
          <div class="pild-mtc-domain-title"><?php echo esc_html( get_the_title( $domain ) ); ?></div>
          <?php foreach ( $tracks as $track ):
            $product_id = pild_get_team_product_id_for_track( $track->ID );
            if ( ! $product_id ) continue; // no Team product configured for this track (or its domain) — nothing to sell
            $min_seats = function_exists( 'pild_team_min_seats' ) ? pild_team_min_seats( $product_id ) : 5;
          ?>
          <label class="pild-mtc-row">
            <input type="checkbox" class="pild-mtc-check" data-product="<?php echo (int) $product_id; ?>" data-min="<?php echo (int) $min_seats; ?>">
            <span class="pild-mtc-name"><?php echo esc_html( get_the_title( $track ) ); ?></span>
            <span class="pild-mtc-seats">
              <?php esc_html_e( 'Seats:', 'pild-unified' ); ?>
              <input type="number" class="pild-mtc-qty" min="<?php echo (int) $min_seats; ?>" value="<?php echo (int) $min_seats; ?>" disabled>
            </span>
          </label>
          <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>

      <div class="pild-mtc-footer">
        <div id="pild-mtc-summary"><?php esc_html_e( 'No tracks selected yet.', 'pild-unified' ); ?></div>
        <button id="pild-mtc-checkout-btn" class="pild-mtc-btn" disabled><?php esc_html_e( 'Proceed to Checkout', 'pild-unified' ); ?></button>
      </div>
      <div id="pild-mtc-error" class="pild-mtc-error" style="display:none;"></div>
    </div>
    <?php

    wp_enqueue_script( 'pild-team-checkout', PILD_URL . 'assets/team-checkout.js', [], PILD_VERSION, true );
    wp_localize_script( 'pild-team-checkout', 'pild_mtc_ajax', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'pild_mtc_nonce' ),
        'i18n'     => [
            'selected_count' => __( '%d track(s) selected — %d total seats', 'pild-unified' ),
            'none_selected'  => __( 'No tracks selected yet.', 'pild-unified' ),
            'error_generic'  => __( 'Something went wrong — please try again.', 'pild-unified' ),
        ],
    ] );

    return pild_mtc_inline_css() . ob_get_clean();
}

function pild_mtc_inline_css() {
    static $printed = false;
    if ( $printed ) return '';
    $printed = true;
    return '<style>
    .pild-mtc{max-width:780px;margin:0 auto;font-family:inherit;}
    .pild-mtc-head h3{margin-bottom:4px;}
    .pild-mtc-head p{color:#6B7280;font-size:.9rem;margin-top:0;margin-bottom:22px;}
    .pild-mtc-sector{margin-bottom:18px;}
    .pild-mtc-sector-title{font-weight:700;font-size:1.05rem;margin-bottom:8px;color:#0D5C4E;}
    .pild-mtc-domain{margin-bottom:12px;padding-inline-start:12px;}
    .pild-mtc-domain-title{font-weight:600;font-size:.92rem;color:#374151;margin-bottom:6px;}
    .pild-mtc-row{display:flex;align-items:center;gap:12px;padding:10px 14px;border:1px solid #E5E7EB;border-radius:8px;margin-bottom:6px;cursor:pointer;}
    .pild-mtc-row:hover{border-color:#0D5C4E;}
    .pild-mtc-name{flex:1;font-size:.92rem;}
    .pild-mtc-seats{display:flex;align-items:center;gap:6px;font-size:.85rem;color:#6B7280;}
    .pild-mtc-qty{width:60px;padding:4px 6px;border:1px solid #D1D5DB;border-radius:6px;}
    .pild-mtc-qty:disabled{background:#F3F4F6;color:#9CA3AF;}
    .pild-mtc-footer{position:sticky;bottom:0;background:#fff;border-top:1px solid #E5E7EB;padding:16px 4px;margin-top:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;}
    #pild-mtc-summary{font-size:.9rem;color:#374151;font-weight:600;}
    .pild-mtc-btn{padding:12px 28px;border-radius:9px;border:none;background:#0D5C4E;color:#fff;font-size:.95rem;cursor:pointer;}
    .pild-mtc-btn:disabled{background:#D1D5DB;cursor:not-allowed;}
    .pild-mtc-error{color:#B91C1C;background:#FEE2E2;padding:10px 14px;border-radius:8px;margin-top:14px;font-size:.88rem;}
    </style>';
}

// ------------------------------------------------------------
// AJAX: build the cart from the selected (product_id, seats) pairs and
// hand back the checkout URL. Runs server-side so the seat minimum is
// enforced even if a visitor bypasses the disabled input in devtools.
// ------------------------------------------------------------
add_action( 'wp_ajax_pild_mtc_checkout', 'pild_mtc_ajax_checkout' );
function pild_mtc_ajax_checkout() {
    check_ajax_referer( 'pild_mtc_nonce', 'nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( __( 'Please log in first.', 'pild-unified' ) );
    if ( ! function_exists( 'WC' ) ) wp_send_json_error( __( 'Checkout is unavailable.', 'pild-unified' ) );

    $items = isset( $_POST['items'] ) ? (array) $_POST['items'] : []; // { product_id: seats }
    if ( empty( $items ) ) wp_send_json_error( __( 'Pick at least one track first.', 'pild-unified' ) );

    WC()->cart->empty_cart();

    $added = 0;
    foreach ( $items as $product_id => $seats ) {
        $product_id = (int) $product_id;
        $seats      = (int) $seats;
        if ( ! $product_id || get_post_type( $product_id ) !== 'product' ) continue;

        $min_seats = function_exists( 'pild_team_min_seats' ) ? pild_team_min_seats( $product_id ) : 5;
        $seats     = max( $min_seats, $seats );

        $ok = WC()->cart->add_to_cart( $product_id, $seats );
        if ( $ok ) $added++;
    }

    if ( ! $added ) wp_send_json_error( __( 'Could not add the selected tracks — please try again.', 'pild-unified' ) );

    wp_send_json_success( [ 'checkout_url' => wc_get_checkout_url() ] );
}
