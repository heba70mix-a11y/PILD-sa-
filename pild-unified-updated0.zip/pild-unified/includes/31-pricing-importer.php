<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 31. TRACK PRICING IMPORTER
// ------------------------------------------------------------
// One upload on this admin page:
//
//   "Products" file — an editable .xlsx (template: use
//   pild_products_level_template_columns() below) with ONE ROW PER
//   LEVEL PRODUCT: its own code, Arabic name, English name, level
//   text, variant, price, partner price. This is the SOURCE OF TRUTH
//   for the shared level products' names/prices — nothing about them is
//   hardcoded in this file. Re-uploading updates the same products
//   (matched by كود_المنتج) instead of duplicating. If this is never
//   uploaded, pild_ensure_level_products() below creates a sane
//   fallback set automatically the first time it's needed but
//   hasn't happened yet — but the Products file is the recommended
//   path since it's what actually controls the bilingual names/prices.
//
// Each track's own level (which of these products it uses) is set
// directly on the Sector import file (includes/18-excel-importer.php,
// "Import Sector" — Tracks sheet, عمود المستوى_السعري), not here.
// This page used to also have a second "Pricing sheet" upload that did
// the same track-to-level linking from a separate file; removed as
// redundant once the Sector file started carrying that column itself.
//
// Not preview/confirm like includes/18-excel-importer.php: this can't
// duplicate or destroy catalog content — it only ever upserts the same
// fixed set of level products by their own code. A full report is
// shown after.
// ============================================================

// ── 31.0 Products-file column names (used by both the importer and the
//         downloadable template) ────────────────────────────────────
function pild_products_level_columns() {
    return [
        'code'    => 'كود_المنتج',
        'name_ar' => 'الاسم_عربي',
        'name_en' => 'الاسم_انجليزي',
        'level'   => 'المستوى',
        'variant' => 'النوع', // 'فردي' or 'مؤسسي'
        'price'   => 'السعر',
        'partner' => 'سعر_الشريك',
    ];
}

// ── 31.0b Import the Products sheet: upsert the 6 (or however many)
//          level products by their own كود_المنتج. This is what actually
//          controls their bilingual names and prices now — nothing here
//          is hardcoded in PHP.
function pild_products_level_import($rows) {
    $errors = []; $created = 0; $updated = 0; $created_en = 0;
    if (!class_exists('WC_Product_Simple')) {
        $errors[] = 'WooCommerce مش شغال — معرفتش أعمل/أعدّل المنتجات.';
        return compact('errors', 'created', 'updated', 'created_en');
    }
    $cols = pild_products_level_columns();
    $polylang_active = function_exists('pll_set_post_language') && function_exists('pll_get_post_translations');

    foreach ($rows as $i => $row) {
        $line   = $i + 2;
        $code   = isset($row[$cols['code']])    ? trim($row[$cols['code']])    : '';
        $ar     = isset($row[$cols['name_ar']]) ? trim($row[$cols['name_ar']]) : '';
        $en     = isset($row[$cols['name_en']]) ? trim($row[$cols['name_en']]) : '';
        $level  = isset($row[$cols['level']])   ? trim($row[$cols['level']])   : '';
        $type   = isset($row[$cols['variant']]) ? trim($row[$cols['variant']]) : '';
        $price  = isset($row[$cols['price']])   ? trim($row[$cols['price']])   : '';
        $partner= isset($row[$cols['partner']]) ? trim($row[$cols['partner']]): '';

        if ($code === '' || $ar === '' || $level === '' || $price === '') {
            $errors[] = "صف $line: محتاج كود_المنتج + الاسم_عربي + المستوى + السعر على الأقل.";
            continue;
        }
        if (!is_numeric($price)) { $errors[] = "صف $line: السعر لازم يكون رقم."; continue; }
        // Accept either "فردي"/"مؤسسي" (this tool's own convention) or
        // the older "منظمة" used by includes/26-products-importer.php's
        // Products sheet, so the same wording habit works here too.
        $variant = (strpos($type, 'مؤسس') !== false || strpos($type, 'منظم') !== false) ? 'team' : 'individual';

        $existing = get_posts([
            'post_type' => 'product', 'posts_per_page' => 1, 'post_status' => 'any',
            'meta_key' => '_pild_level_product_code', 'meta_value' => $code, 'fields' => 'ids',
        ]);
        $product_id = !empty($existing) ? (int) $existing[0] : 0;
        $product = $product_id ? wc_get_product($product_id) : new WC_Product_Simple();
        if (!$product) { $errors[] = "صف $line: معرفتش أوصل للمنتج الموجود."; continue; }

        $product->set_name($ar);
        $product->set_regular_price((string) $price);
        $product->set_status('publish');
        $product->set_catalog_visibility('hidden'); // sold only via "Register", never browsed directly
        $product_id = $product->save();
        if (!$product_id) { $errors[] = "صف $line: فشل حفظ المنتج."; continue; }

        update_post_meta($product_id, '_pild_level_product_code', $code);
        update_post_meta($product_id, '_pild_level', $level);
        update_post_meta($product_id, '_pild_variant', $variant);
        if ($partner !== '' && is_numeric($partner)) update_post_meta($product_id, '_pild_partner_price', (string) $partner);
        if ($variant === 'team') update_post_meta($product_id, '_pild_min_seats', 5);
        $existing ? $updated++ : $created++;

        // Optional linked English product — created whenever the row has
        // an English name, regardless of Polylang. If Polylang IS active
        // it's also properly registered as the Arabic product's
        // translation (so Settings → Languages shows them linked and the
        // front end picks the right one per visitor language); if not,
        // it's still created as its own real product (with the same
        // _pild_level/_pild_variant tags) so nothing is silently skipped —
        // just not marked as a translation pair.
        if ($en !== '') {
            $en_id = 0;
            if ($polylang_active) {
                // BUGFIX: this used to be `if (!pll_get_post_language($product_id))
                // pll_set_post_language($product_id, 'ar');` — but Polylang assigns
                // its own default language to a brand-new post the moment it's
                // saved (before this line ever runs), so the post already "has a
                // language" and this guard silently skipped setting it to 'ar' on
                // every single row. That's why every level product — Arabic-named
                // ones included — ended up tagged 'en'. This is the ARABIC product
                // in this function; force it to 'ar' unconditionally, exactly like
                // the English one a few lines below is unconditionally set to 'en'.
                pll_set_post_language($product_id, 'ar');
                $translations = pll_get_post_translations($product_id);
                $en_id = !empty($translations['en']) ? (int) $translations['en'] : 0;
            }
            $en_product = $en_id ? wc_get_product($en_id) : new WC_Product_Simple();
            if ($en_product) {
                $en_product->set_name($en);
                $en_product->set_regular_price((string) $price);
                $en_product->set_status('publish');
                $en_product->set_catalog_visibility('hidden');
                $new_en_id = $en_product->save();
                if ($new_en_id) {
                    update_post_meta($new_en_id, '_pild_level_product_code', $code . '-EN');
                    update_post_meta($new_en_id, '_pild_level', $level);
                    update_post_meta($new_en_id, '_pild_variant', $variant);
                    if ($partner !== '' && is_numeric($partner)) update_post_meta($new_en_id, '_pild_partner_price', (string) $partner);
                    if ($variant === 'team') update_post_meta($new_en_id, '_pild_min_seats', 5);
                    if (!$en_id) {
                        if ($polylang_active) {
                            pll_set_post_language($new_en_id, 'en');
                            pll_save_post_translations(['ar' => $product_id, 'en' => $new_en_id]);
                        }
                        $created_en++;
                    }
                }
            }
        }
    }

    delete_transient('pild_level_product_map');
    delete_transient('pild_team_product_ids');
    return compact('errors', 'created', 'updated', 'created_en', 'polylang_active');
}

// ── 31.1 Fallback price table (SAR) — ONLY used by pild_ensure_level_
//         products() below when NO level product exists yet at all (i.e.
//         a track went live with a track_pricing_level value — set on
//         the Sector import file — before a Products file was ever
//         uploaded here). Once even one real level product exists, this
//         fallback never runs again.
function pild_pricing_level_table() {
    return [
        'أساسي' => ['individual' => 299, 'team' => 195, 'partner' => 158],
        'متقدم' => ['individual' => 399, 'team' => 260, 'partner' => 211],
        'متخصص' => ['individual' => 499, 'team' => 325, 'partner' => 264],
    ];
}

// Any level product configured at all yet (via either path)?
function pild_any_level_product_exists() {
    global $wpdb;
    return (bool) $wpdb->get_var(
        "SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = '_pild_level' AND meta_value != '' LIMIT 1"
    );
}

// English display names for the 3 fallback levels — same Foundation /
// Professional / Executive mapping already used everywhere else the
// level shows up in English (see includes/12-cert-verify-acf.php, the
// certificate templates, and the seal images in
// assets/images/seals/seal-{foundation,professional,executive}.png).
function pild_pricing_level_en_table() {
    return [
        'أساسي' => 'Foundation',
        'متقدم' => 'Professional',
        'متخصص' => 'Executive',
    ];
}

// ── 31.2 Ensure the 6 shared products exist ──────────────────────────
// Safety net only — see 31.1's comment. Returns
// ['created' => [level|variant => product_id, ...], 'existing' => [...]]
//
// BUGFIX: this used to create ONLY the Arabic product for each
// level/variant, and never called pll_set_post_language() on it either
// — so on a Polylang site the product had no language at all, and (since
// no English translation was ever created) the SAME single Arabic-named
// product was the only one that could ever end up in the cart, no
// matter which language the visitor was browsing in. That's why the
// checkout could show an Arabic product name ("أساسي — تسجيل مؤسسي")
// on an otherwise fully English checkout page. Now mirrors the same
// bilingual create-and-link pattern already used by the real importer
// just above (pild_products_level_import()): an Arabic product, an
// English product, and — when Polylang is active — the two saved as
// translations of each other via pll_set_post_language()/
// pll_save_post_translations(), exactly like every other bilingual pair
// this plugin creates.
function pild_ensure_level_products() {
    $result = ['created' => [], 'existing' => []];
    if (!class_exists('WC_Product_Simple')) return $result;
    if (pild_any_level_product_exists()) return $result; // (A) already ran — never overwrite it with fallback guesses

    $variant_labels    = ['individual' => 'فردي', 'team' => 'مؤسسي'];
    $variant_labels_en = ['individual' => 'Individual', 'team' => 'Team'];
    $levels_en         = pild_pricing_level_en_table();
    $polylang_active   = function_exists('pll_set_post_language') && function_exists('pll_save_post_translations');

    foreach (pild_pricing_level_table() as $level => $prices) {
        $level_en = $levels_en[$level] ?? $level;

        foreach ($variant_labels as $variant => $variant_label) {
            $existing_id = function_exists('pild_get_level_product_id')
                ? pild_get_level_product_id($level, $variant) : 0;

            if ($existing_id) {
                $result['existing'][$level . '|' . $variant] = $existing_id;
                continue;
            }

            $product = new WC_Product_Simple();
            $product->set_name($level . ' — تسجيل ' . $variant_label);
            $product->set_regular_price((string) $prices[$variant]);
            $product->set_status('publish');
            // Sold only through a track's "Register" button, never
            // meant to be browsed/found as a standalone shop item.
            $product->set_catalog_visibility('hidden');
            $product_id = $product->save();
            if (!$product_id) continue;

            update_post_meta($product_id, '_pild_level_product_code', 'FALLBACK-' . $level . '-' . $variant);
            update_post_meta($product_id, '_pild_level', $level);
            update_post_meta($product_id, '_pild_variant', $variant);
            update_post_meta($product_id, '_pild_partner_price', (string) $prices['partner']); // includes/14-partner-pricing.php
            if ($variant === 'team') {
                update_post_meta($product_id, '_pild_min_seats', 5);
            }

            $en_id = 0;
            if ($polylang_active) {
                pll_set_post_language($product_id, 'ar');

                $en_product = new WC_Product_Simple();
                $en_product->set_name($level_en . ' — ' . $variant_labels_en[$variant] . ' Registration');
                $en_product->set_regular_price((string) $prices[$variant]);
                $en_product->set_status('publish');
                $en_product->set_catalog_visibility('hidden');
                $en_id = $en_product->save();

                if ($en_id) {
                    update_post_meta($en_id, '_pild_level_product_code', 'FALLBACK-' . $level . '-' . $variant . '-EN');
                    update_post_meta($en_id, '_pild_level', $level); // same Arabic level value — matched against track_pricing_level, not shown to visitors
                    update_post_meta($en_id, '_pild_variant', $variant);
                    update_post_meta($en_id, '_pild_partner_price', (string) $prices['partner']);
                    if ($variant === 'team') {
                        update_post_meta($en_id, '_pild_min_seats', 5);
                    }
                    pll_set_post_language($en_id, 'en');
                    pll_save_post_translations(['ar' => $product_id, 'en' => $en_id]);
                }
            }

            $result['created'][$level . '|' . $variant] = $product_id;
            if ($en_id) $result['created'][$level . '|' . $variant . '|en'] = $en_id;
        }
    }

    delete_transient('pild_level_product_map');
    delete_transient('pild_team_product_ids');
    return $result;
}

// ── 31.4 Admin page ───────────────────────────────────────────────────
add_action('admin_menu', 'pild_pricing_import_menu');
function pild_pricing_import_menu() {
    add_submenu_page('pild-settings', 'Import Track Pricing', 'Import Track Pricing',
        'manage_options', 'pild-pricing-import', 'pild_pricing_import_page');
}

function pild_pricing_import_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>استيراد منتجات المستويات (الأسماء والأسعار)</h1>';

    echo '<p style="color:#666;max-width:640px">صف واحد لكل منتج مستوى (أو أكتر لو عندكم مستويات إضافية لاحقًا) — الاسم عربي/إنجليزي والسعر بتاعه بيتاخدوا من الملف ده حرفيًا، مفيش أسامي أو أسعار متثبتة في الكود. أعمدة الشيت: <code>' . esc_html(implode(' | ', pild_products_level_columns())) . '</code>. إعادة رفع نفس الملف (بعد تعديل سعر مثلاً) بتحدّث نفس المنتجات (بمطابقة كود_المنتج) مش بتعمل نسخ جديدة. ربط كل تراك بمستواه بيحصل من ملف القطاع نفسه (Import Sector، عمود المستوى_السعري).</p>';

    if (!empty($_POST['pild_products_import_nonce']) && wp_verify_nonce($_POST['pild_products_import_nonce'], 'pild_products_import') && !empty($_FILES['products_file']['tmp_name'])) {
        pild_products_import_handle_upload($_FILES['products_file']['tmp_name']);
    }

    echo '<form method="post" enctype="multipart/form-data" style="margin-bottom:32px;">';
    wp_nonce_field('pild_products_import', 'pild_products_import_nonce');
    echo '<input type="file" name="products_file" accept=".xlsx" required> ';
    echo '<button type="submit" class="button button-primary">استيراد المنتجات</button>';
    echo '</form></div>';
}

function pild_products_import_handle_upload($tmp_path) {
    if (!function_exists('pildcm_xlsx_extract')) {
        echo '<div class="notice notice-error"><p>أداة قراءة الإكسيل الأساسية مش متحملة.</p></div>';
        return;
    }
    $sheets = pildcm_xlsx_extract($tmp_path);
    if (is_wp_error($sheets)) {
        echo '<div class="notice notice-error"><p>' . esc_html($sheets->get_error_message()) . '</p></div>';
        return;
    }
    if (empty($sheets)) {
        echo '<div class="notice notice-error"><p>الملف فاضي أو مفيهوش شيتات.</p></div>';
        return;
    }
    $rows = reset($sheets); // first sheet, regardless of its name

    $result = pild_products_level_import($rows);

    echo '<div class="notice notice-success"><p><strong>خلص استيراد المنتجات.</strong> منتجات جديدة: ' . (int) $result['created'] . '، اتحدّثت: ' . (int) $result['updated'] . '، نسخ إنجليزي جديدة: ' . (int) $result['created_en'] . '</p></div>';
    if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
    if (empty($result['polylang_active'])) {
        echo '<div class="notice notice-warning"><p>Polylang مش شغال (أو الـ Product مش مسجل ضمن الأنواع القابلة للترجمة في Settings → Languages → Custom Post Types) — فأي منتج إنجليزي اتعمل دلوقتي هو منتج مستقل، مش مربوط رسميًا كـ"ترجمة" للمنتج العربي. المتصفح لسه هيقدر يستخدمه (الكود بيختار حسب اللغة الحالية لو موجودة نسختين)، بس مش هيظهر مربوط في شاشة الترجمات بتاعة Polylang.</p></div>';
    }
    if (!empty($result['errors'])) {
        echo '<div class="notice notice-warning"><p>' . implode('<br>', array_map('esc_html', $result['errors'])) . '</p></div>';
    }
}

// ============================================================
// 31.5 LANGUAGE AUDIT + REPAIR (diagnostic tool)
// ------------------------------------------------------------
// Added after a real case where the WooCommerce Products screen showed
// EVERY level product (old Arabic-fallback ones AND freshly-imported
// ones) under the exact same Polylang flag — including products whose
// own name is plainly Arabic text. That admin list is filtered by
// Polylang to the admin's current interface language by default, so it
// is NOT reliable ground truth for "did the Arabic product actually get
// created / does it actually carry the 'ar' language". This page reads
// the real Polylang language tag straight from the DB for every level
// product (found via the _pild_level/_pild_variant meta this plugin
// itself tags them with — so it works whether they came from
// pild_products_level_import(), pild_ensure_level_products(), or were
// tagged by hand), and can fix any that are missing/wrong in one click:
//   - No language row in Polylang at all (pll_get_post_language()
//     returns '' / false) → assign 'ar' or 'en' by detecting Arabic
//     script in the product's own name (a WooCommerce/WordPress product
//     can genuinely exist with zero Polylang language row if 'product'
//     wasn't a registered translatable post type at the moment it was
//     created — pild_pll_register_post_types() in 13-polylang.php fixes
//     that going forward, but never retroactively re-tags old posts).
//   - Tagged, but not linked to its (level, variant) sibling in the
//     other language → linked via pll_save_post_translations(), as long
//     as there's exactly one 'ar' and one 'en' candidate for that pair.
// Read-only until "Fix now" is clicked; nothing here ever deletes a
// product — genuine duplicates (more than 2 products sharing the same
// level+variant) are only reported, left for manual review, since
// picking which duplicate to keep is a judgment call this tool
// shouldn't make silently.
// ============================================================

add_action('admin_menu', 'pild_lang_audit_menu');
function pild_lang_audit_menu() {
    add_submenu_page('pild-settings', 'PILD — Language Audit', 'Language Audit',
        'manage_options', 'pild-lang-audit', 'pild_lang_audit_page');
}

function pild_lang_audit_has_arabic($text) {
    return (bool) preg_match('/[\x{0600}-\x{06FF}]/u', (string) $text);
}

// One row per level product currently tagged _pild_level/_pild_variant —
// this is the same meta both importers (26-products-importer.php's
// per-track products and this file's shared level products) write, so
// it also catches the older per-track-product setup if any of those are
// still in use.
function pild_lang_audit_collect() {
    $polylang_active = function_exists('pll_get_post_language');
    $ids = get_posts([
        'post_type' => 'product', 'posts_per_page' => -1, 'post_status' => 'any',
        'meta_query' => [
            ['key' => '_pild_level', 'compare' => 'EXISTS'],
            ['key' => '_pild_variant', 'compare' => 'EXISTS'],
        ],
        'fields' => 'ids',
    ]);

    $rows = [];
    foreach ($ids as $id) {
        $lang = $polylang_active ? (string) pll_get_post_language($id) : '';
        $name = get_the_title($id);
        $rows[] = [
            'id'      => $id,
            'name'    => $name,
            'level'   => get_post_meta($id, '_pild_level', true),
            'variant' => get_post_meta($id, '_pild_variant', true),
            'lang'    => $lang !== '' ? $lang : '— none —',
            'detected'=> pild_lang_audit_has_arabic($name) ? 'ar' : 'en',
            'status'  => get_post_status($id),
        ];
    }
    return ['rows' => $rows, 'polylang_active' => $polylang_active];
}

function pild_lang_audit_fix() {
    $polylang_active = function_exists('pll_set_post_language') && function_exists('pll_save_post_translations') && function_exists('pll_get_post_translations');
    if (!$polylang_active) return ['fixed_lang' => 0, 'linked' => 0, 'error' => 'Polylang غير مفعّل أو الدوال المطلوبة مش موجودة.'];

    $data = pild_lang_audit_collect();
    $fixed_lang = 0;
    $groups = []; // level|variant => ['ar' => [ids], 'en' => [ids]]

    foreach ($data['rows'] as $r) {
        $current = (string) pll_get_post_language($r['id']);
        // BUGFIX: this used to only fix a product with NO language at all
        // ($current === ''). But the real-world bug found here was products
        // that DID have a language — just the wrong one (Polylang's own
        // auto-assigned default, 'en', on Arabic-named products — see the
        // fix in pild_products_level_import() above). Now corrects any
        // mismatch between the stored language and what the product's own
        // name is actually written in, not just a missing one.
        if ($current === '' || $current !== $r['detected']) {
            pll_set_post_language($r['id'], $r['detected']);
            $current = $r['detected'];
            $fixed_lang++;
        }
        $key = $r['level'] . '|' . $r['variant'];
        $groups[$key][$current][] = $r['id'];
    }

    $linked = 0;
    foreach ($groups as $key => $langs) {
        if (empty($langs['ar']) || empty($langs['en'])) continue; // nothing to link, or a duplicate mess to leave for manual review
        if (count($langs['ar']) !== 1 || count($langs['en']) !== 1) continue; // duplicates — don't guess which pair to link
        $ar_id = $langs['ar'][0];
        $en_id = $langs['en'][0];
        $existing = pll_get_post_translations($ar_id);
        if (!empty($existing['en']) && (int) $existing['en'] === (int) $en_id) continue; // already linked
        pll_save_post_translations(['ar' => $ar_id, 'en' => $en_id]);
        $linked++;
    }

    delete_transient('pild_level_product_map');
    delete_transient('pild_team_product_ids');
    if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();

    return ['fixed_lang' => $fixed_lang, 'linked' => $linked];
}

function pild_lang_audit_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>🩺 PILD — فحص لغة المنتجات</h1>';
    echo '<p style="color:#666;max-width:820px">بيقرا لغة Polylang الحقيقية من قاعدة البيانات لكل منتج مُعلَّم بـ level/variant (زي منتجات المستويات الستة) — بغض النظر عن أي فلتر لغة في شاشة ووكوميرس نفسها.</p>';

    if (!empty($_POST['pild_lang_audit_nonce']) && wp_verify_nonce($_POST['pild_lang_audit_nonce'], 'pild_lang_audit_fix')) {
        $result = pild_lang_audit_fix();
        if (!empty($result['error'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($result['error']) . '</p></div>';
        } else {
            echo '<div class="notice notice-success"><p><strong>تم.</strong> اتصلّحت لغة ' . (int) $result['fixed_lang'] . ' منتج، واترابطت ' . (int) $result['linked'] . ' زوج عربي/إنجليزي كترجمة لبعض.</p></div>';
        }
    }

    $data = pild_lang_audit_collect();
    if (empty($data['polylang_active'])) {
        echo '<div class="notice notice-error"><p>دالة <code>pll_get_post_language</code> مش موجودة — يعني Polylang نفسه مش شغّال دلوقتي (اتأكد إنه مفعّل من صفحة الإضافات).</p></div>';
    } else {
        // The single most useful diagnostic line on this page: if 'ar' isn't
        // in this list, every pll_set_post_language($id, 'ar') call in the
        // whole plugin has been silently failing — Polylang ignores a
        // language slug it doesn't have registered, and every post falls
        // back to showing the site's default language instead (which is
        // exactly the "everything shows as one language" symptom this page
        // exists to catch).
        $registered = function_exists('pll_languages_list') ? pll_languages_list(['fields' => 'slug']) : [];
        $has_ar = in_array('ar', (array) $registered, true);
        echo '<div class="notice ' . ($has_ar ? 'notice-info' : 'notice-error') . '"><p><strong>اللغات المسجّلة فعليًا في Polylang (Settings → Languages → Languages):</strong> '
           . ($registered ? esc_html(implode(', ', $registered)) : 'مفيش ولا لغة مسجّلة')
           . '</p>';
        if (!$has_ar) {
            echo '<p>❌ <strong>"ar" مش موجودة في القايمة دي.</strong> ده هو السبب الحقيقي — لازم تضيف لغة "العربية" (بالـ slug <code>ar</code>) من Settings → Languages → Languages الأول، وبعدين ترجع هنا وتدوس "صلّح اللغات دلوقتي" تاني.</p>';
        }
        echo '</div>';
    }

    if (empty($data['rows'])) {
        echo '<p>مفيش أي منتج معلَّم بـ level/variant لسه.</p></div>';
        return;
    }

    // group for a quick "هل كل مستوى/نوع عنده نسخة عربي ونسخة إنجليزي؟" summary
    $groups = [];
    foreach ($data['rows'] as $r) $groups[$r['level'] . '|' . $r['variant']][] = $r;

    echo '<h2 style="margin-top:24px;">ملخص لكل مستوى/نوع</h2>';
    echo '<table class="widefat striped" style="max-width:900px;margin-bottom:28px"><thead><tr><th>المستوى</th><th>النوع</th><th>عربي؟</th><th>إنجليزي؟</th><th>عدد المنتجات الكلي</th></tr></thead><tbody>';
    foreach ($groups as $key => $rows) {
        [$level, $variant] = explode('|', $key);
        $ar_count = count(array_filter($rows, fn($r) => $r['lang'] === 'ar'));
        $en_count = count(array_filter($rows, fn($r) => $r['lang'] === 'en'));
        $flag = (count($rows) > 2 || $ar_count > 1 || $en_count > 1) ? ' ⚠️ فيه تكرار — راجعها يدوي' : '';
        echo '<tr><td>' . esc_html($level) . '</td><td>' . esc_html($variant) . '</td>'
           . '<td>' . ($ar_count ? "✅ ({$ar_count})" : '❌ مفيش') . '</td>'
           . '<td>' . ($en_count ? "✅ ({$en_count})" : '❌ مفيش') . '</td>'
           . '<td>' . count($rows) . esc_html($flag) . '</td></tr>';
    }
    echo '</tbody></table>';

    echo '<h2>كل المنتجات (تفصيلي)</h2>';
    echo '<table class="widefat striped" style="max-width:1100px"><thead><tr><th>ID</th><th>الاسم</th><th>المستوى</th><th>النوع</th><th>لغة Polylang الحالية</th><th>اللغة المتوقعة من الاسم</th><th>الحالة</th></tr></thead><tbody>';
    foreach ($data['rows'] as $r) {
        $mismatch = ($r['lang'] !== '— none —' && $r['lang'] !== $r['detected']);
        echo '<tr' . ($mismatch ? ' style="background:#FEF3C7"' : '') . '>'
           . '<td>' . (int) $r['id'] . '</td>'
           . '<td><a href="' . esc_url(get_edit_post_link($r['id'])) . '">' . esc_html($r['name']) . '</a></td>'
           . '<td>' . esc_html($r['level']) . '</td>'
           . '<td>' . esc_html($r['variant']) . '</td>'
           . '<td>' . esc_html($r['lang']) . '</td>'
           . '<td>' . esc_html($r['detected']) . '</td>'
           . '<td>' . esc_html($r['status']) . '</td>'
           . '</tr>';
    }
    echo '</tbody></table>';

    echo '<form method="post" style="margin-top:24px;">';
    wp_nonce_field('pild_lang_audit_fix', 'pild_lang_audit_nonce');
    submit_button('🔧 صلّح اللغات دلوقتي (Fix now)');
    echo '</form>';
    echo '</div>';
}
