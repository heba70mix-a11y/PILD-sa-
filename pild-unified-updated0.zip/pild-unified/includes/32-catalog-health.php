<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 32. CATALOG & PRICING HEALTH CHECK
// ------------------------------------------------------------
// A read-only diagnostic page. Every real incident so far in this
// pricing-level system (an unmatched "متخصص" vs "تنفيذي" spelling, a
// track with no level at all rendering as silently "unavailable", a
// wrong catalog file uploaded for the wrong sector) was invisible until
// a visitor actually clicked a broken "Register" button. This page
// surfaces the same gaps proactively, from the admin side, instead.
// Nothing here writes anything — it's purely a report.
// ============================================================

add_action('admin_menu', 'pild_catalog_health_menu');
function pild_catalog_health_menu() {
    add_submenu_page('pild-settings', 'Catalog & Pricing Health', 'Catalog & Pricing Health',
        'manage_options', 'pild-catalog-health', 'pild_catalog_health_page');
}

function pild_catalog_health_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;

    $tracks = get_posts([
        'post_type' => 'track', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids',
    ]);

    $valid_levels = function_exists('pild_pricing_levels') ? pild_pricing_levels() : [];
    $has_get_field = function_exists('get_field');

    $level_of = []; // track_id => level string (may be '')
    foreach ($tracks as $tid) {
        $level = $has_get_field ? get_field('track_pricing_level', $tid) : get_post_meta($tid, 'track_pricing_level', true);
        $level_of[$tid] = trim((string) $level);
    }

    $no_level = [];
    $bad_level = [];
    $level_counts = [];

    foreach ($tracks as $tid) {
        $level = $level_of[$tid];
        if ($level === '') {
            // Only a real gap if there's ALSO no legacy dedicated
            // product on this track or its domain (includes/22-
            // registration-routing.php's fallback, 26.1) — a track
            // relying on that older per-track link is fine as-is.
            $has_legacy = false;
            if ($has_get_field) {
                $has_legacy = (bool) get_field('pild_product_individual', $tid) || (bool) get_field('pild_product_team', $tid);
                if (!$has_legacy) {
                    $domain_id = (int) get_post_meta($tid, 'track_domain', true);
                    if ($domain_id) {
                        $has_legacy = (bool) get_field('pild_product_individual', $domain_id) || (bool) get_field('pild_product_team', $domain_id);
                    }
                }
            }
            if (!$has_legacy) $no_level[] = $tid;
            continue;
        }
        if (!in_array($level, $valid_levels, true)) {
            $bad_level[] = ['id' => $tid, 'level' => $level];
        }
        $level_counts[$level] = ($level_counts[$level] ?? 0) + 1;
    }

    $products = $wpdb->get_results(
        "SELECT p.ID, p.post_title, lvl.meta_value AS level, var.meta_value AS variant,
                reg.meta_value AS price, part.meta_value AS partner_price
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} lvl  ON lvl.post_id = p.ID  AND lvl.meta_key  = '_pild_level'
         INNER JOIN {$wpdb->postmeta} var  ON var.post_id = p.ID  AND var.meta_key  = '_pild_variant'
         LEFT  JOIN {$wpdb->postmeta} reg  ON reg.post_id = p.ID  AND reg.meta_key  = '_regular_price'
         LEFT  JOIN {$wpdb->postmeta} part ON part.post_id = p.ID AND part.meta_key = '_pild_partner_price'
         WHERE p.post_type = 'product' AND p.post_status = 'publish'
           AND lvl.meta_value != '' AND var.meta_value != ''
         ORDER BY lvl.meta_value, var.meta_value"
    );

    echo '<div class="wrap"><h1>صحة الكتالوج والتسعير</h1>';
    echo '<p style="color:#666;max-width:640px">تقرير بس — مفيش هنا أي حاجة بتتعدّل أو تتحذف. الهدف إنك تكتشف نقص أو تعارض في البيانات قبل ما عميل يوصله زرار "تسجيل" مش شغال.</p>';

    echo '<h2>الملخص</h2><ul>';
    echo '<li>إجمالي التراكات المنشورة: <strong>' . count($tracks) . '</strong></li>';
    echo '<li>تراكات من غير مستوى سعري ومن غير منتج مخصص لها: <strong style="color:' . (count($no_level) ? '#B91C1C' : '#1E6F5C') . '">' . count($no_level) . '</strong></li>';
    echo '<li>تراكات بقيمة "مستوى" مش مطابقة لأي منتج فعلي: <strong style="color:' . (count($bad_level) ? '#B91C1C' : '#1E6F5C') . '">' . count($bad_level) . '</strong></li>';
    echo '<li>منتجات المستويات المُعدّة حاليًا: <strong>' . count($products) . '</strong></li>';
    echo '</ul>';

    echo '<h2>منتجات المستويات وعدد التراكات على كل مستوى</h2>';
    if ($products) {
        echo '<table class="widefat striped"><thead><tr><th>المنتج</th><th>المستوى</th><th>النوع</th><th>السعر</th><th>سعر الشريك</th><th>عدد التراكات على نفس المستوى</th></tr></thead><tbody>';
        foreach ($products as $p) {
            $cnt = $level_counts[$p->level] ?? 0;
            echo '<tr><td>' . esc_html($p->post_title) . ' <span style="color:#999">(#' . (int) $p->ID . ')</span></td>'
               . '<td>' . esc_html($p->level) . '</td>'
               . '<td>' . esc_html($p->variant) . '</td>'
               . '<td>' . esc_html($p->price) . '</td>'
               . '<td>' . esc_html($p->partner_price ?: '—') . '</td>'
               . '<td>' . (int) $cnt . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color:#B91C1C">مفيش أي منتج مستوى متظبط لسه — ارفع ملف المنتجات من صفحة Import Track Pricing.</p>';
    }

    echo '<h2>تراكات من غير مستوى سعري ومن غير منتج مخصص (' . count($no_level) . ')</h2>';
    if ($no_level) {
        echo '<p style="color:#666">هيظهرلهم "التسجيل غير متاح حاليًا" على الموقع لحد ما تتظبط.</p><ul>';
        $shown = 0;
        foreach ($no_level as $tid) {
            if ($shown++ >= 100) { echo '<li>و' . (count($no_level) - 100) . ' تراك تاني…</li>'; break; }
            echo '<li><a href="' . esc_url(get_edit_post_link($tid)) . '">' . esc_html(get_the_title($tid)) . '</a> (#' . (int) $tid . ')</li>';
        }
        echo '</ul>';
    } else {
        echo '<p style="color:#1E6F5C">✓ مفيش</p>';
    }

    echo '<h2>تراكات بمستوى مكتوب غلط (' . count($bad_level) . ')</h2>';
    if ($bad_level) {
        echo '<p style="color:#666">القيمة المكتوبة مش مطابقة حرفيًا لأي منتج موجود فعليًا — غالبًا فرق إملائي بسيط.</p><ul>';
        foreach ($bad_level as $row) {
            echo '<li><a href="' . esc_url(get_edit_post_link($row['id'])) . '">' . esc_html(get_the_title($row['id'])) . '</a> (#' . (int) $row['id'] . ') — المكتوب: "' . esc_html($row['level']) . '"</li>';
        }
        echo '</ul>';
    } else {
        echo '<p style="color:#1E6F5C">✓ مفيش</p>';
    }

    echo '</div>';
}
