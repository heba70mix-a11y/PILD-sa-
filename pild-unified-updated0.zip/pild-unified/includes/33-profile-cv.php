<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 33. PROFESSIONAL PROFILE — EXPERIENCE, EDUCATION, SKILLS
// ------------------------------------------------------------
// Adds a LinkedIn-style CV to the member/solo public profile
// (includes/16-public-profile.php), editable from its own standalone
// page — /my-profile/ — reachable from the dashboard nav, NOT a tab
// buried under Settings (client decision, Sep 2026).
//
// Trust model: the public profile always keeps PILD-issued data
// (certificates/badges/points) visually separate from what the member
// types in here (experience/education/skills) — see
// includes/16-public-profile.php. This file only owns the self-reported
// side: storage, editing, and a first-save honesty acknowledgment
// (pild_cv_acknowledged user meta) — it does not verify any of it.
//
// Bilingual (client decision, Sep 2026): every free-text field has an
// Arabic and an English column/meta side by side (job_title/job_title_en,
// company/company_en, etc.) — same _en-suffix convention as the Sector
// importer (includes/18-excel-importer.php). The edit page shows both
// language inputs together (so the owner fills each once, in whichever
// language(s) they want). The PUBLIC profile and the printable CV each
// pick ONE language — whichever the page is currently being viewed in
// (pll_current_language()) — falling back to whichever language IS
// filled in if the other is empty, so a page is never a mix of both.
//
// "Don't show empty state" (client decision, Sep 2026): every stat,
// section, and field on the public profile and CV is wrapped in an
// emptiness check — nothing prints "0" or an empty heading. See
// includes/16-public-profile.php's pp-stat / pp-block conditionals.
//
// Tables (created/kept-in-sync lazily on `init`, same safety-net
// pattern as includes/15-domain-certification.php — works on a site
// where the plugin was already active before this file was added, and
// dbDelta() safely no-ops or adds missing columns on repeat runs, so
// this also carries existing single-language rows forward untouched):
//   - {$prefix}pild_profile_experience
//   - {$prefix}pild_profile_education
// Skills + links + headline fields are user meta (pild_skills[_en],
// pild_linkedin_url, pild_profile_website, pild_job_title[_en],
// pild_bio[_en], pild_country[_en]) — no repeatable structure needed.
// ============================================================

// ── 33.0 Tables (dbDelta runs every time — cheap, and it's how
//         existing installs pick up new _en columns automatically).
add_action('init', 'pildcm_cv_maybe_create_tables');
function pildcm_cv_maybe_create_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset_collate = $wpdb->get_charset_collate();

    $exp_table = $wpdb->prefix . 'pild_profile_experience';
    dbDelta("CREATE TABLE {$exp_table} (
        id             int(11)      NOT NULL AUTO_INCREMENT,
        user_id        int(11)      NOT NULL,
        job_title      varchar(190) DEFAULT NULL,
        job_title_en   varchar(190) DEFAULT NULL,
        company        varchar(190) DEFAULT NULL,
        company_en     varchar(190) DEFAULT NULL,
        start_month    varchar(20)  DEFAULT NULL,
        end_month      varchar(20)  DEFAULT NULL,
        is_current     tinyint(1)   DEFAULT 0,
        description    text         DEFAULT NULL,
        description_en text         DEFAULT NULL,
        sort_order     int(11)      DEFAULT 0,
        created_at     datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_id (user_id)
    ) {$charset_collate};");

    $edu_table = $wpdb->prefix . 'pild_profile_education';
    dbDelta("CREATE TABLE {$edu_table} (
        id                int(11)      NOT NULL AUTO_INCREMENT,
        user_id           int(11)      NOT NULL,
        degree            varchar(190) DEFAULT NULL,
        degree_en         varchar(190) DEFAULT NULL,
        institution       varchar(190) DEFAULT NULL,
        institution_en    varchar(190) DEFAULT NULL,
        field_of_study    varchar(190) DEFAULT NULL,
        field_of_study_en varchar(190) DEFAULT NULL,
        start_year        varchar(10)  DEFAULT NULL,
        end_year          varchar(10)  DEFAULT NULL,
        sort_order        int(11)      DEFAULT 0,
        created_at        datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_id (user_id)
    ) {$charset_collate};");
}

// ── 33.1 Data helpers (used by the edit page AND the public profile) ──
function pildcm_get_profile_experience($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_experience';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE user_id=%d ORDER BY is_current DESC, start_month DESC, sort_order ASC",
        $user_id
    )) ?: [];
}

function pildcm_get_profile_education($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_education';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE user_id=%d ORDER BY end_year DESC, sort_order ASC",
        $user_id
    )) ?: [];
}

function pildcm_get_profile_skills($user_id, $lang = null) {
    $lang = $lang ?: (function_exists('pll_current_language') ? pll_current_language() : 'ar');
    $key  = $lang === 'en' ? 'pild_skills_en' : 'pild_skills';
    $raw  = get_user_meta($user_id, $key, true);
    if (!$raw && $lang === 'en') $raw = get_user_meta($user_id, 'pild_skills', true);
    if (!$raw) return [];
    return array_values(array_filter(array_map('trim', explode(',', $raw))));
}

function pildcm_cv_pick($ar, $en, $lang) {
    if ($lang === 'en') return $en !== '' && $en !== null ? $en : $ar;
    return $ar !== '' && $ar !== null ? $ar : $en;
}

function pildcm_cv_current_lang() {
    return function_exists('pll_current_language') && pll_current_language() === 'en' ? 'en' : 'ar';
}

function pildcm_cv_format_month($ym) {
    if (!$ym) return '';
    $ts = strtotime($ym . '-01');
    if (!$ts) return esc_html($ym);
    return date_i18n('F Y', $ts);
}

// ── 33.2 AJAX: Experience ─────────────────────────────────────────
add_action('wp_ajax_pildcm_save_experience', 'pildcm_ajax_save_experience');
function pildcm_ajax_save_experience() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Not logged in', 'pild-unified')]);
    $user_id = get_current_user_id();

    if (empty($_POST['acknowledged']) && get_user_meta($user_id, 'pild_cv_acknowledged', true) !== '1') {
        wp_send_json_error(['message' => __('Please confirm the information you enter is accurate first.', 'pild-unified')]);
    }
    update_user_meta($user_id, 'pild_cv_acknowledged', '1');

    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_experience';
    $id           = (int) ($_POST['id'] ?? 0);
    $job_title    = sanitize_text_field($_POST['job_title'] ?? '');
    $job_title_en = sanitize_text_field($_POST['job_title_en'] ?? '');
    $company      = sanitize_text_field($_POST['company'] ?? '');
    $company_en   = sanitize_text_field($_POST['company_en'] ?? '');
    $start        = sanitize_text_field($_POST['start_month'] ?? '');
    $is_current   = !empty($_POST['is_current']) ? 1 : 0;
    $end          = $is_current ? null : sanitize_text_field($_POST['end_month'] ?? '');
    $desc         = sanitize_textarea_field($_POST['description'] ?? '');
    $desc_en      = sanitize_textarea_field($_POST['description_en'] ?? '');

    if (($job_title === '' && $job_title_en === '') || ($company === '' && $company_en === '')) {
        wp_send_json_error(['message' => __('Job title and company are required (in at least one language).', 'pild-unified')]);
    }

    $data = [
        'user_id'        => $user_id,
        'job_title'      => $job_title ?: null,
        'job_title_en'   => $job_title_en ?: null,
        'company'        => $company ?: null,
        'company_en'     => $company_en ?: null,
        'start_month'    => $start ?: null,
        'end_month'      => $end ?: null,
        'is_current'     => $is_current,
        'description'    => $desc ?: null,
        'description_en' => $desc_en ?: null,
    ];

    if ($id) {
        $owner = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id=%d", $id));
        if ($owner !== $user_id) wp_send_json_error(['message' => __('Not allowed.', 'pild-unified')]);
        $wpdb->update($table, $data, ['id' => $id]);
    } else {
        $wpdb->insert($table, $data);
    }

    if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
    wp_send_json_success(['message' => __('Saved.', 'pild-unified')]);
}

add_action('wp_ajax_pildcm_delete_experience', 'pildcm_ajax_delete_experience');
function pildcm_ajax_delete_experience() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Not logged in', 'pild-unified')]);
    $user_id = get_current_user_id();
    $id = (int) ($_POST['id'] ?? 0);

    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_experience';
    $owner = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id=%d", $id));
    if ($owner !== $user_id) wp_send_json_error(['message' => __('Not allowed.', 'pild-unified')]);
    $wpdb->delete($table, ['id' => $id]);
    wp_send_json_success();
}

// ── 33.3 AJAX: Education ──────────────────────────────────────────
add_action('wp_ajax_pildcm_save_education', 'pildcm_ajax_save_education');
function pildcm_ajax_save_education() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Not logged in', 'pild-unified')]);
    $user_id = get_current_user_id();

    if (empty($_POST['acknowledged']) && get_user_meta($user_id, 'pild_cv_acknowledged', true) !== '1') {
        wp_send_json_error(['message' => __('Please confirm the information you enter is accurate first.', 'pild-unified')]);
    }
    update_user_meta($user_id, 'pild_cv_acknowledged', '1');

    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_education';
    $id              = (int) ($_POST['id'] ?? 0);
    $degree          = sanitize_text_field($_POST['degree'] ?? '');
    $degree_en       = sanitize_text_field($_POST['degree_en'] ?? '');
    $institution     = sanitize_text_field($_POST['institution'] ?? '');
    $institution_en  = sanitize_text_field($_POST['institution_en'] ?? '');
    $field           = sanitize_text_field($_POST['field_of_study'] ?? '');
    $field_en        = sanitize_text_field($_POST['field_of_study_en'] ?? '');
    $start_year      = sanitize_text_field($_POST['start_year'] ?? '');
    $end_year        = sanitize_text_field($_POST['end_year'] ?? '');

    if (($degree === '' && $degree_en === '') || ($institution === '' && $institution_en === '')) {
        wp_send_json_error(['message' => __('Degree and institution are required (in at least one language).', 'pild-unified')]);
    }

    $data = [
        'user_id'           => $user_id,
        'degree'            => $degree ?: null,
        'degree_en'         => $degree_en ?: null,
        'institution'       => $institution ?: null,
        'institution_en'    => $institution_en ?: null,
        'field_of_study'    => $field ?: null,
        'field_of_study_en' => $field_en ?: null,
        'start_year'        => $start_year ?: null,
        'end_year'          => $end_year ?: null,
    ];

    if ($id) {
        $owner = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id=%d", $id));
        if ($owner !== $user_id) wp_send_json_error(['message' => __('Not allowed.', 'pild-unified')]);
        $wpdb->update($table, $data, ['id' => $id]);
    } else {
        $wpdb->insert($table, $data);
    }

    if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
    wp_send_json_success(['message' => __('Saved.', 'pild-unified')]);
}

add_action('wp_ajax_pildcm_delete_education', 'pildcm_ajax_delete_education');
function pildcm_ajax_delete_education() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Not logged in', 'pild-unified')]);
    $user_id = get_current_user_id();
    $id = (int) ($_POST['id'] ?? 0);

    global $wpdb;
    $table = $wpdb->prefix . 'pild_profile_education';
    $owner = (int) $wpdb->get_var($wpdb->prepare("SELECT user_id FROM {$table} WHERE id=%d", $id));
    if ($owner !== $user_id) wp_send_json_error(['message' => __('Not allowed.', 'pild-unified')]);
    $wpdb->delete($table, ['id' => $id]);
    wp_send_json_success();
}

// ── 33.4 AJAX: headline fields (job title / bio / country), skills, links —
//          all bilingual, all one save.
add_action('wp_ajax_pildcm_save_cv_extras', 'pildcm_ajax_save_cv_extras');
function pildcm_ajax_save_cv_extras() {
    check_ajax_referer('pildcm_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error(['message' => __('Not logged in', 'pild-unified')]);
    $user_id = get_current_user_id();

    $fields = [
        'pild_job_title'    => sanitize_text_field($_POST['job_title'] ?? ''),
        'pild_job_title_en' => sanitize_text_field($_POST['job_title_en'] ?? ''),
        'pild_bio'          => sanitize_textarea_field($_POST['bio'] ?? ''),
        'pild_bio_en'       => sanitize_textarea_field($_POST['bio_en'] ?? ''),
        'pild_country'      => sanitize_text_field($_POST['country'] ?? ''),
        'pild_country_en'   => sanitize_text_field($_POST['country_en'] ?? ''),
    ];
    foreach ($fields as $key => $val) {
        update_user_meta($user_id, $key, $val);
    }

    $skills_raw    = sanitize_text_field($_POST['skills'] ?? '');
    $skills_en_raw = sanitize_text_field($_POST['skills_en'] ?? '');
    $skills    = array_slice(array_values(array_filter(array_map('trim', explode(',', $skills_raw)))), 0, 20);
    $skills_en = array_slice(array_values(array_filter(array_map('trim', explode(',', $skills_en_raw)))), 0, 20);
    update_user_meta($user_id, 'pild_skills', implode(', ', $skills));
    update_user_meta($user_id, 'pild_skills_en', implode(', ', $skills_en));

    update_user_meta($user_id, 'pild_linkedin_url', esc_url_raw($_POST['linkedin_url'] ?? ''));
    update_user_meta($user_id, 'pild_profile_website', esc_url_raw($_POST['profile_website'] ?? ''));

    if (function_exists('pild_flush_sector_explorer_cache')) pild_flush_sector_explorer_cache();
    wp_send_json_success(['message' => __('Saved.', 'pild-unified')]);
}

// ── 33.5 Standalone edit page — /my-profile/ ──────────────────────
add_action('init', 'pildcm_add_edit_profile_rewrite');
function pildcm_add_edit_profile_rewrite() {
    add_rewrite_rule('^my-profile/?$', 'index.php?pild_edit_profile=1', 'top');
}
add_filter('query_vars', 'pildcm_edit_profile_query_vars');
function pildcm_edit_profile_query_vars($vars) {
    $vars[] = 'pild_edit_profile';
    return $vars;
}
add_action('init', function () {
    if (!get_option('pild_edit_profile_rewrite_flushed')) {
        flush_rewrite_rules();
        update_option('pild_edit_profile_rewrite_flushed', 1);
    }
}, 21);

function pildcm_edit_profile_url() {
    return home_url('/my-profile/');
}

add_action('template_redirect', 'pildcm_render_edit_profile_page');
function pildcm_render_edit_profile_page() {
    if (!get_query_var('pild_edit_profile')) return;

    if (!is_user_logged_in()) {
        wp_redirect(wp_login_url(pildcm_edit_profile_url()));
        exit;
    }

    $user_id      = get_current_user_id();
    $user         = wp_get_current_user();
    $job_title    = get_user_meta($user_id, 'pild_job_title', true);
    $job_title_en = get_user_meta($user_id, 'pild_job_title_en', true);
    $bio          = get_user_meta($user_id, 'pild_bio', true);
    $bio_en       = get_user_meta($user_id, 'pild_bio_en', true);
    $country      = get_user_meta($user_id, 'pild_country', true);
    $country_en   = get_user_meta($user_id, 'pild_country_en', true);
    $skills       = get_user_meta($user_id, 'pild_skills', true);
    $skills_en    = get_user_meta($user_id, 'pild_skills_en', true);
    $linkedin_url = get_user_meta($user_id, 'pild_linkedin_url', true);
    $website_url  = get_user_meta($user_id, 'pild_profile_website', true);
    $acknowledged = get_user_meta($user_id, 'pild_cv_acknowledged', true) === '1';
    $experience   = pildcm_get_profile_experience($user_id);
    $education    = pildcm_get_profile_education($user_id);

    wp_enqueue_script('pildcm-js', PILDCM_URL . 'assets/pildcm.js', ['jquery'], PILDCM_VERSION, true);
    wp_localize_script('pildcm-js', 'pildcm_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('pildcm_nonce'),
        'i18n'     => [
            'error'             => __( 'Error', 'pild-unified' ),
            'connection_failed' => __( '✗ Connection failed', 'pild-unified' ),
            'confirm_delete'    => __( 'Delete this entry?', 'pild-unified' ),
            'saved'             => __( '✓ Saved', 'pild-unified' ),
        ],
    ]);

    get_header();
    echo function_exists('pild_global_css') ? pild_global_css() : '';
    echo function_exists('pildcm_css') ? pildcm_css() : '';
    ?>
    <div class="pild-wrap">
      <div class="cm-panel-header">
        <div class="cm-panel-title"><?php esc_html_e( 'Professional Profile', 'pild-unified' ); ?></div>
        <div class="cm-panel-desc"><?php esc_html_e( 'Fill in Arabic and/or English for each field. Your public profile shows whichever language it is being viewed in.', 'pild-unified' ); ?></div>
      </div>

      <div class="cm-settings-footer" style="margin-bottom:1.5rem">
        <a class="cm-btn-primary" href="<?php echo esc_url( function_exists('pildcm_get_public_profile_url') ? pildcm_get_public_profile_url($user_id) : '#' ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View Professional Profile', 'pild-unified' ); ?></a>
      </div>

      <?php if (!$acknowledged): ?>
      <div class="cm-cv-ack-notice" id="cv-ack-notice">
        <label>
          <input type="checkbox" id="cv-ack-checkbox">
          <span><?php esc_html_e( 'I confirm the information I add here is accurate.', 'pild-unified' ); ?></span>
        </label>
      </div>
      <?php endif; ?>

      <div class="cm-cv-section">
        <div class="cm-settings-section-title"><?php esc_html_e( 'Headline', 'pild-unified' ); ?></div>
        <div class="cm-cv-lang-grid">
          <div class="cm-cv-lang-col">
            <div class="cm-cv-lang-label">العربية</div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Job Title', 'pild-unified' ); ?></label><input type="text" id="cv-job-title" value="<?php echo esc_attr($job_title); ?>"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Country', 'pild-unified' ); ?></label><input type="text" id="cv-country" value="<?php echo esc_attr($country); ?>"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Short Bio', 'pild-unified' ); ?></label><textarea id="cv-bio" rows="3"><?php echo esc_textarea($bio); ?></textarea></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Skills (comma-separated)', 'pild-unified' ); ?></label><input type="text" id="cv-skills" value="<?php echo esc_attr($skills); ?>"></div>
          </div>
          <div class="cm-cv-lang-col">
            <div class="cm-cv-lang-label">English</div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Job Title', 'pild-unified' ); ?></label><input type="text" id="cv-job-title-en" value="<?php echo esc_attr($job_title_en); ?>"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Country', 'pild-unified' ); ?></label><input type="text" id="cv-country-en" value="<?php echo esc_attr($country_en); ?>"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Short Bio', 'pild-unified' ); ?></label><textarea id="cv-bio-en" rows="3"><?php echo esc_textarea($bio_en); ?></textarea></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'Skills (comma-separated)', 'pild-unified' ); ?></label><input type="text" id="cv-skills-en" value="<?php echo esc_attr($skills_en); ?>"></div>
          </div>
        </div>
        <div class="cm-settings-fields" style="margin-top:1rem">
          <div class="cm-settings-field"><label><?php esc_html_e( 'LinkedIn URL', 'pild-unified' ); ?></label><input type="text" id="cv-linkedin" value="<?php echo esc_attr($linkedin_url); ?>" placeholder="https://linkedin.com/in/..."></div>
          <div class="cm-settings-field"><label><?php esc_html_e( 'Website', 'pild-unified' ); ?></label><input type="text" id="cv-website" value="<?php echo esc_attr($website_url); ?>" placeholder="https://..."></div>
        </div>
        <div class="cm-settings-footer">
          <button class="cm-btn-primary cm-btn-save" id="cv-save-extras"><?php esc_html_e( 'Save Changes', 'pild-unified' ); ?></button>
          <span id="cv-extras-msg"></span>
        </div>
      </div>

      <div class="cm-cv-section">
        <div class="cm-cv-section-head">
          <div class="cm-settings-section-title"><?php esc_html_e( 'Experience', 'pild-unified' ); ?></div>
          <button type="button" class="cm-btn-secondary cm-cv-add-btn" data-form="experience"><?php esc_html_e( '+ Add Experience', 'pild-unified' ); ?></button>
        </div>

        <div class="cm-cv-list" id="cv-experience-list">
          <?php if (empty($experience)): ?>
            <p class="cm-upload-hint"><?php esc_html_e( 'No experience added yet.', 'pild-unified' ); ?></p>
          <?php endif; ?>
          <?php foreach ($experience as $e): ?>
          <div class="cm-cv-item" data-id="<?php echo (int) $e->id; ?>">
            <div class="cm-cv-item-main">
              <strong><?php echo esc_html($e->job_title ?: $e->job_title_en); ?><?php if ($e->job_title && $e->job_title_en): ?> <span class="cm-cv-item-en">/ <?php echo esc_html($e->job_title_en); ?></span><?php endif; ?></strong>
              <span class="cm-cv-item-sub"><?php echo esc_html($e->company ?: $e->company_en); ?></span>
              <span class="cm-cv-item-dates"><?php echo esc_html(pildcm_cv_format_month($e->start_month)); ?> — <?php echo $e->is_current ? esc_html__( 'Present', 'pild-unified' ) : esc_html(pildcm_cv_format_month($e->end_month)); ?></span>
            </div>
            <div class="cm-cv-item-actions">
              <button type="button" class="cm-cv-edit" data-type="experience" data-id="<?php echo (int) $e->id; ?>"
                data-job_title="<?php echo esc_attr($e->job_title); ?>" data-job_title_en="<?php echo esc_attr($e->job_title_en); ?>"
                data-company="<?php echo esc_attr($e->company); ?>" data-company_en="<?php echo esc_attr($e->company_en); ?>"
                data-start_month="<?php echo esc_attr($e->start_month); ?>" data-end_month="<?php echo esc_attr($e->end_month); ?>" data-is_current="<?php echo (int) $e->is_current; ?>"
                data-description="<?php echo esc_attr($e->description); ?>" data-description_en="<?php echo esc_attr($e->description_en); ?>">✎</button>
              <button type="button" class="cm-cv-delete" data-type="experience" data-id="<?php echo (int) $e->id; ?>">✕</button>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="cm-cv-form cm-cv-form-hidden" id="cv-form-experience">
          <input type="hidden" id="exp-id" value="0">
          <div class="cm-cv-lang-grid">
            <div class="cm-cv-lang-col">
              <div class="cm-cv-lang-label">العربية</div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Job Title', 'pild-unified' ); ?></label><input type="text" id="exp-job-title"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Company', 'pild-unified' ); ?></label><input type="text" id="exp-company"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Description', 'pild-unified' ); ?></label><textarea id="exp-description" rows="3"></textarea></div>
            </div>
            <div class="cm-cv-lang-col">
              <div class="cm-cv-lang-label">English</div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Job Title', 'pild-unified' ); ?></label><input type="text" id="exp-job-title-en"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Company', 'pild-unified' ); ?></label><input type="text" id="exp-company-en"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Description', 'pild-unified' ); ?></label><textarea id="exp-description-en" rows="3"></textarea></div>
            </div>
          </div>
          <div class="cm-settings-fields" style="margin-top:.75rem">
            <div class="cm-settings-field"><label><?php esc_html_e( 'Start (YYYY-MM)', 'pild-unified' ); ?></label><input type="month" id="exp-start"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'End (YYYY-MM)', 'pild-unified' ); ?></label><input type="month" id="exp-end"></div>
            <div class="cm-settings-field"><label><input type="checkbox" id="exp-current"> <?php esc_html_e( 'I currently work here', 'pild-unified' ); ?></label></div>
          </div>
          <div class="cm-settings-footer">
            <button type="button" class="cm-btn-primary cm-btn-save" id="cv-save-experience"><?php esc_html_e( 'Save', 'pild-unified' ); ?></button>
            <button type="button" class="cm-btn-secondary" id="cv-cancel-experience"><?php esc_html_e( 'Cancel', 'pild-unified' ); ?></button>
            <span id="cv-experience-msg"></span>
          </div>
        </div>
      </div>

      <div class="cm-cv-section">
        <div class="cm-cv-section-head">
          <div class="cm-settings-section-title"><?php esc_html_e( 'Education', 'pild-unified' ); ?></div>
          <button type="button" class="cm-btn-secondary cm-cv-add-btn" data-form="education"><?php esc_html_e( '+ Add Education', 'pild-unified' ); ?></button>
        </div>

        <div class="cm-cv-list" id="cv-education-list">
          <?php if (empty($education)): ?>
            <p class="cm-upload-hint"><?php esc_html_e( 'No education added yet.', 'pild-unified' ); ?></p>
          <?php endif; ?>
          <?php foreach ($education as $ed): ?>
          <div class="cm-cv-item" data-id="<?php echo (int) $ed->id; ?>">
            <div class="cm-cv-item-main">
              <strong><?php echo esc_html($ed->degree ?: $ed->degree_en); ?></strong>
              <span class="cm-cv-item-sub"><?php echo esc_html($ed->institution ?: $ed->institution_en); ?></span>
              <span class="cm-cv-item-dates"><?php echo esc_html($ed->start_year); ?><?php if ($ed->end_year): ?> — <?php echo esc_html($ed->end_year); ?><?php endif; ?></span>
            </div>
            <div class="cm-cv-item-actions">
              <button type="button" class="cm-cv-edit" data-type="education" data-id="<?php echo (int) $ed->id; ?>"
                data-degree="<?php echo esc_attr($ed->degree); ?>" data-degree_en="<?php echo esc_attr($ed->degree_en); ?>"
                data-institution="<?php echo esc_attr($ed->institution); ?>" data-institution_en="<?php echo esc_attr($ed->institution_en); ?>"
                data-field_of_study="<?php echo esc_attr($ed->field_of_study); ?>" data-field_of_study_en="<?php echo esc_attr($ed->field_of_study_en); ?>"
                data-start_year="<?php echo esc_attr($ed->start_year); ?>" data-end_year="<?php echo esc_attr($ed->end_year); ?>">✎</button>
              <button type="button" class="cm-cv-delete" data-type="education" data-id="<?php echo (int) $ed->id; ?>">✕</button>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="cm-cv-form cm-cv-form-hidden" id="cv-form-education">
          <input type="hidden" id="edu-id" value="0">
          <div class="cm-cv-lang-grid">
            <div class="cm-cv-lang-col">
              <div class="cm-cv-lang-label">العربية</div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Degree', 'pild-unified' ); ?></label><input type="text" id="edu-degree"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Institution', 'pild-unified' ); ?></label><input type="text" id="edu-institution"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Field of Study', 'pild-unified' ); ?></label><input type="text" id="edu-field"></div>
            </div>
            <div class="cm-cv-lang-col">
              <div class="cm-cv-lang-label">English</div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Degree', 'pild-unified' ); ?></label><input type="text" id="edu-degree-en"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Institution', 'pild-unified' ); ?></label><input type="text" id="edu-institution-en"></div>
              <div class="cm-settings-field"><label><?php esc_html_e( 'Field of Study', 'pild-unified' ); ?></label><input type="text" id="edu-field-en"></div>
            </div>
          </div>
          <div class="cm-settings-fields" style="margin-top:.75rem">
            <div class="cm-settings-field"><label><?php esc_html_e( 'Start Year', 'pild-unified' ); ?></label><input type="text" id="edu-start-year" placeholder="2018"></div>
            <div class="cm-settings-field"><label><?php esc_html_e( 'End Year', 'pild-unified' ); ?></label><input type="text" id="edu-end-year" placeholder="2022"></div>
          </div>
          <div class="cm-settings-footer">
            <button type="button" class="cm-btn-primary cm-btn-save" id="cv-save-education"><?php esc_html_e( 'Save', 'pild-unified' ); ?></button>
            <button type="button" class="cm-btn-secondary" id="cv-cancel-education"><?php esc_html_e( 'Cancel', 'pild-unified' ); ?></button>
            <span id="cv-education-msg"></span>
          </div>
        </div>
      </div>
    </div>

    <?php echo pildcm_cv_edit_page_script(); ?>
    <?php
    get_footer();
    exit;
}

function pildcm_cv_edit_page_script() {
    ob_start(); ?>
    <script>(function($){
      function ackOK(){
        var notice = document.getElementById('cv-ack-notice');
        if (!notice) return true;
        var box = document.getElementById('cv-ack-checkbox');
        if (box && box.checked) return true;
        notice.classList.add('cm-cv-ack-shake');
        setTimeout(function(){ notice.classList.remove('cm-cv-ack-shake'); }, 500);
        return false;
      }
      function ackVal(){
        var box = document.getElementById('cv-ack-checkbox');
        return box ? (box.checked ? '1' : '') : '1';
      }

      document.getElementById('cv-save-extras')?.addEventListener('click', function(){
        var btn=this, msg=document.getElementById('cv-extras-msg'); btn.disabled=true;
        var fd=new FormData();
        fd.append('action','pildcm_save_cv_extras'); fd.append('nonce',pildcm_ajax.nonce);
        fd.append('job_title',document.getElementById('cv-job-title').value);
        fd.append('job_title_en',document.getElementById('cv-job-title-en').value);
        fd.append('country',document.getElementById('cv-country').value);
        fd.append('country_en',document.getElementById('cv-country-en').value);
        fd.append('bio',document.getElementById('cv-bio').value);
        fd.append('bio_en',document.getElementById('cv-bio-en').value);
        fd.append('skills',document.getElementById('cv-skills').value);
        fd.append('skills_en',document.getElementById('cv-skills-en').value);
        fd.append('linkedin_url',document.getElementById('cv-linkedin').value);
        fd.append('profile_website',document.getElementById('cv-website').value);
        fetch(pildcm_ajax.ajax_url,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
          msg.textContent = res.success ? pildcm_ajax.i18n.saved : '✗ '+(res.data?.message||pildcm_ajax.i18n.error);
          btn.disabled=false;
        }).catch(()=>{msg.textContent=pildcm_ajax.i18n.connection_failed; btn.disabled=false;});
      });

      document.querySelectorAll('.cm-cv-add-btn').forEach(function(btn){
        btn.addEventListener('click', function(){
          var type = this.dataset.form;
          if (type === 'experience') {
            document.getElementById('exp-id').value = '0';
            ['job-title','job-title-en','company','company-en','start','end'].forEach(function(f){ document.getElementById('exp-'+f).value=''; });
            document.getElementById('exp-current').checked = false;
            document.getElementById('exp-description').value = '';
            document.getElementById('exp-description-en').value = '';
          } else {
            document.getElementById('edu-id').value = '0';
            ['degree','degree-en','institution','institution-en','field','field-en','start-year','end-year'].forEach(function(f){ document.getElementById('edu-'+f).value=''; });
          }
          document.getElementById('cv-form-'+type).classList.remove('cm-cv-form-hidden');
        });
      });

      document.querySelectorAll('.cm-cv-edit').forEach(function(btn){
        btn.addEventListener('click', function(){
          var type = this.dataset.type, d = this.dataset;
          if (type === 'experience') {
            document.getElementById('exp-id').value = d.id;
            document.getElementById('exp-job-title').value = d.job_title || '';
            document.getElementById('exp-job-title-en').value = d.job_title_en || '';
            document.getElementById('exp-company').value = d.company || '';
            document.getElementById('exp-company-en').value = d.company_en || '';
            document.getElementById('exp-start').value = d.start_month || '';
            document.getElementById('exp-end').value = d.end_month || '';
            document.getElementById('exp-current').checked = d.is_current === '1';
            document.getElementById('exp-description').value = d.description || '';
            document.getElementById('exp-description-en').value = d.description_en || '';
          } else {
            document.getElementById('edu-id').value = d.id;
            document.getElementById('edu-degree').value = d.degree || '';
            document.getElementById('edu-degree-en').value = d.degree_en || '';
            document.getElementById('edu-institution').value = d.institution || '';
            document.getElementById('edu-institution-en').value = d.institution_en || '';
            document.getElementById('edu-field').value = d.field_of_study || '';
            document.getElementById('edu-field-en').value = d.field_of_study_en || '';
            document.getElementById('edu-start-year').value = d.start_year || '';
            document.getElementById('edu-end-year').value = d.end_year || '';
          }
          document.getElementById('cv-form-'+type).classList.remove('cm-cv-form-hidden');
        });
      });

      ['experience','education'].forEach(function(type){
        document.getElementById('cv-cancel-'+type)?.addEventListener('click', function(){
          document.getElementById('cv-form-'+type).classList.add('cm-cv-form-hidden');
        });
      });

      document.querySelectorAll('.cm-cv-delete').forEach(function(btn){
        btn.addEventListener('click', function(){
          if (!confirm(pildcm_ajax.i18n.confirm_delete)) return;
          var type = this.dataset.type, id = this.dataset.id;
          var fd = new FormData();
          fd.append('action', 'pildcm_delete_'+type); fd.append('nonce', pildcm_ajax.nonce); fd.append('id', id);
          fetch(pildcm_ajax.ajax_url,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
            if (res.success) location.reload();
          });
        });
      });

      document.getElementById('cv-save-experience')?.addEventListener('click', function(){
        if (!ackOK()) return;
        var btn=this, msg=document.getElementById('cv-experience-msg'); btn.disabled=true;
        var fd=new FormData();
        fd.append('action','pildcm_save_experience'); fd.append('nonce',pildcm_ajax.nonce);
        fd.append('acknowledged', ackVal());
        fd.append('id', document.getElementById('exp-id').value);
        fd.append('job_title', document.getElementById('exp-job-title').value);
        fd.append('job_title_en', document.getElementById('exp-job-title-en').value);
        fd.append('company', document.getElementById('exp-company').value);
        fd.append('company_en', document.getElementById('exp-company-en').value);
        fd.append('start_month', document.getElementById('exp-start').value);
        fd.append('end_month', document.getElementById('exp-end').value);
        fd.append('is_current', document.getElementById('exp-current').checked ? '1' : '');
        fd.append('description', document.getElementById('exp-description').value);
        fd.append('description_en', document.getElementById('exp-description-en').value);
        fetch(pildcm_ajax.ajax_url,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
          if (res.success) { location.reload(); }
          else { msg.textContent = '✗ '+(res.data?.message||pildcm_ajax.i18n.error); btn.disabled=false; }
        }).catch(()=>{msg.textContent=pildcm_ajax.i18n.connection_failed; btn.disabled=false;});
      });

      document.getElementById('cv-save-education')?.addEventListener('click', function(){
        if (!ackOK()) return;
        var btn=this, msg=document.getElementById('cv-education-msg'); btn.disabled=true;
        var fd=new FormData();
        fd.append('action','pildcm_save_education'); fd.append('nonce',pildcm_ajax.nonce);
        fd.append('acknowledged', ackVal());
        fd.append('id', document.getElementById('edu-id').value);
        fd.append('degree', document.getElementById('edu-degree').value);
        fd.append('degree_en', document.getElementById('edu-degree-en').value);
        fd.append('institution', document.getElementById('edu-institution').value);
        fd.append('institution_en', document.getElementById('edu-institution-en').value);
        fd.append('field_of_study', document.getElementById('edu-field').value);
        fd.append('field_of_study_en', document.getElementById('edu-field-en').value);
        fd.append('start_year', document.getElementById('edu-start-year').value);
        fd.append('end_year', document.getElementById('edu-end-year').value);
        fetch(pildcm_ajax.ajax_url,{method:'POST',body:fd}).then(r=>r.json()).then(res=>{
          if (res.success) { location.reload(); }
          else { msg.textContent = '✗ '+(res.data?.message||pildcm_ajax.i18n.error); btn.disabled=false; }
        }).catch(()=>{msg.textContent=pildcm_ajax.i18n.connection_failed; btn.disabled=false;});
      });
    })(jQuery);</script>
    <?php
    return ob_get_clean();
}

// ── 33.6 CSS — appended once alongside pildcm_css() (11-css.php)
function pildcm_cv_tab_css() {
    return '
    .cm-cv-section{margin-top:2rem;padding-top:1.75rem;border-top:1px solid var(--border,rgba(13,17,23,.12));}
    .cm-cv-section:first-of-type{margin-top:1.5rem;padding-top:0;border-top:none;}
    .cm-cv-section-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;}
    .cm-cv-ack-notice{background:#FEF3C7;border:1px solid #FDE68A;border-radius:10px;padding:.85rem 1.1rem;margin-bottom:1.5rem;}
    .cm-cv-ack-notice label{display:flex;align-items:flex-start;gap:.6rem;font-size:.9rem;cursor:pointer;}
    .cm-cv-ack-shake{animation:cmCvShake .4s;}
    @keyframes cmCvShake{25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}
    .cm-cv-lang-grid{display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;}
    .cm-cv-lang-label{font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--gold,#B8960C);margin-bottom:.5rem;}
    .cm-cv-item-en{color:var(--ink3,#7A8090);font-weight:400;font-size:.85em;}
    .cm-cv-list{display:flex;flex-direction:column;gap:.6rem;margin-bottom:1rem;}
    .cm-cv-item{display:flex;justify-content:space-between;gap:1rem;border:1px solid var(--border,rgba(13,17,23,.12));border-radius:10px;padding:.9rem 1.1rem;}
    .cm-cv-item-main strong{display:block;font-size:.95rem;}
    .cm-cv-item-sub{display:block;font-size:.85rem;color:var(--ink2,#3A3F4A);}
    .cm-cv-item-dates{display:block;font-size:.78rem;color:var(--ink3,#7A8090);margin-top:.15rem;}
    .cm-cv-item-actions{display:flex;gap:.4rem;align-items:flex-start;flex-shrink:0;}
    .cm-cv-item-actions button{border:1px solid var(--border,rgba(13,17,23,.12));background:#fff;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:.85rem;}
    .cm-cv-form{margin-top:.75rem;padding:1.25rem;background:var(--cream,#EEE9DD);border-radius:10px;}
    .cm-cv-form-hidden{display:none;}
    @media (max-width:700px){ .cm-cv-lang-grid{grid-template-columns:1fr;} }
    ';
}
