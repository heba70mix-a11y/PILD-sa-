<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 34. BOOK STORE — القطاع ← المجال ← الكتاب، وكل كتاب مربوط بمنتج ووكوميرس
// ------------------------------------------------------------
// بند جديد في البلاجن بدل ما نضيف كتاب فى بوست عادي ونربطه بمنتج يدوي.
// بيستخدم نفس فكرة التصنيف الموجودة بالفعل (سكتور إكسبلورر:
// Sector -> Domain -> Track -> Program) لكن مبسّطة لمستوين بس:
//   Sector (نفس الـ CPT 'sector' الموجود) -> Domain (نفس الـ CPT 'domain')
//   -> Book (CPT جديد 'store_book').
//
// كل كتاب (store_book) بيتربط بمجال (book_domain، post_object -> domain)
// بنفس أسلوب track_domain/domain_sector الموجود، وبيتربط بمنتج ووكوميرس
// (book_product، post_object -> product).
//
// آلية فتح المحتوى بعد الشراء مش جديدة — بنعيد استخدام نفس الآلية
// المستخدمة حالياً للكتب اللي بتتضاف كبوستات (pild_user_purchased_
// product_linked_to_post() في includes/02-helpers.php):
//   - على البوست (الكتاب): ميتا 'prwc_products' = آي دي المنتج
//     (بيستخدمها "Page Restrict for WooCommerce" اللي شغال بالفعل).
//   - على المنتج: حقل ACF 'product_book_url' = رابط صفحة الكتاب
//     (نفس الحقل اللي بيستخدمه Dashboard "مكتبتي" حالياً في
//     06-dashboard-solo.php / pildcm_get_member_purchased_products()).
// يعني أي كتاب يتعمل من هنا بيظهر تلقائي في مكتبة العميل بعد الشراء
// من غير أي تعديل تاني في أي ملف موجود.
//
// الاستيراد من إكسيل (34.6 تحت) بيعمل كل حاجة مرة واحدة من ملف واحد:
// القطاع والمجال ليهم كود ثابت (زي أي استيراد تاني في البلاجن) عشان
// إعادة الرفع يحدّث بدل ما يكرر، وبيتعمل بوست الكتاب ومنتج الووكوميرس
// ويتربطوا ببعض — بالظبط زي ما اتطلب. تصنيف الووكوميرس هرمي: القطاع
// كاتوجري رئيسي والمجال كاتوجري فرعي تحته (34.6.2 تحت).
//
// غلاف كرت المنتج: أيقونة (فوق) + عنوان رئيسي + عنوان فرعي (تحته) +
// اسم "Pild" (تحت في الآخر) — كل ده بياخد بياناته من أعمدة الإكسيل
// مباشرة (مش باشتقاق تلقائي من وصف المنتج زي الإصدار القديم). لو فيه
// رابط صورة، بتبقى خلفية وراء العناصر دي بدل الخلفية الخضرا الزخرفية.
//
// صفحة الكتاب بعد الشراء: لو فيه "رابط محتوى الكتاب"، بيتعرض جوه
// الصفحة كـ iframe بدل المحتوى النصي القديم.
// ============================================================


// ============================================================
// 34.1 — CPT: store_book
// ============================================================
add_action('init', 'pild_register_store_book_cpt');
function pild_register_store_book_cpt() {
    register_post_type('store_book', [
        'labels' => [
            'name'          => 'متجر الكتب',
            'singular_name' => 'كتاب',
            'add_new'       => 'إضافة كتاب',
            'add_new_item'  => 'إضافة كتاب جديد',
            'edit_item'     => 'تعديل الكتاب',
            'all_items'     => 'كل الكتب',
        ],
        'public'        => true,
        'show_ui'       => true,
        // الرابط بقى /digital-library/اسم-الكتاب/ بدل /store_book/اسم-الكتاب/
        // (وبنفس الاسم في اللغتين — Polylang بيحط بادئة اللغة /ar/ أو /en/
        // قبله زي أي رابط تاني، مش محتاجين رابط مختلف لكل لغة).
        'has_archive'   => 'digital-library',
        'rewrite'       => ['slug' => 'digital-library', 'with_front' => false],
        'show_in_rest'  => true,
        'supports'      => ['title', 'editor', 'thumbnail', 'excerpt'],
        'menu_icon'     => 'dashicons-book-alt',
        'menu_position' => 11,
    ]);

    // CPT جديد مُضاف من غير إعادة تفعيل البلاجن -> لازم نعمل flush مرة واحدة
    // عشان رابط الكتاب والأرشيف يشتغلوا من غير ما الأدمن يروح يحفظ صفحة
    // الروابط الثابتة يدوي. بيستخدم نفس آلية pild_flush_needed الموجودة
    // بالفعل في pild-unified.php (بتتنفذ عند init بريوريتي 20).
    if (!get_option('pild_bookstore_registered_v1')) {
        update_option('pild_flush_needed', 1);
        update_option('pild_bookstore_registered_v1', 1);
    }
    // نفس الفكرة، بس لتغيير الـ slug بعد ما كان مسجل قبل كده بـ /store_book/ —
    // لازم flush تاني وإلا الروابط الجديدة هتفضل تدي 404/503 لحد ما حد
    // يحفظ صفحة "الروابط الثابتة" يدوي من الأدمن.
    if (!get_option('pild_bookstore_slug_digital_library_v1')) {
        update_option('pild_flush_needed', 1);
        update_option('pild_bookstore_slug_digital_library_v1', 1);
    }
}

// ============================================================
// أي رابط قديم بصيغة /store_book/اسم-الكتاب/ (قبل تغيير الـ slug فوق)
// بيتحول 301 لنفس الكتاب على /digital-library/اسم-الكتاب/ — بنفس أسلوب
// pild_redirect_old_slugs() الموجود في pild-unified.php بالظبط
// (lesson->playbook / exam->assessment)، بس بيراعي بادئة اللغة اللي
// Polylang بيحطها (/ar/ أو /en/) قبل الاسم القديم.
// ============================================================
add_action('template_redirect', 'pild_bookstore_redirect_old_slug');
function pild_bookstore_redirect_old_slug() {
    if (!is_404()) return;
    $path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    if ($path === '') return;

    $segments    = explode('/', $path);
    $lang_prefix = '';
    if (function_exists('pll_languages_list') && !empty($segments[0])
        && in_array($segments[0], pll_languages_list(), true)) {
        $lang_prefix = array_shift($segments) . '/';
    }
    $rest_path = implode('/', $segments);

    if (strpos($rest_path, 'store_book/') !== 0) return;
    $slug = trim(substr($rest_path, strlen('store_book/')), '/');
    if ($slug === '') return;

    if (get_page_by_path($slug, OBJECT, 'store_book')) {
        wp_safe_redirect(home_url('/' . $lang_prefix . 'digital-library/' . $slug . '/'), 301);
        exit;
    }
}

// ============================================================
// ترحيل لمرة واحدة: الكتب اللي اتعملت قبل إضافة
// pild_bookstore_sync_bilingual_prwc() فوق كانت اتحفظت بميتا
// prwc_products = منتج نسختها هي بس (مش الاتنين مع بعض) — يعني عميل
// اشترى النسخة العربية وفتح رابط "Read in English" من الداشبورد كان
// بيتقفل عليه برسالة "اشترِ المنتج ده" لأن PRWC شايف إن المنتج
// الإنجليزي مش من ضمن مشترياته. الكود ده بيعيد كتابة prwc_products
// لكل الكتب الموجودة بالفعل مرة واحدة بس (زي pild_bookstore_registered_v1
// فوق بالظبط)، من غير ما يحتاج الأدمن يعيد رفع ملف الإكسيل.
// ============================================================
add_action('init', 'pild_bookstore_backfill_bilingual_prwc', 25);
function pild_bookstore_backfill_bilingual_prwc() {
    if (get_option('pild_bookstore_bilingual_prwc_v1')) return;
    if (!function_exists('get_field')) return;

    $books = get_posts([
        'post_type'      => 'store_book',
        'posts_per_page' => -1,
        'post_status'    => 'any',
        'fields'         => 'ids',
        'suppress_filters' => true,
    ]);
    $done_groups = [];
    foreach ($books as $book_id) {
        $group_key = function_exists('pild_bilingual_group_key') ? pild_bilingual_group_key($book_id) : $book_id;
        if (isset($done_groups[$group_key])) continue;
        $done_groups[$group_key] = true;
        pild_bookstore_sync_bilingual_prwc($book_id);
    }

    update_option('pild_bookstore_bilingual_prwc_v1', 1);
}


// ============================================================
// ترحيل لمرة واحدة: الكتب اللي اتعملت قبل إضافة sideload الأيقونة فوق
// (pild_bookstore_sideload_icon) كانت مخزّنة برابط خارجي مباشر في
// pild_book_icon — وده اللي ظاهر مكسور في كروت المتجر. الكود ده بيمرّ
// على كل الكتب الموجودة بالفعل مرة واحدة بس، وبيحمّل نفس الرابط على
// مكتبة الميديا بتاعتنا ويستبدله، من غير ما يحتاج الأدمن يعيد رفع ملف
// الإكسيل تاني.
// ============================================================
add_action('init', 'pild_bookstore_backfill_icons', 25);
function pild_bookstore_backfill_icons() {
    if (get_option('pild_bookstore_icon_sideload_v1')) return;
    if (!function_exists('media_sideload_image')) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    $books = get_posts([
        'post_type'         => 'store_book',
        'posts_per_page'    => -1,
        'post_status'       => 'any',
        'fields'            => 'ids',
        'suppress_filters'  => true,
    ]);
    foreach ($books as $book_id) {
        $icon = get_post_meta($book_id, 'pild_book_icon', true);
        if ($icon === '') continue;
        // لو already اتحملت قبل كده (عندها pild_book_icon_source) سيبها —
        // ده بس للروابط الخارجية القديمة اللي لسه من غير sideload.
        if (get_post_meta($book_id, 'pild_book_icon_source', true) !== '') continue;

        $local_icon = pild_bookstore_sideload_icon($icon);
        if ($local_icon !== '') {
            update_post_meta($book_id, 'pild_book_icon', $local_icon);
            update_post_meta($book_id, 'pild_book_icon_source', $icon);
        }
    }

    update_option('pild_bookstore_icon_sideload_v1', 1);
}

// ============================================================
// 34.2 — ACF: تصنيف الكتاب (المجال) + المنتج المرتبط
// ============================================================
add_action('acf/include_fields', 'pild_bookstore_acf_fields');
function pild_bookstore_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'    => 'group_book_classification',
        'title'  => 'تصنيف الكتاب والمنتج المرتبط',
        'fields' => [
            [
                'key'           => 'field_book_domain',
                'label'         => 'المجال (Practice Area)',
                'name'          => 'book_domain',
                'type'          => 'post_object',
                'post_type'     => ['domain'],
                'return_format' => 'id',
                'required'      => 1,
                'instructions'  => 'القطاع بيتحدد تلقائي من المجال اللي هتختاره هنا (كل مجال أصلاً مربوط بقطاع).',
            ],
            [
                'key'           => 'field_book_product',
                'label'         => 'منتج الووكوميرس المرتبط',
                'name'          => 'book_product',
                'type'          => 'post_object',
                'post_type'     => ['product'],
                'return_format' => 'id',
                'required'      => 0,
                'instructions'  => 'اللي هيشتري المنتج ده هيقدر يفتح صفحة الكتاب دي تلقائي. لو عندك عدد كبير من الكتب، الأسهل إنك تستخدم "استيراد متجر الكتب" تحت — بيعمل المنتج ويربطه لوحده.',
            ],
        ],
        'location' => [[['param' => 'post_type', 'operator' => '==', 'value' => 'store_book']]],
    ]);
}

// عند حفظ الكتاب من الأدمن: نزامن الربط في الاتجاهين (نفس الآلية
// المستخدمة للكتب-كبوستات القديمة، لكن تلقائي بدل اليدوي).
add_action('acf/save_post', 'pild_bookstore_sync_product_link', 20);
function pild_bookstore_sync_product_link($post_id) {
    if (get_post_type($post_id) !== 'store_book') return;
    pild_bookstore_link_book_to_product((int) $post_id);
}

function pild_bookstore_link_book_to_product($book_id) {
    if (!function_exists('get_field')) return;
    $product_id = (int) get_field('book_product', $book_id);

    if (!$product_id) {
        delete_post_meta($book_id, 'prwc_products');
        return;
    }

    // على المنتج: رابط صفحة الكتاب (يستخدمها Dashboard "مكتبتي" الموجود بالفعل).
    if (function_exists('update_field')) {
        update_field('product_book_url', get_permalink($book_id), $product_id);
    }

    // على البوست (الكتاب): قائمة كل منتجات النسخ اللغوية (تستخدمها
    // "Page Restrict for WooCommerce") — انظر pild_bookstore_sync_bilingual_prwc().
    pild_bookstore_sync_bilingual_prwc($book_id);

    if (function_exists('pildcm_purge_post_cache')) pildcm_purge_post_cache($book_id);
}

// ============================================================
// "Page Restrict for WooCommerce" بيقفل كل بوست كتاب بمنتجه الخاص بس
// (ميتا prwc_products على البوست) — والإضافة دي مالهاش أي فكرة عن
// Polylang ولا إن نسخة عربي/إنجليزي من نفس الكتاب مرتبطين ببعض. فلو
// العميل اشترى النسخة العربية، PRWC بيشوف إن منتج النسخة الإنجليزية
// (مختلف) مش من ضمن اللي اشتراه، ويقفل صفحة القراءة بالإنجليزي —
// حتى مع وجود كل منطق pild_user_purchased_product_linked_to_post() في
// 02-helpers.php (ده بيفتح "طبقتنا احنا" بس، PRWC بيطبق قفله هو
// بمنطقه الداخلي الخاص وبيتجاهل أي حاجة إحنا فتحناها).
//
// الحل الوحيد اللي بيشتغل مع PRWC فعلياً: نكتب على ميتا prwc_products
// نفسها (اللي PRWC بيقرأها) قائمة منتجات النسختين اللغويتين مع بعض،
// على البوستين الاتنين — عشان شراء أي نسخة يفتح PRWC مباشرة للاتنين،
// من غير ما نعتمد على أي bypass filter بتاعنا إحنا.
// ============================================================
function pild_bookstore_sync_bilingual_prwc($book_id) {
    if (!function_exists('get_field')) return;

    $ids = [$book_id];
    if (function_exists('pll_get_post_translations')) {
        $translations = pll_get_post_translations($book_id);
        if (is_array($translations)) {
            foreach ($translations as $tid) {
                $tid = (int) $tid;
                if ($tid) $ids[] = $tid;
            }
        }
    }
    $ids = array_values(array_unique($ids));

    $product_ids = [];
    foreach ($ids as $id) {
        $pid = (int) get_field('book_product', $id);
        if ($pid) $product_ids[] = $pid;
    }
    $product_ids = array_values(array_unique($product_ids));
    if (empty($product_ids)) return;

    $combined = implode(',', $product_ids);
    foreach ($ids as $id) {
        update_post_meta($id, 'prwc_products', $combined);
    }
}


// ============================================================
// 34.3 — أعمدة شاشة الأدمن (القطاع / المجال / المنتج / السعر)
// ============================================================
add_filter('manage_store_book_posts_columns', 'pild_bookstore_admin_columns');
function pild_bookstore_admin_columns($cols) {
    $new = [];
    foreach ($cols as $key => $label) {
        $new[$key] = $label;
        if ($key === 'title') {
            $new['pild_sector']  = 'القطاع';
            $new['pild_domain']  = 'المجال';
            $new['pild_product'] = 'المنتج';
            $new['pild_price']   = 'السعر';
        }
    }
    return $new;
}
add_action('manage_store_book_posts_custom_column', 'pild_bookstore_admin_column_content', 10, 2);
function pild_bookstore_admin_column_content($column, $post_id) {
    if (!in_array($column, ['pild_sector', 'pild_domain', 'pild_product', 'pild_price'], true)) return;
    if (!function_exists('get_field')) { echo '—'; return; }

    $domain_id  = (int) get_field('book_domain', $post_id);
    $product_id = (int) get_field('book_product', $post_id);

    switch ($column) {
        case 'pild_domain':
            echo $domain_id ? esc_html(get_the_title($domain_id)) : '—';
            break;
        case 'pild_sector':
            $sector_id = $domain_id ? (int) get_field('domain_sector', $domain_id) : 0;
            echo $sector_id ? esc_html(get_the_title($sector_id)) : '—';
            break;
        case 'pild_product':
            if ($product_id) {
                echo '<a href="' . esc_url(get_edit_post_link($product_id)) . '">' . esc_html(get_the_title($product_id)) . '</a>';
            } else {
                echo '<span style="color:#b32d2e;">⚠️ مفيش منتج مربوط</span>';
            }
            break;
        case 'pild_price':
            if ($product_id && function_exists('wc_get_product')) {
                $p = wc_get_product($product_id);
                echo $p ? wp_kses_post($p->get_price_html()) : '—';
            } else {
                echo '—';
            }
            break;
    }
}

// فلاتر القطاع/المجال فوق شاشة الكتب — بيعيد استخدام دوال 20-admin-filters.php
// الموجودة بالفعل (pildcm_filters_dropdown / pildcm_filters_children_ids)
// لو الملف ده محمّل، بدون أي تعديل في 20-admin-filters.php نفسه.
add_action('restrict_manage_posts', 'pild_bookstore_admin_filters', 10, 2);
function pild_bookstore_admin_filters($post_type, $which) {
    if ($post_type !== 'store_book' || $which !== 'top') return;
    if (!function_exists('pildcm_filters_dropdown')) return;
    pildcm_filters_dropdown('sector', 'pild_filter_sector', 'كل القطاعات');
    pildcm_filters_dropdown('domain', 'pild_filter_domain', 'كل المجالات');
}
add_action('pre_get_posts', 'pild_bookstore_admin_filters_apply');
function pild_bookstore_admin_filters_apply($query) {
    if (!is_admin() || !$query->is_main_query()) return;
    if ($query->get('post_type') !== 'store_book') return;

    $sector_id = !empty($_GET['pild_filter_sector']) ? (int) $_GET['pild_filter_sector'] : 0;
    $domain_id = !empty($_GET['pild_filter_domain']) ? (int) $_GET['pild_filter_domain'] : 0;
    if (!$sector_id && !$domain_id) return;

    if ($domain_id) {
        $query->set('meta_query', [['key' => 'book_domain', 'value' => $domain_id, 'compare' => '=']]);
    } elseif (function_exists('pildcm_filters_children_ids')) {
        $domain_ids = pildcm_filters_children_ids('domain', 'domain_sector', [$sector_id]);
        $query->set('meta_query', [['key' => 'book_domain', 'value' => $domain_ids, 'compare' => 'IN']]);
    }
}


// ============================================================
// ============================================================
// 34.3b — أي زائر (سواء زائر عادي أو صاحب حساب) بيفتح صفحة كتاب
// (/digital-library/اسم-الكتاب/، عربي أو إنجليزي) وهو مش مالك المنتج
// المرتبط بيه، بيتحول مباشرة (302) لصفحة "معرض الكتب" (digital-books)
// بدل ما يشوف صفحة الكتاب نفسها بأي شكل — قبل ما ووردبريس يعمل render
// لأي محتوى خالص (template_redirect بيشتغل قبل الـ loop).
//
// لو الكتاب مالوش منتج مربوط أصلاً (مفيش قفل من الأساس)، أو الزائر
// فعلاً مالك المنتج، الصفحة بتفتح عادي زي ما هي (نفس منطق
// pild_bookstore_gate_content تحت بالظبط).
// ============================================================
add_action('template_redirect', 'pild_bookstore_redirect_unowned_to_gallery');
function pild_bookstore_redirect_unowned_to_gallery() {
    if (!is_singular('store_book') || !is_main_query()) return;

    $post_id    = get_queried_object_id();
    $product_id = function_exists('get_field') ? (int) get_field('book_product', $post_id) : 0;
    if (!$product_id) return;

    $user_id = get_current_user_id();
    $owned   = $user_id && function_exists('pild_user_purchased_product_linked_to_post')
        && pild_user_purchased_product_linked_to_post($user_id, $post_id);
    if ($owned) return;

    $lang = function_exists('pll_get_post_language') ? pll_get_post_language($post_id) : null;
    wp_safe_redirect(pild_bookstore_gallery_url($lang), 302);
    exit;
}

// صفحة "معرض الكتب" — بندوّر عليها بالـ slug 'digital-books' (زي ما
// طلب العميل بالظبط: pild.org/sa/digital-books/ و pild.org/sa/ar/digital-books/)
// وبنرجّع نسخة اللغة المطلوبة لو Polylang شغال ومعاه ترجمة للصفحة دي.
// لو الصفحة لسه معمولةش (أو ملهاش ترجمة باللغة دي)، بنرجع رابط افتراضي
// بنفس الـ slug عشان الأدمن يقدر يعمل الصفحة بعدين من غير ما نكسر حاجة.
function pild_bookstore_gallery_url($lang = null) {
    $page = get_page_by_path('digital-books', OBJECT, 'page');

    if ($page && $lang && function_exists('pll_get_post')) {
        $translated_id = pll_get_post($page->ID, $lang);
        if ($translated_id) return get_permalink($translated_id);
    }
    if ($page) return get_permalink($page->ID);

    return home_url('/digital-books/');
}

// ============================================================
// 34.4 — فتح المحتوى بعد الشراء (طبقة أمان إضافية على "Page Restrict
// for WooCommerce"، بتشتغل حتى لو الإضافة دي مش مُعدّة لأنواع محتوى
// مخصصة). لو مفيش منتج مربوط أصلاً، مفيش قفل — المحتوى ظاهر عادي.
//
// لو الكتاب عنده "رابط محتوى" (pild_book_content_url — من عمود
// رابط_محتوى_الكتاب في الإكسيل)، بيتعرض جوه الصفحة كـ iframe بدل
// المحتوى النصي. لو مفيش رابط (كتب قديمة اتعملت قبل التحديث ده)،
// بيرجع لعرض $content العادي (post_content) زي الإصدار القديم بالظبط.
//
// عرض الكانفاس: الـ iframe بيتعرض "Fullscreen" (position:fixed تغطي
// كامل الشاشة 100vw × 100vh فوق أي عناصر تانية في الثيم — هيدر/فوتر/
// سايدبار)، بدل الصندوق الصغير القديم. الزرار الدائري أعلى الشاشة
// بيرجّع الزائر لصفحة الكتاب العادية (يقفل وضع القراءة).
//
// ملحوظة: الحالة "مش مالك" (locked) تحت بقت عملياً مش هتتنفذ خالص —
// pild_bookstore_redirect_unowned_to_gallery() فوق بترحّل الزائر قبل
// ما نوصل هنا أصلاً. سايباها زي ما هي كـ fallback دفاعي بس (لو حصل
// وطلب معين فوّت الـ redirect لأي سبب)، مش بتتنفذ في المسار العادي.
// ============================================================
add_filter('the_content', 'pild_bookstore_gate_content', 5);
function pild_bookstore_gate_content($content) {
    // ============================================================
    // حارس ضد التكرار اللانهائي: لو الفنكشن دي بالفعل شغالة في نفس
    // الطلب (شوف السبب الحقيقي تحت عند get_the_excerpt())، منسيبهاش
    // تنادي نفسها تاني — نرجّع $content زي ما هي عشان نكسر أي حلقة.
    // ============================================================
    static $in_progress = false;
    if ($in_progress) return $content;
    if (!is_singular('store_book') || !in_the_loop() || !is_main_query()) return $content;

    $in_progress = true;
    $result = pild_bookstore_gate_content_build($content);
    $in_progress = false;
    return $result;
}
function pild_bookstore_gate_content_build($content) {
    $post_id    = get_the_ID();
    $product_id = function_exists('get_field') ? (int) get_field('book_product', $post_id) : 0;
    if (!$product_id) return $content;

    $user_id = get_current_user_id();
    if ($user_id && function_exists('pild_user_purchased_product_linked_to_post')
        && pild_user_purchased_product_linked_to_post($user_id, $post_id)) {
        $content_url = get_post_meta($post_id, 'pild_book_content_url', true);
        if ($content_url) {
            $GLOBALS['pild_book_fullscreen_active'] = true; // wp_footer بيقرأ الفلاج ده يضيف الـ CSS
            $close_url = remove_query_arg('pild_read', get_permalink($post_id));
            return '<div class="pild-book-embed-fullscreen">'
                 . '<a href="' . esc_url($close_url) . '" class="pild-book-close" aria-label="' . esc_attr__('Close', 'pild-unified') . '">&times;</a>'
                 . '<iframe src="' . esc_url($content_url) . '" loading="lazy" allowfullscreen></iframe>'
                 . '</div>';
        }
        // كتاب قديم من غير رابط محتوى في الحقل المخصص — لكن لسه ممكن يكون
        // الأدمن حط iframe يدوي جوه محرر المحتوى نفسه (زي "The Boardroom
        // Whisper" — iframe مباشر بـ height:100vh ملصوق في محرر الوورد
        // بريس بدل حقل "رابط محتوى الكتاب"). في الحالة دي لازم يتعامل
        // معاها بالظبط زي حالة الـ content_url: تغطية كامل الشاشة
        // (position:fixed) مش الحاوية الضيقة تحت — وإلا الـ iframe هيتحط
        // جوه عمود 760px بعرض الصفحة بدل ما يملا الشاشة زي ما هو متصمم.
        if (stripos($content, '<iframe') !== false) {
            $GLOBALS['pild_book_fullscreen_active'] = true;
            $close_url = remove_query_arg('pild_read', get_permalink($post_id));
            return '<div class="pild-book-embed-fullscreen">'
                 . '<a href="' . esc_url($close_url) . '" class="pild-book-close" aria-label="' . esc_attr__('Close', 'pild-unified') . '">&times;</a>'
                 . $content
                 . '</div>';
        }

        // كتاب قديم من غير رابط محتوى ولا iframe خالص: المحتوى النصي
        // القديم زي ما هو، بس دلوقتي الصفحة كلها canvas (من غير هيدر/فوتر
        // الثيم — انظر 27-canvas-template.php) فلازم نلف العنوان والمحتوى
        // بحاوية بنفسنا عشان الصفحة متبقاش نص عاري شمال الشاشة من غير أي تنسيق.
        return '<div class="pild-book-canvas-wrap">'
             . '<h1 class="pild-book-canvas-title">' . esc_html(get_the_title($post_id)) . '</h1>'
             . '<div class="pild-book-canvas-body">' . $content . '</div>'
             . '</div>';
    }

    // ============================================================
    // السبب الحقيقي لـ 503 على أي كتاب لسه مش مشترى:
    // get_the_excerpt() لما مفيش "مقتطف" (excerpt) متحطوط يدوي على
    // البوست (وده حال كل الكتب المستوردة من الإكسيل — الاستيراد بيحط
    // القيمة في post_content بس، مش post_excerpt) بترجع تلقائي لـ
    // wp_trim_excerpt() جوه ووردبريس، واللي بدورها بتعمل:
    //   apply_filters('the_content', get_the_content(...))
    // يعني بتنادي فلتر 'the_content' تاني من جوه نفسه — وإحنا مسجلين
    // على نفس الفلتر ده (pild_bookstore_gate_content فوق) — فبترجع
    // تنفّذ نفس الكود تاني، تنادي get_the_excerpt() تاني، وهكذا تكرار
    // لا نهائي (infinite recursion) لحد ما الـ PHP process يفضي
    // (memory/stack limit) وسيرفر الاستضافة بيرجّع صفحة "503 Service
    // Unavailable" العامة بتاعته بدل الصفحة. ده بيحصل بس في الحالة دي
    // (كتاب مقفول لسه مش مشترى) لأن حالة "مالك الكتاب" فوق بترجع
    // مباشرة من غير ما تنادي get_the_excerpt() خالص.
    //
    // الحل: نبني نص المقتطف إحنا بنفسنا من raw post_content مباشرة
    // (wp_trim_words + wp_strip_all_tags) من غير ما نعدي على فلتر
    // the_content تاني خالص.
    // ============================================================
    $post    = get_post($post_id);
    $excerpt = $post ? trim((string) $post->post_excerpt) : '';
    if ($excerpt === '' && $post) {
        $excerpt = wp_trim_words(wp_strip_all_tags($post->post_content), 40, '…');
    }
    $buy_url = get_permalink($product_id);

    $html = '<div class="pild-book-canvas-wrap">';
    $html .= '<h1 class="pild-book-canvas-title">' . esc_html(get_the_title($post_id)) . '</h1>';
    $html .= '<div class="pild-book-locked" style="padding:24px;border:1px solid #e2e2e2;border-radius:8px;background:#fafafa;">';
    if ($excerpt) $html .= '<p>' . esc_html($excerpt) . '</p>';
    $html .= '<p><a class="button pild-btn-primary" href="' . esc_url($buy_url) . '">'
           . esc_html__('اشترِ الكتاب لفتح المحتوى كاملاً', 'pild-unified') . '</a></p>';
    $html .= '</div></div>';
    return $html;
}

// عرض الـ canvas للحالتين اللي مش fullscreen-iframe (كتاب مقفول، أو كتاب
// قديم من غير رابط محتوى) — لأن قالب canvas.php بيعرض the_content() لوحدها
// من غير أي حاوية/عرض أقصى من الثيم، فلازم نديها الحد الأقصى للعرض والمسافة
// من نفسنا هنا، وإلا هيبقى المحتوى نص عاري ملزّق في أول الشاشة.
add_action('wp_head', 'pild_bookstore_canvas_wrap_styles', 999);
function pild_bookstore_canvas_wrap_styles() {
    if (!is_singular('store_book')) return;
    ?>
    <style>
        .pild-book-canvas-wrap {
            max-width: 760px; margin: 3.5rem auto; padding: 0 1.5rem 3rem;
            font-family: "DM Sans", sans-serif; color: #1a1a1a;
        }
        .pild-book-canvas-title {
            font-family: "DM Serif Display", serif; font-size: 2rem;
            margin: 0 0 1.5rem; line-height: 1.25;
        }
        .pild-book-canvas-body { font-size: 1rem; line-height: 1.8; }
    </style>
    <?php
}

// الـ CSS بتاع وضع القراءة الكانفاس (فقط لما الفلاج فوق يتفعّل، يعني في
// نفس التحميل اللي فيه الـ iframe فعلاً اتطبع). بيغطي كامل الشاشة
// ويشيل السكرول من الصفحة عشان يبقى إحساسه Canvas حقيقي مش صندوق جوه الصفحة.
add_action('wp_head', 'pild_bookstore_fullscreen_styles', 999);
function pild_bookstore_fullscreen_styles() {
    if (!is_singular('store_book')) return;
    ?>
    <style>
        html.pild-reading,
        html.pild-reading body { height: 100% !important; margin: 0 !important; overflow: hidden !important; }
        .pild-book-embed-fullscreen {
            position: fixed; inset: 0; width: 100vw; height: 100vh;
            z-index: 99999; background: #000;
        }
        .pild-book-embed-fullscreen iframe {
            position: absolute; inset: 0; width: 100%; height: 100%; border: 0; display: block;
        }
        .pild-book-embed-fullscreen .pild-book-close {
            position: fixed; top: 16px; inset-inline-end: 16px; z-index: 100000;
            width: 40px; height: 40px; border-radius: 50%;
            background: rgba(0,0,0,.55); color: #fff; text-decoration: none;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px; line-height: 1; font-family: sans-serif;
        }
        .pild-book-embed-fullscreen .pild-book-close:hover { background: rgba(0,0,0,.8); color: #fff; }
    </style>
    <?php
}

// إضافة كلاس على <html> فقط لو الـ iframe فعلاً اتطبع في نفس الطلب ده
// (يعني العميل مالك الكتاب وعنده رابط محتوى) — عشان الصفحات التانية
// (كتاب مقفول، أو كتاب قديم بدون رابط محتوى) تفضل عادية زي ما هي.
// استخدمنا سطر JS بسيط في الفوتر بدل فلتر على وسم <html> نفسه عشان
// نضمن التوافق مع أي ثيم (مافيش خطر تعارض مع كلاسات الثيم على <html>).
add_action('wp_footer', 'pild_bookstore_fullscreen_class_script', 999);
function pild_bookstore_fullscreen_class_script() {
    if (empty($GLOBALS['pild_book_fullscreen_active'])) return;
    echo '<script>document.documentElement.classList.add("pild-reading");</script>';
}


// ============================================================
// 34.5 — واجهة المتجر العامة: [pild_book_store]
// سايدبار أكورديون (القطاع -> المجال) + شبكة كروت: غلاف أخضر بإطار
// زخرفي (عنوان الكتاب / خط فاصل ذهبي / عنوان فرعي مأخوذ من الوصف
// القصير لمنتج الووكوميرس / "Pild" كمؤلف)، فتح مباشر لو العميل مالك
// الكتاب، وإلا زرار شراء يوديه لصفحة المنتج.
// ============================================================
add_shortcode('pild_book_store', 'pild_bookstore_shortcode');
function pild_bookstore_shortcode() {
    $lang = null;
    $queried_id = get_queried_object_id();
    if (function_exists('pll_get_post_language') && $queried_id) $lang = pll_get_post_language($queried_id);
    if (!$lang && function_exists('pll_current_language')) $lang = pll_current_language();
    if (!$lang) $lang = function_exists('pll_default_language') ? pll_default_language() : 'ar';
    $is_en = ($lang === 'en');
    $dir   = $is_en ? 'ltr' : 'rtl';

    $books_query_args = [
        'post_type'      => 'store_book',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC',
    ];
    // كل كتاب له نسخة عربي ونسخة إنجليزي منفصلة (بوستين مربوطين كترجمة)،
    // فلازم نفلتر بلغة الصفحة الحالية وإلا هيظهروا مخلوطين مع بعض.
    // ملحوظة: get_posts() بتحط suppress_filters=true افتراضياً، يعني
    // فلتر Polylang التلقائي (pre_get_posts) مش بيشتغل هنا من غير ما
    // نبعت 'lang' صراحةً زي تحت.
    if (function_exists('pll_languages_list')) $books_query_args['lang'] = $lang;
    $books = get_posts($books_query_args);

    $t = $is_en ? [
        'browse' => 'Browse by sector', 'all' => 'All', 'buy' => 'Buy Now', 'open' => 'Open the Book',
        'details' => 'Details', 'empty' => 'No books available yet.', 'noneCat' => 'No books in this category yet.',
        'author' => 'Pild',
    ] : [
        'browse' => 'تصفح حسب القطاع', 'all' => 'كل الكتب', 'buy' => 'اشترِ الآن', 'open' => 'افتح الكتاب',
        'details' => 'التفاصيل', 'empty' => 'لا توجد كتب متاحة حالياً.', 'noneCat' => 'لا توجد كتب في هذا التصنيف بعد.',
        'author' => 'Pild',
    ];

    if (empty($books)) return '<p>' . esc_html($t['empty']) . '</p>';

    $tree    = [];
    $user_id = get_current_user_id();

    foreach ($books as $book) {
        $domain_id = function_exists('get_field') ? (int) get_field('book_domain', $book->ID) : 0;
        if (!$domain_id) continue;
        $sector_id = (int) get_field('domain_sector', $domain_id);
        if (!$sector_id) continue;

        if (!isset($tree[$sector_id])) {
            $tree[$sector_id] = ['title' => get_the_title($sector_id), 'domains' => []];
        }
        if (!isset($tree[$sector_id]['domains'][$domain_id])) {
            $tree[$sector_id]['domains'][$domain_id] = ['title' => get_the_title($domain_id), 'books' => []];
        }

        $product_id = (int) get_field('book_product', $book->ID);
        $owned = $user_id && $product_id && function_exists('pild_user_purchased_product_linked_to_post')
            && pild_user_purchased_product_linked_to_post($user_id, $book->ID);

        $price_html = '';
        if ($product_id && function_exists('wc_get_product')) {
            $p = wc_get_product($product_id);
            if ($p) $price_html = $p->get_price_html();
        }

        $tree[$sector_id]['domains'][$domain_id]['books'][] = [
            'sector_id'  => $sector_id,
            'domain_id'  => $domain_id,
            'title'      => get_the_title($book),
            // العنوان الفرعي والأيقونة بيجوا مباشرة من أعمدة الإكسيل
            // (عنوان_فرعي / أيقونة_الغلاف) — اتخزنوا كـ post meta وقت
            // الاستيراد، مش مشتقين من وصف المنتج.
            'subtitle'   => get_post_meta($book->ID, 'pild_book_subtitle', true),
            'icon'       => get_post_meta($book->ID, 'pild_book_icon', true),
            'permalink'  => get_permalink($book),
            'thumb'      => get_the_post_thumbnail_url($book->ID, 'large'),
            'cover_bg'   => pild_bookstore_domain_cover_bg($domain_id),
            'product_id' => $product_id,
            'price_html' => $price_html,
            'owned'      => $owned,
        ];
    }

    if (empty($tree)) return '<p>' . esc_html($t['empty']) . '</p>';

    $flat_books = [];
    foreach ($tree as $sector) foreach ($sector['domains'] as $domain) foreach ($domain['books'] as $b) $flat_books[] = $b;

    ob_start();
    static $printed_style = false;
    if (!$printed_style) {
        $printed_style = true;
        ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=El+Messiri:wght@500;600;700&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
#pild-books-app{
  --ink:#0C1018;--ink-soft:#3A3428;--paper:#F2ECDD;--paper-raised:#FBF8F0;
  --brass:#B9862F;--brass-soft:#D8AE5E;--emerald:#1E6F5C;--emerald-deep:#154F42;
  --slate:#6B6350;--line:#D8C9A3;
}
#pild-books-app,#pild-books-app *,#pild-books-app *::before,#pild-books-app *::after{box-sizing:border-box;margin:0;padding:0;}
#pild-books-app{font-family:'IBM Plex Sans Arabic',sans-serif;background:var(--paper);color:var(--ink);-webkit-font-smoothing:antialiased;line-height:1.5;direction:<?php echo esc_attr($dir); ?>;text-align:start;}
#pild-books-app a,#pild-books-app a:link,#pild-books-app a:visited{color:inherit;text-decoration:none;}
#pild-books-app img{max-width:100%;display:block;}
#pild-books-app .serif{font-family:'El Messiri',serif!important;font-weight:600!important;}

#pild-books-app .pba-wrap{max-width:1200px;margin:0 auto;padding:40px 24px 90px;}
#pild-books-app .pba-grid{display:grid;grid-template-columns:270px 1fr;gap:44px;align-items:start;}
@media (max-width:860px){ #pild-books-app .pba-grid{grid-template-columns:1fr;} }

#pild-books-app .pba-aside{position:sticky;top:20px;}
#pild-books-app .pba-aside-title{font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--slate);margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--line);}
#pild-books-app .pba-all,#pild-books-app .pba-sector summary,#pild-books-app .pba-domain-item{
  display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 14px;border-radius:2px;
  font-size:14.5px;color:var(--ink-soft);cursor:pointer;border-inline-start:3px solid transparent;
  transition:background .15s,color .15s,border-color .15s;list-style:none;
}
#pild-books-app .pba-sector{border-bottom:1px solid var(--line);}
#pild-books-app .pba-sector:first-of-type{border-top:1px solid var(--line);}
#pild-books-app .pba-sector summary::-webkit-details-marker{display:none;}
#pild-books-app .pba-all:hover,#pild-books-app .pba-sector summary:hover,#pild-books-app .pba-domain-item:hover{background:var(--paper-raised);}
#pild-books-app .pba-all.pba-active,#pild-books-app .pba-sector.pba-active>summary,#pild-books-app .pba-domain-item.pba-active{
  background:var(--paper-raised);border-inline-start-color:var(--brass);color:var(--ink);font-weight:600;
}
#pild-books-app .pba-domain-item.pba-active{background:rgba(30,111,92,.08);border-inline-start-color:var(--emerald);color:var(--emerald-deep);}
#pild-books-app .pba-count{font-size:12px;color:var(--slate);background:var(--line);padding:2px 8px;border-radius:2px;}
#pild-books-app .pba-all.pba-active .pba-count,#pild-books-app .pba-sector.pba-active>summary .pba-count{background:var(--brass);color:#fff;}
#pild-books-app .pba-domain-item.pba-active .pba-count{background:var(--emerald);color:#fff;}
#pild-books-app .pba-domains{list-style:none;margin-top:2px;padding:4px 0 10px;display:flex;flex-direction:column;gap:1px;}
#pild-books-app .pba-domain-item{font-size:13.5px;margin-inline-start:14px;border-inline-start-width:2px;}
#pild-books-app .pba-plus{font-size:16px;color:var(--brass);transition:transform .2s;flex:none;}
#pild-books-app .pba-sector[open]>summary .pba-plus{transform:rotate(45deg);}

#pild-books-app .pba-status{font-size:13.5px;color:var(--slate);margin-bottom:22px;}
#pild-books-app .pba-book-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:22px;}
#pild-books-app .pba-card{background:var(--paper-raised);border:1px solid var(--line);border-radius:6px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .15s,transform .15s;}
#pild-books-app .pba-card:hover{box-shadow:0 8px 20px rgba(12,16,24,.1);transform:translateY(-2px);}
#pild-books-app .pba-cover{aspect-ratio:3/4;width:100%;background:linear-gradient(160deg,var(--emerald),var(--emerald-deep));background-size:cover;background-position:center;display:flex;align-items:center;justify-content:center;padding:22px;text-align:center;position:relative;overflow:hidden;}
#pild-books-app .pba-cover-photo-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(12,16,24,.2),rgba(12,16,24,.6));}
#pild-books-app .pba-cover-frame{position:absolute;inset:14px;border:1px solid rgba(216,174,94,.55);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:20px;}
#pild-books-app .pba-cover-frame::before,#pild-books-app .pba-cover-frame::after{content:'';position:absolute;width:16px;height:16px;border:1px solid var(--brass-soft);}
#pild-books-app .pba-cover-frame::before{inset-block-start:-1px;inset-inline-start:-1px;border-inline-end:none;border-block-end:none;}
#pild-books-app .pba-cover-frame::after{inset-block-end:-1px;inset-inline-end:-1px;border-inline-start:none;border-block-start:none;}
#pild-books-app .pba-cover-icon{width:32px;height:32px;object-fit:contain;filter:drop-shadow(0 1px 3px rgba(0,0,0,.4));}
#pild-books-app .pba-cover-icon-emoji{width:auto;height:auto;font-size:30px;line-height:1;display:block;}
#pild-books-app .pba-cover-title{font-family:'El Messiri',serif;font-weight:600;font-size:1.1rem;line-height:1.5;letter-spacing:.03em;color:var(--brass-soft);text-shadow:0 1px 3px rgba(0,0,0,.35);}
#pild-books-app .pba-cover-goldline{width:44px;height:1px;background:var(--brass-soft);opacity:.85;}
#pild-books-app .pba-cover-subtitle{font-weight:400;font-size:.72rem;line-height:1.5;color:rgba(242,236,221,.75);}
#pild-books-app .pba-cover-byline{position:absolute;inset-inline-start:0;inset-inline-end:0;bottom:18px;text-align:center;font-family:'El Messiri',serif;font-style:italic;font-weight:500;font-size:.78rem;letter-spacing:.06em;color:rgba(242,236,221,.75);}
#pild-books-app .pba-body{padding:16px 16px 18px;display:flex;flex-direction:column;gap:8px;flex:1;}
#pild-books-app .pba-book-title{font-size:15px;line-height:1.4;font-weight:600;color:var(--ink);}
#pild-books-app .pba-price{margin-top:auto;font-weight:600;color:var(--brass);font-size:14px;}
#pild-books-app .pba-btn{display:block;text-align:center;padding:9px;border-radius:4px;font-size:13.5px;font-weight:600;background:var(--ink);color:#fff!important;margin-top:4px;}
#pild-books-app .pba-btn:hover{background:var(--emerald);}
#pild-books-app .pba-hide{display:none!important;}
#pild-books-app .pba-empty{grid-column:1/-1;padding:60px 20px;text-align:center;color:var(--slate);}
</style>
        <?php
    }
    ?>
    <div id="pild-books-app" lang="<?php echo esc_attr($lang); ?>">
      <div class="pba-wrap">
        <div class="pba-grid">
          <aside class="pba-aside">
            <div class="pba-aside-title"><?php echo esc_html($t['browse']); ?></div>
            <div class="pba-all pba-active" data-sector="0" data-domain="0"><span><?php echo esc_html($t['all']); ?></span><span class="pba-count"><?php echo count($flat_books); ?></span></div>
            <?php foreach ($tree as $sector_id => $sector):
                $sector_count = 0; foreach ($sector['domains'] as $d) $sector_count += count($d['books']); ?>
              <details class="pba-sector">
                <summary data-sector="<?php echo (int) $sector_id; ?>" data-domain="0">
                  <span style="display:flex;align-items:center;gap:10px;"><span class="pba-plus">+</span><span class="serif"><?php echo esc_html($sector['title']); ?></span></span>
                  <span class="pba-count"><?php echo (int) $sector_count; ?></span>
                </summary>
                <ul class="pba-domains">
                  <?php foreach ($sector['domains'] as $domain_id => $domain): ?>
                    <li class="pba-domain-item" data-sector="<?php echo (int) $sector_id; ?>" data-domain="<?php echo (int) $domain_id; ?>">
                      <span><?php echo esc_html($domain['title']); ?></span>
                      <span class="pba-count"><?php echo count($domain['books']); ?></span>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </details>
            <?php endforeach; ?>
          </aside>

          <div>
            <div class="pba-status" id="pbaStatus"></div>
            <div class="pba-book-grid" id="pbaGrid">
              <?php foreach ($flat_books as $b): ?>
                <div class="pba-card" data-sector="<?php echo (int) $b['sector_id']; ?>" data-domain="<?php echo (int) $b['domain_id']; ?>">
                  <div class="pba-cover"<?php if ($b['thumb']): ?> style="background-image:url('<?php echo esc_url($b['thumb']); ?>')"<?php elseif ($b['cover_bg']): ?> style="background:<?php echo esc_attr($b['cover_bg']); ?>"<?php endif; ?>>
                    <?php if ($b['thumb']): ?><div class="pba-cover-photo-overlay"></div><?php endif; ?>
                    <div class="pba-cover-frame">
                      <?php if ($b['icon'] !== ''): ?>
                        <?php if (preg_match('~^https?://~i', $b['icon'])): ?>
                          <img class="pba-cover-icon" src="<?php echo esc_url($b['icon']); ?>" alt="">
                        <?php else: ?>
                          <span class="pba-cover-icon pba-cover-icon-emoji"><?php echo esc_html($b['icon']); ?></span>
                        <?php endif; ?>
                      <?php endif; ?>
                      <span class="pba-cover-title"><?php echo esc_html($b['title']); ?></span>
                      <?php if ($b['subtitle'] !== ''): ?>
                        <span class="pba-cover-goldline"></span>
                        <span class="pba-cover-subtitle"><?php echo esc_html($b['subtitle']); ?></span>
                      <?php endif; ?>
                    </div>
                    <span class="pba-cover-byline"><?php echo esc_html($t['author']); ?></span>
                  </div>
                  <div class="pba-body">
                    <div class="pba-book-title"><?php echo esc_html($b['title']); ?></div>
                    <?php if ($b['owned']): ?>
                      <a class="pba-btn" href="<?php echo esc_url($b['permalink']); ?>"><?php echo esc_html($t['open']); ?></a>
                    <?php elseif ($b['product_id']): ?>
                      <div class="pba-price"><?php echo wp_kses_post($b['price_html']); ?></div>
                      <a class="pba-btn" href="<?php echo esc_url(get_permalink($b['product_id'])); ?>"><?php echo esc_html($t['buy']); ?></a>
                    <?php else: ?>
                      <a class="pba-btn" href="<?php echo esc_url($b['permalink']); ?>"><?php echo esc_html($t['details']); ?></a>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
    (function(){
      var app = document.getElementById('pild-books-app');
      if (!app || app.dataset.pbaBound) return;
      app.dataset.pbaBound = '1';

      var cards  = app.querySelectorAll('.pba-card');
      var status = document.getElementById('pbaStatus');
      var noneCatText = <?php echo wp_json_encode($t['noneCat']); ?>;

      function setActive(sector, domain){
        app.querySelectorAll('.pba-all,.pba-sector,.pba-domain-item').forEach(function(el){ el.classList.remove('pba-active'); });
        if (sector === 0){ app.querySelector('.pba-all').classList.add('pba-active'); return; }
        var det = app.querySelector('.pba-sector summary[data-sector="'+sector+'"]');
        if (det) det.closest('.pba-sector').classList.add('pba-active');
        if (domain){
          var li = app.querySelector('.pba-domain-item[data-domain="'+domain+'"]');
          if (li) li.classList.add('pba-active');
        }
      }

      function filter(sector, domain){
        var shown = 0;
        cards.forEach(function(card){
          var match = sector === 0 || (domain ? Number(card.dataset.domain) === domain : Number(card.dataset.sector) === sector);
          card.classList.toggle('pba-hide', !match);
          if (match) shown++;
        });
        status.textContent = shown ? '' : noneCatText;
        setActive(sector, domain);
      }

      app.querySelector('.pba-all').addEventListener('click', function(){
        app.querySelectorAll('.pba-sector').forEach(function(d){ d.open = false; });
        filter(0, 0);
      });

      app.querySelectorAll('.pba-sector summary').forEach(function(sum){
        sum.addEventListener('click', function(){
          setTimeout(function(){ filter(Number(sum.dataset.sector), 0); }, 0);
        });
      });

      app.querySelectorAll('.pba-domain-item').forEach(function(li){
        li.addEventListener('click', function(e){
          e.stopPropagation();
          filter(Number(li.dataset.sector), Number(li.dataset.domain));
        });
      });
    })();
    </script>
    <?php
    return ob_get_clean();
}


// ============================================================
// 34.6 — استيراد متجر الكتب من إكسيل
// ------------------------------------------------------------
// ملف .xlsx شيت واحد اسمه "Bookstore"، صف واحد = كتاب واحد. القطاع
// والمجال ليهم كود ثابت (زي أي استيراد تاني في البلاجن، بنفس آلية
// pild_import_code) — إعادة الرفع بتحدّث بدل ما تكرر، سواء للقطاع
// والمجال أو للكتاب والمنتج. تصنيف الووكوميرس هرمي تلقائي: القطاع
// كاتوجري أب، والمجال كاتوجري ابن تحته — بيترعمل ويترابط لوحده.
//
// أعمدة الشيت "Bookstore" (٢٤ عمود):
//   كود_الكاتوجري_الرئيسي    - اختياري. كود كاتوجري الأب (المستوى الأول) اللي
//                               القطاع هيتحط تحته (زي "Playbooks - الكتب التطبيقية").
//                               لو فاضي، بيستخدم الافتراضي CAT-PLAYBOOKS
//   اسم_الكاتوجري_الرئيسي    - اسم الكاتوجري الأب (عربي). لو فاضي، بيستخدم
//                               "الكتب التطبيقية" كافتراضي
//   اسم_الكاتوجري_الرئيسي_EN - نفس الفكرة إنجليزي. لو فاضي، بيستخدم "Playbooks"
//   كود_القطاع            - كود ثابت للقطاع (للتحديث لاحقاً بدل التكرار)
//   اسم_القطاع            - اسم القطاع (عربي) = اسم الكاتوجري الرئيسي في المتجر
//   اسم_القطاع_EN         - نفس الاسم بالإنجليزي (اختياري، لازم Polylang شغّال)
//   كود_المجال            - كود ثابت للمجال
//   اسم_المجال            - اسم المجال (عربي) = اسم الكاتوجري الفرعي تحت القطاع
//   اسم_المجال_EN         - نفس الاسم بالإنجليزي (اختياري)
//   كود_الكتاب            - كود فريد للكتاب (للتحديث عند إعادة الرفع)
//   عنوان_الكتاب          - العنوان الرئيسي (عربي) — يظهر في صفحة المنتج
//                            وعلى كرت المنتج في الغلاف = اسم منتج الووكوميرس
//   عنوان_الكتاب_EN       - لو معبّى وPolylang شغّال، هيتعمل كتاب + منتج
//                            ووكوميرس إنجليزي كامل منفصل ومربوط كترجمة
//   السعر                 - رقم (سعر منتج الووكوميرس، نفسه للعربي والإنجليزي)
//   الوصف_القصير          - الوصف المختصر لمنتج الووكوميرس (عربي)
//   الوصف_القصير_EN       - نفس الفكرة إنجليزي (لو فاضية بتستخدم نص العمود العربي)
//   وصف_الكتاب            - الوصف الطويل: محتوى منتج الووكوميرس (عربي).
//                            كود/HTML جاهز — بيتخزن زي ما هو من غير أي
//                            تعديل تلقائي (من غير wpautop مثلاً)
//   وصف_الكتاب_EN         - نفس الفكرة إنجليزي (لو فاضية بتستخدم نص العمود العربي)
//   رابط_الصورة           - رابط صورة المنتج/الغلاف (عربي) — بتتحمّل كصورة
//                            مميزة لكل من بوست الكتاب ومنتج الووكوميرس العربي
//   رابط_الصورة_EN        - نفس الفكرة لكن للنسخة الإنجليزية (لو فاضية
//                            بتستخدم نفس صورة العمود العربي)
//   أيقونة_الغلاف         - رابط صورة أيقونة صغيرة، بتظهر أعلى العنوان على
//                            غلاف الكارت في المتجر (مشتركة للعربي والإنجليزي)
//   عنوان_فرعي            - العنوان الفرعي (عربي) — بيظهر على الغلاف تحت
//                            العنوان الرئيسي وخط ذهبي فاصل بينهم
//   عنوان_فرعي_EN         - نفس الفكرة إنجليزي (لو فاضية بتستخدم نص العمود العربي)
//   رابط_محتوى_الكتاب     - رابط (URL) بيتعرض جوه صفحة الكتاب كـ iframe
//                            بعد الشراء (عربي)
//   رابط_محتوى_الكتاب_EN  - نفس الفكرة للنسخة الإنجليزية
//   لون_المجال            - اختياري. كود hex (#2F5D50) للون غلاف كتب المجال. لو فاضي
//                            المجال بياخد لون تلقائي من باليتة ثابتة (34.8)
// ============================================================

add_action('admin_menu', 'pild_bookstore_import_menu');
function pild_bookstore_import_menu() {
    add_submenu_page('pild-settings', 'استيراد متجر الكتب', 'استيراد متجر الكتب',
        'manage_options', 'pild-bookstore-import', 'pild_bookstore_import_page');
}

// ── بحث عام عن بوستات نوع معين، بالاسم (case/whitespace-insensitive) ──
function pild_bookstore_get_posts_by_type($post_type) {
    static $cache = [];
    if (isset($cache[$post_type])) return $cache[$post_type];
    $cache[$post_type] = get_posts(['post_type' => $post_type, 'posts_per_page' => -1, 'post_status' => 'any']);
    return $cache[$post_type];
}
function pild_bookstore_find_existing_by_code($post_type, $code) {
    $ids = get_posts([
        'post_type' => $post_type, 'posts_per_page' => 1, 'post_status' => 'any',
        'meta_key' => 'pild_import_code', 'meta_value' => $code, 'fields' => 'ids',
    ]);
    return !empty($ids) ? (int) $ids[0] : 0;
}

// ============================================================
// 34.6.1 — القطاع/المجال: بحث بالكود الثابت (pild_import_code)، ولو
// مش موجود يتعمل. نسخة عربي دايماً + نسخة إنجليزي اختيارية مربوطة
// كترجمة (Polylang) — بنفس أسلوب 18-excel-importer.php.
// ============================================================
function pild_bookstore_find_or_create_sector(&$cache, $code, $title_ar, $title_en, $polylang_active) {
    if (isset($cache[$code])) return $cache[$code];

    $created = false;
    $ar_id = pild_bookstore_find_existing_by_code('sector', $code);
    if (!$ar_id) {
        $new_id = wp_insert_post(['post_type' => 'sector', 'post_title' => $title_ar, 'post_status' => 'publish'], true);
        if (!is_wp_error($new_id) && $new_id) { $ar_id = $new_id; $created = true; }
    } elseif (get_the_title($ar_id) !== $title_ar) {
        wp_update_post(['ID' => $ar_id, 'post_title' => $title_ar]);
    }
    if ($ar_id) {
        update_post_meta($ar_id, 'pild_import_code', $code);
        if ($polylang_active) pll_set_post_language($ar_id, 'ar');
    }

    $en_id = 0;
    if ($polylang_active && $title_en !== '') {
        $en_code = $code . '-en';
        $en_id = pild_bookstore_find_existing_by_code('sector', $en_code);
        if (!$en_id) {
            $new_en = wp_insert_post(['post_type' => 'sector', 'post_title' => $title_en, 'post_status' => 'publish'], true);
            if (!is_wp_error($new_en) && $new_en) $en_id = $new_en;
        } elseif (get_the_title($en_id) !== $title_en) {
            wp_update_post(['ID' => $en_id, 'post_title' => $title_en]);
        }
        if ($en_id) {
            update_post_meta($en_id, 'pild_import_code', $en_code);
            pll_set_post_language($en_id, 'en');
            if ($ar_id) pll_save_post_translations(['ar' => $ar_id, 'en' => $en_id]);
        }
    }

    return $cache[$code] = ['ar_id' => $ar_id, 'en_id' => $en_id, 'created' => $created];
}

function pild_bookstore_find_or_create_domain(&$cache, $code, $title_ar, $title_en, $sector, $polylang_active) {
    if (isset($cache[$code])) return $cache[$code];

    $created = false;
    $ar_id = pild_bookstore_find_existing_by_code('domain', $code);
    if (!$ar_id) {
        $new_id = wp_insert_post(['post_type' => 'domain', 'post_title' => $title_ar, 'post_status' => 'publish'], true);
        if (!is_wp_error($new_id) && $new_id) { $ar_id = $new_id; $created = true; }
    } elseif (get_the_title($ar_id) !== $title_ar) {
        wp_update_post(['ID' => $ar_id, 'post_title' => $title_ar]);
    }
    if ($ar_id) {
        update_post_meta($ar_id, 'pild_import_code', $code);
        if ($polylang_active) pll_set_post_language($ar_id, 'ar');
        if (function_exists('update_field') && $sector['ar_id']) update_field('domain_sector', $sector['ar_id'], $ar_id);
    }

    $en_id = 0;
    if ($polylang_active && $title_en !== '') {
        $en_code = $code . '-en';
        $en_id = pild_bookstore_find_existing_by_code('domain', $en_code);
        if (!$en_id) {
            $new_en = wp_insert_post(['post_type' => 'domain', 'post_title' => $title_en, 'post_status' => 'publish'], true);
            if (!is_wp_error($new_en) && $new_en) $en_id = $new_en;
        } elseif (get_the_title($en_id) !== $title_en) {
            wp_update_post(['ID' => $en_id, 'post_title' => $title_en]);
        }
        if ($en_id) {
            update_post_meta($en_id, 'pild_import_code', $en_code);
            pll_set_post_language($en_id, 'en');
            if ($sector['en_id']) update_field('domain_sector', $sector['en_id'], $en_id);
            if ($ar_id) pll_save_post_translations(['ar' => $ar_id, 'en' => $en_id]);
        }
    }

    return $cache[$code] = ['ar_id' => $ar_id, 'en_id' => $en_id, 'created' => $created];
}

// ============================================================
// 34.6.2 — تصنيف ووكوميرس هرمي أربع مستويات:
//   Playbooks / الكتب التطبيقية  (كاتوجري أب ثابت، كوده CAT-PLAYBOOKS)
//     └── القطاع  (بنفس كود_القطاع من الإكسيل)
//           └── المجال  (بنفس كود_المجال من الإكسيل)
//                 └── المنتج (الكتاب)
// كل تصنيف بيتلاقى/يتعمل بالكود (pild_import_code كـ term meta) مش
// بالاسم — عشان لو الاسم اتغيّر يوم من الأيام يتحدّث بدل ما يتكرر
// كاتوجري جديد. كل لغة عندها شجرة Terms منفصلة مربوطة كترجمة (Polylang).
// ============================================================
function pild_bookstore_find_or_create_cat_by_code($code, $name, $parent_id, $lang, $polylang_active) {
    $name = trim($name);
    if ($code === '' || $name === '' || !taxonomy_exists('product_cat')) return 0;

    $full_code = $lang === 'en' ? $code . '-en' : $code;

    // بحث مباشر في جدول termmeta بدل get_terms(): Polylang بيفلتر get_terms
    // بلغة الأدمن الحالية، فتصنيف اللغة التانية كان "بيختفي" ويرجع 0
    // (فالمجال يتعمل تحت الأب 0 = مستوى أول). الـ SQL ده مش بيتأثر بأي فلتر لغة.
    global $wpdb;
    $found_id = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT tm.term_id FROM {$wpdb->termmeta} tm
         INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = tm.term_id AND tt.taxonomy = 'product_cat'
         WHERE tm.meta_key = 'pild_import_code' AND tm.meta_value = %s LIMIT 1",
        $full_code
    ));
    if ($found_id) {
        $term = get_term($found_id, 'product_cat');
        if ($term && !is_wp_error($term)) {
            if ($term->name !== $name) {
                wp_update_term($found_id, 'product_cat', ['name' => $name]);
            }
            if ((int) $term->parent !== (int) $parent_id) {
                wp_update_term($found_id, 'product_cat', ['parent' => (int) $parent_id]);
            }
            if ($polylang_active && function_exists('pll_set_term_language')
                && (!function_exists('pll_get_term_language') || pll_get_term_language($found_id) !== $lang)) {
                pll_set_term_language($found_id, $lang);
            }
            return $found_id;
        }
    }

    $args = $parent_id ? ['parent' => (int) $parent_id] : [];
    $new = wp_insert_term($name, 'product_cat', $args);
    if (is_wp_error($new)) {
        // لو فيه تصنيف بنفس الاسم تحت نفس الأب (مثلاً اتعمل قبل كده من غير كود)،
        // نستخدمه ونوسمه بالكود بدل ما نرجع 0 ونسيب المجال من غير أب.
        $existing_id = (int) $new->get_error_data('term_exists');
        if (!$existing_id) return 0;
        update_term_meta($existing_id, 'pild_import_code', $full_code);
        if ($polylang_active && function_exists('pll_set_term_language')) {
            pll_set_term_language($existing_id, $lang);
        }
        return $existing_id;
    }
    $term_id = (int) $new['term_id'];
    update_term_meta($term_id, 'pild_import_code', $full_code);
    if ($polylang_active && function_exists('pll_set_term_language')) {
        pll_set_term_language($term_id, $lang);
    }
    return $term_id;
}

// ── كاتوجري الأب الثابت "Playbooks / الكتب التطبيقية". كوده وأسماؤه
// بييجوا من أعمدة الإكسيل (كود_الكاتوجري_الرئيسي / اسم_الكاتوجري_الرئيسي
// / اسم_الكاتوجري_الرئيسي_EN)، ولو الصف سايبها فاضية بيرجع للقيمة
// الافتراضية (CAT-PLAYBOOKS / الكتب التطبيقية / Playbooks). بيتلاقى أو
// يتعمل مرة واحدة بس لكل كود ويتكاش. ──
function pild_bookstore_find_or_create_root_cat($root_code, $root_ar, $root_en, $lang, $polylang_active) {
    static $cache = [];
    $root_code = $root_code !== '' ? $root_code : 'CAT-PLAYBOOKS';
    $root_ar   = $root_ar   !== '' ? $root_ar   : 'الكتب التطبيقية';
    $root_en   = $root_en   !== '' ? $root_en   : 'Playbooks';
    $ckey = $root_code . '|' . $lang;
    if (isset($cache[$ckey])) return $cache[$ckey];
    $name = $lang === 'en' ? $root_en : $root_ar;
    return $cache[$ckey] = pild_bookstore_find_or_create_cat_by_code($root_code, $name, 0, $lang, $polylang_active);
}

// ── يرجّع تصنيف المجال (الابن) لكل لغة، بعد ما يتأكد إن تصنيف القطاع
// (الأب) موجود تحت "Playbooks / الكتب التطبيقية" فوقه — ده اللي بيتحط
// فعلياً على المنتج. ──
function pild_bookstore_resolve_hierarchical_cats(&$cache, $root_code, $root_ar, $root_en, $sector_code, $sector_ar, $sector_en, $domain_code, $domain_ar, $domain_en, $polylang_active) {
    $key = $root_code . '|' . $sector_code . '|' . $domain_code;
    if (isset($cache[$key])) return $cache[$key];

    $root_ar_cat = pild_bookstore_find_or_create_root_cat($root_code, $root_ar, $root_en, 'ar', $polylang_active);

    $sector_ar_cat = pild_bookstore_find_or_create_cat_by_code($sector_code, $sector_ar, $root_ar_cat, 'ar', $polylang_active);
    $sector_en_cat = 0;
    if ($polylang_active) {
        $root_en_cat = pild_bookstore_find_or_create_root_cat($root_code, $root_ar, $root_en, 'en', $polylang_active);
        if ($root_ar_cat && $root_en_cat && function_exists('pll_save_term_translations')) {
            pll_save_term_translations(['ar' => $root_ar_cat, 'en' => $root_en_cat]);
        }
        $sen = $sector_en !== '' ? $sector_en : $sector_ar;
        $sector_en_cat = pild_bookstore_find_or_create_cat_by_code($sector_code, $sen, $root_en_cat, 'en', $polylang_active);
        if ($sector_ar_cat && $sector_en_cat && function_exists('pll_save_term_translations')) {
            pll_save_term_translations(['ar' => $sector_ar_cat, 'en' => $sector_en_cat]);
        }
    }

    $domain_ar_cat = pild_bookstore_find_or_create_cat_by_code($domain_code, $domain_ar, $sector_ar_cat, 'ar', $polylang_active);
    $domain_en_cat = 0;
    if ($polylang_active) {
        $den = $domain_en !== '' ? $domain_en : $domain_ar;
        $domain_en_cat = pild_bookstore_find_or_create_cat_by_code($domain_code, $den, $sector_en_cat, 'en', $polylang_active);
        if ($domain_ar_cat && $domain_en_cat && function_exists('pll_save_term_translations')) {
            pll_save_term_translations(['ar' => $domain_ar_cat, 'en' => $domain_en_cat]);
        }
    }

    return $cache[$key] = ['ar' => $domain_ar_cat, 'en' => $domain_en_cat];
}

function pild_bookstore_sideload_cover($url, $post_id) {
    if (!function_exists('media_sideload_image')) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
    $attach_id = media_sideload_image($url, $post_id, null, 'id');
    if (!is_wp_error($attach_id) && $attach_id) set_post_thumbnail($post_id, $attach_id);
}

// ============================================================
// نفس فكرة pild_bookstore_sideload_cover() فوق، لكن للأيقونة الصغيرة:
// بترجع رابط الصورة بعد ما تتحمّل على مكتبة الميديا بتاعتنا، من غير ما
// تتحط "featured image" للبوست (عشان الغلاف نفسه هو الـ featured image،
// مش الأيقونة). لو فشل التحميل بترجع '' والكود اللي بينادي عليها بيرجع
// للرابط الخارجي الأصلي كحل احتياطي.
//
// عمود "أيقونة_الغلاف" في الإكسيل ممكن يبقى رابط صورة حقيقي، أو ممكن
// يبقى إيموجي/رمز نصي بسيط (🧭 📈 💰...) — زي ملف الديمو المرفوع.
// الإيموجي مش لازم ولا ينفع يتحمّل كصورة (مش رابط أصلاً)، فبنتأكد الأول
// إن القيمة رابط حقيقي (http/https) قبل أي محاولة sideload.
// ============================================================
function pild_bookstore_sideload_icon($url) {
    if ($url === '' || !preg_match('~^https?://~i', $url)) return '';
    if (!function_exists('media_sideload_image')) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
    $attach_id = media_sideload_image($url, 0, null, 'id');
    if (is_wp_error($attach_id) || !$attach_id) return '';
    $local_url = wp_get_attachment_url($attach_id);
    return $local_url ? $local_url : '';
}

// ── معاينة: نتأكد من الأعمدة المطلوبة، من غير ما نكتب أي حاجة ──
function pild_bookstore_build_plan($rows) {
    $errors = []; $plan = []; $seen = [];

    foreach ($rows as $i => $row) {
        $line = $i + 2;

        $root_code = isset($row['كود_الكاتوجري_الرئيسي'])      ? trim($row['كود_الكاتوجري_الرئيسي'])      : '';
        $root_ar   = isset($row['اسم_الكاتوجري_الرئيسي'])      ? trim($row['اسم_الكاتوجري_الرئيسي'])      : '';
        $root_en   = isset($row['اسم_الكاتوجري_الرئيسي_EN'])   ? trim($row['اسم_الكاتوجري_الرئيسي_EN'])   : '';

        $sector_code = isset($row['كود_القطاع'])           ? trim($row['كود_القطاع'])           : '';
        $sector      = isset($row['اسم_القطاع'])           ? trim($row['اسم_القطاع'])           : '';
        $sector_en   = isset($row['اسم_القطاع_EN'])        ? trim($row['اسم_القطاع_EN'])        : '';
        $domain_code = isset($row['كود_المجال'])           ? trim($row['كود_المجال'])           : '';
        $domain      = isset($row['اسم_المجال'])           ? trim($row['اسم_المجال'])           : '';
        $domain_color = isset($row['لون_المجال']) ? trim($row['لون_المجال']) : '';
        $domain_en   = isset($row['اسم_المجال_EN'])        ? trim($row['اسم_المجال_EN'])        : '';

        $code       = isset($row['كود_الكتاب'])        ? trim($row['كود_الكتاب'])        : '';
        $title      = isset($row['عنوان_الكتاب'])      ? trim($row['عنوان_الكتاب'])      : '';
        $title_en   = isset($row['عنوان_الكتاب_EN'])   ? trim($row['عنوان_الكتاب_EN'])   : '';

        $price      = isset($row['السعر'])              ? trim($row['السعر'])             : '';

        $short_desc    = isset($row['الوصف_القصير'])    ? trim($row['الوصف_القصير'])    : '';
        $short_desc_en = isset($row['الوصف_القصير_EN']) ? trim($row['الوصف_القصير_EN']) : '';
        $excerpt       = isset($row['وصف_الكتاب'])      ? trim($row['وصف_الكتاب'])      : '';
        $excerpt_en    = isset($row['وصف_الكتاب_EN'])   ? trim($row['وصف_الكتاب_EN'])   : '';

        $image      = isset($row['رابط_الصورة'])       ? trim($row['رابط_الصورة'])       : '';
        $image_en   = isset($row['رابط_الصورة_EN'])    ? trim($row['رابط_الصورة_EN'])    : '';

        $icon       = isset($row['أيقونة_الغلاف'])     ? trim($row['أيقونة_الغلاف'])     : '';
        $subtitle    = isset($row['عنوان_فرعي'])        ? trim($row['عنوان_فرعي'])        : '';
        $subtitle_en = isset($row['عنوان_فرعي_EN'])     ? trim($row['عنوان_فرعي_EN'])     : '';

        $content_url    = isset($row['رابط_محتوى_الكتاب'])    ? trim($row['رابط_محتوى_الكتاب'])    : '';
        $content_url_en = isset($row['رابط_محتوى_الكتاب_EN']) ? trim($row['رابط_محتوى_الكتاب_EN']) : '';

        if ($code === '' || $title === '') { $errors[] = "صف $line: لازم يتحدد كود واسم للكتاب."; continue; }
        if (isset($seen[$code])) { $errors[] = "صف $line: الكود '$code' مكرر في نفس الشيت."; continue; }
        $seen[$code] = true;

        if ($sector_code === '' || $sector === '') { $errors[] = "صف $line: لازم يتحدد كود القطاع واسم القطاع."; continue; }
        if ($domain_code === '' || $domain === '') { $errors[] = "صف $line: لازم يتحدد كود المجال واسم المجال."; continue; }
        if ($domain_color !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $domain_color)) { $errors[] = "صف $line: عمود 'لون_المجال' لازم يكون كود hex زي #2F5D50."; continue; }
        if ($price === '' || !is_numeric($price) || (float) $price < 0) { $errors[] = "صف $line: عمود 'السعر' لازم يكون رقم (0 أو أكبر)."; continue; }

        $plan[] = [
            'root_code' => $root_code, 'root_ar' => $root_ar, 'root_en' => $root_en,
            'sector_code' => $sector_code, 'sector' => $sector, 'sector_en' => $sector_en,
            'domain_code' => $domain_code, 'domain' => $domain, 'domain_en' => $domain_en, 'domain_color' => $domain_color,
            'code' => $code, 'title' => $title, 'title_en' => $title_en,
            'price' => (float) $price,
            'excerpt' => $excerpt, 'excerpt_en' => $excerpt_en,
            'short_desc' => $short_desc, 'short_desc_en' => $short_desc_en,
            'image' => $image, 'image_en' => $image_en,
            'icon' => $icon,
            'subtitle' => $subtitle, 'subtitle_en' => $subtitle_en,
            'content_url' => $content_url, 'content_url_en' => $content_url_en,
        ];
    }
    return ['rows' => $plan, 'errors' => $errors];
}

// ── إنشاء/تحديث كتاب واحد + منتجه، للغة واحدة ──
function pild_bookstore_save_one_book($row, $domain_id, $category_id, $lang, $polylang_active, &$created_books, &$updated_books, &$created_products, &$updated_products) {
    $code  = $lang === 'en' ? $row['code'] . '-en' : $row['code'];
    $title = $lang === 'en' ? $row['title_en'] : $row['title'];

    // لكل عمود لغته: لو اللغة إنجليزي وعندنا نسخة إنجليزية مخصصة (_EN)
    // نستخدمها، وإلا (سيبها فاضية) بنرجع لنص/رابط النسخة العربية كحل
    // احتياطي بدل ما المنتج/الكتاب الإنجليزي يفضل من غير قيمة خالص.
    $excerpt     = ($lang === 'en' && $row['excerpt_en'] !== '')     ? $row['excerpt_en']     : $row['excerpt'];
    $short_desc  = ($lang === 'en' && $row['short_desc_en'] !== '')  ? $row['short_desc_en']  : $row['short_desc'];
    $subtitle    = ($lang === 'en' && $row['subtitle_en'] !== '')    ? $row['subtitle_en']    : $row['subtitle'];
    $image       = ($lang === 'en' && $row['image_en'] !== '')       ? $row['image_en']       : $row['image'];
    $content_url = ($lang === 'en' && $row['content_url_en'] !== '') ? $row['content_url_en'] : $row['content_url'];

    // ---- بوست الكتاب ----
    // الوصف كود/HTML جاهز بتنسيقات مخصصة من عندك، فبيتخزن زي ما هو من
    // غير wpautop أو أي تعديل تلقائي عليه.
    $existing_book_id = pild_bookstore_find_existing_by_code('store_book', $code);
    $book_args = ['post_type' => 'store_book', 'post_title' => $title, 'post_status' => 'publish'];
    if ($excerpt !== '') $book_args['post_content'] = $excerpt;

    if ($existing_book_id) {
        $book_args['ID'] = $existing_book_id;
        $book_id = wp_update_post($book_args, true);
        $updated_books++;
    } else {
        $book_id = wp_insert_post($book_args, true);
        $created_books++;
    }
    if (is_wp_error($book_id) || !$book_id) return ['book_id' => 0, 'product_id' => 0];

    update_post_meta($book_id, 'pild_import_code', $code);
    if (function_exists('update_field')) update_field('book_domain', $domain_id, $book_id);
    if ($polylang_active) pll_set_post_language($book_id, $lang);

    // غلاف الكارت: العنوان الفرعي والأيقونة بيتخزنوا كـ meta مباشرة على
    // بوست الكتاب (مش مشتقين من وصف المنتج). الأيقونة كانت بتتخزن كرابط
    // خارجي زي ما هو، وده كان بيظهر مكسور لو المصدر بيمنع hotlinking —
    // فبقى بيتم تحميلها على مكتبة الميديا بتاعتنا (pild_bookstore_sideload_icon
    // فوق) ونخزن الرابط المحلي بدل الخارجي. بنقارن بالرابط الخارجي الأصلي
    // (pild_book_icon_source) عشان إعادة رفع نفس الإكسيل تاني ما يعملش
    // تحميل مكرر كل مرة من غير داعي.
    update_post_meta($book_id, 'pild_book_subtitle', $subtitle);
    $icon_source = $row['icon'];
    if ($icon_source === '') {
        update_post_meta($book_id, 'pild_book_icon', '');
        delete_post_meta($book_id, 'pild_book_icon_source');
    } elseif ($icon_source !== get_post_meta($book_id, 'pild_book_icon_source', true)
              || get_post_meta($book_id, 'pild_book_icon', true) === '') {
        $local_icon = pild_bookstore_sideload_icon($icon_source);
        update_post_meta($book_id, 'pild_book_icon', $local_icon !== '' ? $local_icon : $icon_source);
        update_post_meta($book_id, 'pild_book_icon_source', $icon_source);
    }
    update_post_meta($book_id, 'pild_book_content_url', $content_url);

    if ($image !== '' && !has_post_thumbnail($book_id)) {
        pild_bookstore_sideload_cover($image, $book_id);
    }

    // ---- منتج الووكوميرس ----
    $existing_product_id = pild_bookstore_find_existing_by_code('product', $code);
    if ($existing_product_id) {
        $product = wc_get_product($existing_product_id);
        $updated_products++;
    } else {
        $product = new WC_Product_Simple();
        $created_products++;
    }
    if (!$product) return ['book_id' => $book_id, 'product_id' => 0];

    $product->set_name($title);
    $product->set_regular_price((string) $row['price']);
    $product->set_status('publish');
    $product->set_catalog_visibility('visible');
    $product->set_sold_individually(true); // كتاب بيتشترى مرة واحدة — من غير خانة كمية
    if ($excerpt !== '')    $product->set_description($excerpt);
    if ($short_desc !== '') $product->set_short_description($short_desc);
    if ($category_id) $product->set_category_ids([$category_id]);

    $product_id = $product->save();
    if (!$product_id) return ['book_id' => $book_id, 'product_id' => 0];

    update_post_meta($product_id, 'pild_import_code', $code);
    if ($polylang_active) pll_set_post_language($product_id, $lang);
    if ($image !== '' && !has_post_thumbnail($product_id)) {
        pild_bookstore_sideload_cover($image, $product_id);
    }

    // ---- الربط في الاتجاهين (نفس آلية 34.2) ----
    if (function_exists('update_field')) {
        update_field('book_product', $product_id, $book_id);
        update_field('product_book_url', get_permalink($book_id), $product_id);
    }
    update_post_meta($book_id, 'prwc_products', (string) $product_id);

    if (function_exists('pildcm_purge_post_cache')) pildcm_purge_post_cache($book_id);

    return ['book_id' => $book_id, 'product_id' => $product_id];
}

// ============================================================
// 34.4b — SLUG موحّد بين نسخة عربي/إنجليزي (كتاب أو منتج) — طلب العميل:
// "أي slug موحّد لكل حاجة في النسختين العربي والإنجليزي، وياخد اسم
// الإنجليزي". نفس فكرة PHASE 20 الموجودة في 18-excel-importer.php،
// لكن store_book والمنتج بيتعملوا من مسار مستقل هنا (pild_bookstore_execute)
// فمكانوش بيمروا على منطق التوحيد القديم أصلاً. من غير الفرض اليدوي ده،
// wp_insert_post()/WC_Product::save() بيولّدوا الـ slug من العنوان
// العربي على النسخة العربية، وعلى النسخة الإنجليزية بيولّدوه من
// الإنجليزي لكن wp_unique_post_slug() بيشوفه متصادم مع سلاج بوست
// تاني (لو اتكرر) ويلزّق "-2" في الآخر. الحل: نفرض نفس الـ slug
// (المشتق من العنوان الإنجليزي دايماً) على البوستين مباشرة عبر $wpdb،
// بعد التأكد إنه مش متصادم فعلياً مع بوست تالت. بتشتغل على كل استيراد
// (مش أول مرة بس)، فرفع نفس الملف تاني بيصلح أي slug كان اتفرق قبل كده.
// ============================================================
function pild_bookstore_force_unified_slug($post_type, $ar_id, $en_id, $title_en) {
    if (!$ar_id || !$en_id || $title_en === '') return;
    $slug = sanitize_title($title_en);
    if ($slug === '') return;

    global $wpdb;
    $conflict = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_name=%s AND post_type=%s AND post_status NOT IN ('trash','auto-draft') AND ID NOT IN (%d,%d) LIMIT 1",
        $slug, $post_type, $ar_id, $en_id
    ));
    if ($conflict) return; // تصادم حقيقي مع بوست تالت — سيبها لـ WordPress تحلها زي ما هي

    $wpdb->update($wpdb->posts, ['post_name' => $slug], ['ID' => $ar_id]);
    $wpdb->update($wpdb->posts, ['post_name' => $slug], ['ID' => $en_id]);
    clean_post_cache($ar_id);
    clean_post_cache($en_id);
}

// ── تنفيذ فعلي على كل صفوف الخطة ──
function pild_bookstore_execute($plan_rows) {
    $sector_cache = []; $domain_cache = []; $cat_cache = [];
    $created_sectors = 0; $created_domains = 0;
    $created_books = 0; $updated_books = 0;
    $created_products = 0; $updated_products = 0;
    $created_en = 0;

    $polylang_active = function_exists('pll_set_post_language') && function_exists('pll_save_post_translations');

    foreach ($plan_rows as $row) {
        $sres = pild_bookstore_find_or_create_sector($sector_cache, $row['sector_code'], $row['sector'], $row['sector_en'], $polylang_active);
        if (!$sres['ar_id']) continue; // فشل الإنشاء (نادر) -> تخطي الصف بأمان
        if ($sres['created']) $created_sectors++;

        $dres = pild_bookstore_find_or_create_domain($domain_cache, $row['domain_code'], $row['domain'], $row['domain_en'], $sres, $polylang_active);
        if (!$dres['ar_id']) continue;
        if ($dres['created']) $created_domains++;
        pild_bookstore_ensure_domain_color($dres, $row['domain_color']);

        $cats = pild_bookstore_resolve_hierarchical_cats(
            $cat_cache, $row['root_code'], $row['root_ar'], $row['root_en'],
            $row['sector_code'], $row['sector'], $row['sector_en'],
            $row['domain_code'], $row['domain'], $row['domain_en'], $polylang_active
        );

        $ar_result  = pild_bookstore_save_one_book(
            $row, $dres['ar_id'], $cats['ar'], 'ar', $polylang_active,
            $created_books, $updated_books, $created_products, $updated_products
        );
        $ar_book_id    = $ar_result['book_id'];
        $ar_product_id = $ar_result['product_id'];

        if ($polylang_active && $row['title_en'] !== '' && $ar_book_id) {
            $en_domain_id = $dres['en_id'] ?: $dres['ar_id'];
            $en_cat_id    = $cats['en'] ?: $cats['ar'];
            $en_result  = pild_bookstore_save_one_book(
                $row, $en_domain_id, $en_cat_id, 'en', $polylang_active,
                $created_books, $updated_books, $created_products, $updated_products
            );
            $en_book_id    = $en_result['book_id'];
            $en_product_id = $en_result['product_id'];
            if ($en_book_id) {
                pll_save_post_translations(['ar' => $ar_book_id, 'en' => $en_book_id]);
                $created_en++;
                // نفس الـ slug (من الإنجليزي) على صفحة الكتاب AR/EN، وبرضه
                // على صفحة المنتج AR/EN — طلب العميل: صفحة واحدة بنفس
                // الرابط بصرف النظر عن اللغة، مبني على الاسم الإنجليزي.
                pild_bookstore_force_unified_slug('store_book', $ar_book_id, $en_book_id, $row['title_en']);
                if ($ar_product_id && $en_product_id) {
                    // ربط منتج الووكوميرس العربي بالإنجليزي كترجمة (Polylang) —
                    // كان بيتعمل للكتب بس، فالمنتجات كانت بتفضل منفصلة.
                    if (function_exists('pll_get_post_translations')) {
                        $prod_tr = pll_get_post_translations($ar_product_id);
                        $prod_tr = is_array($prod_tr) ? $prod_tr : [];
                        $prod_tr['ar'] = $ar_product_id;
                        $prod_tr['en'] = $en_product_id;
                        pll_save_post_translations($prod_tr);
                    }
                    pild_bookstore_force_unified_slug('product', $ar_product_id, $en_product_id, $row['title_en']);
                }
            }
        }

        // بعد ربط الترجمة (لو حصلت) بين النسخة العربية والإنجليزية،
        // نزامن prwc_products على الاتنين مع بعض — شراء أي نسخة يفتح
        // الاتنين فعلياً عند "Page Restrict for WooCommerce" (انظر
        // pild_bookstore_sync_bilingual_prwc() في 34.2 فوق).
        if ($ar_book_id) pild_bookstore_sync_bilingual_prwc($ar_book_id);
    }

    return [
        'created_sectors' => $created_sectors, 'created_domains' => $created_domains,
        'created_books' => $created_books, 'updated_books' => $updated_books,
        'created_products' => $created_products, 'updated_products' => $updated_products,
        'created_en' => $created_en,
    ];
}


// ── صفحة الأدمن: رفع -> معاينة -> تأكيد (نفس أسلوب 26-products-importer.php) ──
function pild_bookstore_import_page() {
    if (!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>📚 استيراد متجر الكتب</h1>';
    echo '<p>شيت واحد اسمه "Bookstore". كل صف = كتاب: بيتعمل (أو يتحدّث بالكود) القطاع والمجال والتصنيف الهرمي لو مش موجودين، وبوست الكتاب، ومنتج الووكوميرس، ويترابطوا كلهم تلقائي.</p>';

    echo '<div class="notice notice-info" style="padding:12px 16px;"><p><strong>عناوين الأعمدة المطلوبة في الصف الأول (بالظبط بنفس الترتيب والتهجئة):</strong></p>'
       . '<code style="display:block;padding:8px;background:#f6f7f7;overflow-x:auto;">كود_الكاتوجري_الرئيسي | اسم_الكاتوجري_الرئيسي | اسم_الكاتوجري_الرئيسي_EN | كود_القطاع | اسم_القطاع | اسم_القطاع_EN | كود_المجال | اسم_المجال | اسم_المجال_EN | كود_الكتاب | عنوان_الكتاب | عنوان_الكتاب_EN | السعر | الوصف_القصير | الوصف_القصير_EN | وصف_الكتاب | وصف_الكتاب_EN | رابط_الصورة | رابط_الصورة_EN | أيقونة_الغلاف | عنوان_فرعي | عنوان_فرعي_EN | رابط_محتوى_الكتاب | رابط_محتوى_الكتاب_EN | لون_المجال</code>'
       . '<p style="margin-top:8px;">إجباري: كود_القطاع، اسم_القطاع، كود_المجال، اسم_المجال، كود_الكتاب، عنوان_الكتاب، السعر. الباقي كله اختياري.</p>'
       . '<p style="margin-top:8px;">🗂️ <strong>الكاتوجري الرئيسي (المستوى الأول):</strong> أعمدة كود_الكاتوجري_الرئيسي / اسم_الكاتوجري_الرئيسي / اسم_الكاتوجري_الرئيسي_EN اختيارية — لو سايبها فاضية، القطاع بيتحط تلقائي تحت كاتوجري ثابت اسمه "الكتب التطبيقية" (EN: Playbooks) بكود CAT-PLAYBOOKS. لو عبّيتها بقيمة تانية، القطاع هيتحط تحت الكاتوجري ده بدل الافتراضي.</p>'
       . '<p style="margin-top:8px;">🗂️ <strong>القطاع والمجال:</strong> الكاتوجري الرئيسي ← القطاع ← المجال ← المنتج (تصنيف ووكوميرس هرمي بيتعمل لوحده). لكل منهم كود ثابت — إعادة رفع الملف بتحدّث الاسم بدل ما تعمل تكرار.</p>'
       . '<p style="margin-top:8px;">📦 <strong>ثنائي اللغة بالكامل:</strong> لو عبّيت عنوان_الكتاب_EN (وأي أعمدة _EN تانية) وPolylang شغّال، هيتعمل كتاب ومنتج ووكوميرس إنجليزي كامل منفصل ومربوط كترجمة، وكمان تصنيف القطاع/المجال الهرمي بالإنجليزي مربوط كترجمة للعربي. أي عمود _EN سايبه فاضي بياخد نص/رابط العمود العربي المقابل احتياطياً.</p>'
       . '<p style="margin-top:8px;">💻 <strong>الوصف كود/HTML:</strong> وصف_الكتاب والوصف_القصير بيتخزنوا زي ما هما بالظبط من غير أي تعديل تلقائي (من غير wpautop مثلاً) — يعني تقدر تحط فيهم HTML جاهز بتنسيقاتك الخاصة براحتك.</p>'
       . '<p style="margin-top:8px;">🎨 <strong>لون المجال:</strong> كل مجال بياخد لون غلاف تلقائي من باليتة ثابتة (٨ ألوان) أول ما يتعمل، وكل كتب المجال بتشاركه. عمود لون_المجال اختياري (كود hex زي #2F5D50) لو عايز لون معين.</p>'
       . '<p style="margin-top:8px;">🖼️ <strong>غلاف كرت المنتج:</strong> أيقونة_الغلاف بتظهر فوق العنوان، وعنوان_فرعي بيظهر تحت العنوان وخط ذهبي فاصل، و"Pild" ثابت تحت في الآخر. لو رابط_الصورة موجود، بيبقى خلفية وراء كل ده بدل الغلاف الأخضر الزخرفي.</p>'
       . '<p style="margin-top:8px;">📖 <strong>صفحة الكتاب بعد الشراء:</strong> لو رابط_محتوى_الكتاب موجود، بيتعرض جوه صفحة الكتاب كـ iframe. لو فاضي، بيرجع للمحتوى النصي من وصف_الكتاب زي الإصدار القديم.</p></div>';

    if (!class_exists('WC_Product_Simple')) {
        echo '<div class="notice notice-error"><p>لازم ووكوميرس يكون شغّال عشان الاستيراد ده يعمل منتجات.</p></div></div>';
        return;
    }

    $step = isset($_POST['pildcm_step']) ? sanitize_text_field(wp_unslash($_POST['pildcm_step'])) : '';
    $tkey = 'pild_bookstore_import_plan_' . get_current_user_id();

    if ($step === 'confirm' && check_admin_referer('pild_bookstore_import_confirm')) {
        $plan_rows = get_transient($tkey);
        if ($plan_rows === false) {
            echo '<div class="notice notice-error"><p>انتهت صلاحية بيانات المعاينة (بعد ساعة). ارفع الملف تاني.</p></div>';
        } else {
            $r = pild_bookstore_execute($plan_rows);
            delete_transient($tkey);
            echo '<div class="notice notice-success"><p><strong>تم الاستيراد بنجاح ✅</strong><br>'
               . 'قطاعات جديدة: ' . (int) $r['created_sectors'] . ' — مجالات جديدة: ' . (int) $r['created_domains'] . '<br>'
               . 'كتب جديدة: ' . (int) $r['created_books'] . '، كتب تم تحديثها: ' . (int) $r['updated_books'] . '<br>'
               . 'منتجات جديدة: ' . (int) $r['created_products'] . '، منتجات تم تحديثها: ' . (int) $r['updated_products'] . '<br>'
               . 'نسخ إنجليزي جديدة: ' . (int) $r['created_en']
               . '</p></div>';
        }
    } elseif ($step === 'preview' && check_admin_referer('pild_bookstore_import_preview') && !empty($_FILES['pild_bookstore_file']['tmp_name'])) {
        $tmp_name  = $_FILES['pild_bookstore_file']['tmp_name'];
        $orig_name = isset($_FILES['pild_bookstore_file']['name']) ? sanitize_file_name($_FILES['pild_bookstore_file']['name']) : '';

        if (strtolower(pathinfo($orig_name, PATHINFO_EXTENSION)) !== 'xlsx') {
            echo '<div class="notice notice-error"><p>لازم يكون الملف بصيغة .xlsx.</p></div>';
        } elseif (!function_exists('pildcm_xlsx_extract')) {
            echo '<div class="notice notice-error"><p>أداة قراءة الإكسيل غير متاحة (تأكد إن includes/18-excel-importer.php محمّل).</p></div>';
        } else {
            $sheets_raw = pildcm_xlsx_extract($tmp_name);
            if (is_wp_error($sheets_raw)) {
                echo '<div class="notice notice-error"><p>' . esc_html($sheets_raw->get_error_message()) . '</p></div>';
            } elseif (empty($sheets_raw['Bookstore'])) {
                echo '<div class="notice notice-error"><p>لازم يكون فيه شيت اسمه "Bookstore" بالظبط.</p></div>';
            } else {
                $build = pild_bookstore_build_plan($sheets_raw['Bookstore']);

                echo '<h2>📋 معاينة قبل الاستيراد</h2>';
                echo '<p>عدد الصفوف الصالحة: <strong>' . count($build['rows']) . '</strong></p>';

                if (!empty($build['errors'])) {
                    echo '<div class="notice notice-error"><p><strong>فيه أخطاء لازم تتصلح جوه الإكسيل الأول (لسه مفيش أي حاجة اتحفظت):</strong></p><ul style="list-style:disc;margin-inline-start:20px">';
                    foreach ($build['errors'] as $err) echo '<li>' . esc_html($err) . '</li>';
                    echo '</ul></div>';
                } else {
                    echo '<table class="widefat striped" style="max-width:1000px;margin-bottom:20px"><thead><tr><th>الكود</th><th>الاسم</th><th>القطاع</th><th>المجال</th><th>السعر</th></tr></thead><tbody>';
                    foreach ($build['rows'] as $r) {
                        echo '<tr><td>' . esc_html($r['code']) . '</td><td>' . esc_html($r['title'])
                           . ($r['title_en'] !== '' ? ' <span style="color:#888">/ ' . esc_html($r['title_en']) . '</span>' : '')
                           . '</td><td>' . esc_html($r['sector']) . '</td><td>' . esc_html($r['domain']) . '</td><td>' . esc_html($r['price']) . '</td></tr>';
                    }
                    echo '</tbody></table>';

                    set_transient($tkey, $build['rows'], HOUR_IN_SECONDS);
                    echo '<div class="notice notice-success"><p>مفيش أخطاء ✅ — دوس "تأكيد الاستيراد" عشان تتنفذ العملية فعلياً على الموقع.</p></div>';
                    echo '<form method="post">';
                    wp_nonce_field('pild_bookstore_import_confirm');
                    echo '<input type="hidden" name="pildcm_step" value="confirm">';
                    submit_button('✅ تأكيد استيراد متجر الكتب الآن');
                    echo '</form>';
                }
            }
        }
    }

    echo '<h2 style="margin-top:32px;">رفع ملف جديد</h2>';
    echo '<form method="post" enctype="multipart/form-data">';
    wp_nonce_field('pild_bookstore_import_preview');
    echo '<input type="hidden" name="pildcm_step" value="preview">';
    echo '<input type="file" name="pild_bookstore_file" accept=".xlsx" required> ';
    submit_button('👁️ معاينة الملف');
    echo '</form>';

    echo '</div>';
}


// ============================================================
// 34.7 — منتج الكتاب: غلاف تلقائي + من غير كمية + زرار شراء مخصص
// ------------------------------------------------------------
// - الغلاف: لو منتج الكتاب ملوش صورة، بنرسم نفس غلاف كرت المتجر (أيقونة +
//   عنوان + خط ذهبي + عنوان فرعي + Pild) بـ HTML/CSS بدل صورة الووكوميرس
//   الفاضية. لو فيه صورة (رابط_الصورة في الإكسيل) الصورة بتتقدّم عليه.
// - الكمية: الكتاب بيتشترى مرة واحدة ويتقرا على الموقع، فبنخليه
//   "sold individually" — خانة الكمية بتختفي وميقدرش يتضاف للسلة مرتين.
// - نص الزرار: "اشترِ وابدأ القراءة" / "Buy & Start Reading".
// كل ده بيشتغل بس على منتجات مربوطة بكتاب (store_book)، أي منتج تاني في
// الموقع بيفضل زي ما هو.
// ============================================================

// الكتاب المربوط بمنتج معين (عكس book_product)، بكاش داخل الطلب.
function pild_bookstore_book_for_product($product_id) {
    static $cache = [];
    $product_id = (int) $product_id;
    if (!$product_id) return 0;
    if (array_key_exists($product_id, $cache)) return $cache[$product_id];
    $ids = get_posts([
        'post_type'        => 'store_book',
        'posts_per_page'   => 1,
        'post_status'      => 'any',
        'fields'           => 'ids',
        'suppress_filters' => true,
        'meta_query'       => [['key' => 'book_product', 'value' => $product_id, 'compare' => '=']],
    ]);
    return $cache[$product_id] = !empty($ids) ? (int) $ids[0] : 0;
}

function pild_bookstore_product_lang($product_id) {
    if (function_exists('pll_get_post_language')) {
        $l = pll_get_post_language($product_id);
        if ($l) return $l;
    }
    return is_rtl() ? 'ar' : 'en';
}

function pild_bookstore_render_auto_cover($product_id, $book_id) {
    $title    = get_the_title($product_id);
    $subtitle = (string) get_post_meta($book_id, 'pild_book_subtitle', true);
    $icon     = (string) get_post_meta($book_id, 'pild_book_icon', true);
    $is_en    = pild_bookstore_product_lang($product_id) === 'en';
    $dir      = $is_en ? 'ltr' : 'rtl';

    static $printed = false;
    $out = '';
    if (!$printed) {
        $printed = true;
        $out .= '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
              . '<link href="https://fonts.googleapis.com/css2?family=El+Messiri:wght@500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500&display=swap" rel="stylesheet">'
              . '<style>
.pild-autocover{aspect-ratio:3/4;width:100%;max-width:460px;margin:0 auto;background:linear-gradient(160deg,#1E6F5C,#154F42);position:relative;overflow:hidden;border-radius:6px;display:block;}
.pild-autocover *{box-sizing:border-box;}
.pild-autocover-frame{position:absolute;inset:6%;border:1px solid rgba(216,174,94,.55);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:8% 7%;text-align:center;}
.pild-autocover-frame::before,.pild-autocover-frame::after{content:"";position:absolute;width:6%;aspect-ratio:1;border:1px solid #D8AE5E;}
.pild-autocover-frame::before{inset-block-start:-1px;inset-inline-start:-1px;border-inline-end:none;border-block-end:none;}
.pild-autocover-frame::after{inset-block-end:-1px;inset-inline-end:-1px;border-inline-start:none;border-block-start:none;}
.pild-autocover-icon{width:12%;min-width:28px;max-height:60px;object-fit:contain;filter:drop-shadow(0 1px 3px rgba(0,0,0,.4));}
.pild-autocover-emoji{font-size:clamp(26px,9cqw,44px);line-height:1;}
.pild-autocover-title{font-family:"El Messiri",serif;font-weight:600;font-size:clamp(16px,5.2cqw,30px);line-height:1.5;letter-spacing:.03em;color:#D8AE5E;text-shadow:0 1px 3px rgba(0,0,0,.35);}
.pild-autocover-line{width:44px;height:1px;background:#D8AE5E;opacity:.85;}
.pild-autocover-sub{font-family:"IBM Plex Sans Arabic",sans-serif;font-size:clamp(11px,3.2cqw,17px);line-height:1.6;color:rgba(242,236,221,.78);}
.pild-autocover-by{position:absolute;inset-inline:0;bottom:9%;text-align:center;font-family:"El Messiri",serif;font-style:italic;font-weight:500;font-size:clamp(12px,3.4cqw,18px);letter-spacing:.06em;color:rgba(242,236,221,.78);}
.pild-autocover{container-type:inline-size;}
</style>';
    }

    $bg_domain = function_exists('get_field') ? (int) get_field('book_domain', $book_id) : 0;
    $bg        = $bg_domain ? pild_bookstore_domain_cover_bg($bg_domain) : '';
    $out .= '<div class="pild-autocover" dir="' . esc_attr($dir) . '"' . ($bg ? ' style="background:' . esc_attr($bg) . '"' : '') . '><div class="pild-autocover-frame">';
    if ($icon !== '') {
        if (preg_match('~^https?://~i', $icon)) {
            $out .= '<img class="pild-autocover-icon" src="' . esc_url($icon) . '" alt="">';
        } else {
            $out .= '<span class="pild-autocover-emoji">' . esc_html($icon) . '</span>';
        }
    }
    $out .= '<span class="pild-autocover-title">' . esc_html($title) . '</span>';
    if ($subtitle !== '') {
        $out .= '<span class="pild-autocover-line"></span><span class="pild-autocover-sub">' . esc_html($subtitle) . '</span>';
    }
    $out .= '</div><span class="pild-autocover-by">Pild</span></div>';
    return $out;
}

// صفحة المنتج: لو مفيش صورة مميزة، الغلاف التلقائي مكان الصورة الفاضية.
add_filter('woocommerce_single_product_image_thumbnail_html', 'pild_bookstore_single_image_cover', 20, 2);
function pild_bookstore_single_image_cover($html, $thumb_id) {
    if ($thumb_id) return $html;
    global $product;
    if (!($product instanceof WC_Product)) return $html;
    $book_id = pild_bookstore_book_for_product($product->get_id());
    if (!$book_id) return $html;
    return '<div class="woocommerce-product-gallery__image--placeholder">' . pild_bookstore_render_auto_cover($product->get_id(), $book_id) . '</div>';
}

// الشوب/الأرشيف/المنتجات المرتبطة (نفس مكان الصورة الفاضية).
add_filter('woocommerce_placeholder_img', 'pild_bookstore_placeholder_cover', 20);
function pild_bookstore_placeholder_cover($html) {
    global $product;
    if (!($product instanceof WC_Product)) return $html;
    if ($product->get_image_id()) return $html;
    $book_id = pild_bookstore_book_for_product($product->get_id());
    if (!$book_id) return $html;
    return pild_bookstore_render_auto_cover($product->get_id(), $book_id);
}

// صورة السلة.
add_filter('woocommerce_cart_item_thumbnail', 'pild_bookstore_cart_cover', 20, 3);
function pild_bookstore_cart_cover($thumb, $cart_item, $key) {
    $pid = isset($cart_item['product_id']) ? (int) $cart_item['product_id'] : 0;
    $p   = $pid ? wc_get_product($pid) : null;
    if (!$p || $p->get_image_id()) return $thumb;
    $book_id = pild_bookstore_book_for_product($pid);
    return $book_id ? pild_bookstore_render_auto_cover($pid, $book_id) : $thumb;
}

// من غير كمية: الكتاب بيتشترى مرة واحدة (كمان بيغطي المنتجات اللي اتعملت
// قبل التحديث، من غير ما تحتاج إعادة استيراد).
add_filter('woocommerce_is_sold_individually', 'pild_bookstore_sold_individually', 20, 2);
function pild_bookstore_sold_individually($return, $product) {
    if ($return || !($product instanceof WC_Product)) return $return;
    return pild_bookstore_book_for_product($product->get_id()) ? true : $return;
}

// نص زرار الشراء (صفحة المنتج + الشوب).
add_filter('woocommerce_product_single_add_to_cart_text', 'pild_bookstore_add_to_cart_text', 20, 2);
add_filter('woocommerce_product_add_to_cart_text', 'pild_bookstore_add_to_cart_text', 20, 2);
function pild_bookstore_add_to_cart_text($text, $product) {
    if (!($product instanceof WC_Product) || !pild_bookstore_book_for_product($product->get_id())) return $text;
    return pild_bookstore_product_lang($product->get_id()) === 'en' ? 'Buy & Start Reading' : 'اشترِ وابدأ القراءة';
}


// ============================================================
// 34.8 — لون غلاف لكل مجال (الباليتة الهادية)
// ------------------------------------------------------------
// اللون بيتخزن على بوست المجال (ميتا pild_domain_color، كود hex) وبيتطبق
// على غلاف الكارت في المتجر وعلى الغلاف التلقائي في صفحة المنتج. الإطار
// الذهبي وباقي العناصر ثابتة زي ما هي، اللون بس هو اللي بيتغيّر.
// أول مرة يتعمل مجال (أو أول استيراد بعد التحديث) بياخد اللون التالي من
// الباليتة بالترتيب، والنسخة الإنجليزية بتاخد نفس لون العربية.
// ============================================================
function pild_bookstore_domain_palette() {
    return ['#2F5D50', '#2E4057', '#6E2F35', '#4B3A5E', '#2D5561', '#5C5B2E', '#7A4A3A', '#3B3F46'];
}

function pild_bookstore_darken_hex($hex, $factor = 0.66) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) !== 6) return '#154F42';
    $out = '#';
    foreach ([0, 2, 4] as $i) {
        $out .= str_pad(dechex((int) round(hexdec(substr($hex, $i, 2)) * $factor)), 2, '0', STR_PAD_LEFT);
    }
    return $out;
}

// الخلفية الجاهزة لغلاف مجال معين ('' لو المجال ملوش لون → الأخضر الافتراضي).
function pild_bookstore_domain_cover_bg($domain_id) {
    $c = $domain_id ? (string) get_post_meta($domain_id, 'pild_domain_color', true) : '';
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $c)) return '';
    return 'linear-gradient(160deg,' . $c . ',' . pild_bookstore_darken_hex($c) . ')';
}

// بيتنادى من الاستيراد لكل صف: لون الإكسيل بيتقدّم، وإلا لو المجال ملوش
// لون بياخد التالي من الباليتة. (مجال عنده لون بالفعل مبيتغيّرش عند إعادة الرفع.)
function pild_bookstore_ensure_domain_color($dres, $override) {
    $ids = array_filter([(int) $dres['ar_id'], (int) $dres['en_id']]);
    if (empty($ids)) return;

    $color = '';
    if ($override !== '') {
        $color = strtoupper($override);
    } else {
        foreach ($ids as $id) {
            $existing = (string) get_post_meta($id, 'pild_domain_color', true);
            if (preg_match('/^#[0-9a-fA-F]{6}$/', $existing)) { $color = $existing; break; }
        }
        if ($color === '') {
            $palette = pild_bookstore_domain_palette();
            $n = (int) get_option('pild_domain_color_next', 0);
            $color = $palette[$n % count($palette)];
            update_option('pild_domain_color_next', $n + 1);
        }
    }
    foreach ($ids as $id) update_post_meta($id, 'pild_domain_color', $color);
}