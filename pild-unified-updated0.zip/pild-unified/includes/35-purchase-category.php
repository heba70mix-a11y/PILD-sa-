<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 35. PURCHASE-CATEGORY EXTENSIONS (Sep 2026 client decisions)
// ------------------------------------------------------------
// Two pieces that build on top of includes/22-registration-routing.php
// without touching its core resolution logic more than necessary:
//
//   A) Training Partner "pending application" lock — a user who clicked
//      through to the partnership-application form is fully blocked from
//      buying anything (individual OR team) until an admin approves them
//      (grants the pild_training_partner role). See pild_is_partner_pending()
//      and pild_get_registration_context()'s 'partner_pending' branch.
//
//   B) Organization quick-registration — when a guest or a logged-in user
//      with no team yet explicitly picks "Organizations" from the new
//      card-level selector (includes/17-sector-explorer.php), we collect
//      just the 3 required fields (org name, responsible person, phone)
//      plus 2 optional ones (website, address) BEFORE letting the
//      individual/team add-to-cart proceed — the exact same fields/meta
//      keys as the existing Organization Profile in the company dashboard
//      (includes/03-ajax.php's pildcm_ajax_save_settings), so nothing is
//      duplicated and the manager can just complete the rest (logo) later
//      from their dashboard.
//      - Logged-in visitor: saved straight to their user meta.
//      - Guest: no account exists yet to attach it to, so it's held in the
//        WooCommerce session and applied once an account actually exists —
//        either at checkout (they tick "create an account") or, for an
//        existing-team purchase, when pild_team_create_from_purchase()
//        (includes/24-team-purchase.php) resolves the owner. See
//        pild_apply_pending_org_profile() below, hooked on order creation.
// ============================================================

// ── 35.1 Pending Training-Partner application flag ──────────────────
function pild_is_partner_pending($user_id = 0) {
    $user_id = $user_id ?: get_current_user_id();
    if (!$user_id) return false;
    if (function_exists('pildcm_is_training_partner') && pildcm_is_training_partner($user_id)) return false; // already approved — not "pending" anymore
    return get_user_meta($user_id, '_pild_partner_pending', true) === '1';
}

// PILD_PARTNERSHIP_FORM_ID: the Fluent Forms form ID for "طلب الشراكة
// لمراكز التدريب" (https://pild.org/sa/ar/for-training-center/
// partnership-application/), confirmed from the client's own form export
// (fluentform-export-forms, Sep 2026) — id 20, status "published". If the
// form is ever rebuilt/re-exported with a new ID, update this constant
// (or override via the pild_partnership_form_id filter) rather than
// editing the hook below.
if (!defined('PILD_PARTNERSHIP_FORM_ID')) {
    define('PILD_PARTNERSHIP_FORM_ID', apply_filters('pild_partnership_form_id', 20));
}

// ── The real lock trigger: an ACTUAL Fluent Forms submission of the
// partnership-application form — not just a click on its link (a click
// only means the visitor opened the form, not that they finished and
// submitted it, so locking on click would wrongly block someone who
// backed out). Fluent Forms fires this the moment a submission is saved
// to its own DB, before any of its own email notifications go out.
// $insert_id = the Fluent Forms submission's own row ID (entry ID) —
// unrelated to $form_id, just what the hook always passes first.
add_action('fluentform_submission_inserted', 'pild_ff_partnership_submitted', 10, 3);
function pild_ff_partnership_submitted($insert_id, $form_data, $form) {
    $form_id = is_object($form) ? (int) $form->id : (int) $form;
    if ($form_id !== (int) PILD_PARTNERSHIP_FORM_ID) return;

    $email = isset($form_data['contact_email']) ? sanitize_email($form_data['contact_email']) : '';
    if (!$email || !is_email($email)) return;

    $center_name = isset($form_data['center_name_ar']) ? sanitize_text_field($form_data['center_name_ar']) : '';
    $contact_name = isset($form_data['contact_full_name']) ? sanitize_text_field($form_data['contact_full_name']) : '';

    $user = get_user_by('email', $email);
    if ($user) {
        pild_apply_partner_pending_to_user($user->ID, $center_name, $contact_name);
        return;
    }

    // No account under this email yet (guest applied, or applied with a
    // different email than their eventual PILD login) — queue it, and
    // apply it the moment an account with a matching email shows up (see
    // pild_apply_pending_partner_on_login/on_register below). Capped list
    // isn't needed here: entries are removed as soon as they're consumed.
    $pending = get_option('pild_partner_pending_emails', []);
    $pending[strtolower($email)] = ['center_name' => $center_name, 'contact_name' => $contact_name];
    update_option('pild_partner_pending_emails', $pending, false);
}

function pild_apply_partner_pending_to_user($user_id, $center_name = '', $contact_name = '') {
    update_user_meta($user_id, '_pild_partner_pending', '1');
    if ($center_name)  update_user_meta($user_id, '_pild_partner_pending_center_name', $center_name);
    if ($contact_name) update_user_meta($user_id, '_pild_partner_pending_contact_name', $contact_name);
}

// Reconciles a queued-by-email application the moment a matching account
// actually exists — covers both "already had an account, just logged in
// after applying as a guest" and "created the account after applying".
add_action('wp_login', 'pild_apply_pending_partner_on_login', 10, 2);
function pild_apply_pending_partner_on_login($user_login, $user) {
    pild_reconcile_pending_partner_email($user);
}
add_action('user_register', 'pild_apply_pending_partner_on_register');
function pild_apply_pending_partner_on_register($user_id) {
    $user = get_userdata($user_id);
    if ($user) pild_reconcile_pending_partner_email($user);
}
function pild_reconcile_pending_partner_email($user) {
    if (!$user || !$user->user_email) return;
    $key = strtolower($user->user_email);
    $pending = get_option('pild_partner_pending_emails', []);
    if (!isset($pending[$key])) return;
    $entry = $pending[$key];
    pild_apply_partner_pending_to_user($user->ID, $entry['center_name'] ?? '', $entry['contact_name'] ?? '');
    unset($pending[$key]);
    update_option('pild_partner_pending_emails', $pending, false);
}

// The moment an admin actually approves someone (grants pild_training_
// partner), clear the pending flag automatically so it never lingers.
add_action('set_user_role', 'pild_clear_partner_pending_on_approval', 10, 3);
function pild_clear_partner_pending_on_approval($user_id, $role, $old_roles) {
    if ($role === 'pild_training_partner') {
        delete_user_meta($user_id, '_pild_partner_pending');
    }
}
add_action('add_user_role', function ($user_id, $role) {
    if ($role === 'pild_training_partner') {
        delete_user_meta($user_id, '_pild_partner_pending');
    }
}, 10, 2);

// ── 35.2 Organization quick-registration ─────────────────────────────
// Same required/optional split as the client decision: org name +
// responsible person + phone required; website + address optional (logo
// stays a dashboard-only upload — no file input in this inline flow).
add_action('wp_ajax_pild_org_quick_register', 'pild_ajax_org_quick_register');
add_action('wp_ajax_nopriv_pild_org_quick_register', 'pild_ajax_org_quick_register');
function pild_ajax_org_quick_register() {
    nocache_headers();
    check_ajax_referer('pild_reg_ctx', 'nonce');

    $org_name    = sanitize_text_field(wp_unslash($_POST['org_name']    ?? ''));
    $responsible = sanitize_text_field(wp_unslash($_POST['responsible'] ?? ''));
    $phone       = sanitize_text_field(wp_unslash($_POST['phone']       ?? ''));
    $website     = esc_url_raw(wp_unslash($_POST['website']             ?? ''));
    $address     = sanitize_textarea_field(wp_unslash($_POST['address'] ?? ''));

    if ($org_name === '' || $responsible === '' || $phone === '') {
        wp_send_json_error(['message' => __('اسم المنظمة، اسم المسؤول، والهاتف حقول إجبارية.', 'pild-unified')]);
    }

    $profile = [
        'pild_company_name' => $org_name,
        'pild_phone'        => $phone,
    ];
    if ($website) $profile['pild_website'] = $website;
    if ($address) $profile['pild_address'] = $address;

    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        foreach ($profile as $meta_key => $val) {
            update_user_meta($user_id, $meta_key, $val);
        }
        // "اسم المسؤول" — the responsible person's own display name.
        wp_update_user(['ID' => $user_id, 'display_name' => $responsible]);
    } else {
        // No account yet — hold it in the WooCommerce session (survives
        // across the guest's visit the same way the cart itself does) and
        // apply it once an account exists — see pild_apply_pending_org_
        // profile() below.
        if (!function_exists('WC') || !WC()->session) {
            wp_send_json_error(['message' => __('تعذّر حفظ بيانات المنظمة مؤقتًا — جرّب تاني.', 'pild-unified')]);
        }
        $profile['pild_responsible_name'] = $responsible;
        WC()->session->set('pild_pending_org_profile', $profile);
    }

    wp_send_json_success();
}

// Applies a guest's pending org profile (set above) to the resulting order
// owner's user meta, the moment their account exists — right after
// checkout creates/logs in the user, before pild_team_create_from_
// purchase() (includes/24-team-purchase.php, same hook priority group)
// needs an owner to attach the team to. Runs once, then clears the
// session flag so it's never re-applied to a later, unrelated order.
add_action('woocommerce_checkout_order_processed', 'pild_apply_pending_org_profile', 4, 3);
function pild_apply_pending_org_profile($order_id, $posted_data, $order) {
    if (!function_exists('WC') || !WC()->session) return;
    $profile = WC()->session->get('pild_pending_org_profile');
    if (!$profile) return;

    $user_id = $order ? (int) $order->get_user_id() : 0;
    if (!$user_id) return; // still a true guest order — nothing to attach to

    $responsible = $profile['pild_responsible_name'] ?? '';
    unset($profile['pild_responsible_name']);
    foreach ($profile as $meta_key => $val) {
        // Don't overwrite something the user already has on file.
        if (!get_user_meta($user_id, $meta_key, true)) {
            update_user_meta($user_id, $meta_key, $val);
        }
    }
    if ($responsible) {
        $user = get_userdata($user_id);
        if ($user && (empty($user->display_name) || $user->display_name === $user->user_login)) {
            wp_update_user(['ID' => $user_id, 'display_name' => $responsible]);
        }
    }
    WC()->session->__unset('pild_pending_org_profile');
}
