<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 36 — رمز الريال السعودي الرسمي الجديد (بدل النص "ر.س" اللي بيطلع
// من ووكومرس، واللي بيفضل عربي حتى لو الصفحة بالإنجليزي).
//
// السعودي المركزي (ساما) أصدر الرمز الرسمي في فبراير 2025 كملف SVG
// رسمي منشور على موقعهم. إحنا مش بنحط لينك خارجي مباشر عليه (لو
// ساما غيّرت مسار الملف يوم من الأيام، الرمز هيختفي من الموقع من غير
// سابق إنذار) — بدل كده، أول ما البلاجن يشتغل، السيرفر بتاعك (مش
// جهازي أنا) بيحمّل نسخة من الملف الرسمي مرة واحدة ويخزّنها في مكتبة
// الميديا بتاعتك، وبعد كده بنستخدم النسخة المحلية دي بس. لو التحميل
// فشل لأي سبب (مثلاً السيرفر بتاعك ماسك الطلبات الخارجية)، بيرجع
// تلقائي لنص "ر.س" العادي زي ما هو — مفيش أي كسر ممكن يحصل.
// ============================================================

define('PILD_SAR_SYMBOL_SOURCE_URL', 'https://www.sama.gov.sa/ar-sa/Currency/Documents/Saudi_Riyal_Symbol-2.svg');

// نسخة رفعناها يدوي على السيرفر بتاعنا (السيرفر بيمنع الطلبات
// الخارجية لـ sama.gov.sa، فالتحميل التلقائي تحت فاضل يفشل بصمت).
// دي مش بديل نهائي عن التحميل التلقائي — لو يوم من الأيام السيرفر
// سمح بالطلبات الخارجية، pild_sar_symbol_maybe_download() هتنجح
// وتسجّل نسخة في مكتبة الميديا، وساعتها الفلتر تحت هيستخدمها هي
// بدل النسخة اليدوية دي (لأنها بتتفحص الأول). لحد ما يحصل كده،
// النسخة اليدوية دي هي اللي هتظهر للزوار.
define('PILD_SAR_SYMBOL_FALLBACK_URL', 'https://pild.org/sa/wp-content/uploads/2026/09/Saudi_Riyal_Symbol-2.svg');

add_action('init', 'pild_sar_symbol_maybe_download', 20);
function pild_sar_symbol_maybe_download() {
    // لو عندنا نسخة محلية شغالة بالفعل، مفيش داعي نحاول تاني.
    $existing = get_option('pild_sar_symbol_local_url');
    if ($existing) return;

    // منمنعش محاولات متكررة كل تحميل صفحة لو فشلت قبل كده — نجرب تاني
    // كل ساعة بس، مش كل مرة حد يفتح أي صفحة في الموقع.
    if (get_transient('pild_sar_symbol_retry_lock')) return;
    set_transient('pild_sar_symbol_retry_lock', 1, HOUR_IN_SECONDS);

    $response = wp_remote_get(PILD_SAR_SYMBOL_SOURCE_URL, ['timeout' => 15]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return;

    $svg_body = wp_remote_retrieve_body($response);
    if ($svg_body === '' || stripos($svg_body, '<svg') === false) return;

    if (!function_exists('wp_upload_bits')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    $upload = wp_upload_bits('sar-symbol.svg', null, $svg_body);
    if (!empty($upload['error'])) return;

    // بنسجّلها كـ attachment عادي في مكتبة الميديا (من غير ما نحتاج
    // نفعّل رفع ملفات SVG من شاشة الأدمن أو أي إضافة "safe svg" —
    // wp_insert_attachment() هنا بيدخل الملف مباشرة من غير فحص
    // الامتدادات اللي بيحصل بس وقت الرفع اليدوي من واجهة ووردبريس).
    $attachment_id = wp_insert_attachment([
        'post_mime_type' => 'image/svg+xml',
        'post_title'     => 'Saudi Riyal Symbol (SAMA official)',
        'post_status'    => 'inherit',
    ], $upload['file']);

    if (!is_wp_error($attachment_id) && $attachment_id) {
        update_option('pild_sar_symbol_local_url', $upload['url']);
        delete_transient('pild_sar_symbol_retry_lock');
    }
}

// ============================================================
// استبدال رمز العملة في ووكومرس كله (منتجات، سلة، فواتير، كروت
// المتجر...) — بيشتغل بنفس الشكل بالظبط في العربي والإنجليزي، لأن
// الرمز صورة/شعار مش نص، فمفيش "ترجمة" له من الأساس.
// ============================================================
add_filter('woocommerce_currency_symbol', 'pild_sar_symbol_replace', 10, 2);
function pild_sar_symbol_replace($currency_symbol, $currency) {
    if ($currency !== 'SAR') return $currency_symbol;

    $local_url = get_option('pild_sar_symbol_local_url');
    if (!$local_url) $local_url = PILD_SAR_SYMBOL_FALLBACK_URL; // التحميل التلقائي فاضل فاشل عندنا -> نستخدم النسخة اليدوية

    // إرشادات ساما: ارتفاع الرمز يساوي ارتفاع النص المجاور له، ومحاذاة
    // بسيطة على خط الكتابة (vertical-align) عشان يبان متزن مع الرقم.
    return '<img src="' . esc_url($local_url) . '" alt="' . esc_attr__('ريال', 'pild-unified')
         . '" style="height:0.85em;width:auto;vertical-align:-0.05em;display:inline-block;">';
}

// ============================================================
// مكان الرمز بالنسبة للرقم لازم يتغيّر حسب لغة الصفحة، مش يفضل ثابت
// زي ما إعداد ووكومرس العادي (Currency Position) بيعمل. حسب إرشادات
// ساما (لازم مسافة بين الرمز والرقم):
//   - صفحة عربي  -> الرمز يسار الرقم   (مثال: ﷼ 160.00)
//   - صفحة إنجليزي -> الرمز يمين الرقم  (مثال: 160.00 ﷼)
// بنتجاهل إعداد "Currency Position" العادي بتاع ووكومرس هنا، وبس
// لعملة SAR تحديدًا — أي عملة تانية (لو موجودة) بتفضل تاخد إعداد
// ووكومرس العادي زي ما هو.
// ============================================================
add_filter('woocommerce_price_format', 'pild_sar_symbol_price_format', 20, 2);
function pild_sar_symbol_price_format($format, $currency_pos) {
    if (get_woocommerce_currency() !== 'SAR') return $format;

    $is_arabic = false;
    if (function_exists('pll_current_language')) {
        $is_arabic = (pll_current_language() === 'ar');
    } else {
        $is_arabic = is_rtl(); // fallback لو Polylang مش شغال لأي سبب
    }

    // %1$s = الرمز (currency_symbol)، %2$s = الرقم (price_amount)
    return $is_arabic ? '%1$s&nbsp;%2$s' : '%2$s&nbsp;%1$s';
}