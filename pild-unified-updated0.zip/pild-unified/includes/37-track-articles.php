<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 37. TRACK-LINKED ARTICLES — مقالات (post) مرتبطة بمجال (domain) عن
// طريق الكاتوجري (category)، وبتتفتح لأي عضو مسجّل (enrolled, عن طريق
// pild_enrollments) في أي تراك تحت نفس المجال.
// ------------------------------------------------------------
// القاعدة: كاتوجري المقال مش مربوطة بأي مجال -> المقال مجاني، يفتح
// للجميع زي ما هو عادي في ووردبريس. كاتوجري المقال مربوطة بمجال ->
// المقال مقفول إلا لو المستخدم مسجّل دخول ومسجّل (enrolled) في تراك
// واحد على الأقل تحت المجال ده.
//
// الربط كاتوجري <-> مجال بيتخزّن كـ ACF field على شاشة تعديل الكاتوجري
// نفسها (term meta)، بنفس أسلوب حقول domain_sector / track_domain
// الموجودة بالفعل لمتصفح القطاعات (17-sector-explorer.php) — علاقة
// واحد لواحد (كاتوجري <-> مجال واحد)، بالظبط زي كل تراك مربوط بمجال
// واحد بس.
//
// الحماية نفسها بنفس فلسفة إصلاح pild_user_can_access() للبلاي بوك
// (fail-closed): لو فيه مجال مرتبط ومفيش تسجيل فعلي، المحتوى يتقفل،
// مش يتفتح افتراضيًا. مفيش أي اعتماد على WooCommerce Memberships ولا
// أي إضافة تانية — بس pild_enrollments (عن طريق pildcm_is_enrolled()
// الموجودة بالفعل).
// ============================================================


// ============================================================
// 37.1 — ACF: حقل "المجال المرتبط" على شاشة تعديل الكاتوجري (category)
// ============================================================
add_action('acf/include_fields', 'pild_track_articles_acf_fields');
function pild_track_articles_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key'    => 'group_category_domain_link',
        'title'  => 'ربط الكاتوجري بالمجال (مقالات التراكات)',
        'fields' => [
            [
                'key'           => 'field_category_domain',
                'label'         => 'المجال المرتبط',
                'name'          => 'category_domain',
                'type'          => 'post_object',
                'post_type'     => ['domain'],
                'return_format' => 'id',
                'required'      => 0,
                'instructions'  => 'لو اخترت مجال هنا، أي مقال تحت الكاتوجري ده هيتقفل ومش هيفتح إلا لعضو مسجّل في تراك من تراكات المجال ده. سيبها فاضية عشان الكاتوجري يفضل مجاني ومفتوح للجميع.',
            ],
        ],
        'location' => [[['param' => 'taxonomy', 'operator' => '==', 'value' => 'category']]],
    ]);
}


// ============================================================
// 37.2 — Helpers
// ============================================================

// المجال المرتبط بكاتوجري معيّنة (0 لو الكاتوجري مجانية/غير مربوطة).
function pild_get_category_domain_id($term_id) {
    $term_id = (int) $term_id;
    if (!$term_id || !function_exists('get_field')) return 0;
    static $cache = [];
    if (isset($cache[$term_id])) return $cache[$term_id];
    // زي get_field('track_domain', $tid) / get_field('book_domain_term', $pid)
    // في باقي البلاجن بالظبط: بنستخدم اسم الحقل (category_domain)، مش
    // مفتاحه الداخلي (field_category_domain) — ده بالظبط اسم الـ meta_key
    // اللي ACF بيخزّن القيمة تحته فعليًا (شوف 37.4 تحت، نفس المفتاح).
    return $cache[$term_id] = (int) get_field('category_domain', 'category_' . $term_id);
}

// كل تراكات (منشورة) مجال معيّن — نفس العلاقة track_domain المستخدمة في
// متصفح القطاعات (17-sector-explorer.php).
function pild_get_domain_track_ids($domain_id) {
    $domain_id = (int) $domain_id;
    if (!$domain_id) return [];
    static $cache = [];
    if (isset($cache[$domain_id])) return $cache[$domain_id];

    $ids = get_posts([
        'post_type'        => 'track',
        'posts_per_page'   => -1,
        'post_status'      => 'publish',
        'fields'           => 'ids',
        'suppress_filters' => true,
        'meta_key'         => 'track_domain',
        'meta_value'       => $domain_id,
    ]);
    return $cache[$domain_id] = array_map('intval', $ids);
}

// كل المجالات المرتبطة بمقال معيّن (عن طريق كل كاتوجرياته) — مصفوفة
// فريدة من آي ديهات المجالات، فاضية لو المقال مجاني (مفيش أي كاتوجري
// من كاتوجرياته مربوطة بمجال).
function pild_article_domain_ids($post_id) {
    $cats = get_the_category($post_id);
    if (empty($cats)) return [];
    $domain_ids = [];
    foreach ($cats as $cat) {
        $did = pild_get_category_domain_id($cat->term_id);
        if ($did) $domain_ids[$did] = true;
    }
    return array_keys($domain_ids);
}

// هل المستخدم ده يقدر يشوف المقال ده كامل؟ fail-closed: لو فيه مجال
// مرتبط ومفيش تسجيل فعلي في تراك تحته، النتيجة false.
function pild_user_can_access_article($user_id, $post_id) {
    if ($user_id && user_can($user_id, 'manage_options')) return true;

    $domain_ids = pild_article_domain_ids($post_id);
    if (empty($domain_ids)) return true; // مقال مجاني — مفيش كاتوجري مربوطة بمجال

    if (!$user_id) return false;
    if (!function_exists('pildcm_is_enrolled')) return false;

    foreach ($domain_ids as $did) {
        foreach (pild_get_domain_track_ids($did) as $tid) {
            if (pildcm_is_enrolled($user_id, $tid)) return true;
        }
    }
    return false;
}

// أول تراك "تمثيلي" تحت أول مجال مرتبط بالمقال — بيستخدم بس لبناء
// زرار "شوف التراك" في رسالة القفل (pild_restricted_html نوع 'track').
function pild_article_representative_track_id($post_id) {
    foreach (pild_article_domain_ids($post_id) as $did) {
        $tracks = pild_get_domain_track_ids($did);
        if (!empty($tracks)) return (int) $tracks[0];
    }
    return 0;
}


// ============================================================
// 37.3 — الحماية الفعلية على صفحة المقال (the_content)، بنفس أسلوب
// pild_add_complete_button() للبلاي بوك بالظبط: مقال مقفول يعرض
// مقتطف + زرار بدل المحتوى الكامل.
// ============================================================
add_filter('the_content', 'pild_track_articles_gate_content', 20);
function pild_track_articles_gate_content($content) {
    if (!is_singular('post') || !in_the_loop() || !is_main_query()) return $content;

    $post_id = get_the_ID();
    $user_id = get_current_user_id();
    if (pild_user_can_access_article($user_id, $post_id)) return $content;

    $track_id = pild_article_representative_track_id($post_id);
    $type     = $user_id ? 'track' : 'login';
    return function_exists('pild_restricted_html')
        ? pild_restricted_html($type, get_permalink($post_id), $track_id)
        : $content;
}

// المقتطف (الكارت في الأرشيف/القايمة) بيفضل زي ما هو عادي — مش بنمنعه،
// بس بنحط badge "🔒" قبل عنوان أي مقال مقفول في أي عرض list/archive
// عادي للووردبريس، عشان العضو يعرف من الأول قبل ما يدخل.
add_filter('the_title', 'pild_track_articles_lock_badge_title', 10, 2);
function pild_track_articles_lock_badge_title($title, $post_id) {
    if (is_admin() || get_post_type($post_id) !== 'post') return $title;
    // صفحة المقال المفرد نفسها بتوضح الحالة بالفعل في المحتوى -> من غير badge هنا.
    if (is_singular('post') && in_the_loop() && is_main_query()) return $title;

    static $cache = [];
    if (!isset($cache[$post_id])) {
        $cache[$post_id] = !pild_user_can_access_article(get_current_user_id(), $post_id);
    }
    return $cache[$post_id] ? '🔒 ' . $title : $title;
}


// ============================================================
// 37.4 — لوحة العضو: كل المقالات المفتوحة له فعليًا بسبب تسجيله في
// تراك (مش المقالات المجانية العامة — دي من pildcm_get_member_articles()
// الموجودة بالفعل ومنفصلة تمامًا).
// ============================================================
function pildcm_get_member_track_articles($user_id) {
    if (!$user_id) return [];

    global $wpdb;
    $track_ids = array_map('intval', (array) $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT track_id FROM {$wpdb->prefix}pild_enrollments WHERE user_id=%d AND status='active'",
        $user_id
    )));
    if (empty($track_ids)) return [];

    // تراك -> مجاله (علاقة track_domain)، مجموعة فريدة من المجالات.
    $domain_ids = [];
    foreach ($track_ids as $tid) {
        $did = (int) get_post_meta($tid, 'track_domain', true);
        if ($did) $domain_ids[$did] = true;
    }
    if (empty($domain_ids)) return [];

    // كل الكاتوجريهات المربوطة بأي مجال من المجالات دي. meta_key هنا هو
    // اسم الحقل 'category_domain' (مش مفتاحه الداخلي) — نفس الملاحظة في
    // pild_get_category_domain_id() فوق بالظبط.
    $placeholders = implode(',', array_fill(0, count($domain_ids), '%d'));
    $term_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT tm.term_id FROM {$wpdb->termmeta} tm
         INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = tm.term_id AND tt.taxonomy = 'category'
         WHERE tm.meta_key = 'category_domain' AND tm.meta_value IN ($placeholders)",
        array_keys($domain_ids)
    ));
    if (empty($term_ids)) return [];

    return get_posts([
        'post_type'      => 'post',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'category__in'   => array_map('intval', $term_ids),
    ]);
}
