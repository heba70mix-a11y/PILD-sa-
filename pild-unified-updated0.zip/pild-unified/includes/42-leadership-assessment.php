<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// 42. LEADERSHIP ASSESSMENT (free, self-report, sector-aware)
// ============================================================
// Self-contained module — everything it needs lives in this one file
// plus includes/data/leadership/ (bundled JSON question bank) and
// assets/leadership-assessment.js (front-end wizard). It only touches
// two other files in the whole plugin:
//   - pild-unified.php   -> one line added to $pild_modules
//   - 06-dashboard-solo.php -> two new tabs added (clearly marked blocks)
// Kept isolated on purpose: this plugin build has book-store/articles
// work happening in parallel elsewhere, so this module avoids editing
// any file that other work is likely to touch, and uses its own
// pild_la_* / wp_pild_la_* namespace throughout (no shared tables).
//
// NOTE ON DATA MODEL: this is a self-report psychometric instrument
// (Likert 1–5 across 8 weighted competencies -> an "archetype" + a
// recommended development track), not a pass/fail knowledge exam —
// there is no "correct answer" to hide from the browser, which is why
// this module does its own lightweight session/scoring instead of
// reusing includes/28-quiz-engine.php (built for graded course exams
// with a real question bank, anti-cheat draw locking and certificates).
// ============================================================

define('PILD_LA_DATA_PATH', PILD_PATH . 'includes/data/leadership/');
define('PILD_LA_DB_VERSION', '1.0');


/* ============================================================
   A. DB INSTALL (self-healing — safe to run on every load)
   ============================================================ */

add_action('plugins_loaded', 'pild_la_maybe_install');
function pild_la_maybe_install() {
    if (get_option('pild_la_schema_version') === PILD_LA_DB_VERSION) return;
    pild_la_install();
    update_option('pild_la_schema_version', PILD_LA_DB_VERSION);
}

function pild_la_install() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();

    // One row per completed assessment. Kept append-only (a retake inserts a
    // new row) so a member's/manager's history isn't lost on retake; the
    // dashboard always reads the most recent row per user.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_la_results (
        id                   bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        user_id              bigint(20) unsigned NOT NULL,
        category_id          varchar(60)  DEFAULT '',
        category_label       varchar(190) DEFAULT '',
        sector_id            varchar(90)  DEFAULT '',
        sector_label         varchar(190) DEFAULT '',
        goal_id              varchar(60)  DEFAULT '',
        goal_label           varchar(190) DEFAULT '',
        competency_scores    longtext,
        total_score          int(11)      DEFAULT 0,
        archetype_id         varchar(60)  DEFAULT '',
        consistency_penalty  decimal(3,2) DEFAULT 1.00,
        answered_count       int(11)      DEFAULT 0,
        total_questions      int(11)      DEFAULT 0,
        completed_at         datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_idx (user_id)
    ) $c;");

    // In-progress attempt: the exact question set drawn for this user is
    // stored server-side the moment they start, so submit() grades against
    // what was actually served (not whatever the browser sends back) and a
    // page refresh mid-assessment can resume instead of losing progress.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_la_attempts (
        id                bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        user_id           bigint(20) unsigned NOT NULL,
        category_id       varchar(60)  DEFAULT '',
        category_label    varchar(190) DEFAULT '',
        sector_id         varchar(90)  DEFAULT '',
        sector_label      varchar(190) DEFAULT '',
        goal_id           varchar(60)  DEFAULT '',
        goal_label         varchar(190) DEFAULT '',
        question_payload  longtext,
        created_at        datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_idx (user_id)
    ) $c;");

    // Independent free invite system (deliberately NOT reusing pild_teams /
    // pild_team_members — those only exist off the back of a paid seat
    // purchase; this one lets ANY registered member invite colleagues to
    // take the free assessment, with no purchase involved). One free team
    // per manager keeps the model simple for v1.
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_la_teams (
        id           bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        owner_id     bigint(20) unsigned NOT NULL,
        name         varchar(190) DEFAULT '',
        created_at   datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY owner_idx (owner_id)
    ) $c;");

    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_la_team_members (
        id           bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        team_id      bigint(20) unsigned NOT NULL,
        user_id      bigint(20) unsigned DEFAULT 0,
        email        varchar(190) NOT NULL,
        token        varchar(64)  NOT NULL,
        status       varchar(20)  DEFAULT 'invited',
        invited_at   datetime DEFAULT CURRENT_TIMESTAMP,
        joined_at    datetime DEFAULT NULL,
        PRIMARY KEY (id),
        KEY team_idx (team_id),
        KEY token_idx (token),
        KEY user_idx (user_id)
    ) $c;");
}


/* ============================================================
   B. DATA LOADING (bundled JSON question bank)
   ============================================================ */

function pild_la_load_json($relative_path) {
    static $cache = [];
    if (isset($cache[$relative_path])) return $cache[$relative_path];
    $file = PILD_LA_DATA_PATH . $relative_path;
    if (!file_exists($file)) return $cache[$relative_path] = [];
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    return $cache[$relative_path] = (is_array($data) ? $data : []);
}

function pild_la_get_config()       { $d = pild_la_load_json('config.json');       return $d ?: []; }
function pild_la_get_competencies() { $d = pild_la_load_json('competencies.json'); return $d['competencies'] ?? []; }
function pild_la_get_categories()   { $d = pild_la_load_json('categories.json');   return $d['categories']   ?? []; }
function pild_la_get_goals()        { $d = pild_la_load_json('goals.json');        return $d['goals']        ?? []; }
function pild_la_get_archetypes()   { $d = pild_la_load_json('archetypes.json');   return $d['archetypes']   ?? []; }
function pild_la_get_tracks()       { $d = pild_la_load_json('tracks.json');       return $d['tracks']       ?? []; }

function pild_la_find_category($category_id) {
    foreach (pild_la_get_categories() as $c) if ($c['id'] === $category_id) return $c;
    return null;
}
function pild_la_find_sector($category_id, $sector_id) {
    $cat = pild_la_find_category($category_id);
    if (!$cat) return null;
    foreach (($cat['sectors'] ?? []) as $s) if ($s['id'] === $sector_id) return $s;
    return null;
}
function pild_la_find_goal($goal_id) {
    foreach (pild_la_get_goals() as $g) if ($g['id'] === $goal_id) return $g;
    return null;
}

function pild_la_get_general_questions() {
    $out = [];
    foreach (pild_la_get_competencies() as $comp) {
        if (empty($comp['questionFile'])) continue;
        $d = pild_la_load_json('questions/' . $comp['questionFile']);
        foreach (($d['questions'] ?? []) as $q) { $q['questionType'] = 'general'; $out[] = $q; }
    }
    return $out;
}
function pild_la_get_category_questions($category_id) {
    $d = pild_la_load_json("questions/categories/{$category_id}.json");
    $out = [];
    foreach (($d['questions'] ?? []) as $q) { $q['questionType'] = 'category'; $out[] = $q; }
    return $out;
}
function pild_la_get_sector_questions($category_id, $sector_id) {
    $d = pild_la_load_json("questions/sectors/{$category_id}/{$sector_id}.json");
    $out = [];
    foreach (($d['questions'] ?? []) as $q) { $q['questionType'] = 'sector'; $out[] = $q; }
    return $out;
}
function pild_la_get_consistency_questions() {
    $d = pild_la_load_json('questions/consistency.json');
    $out = [];
    foreach (($d['questions'] ?? []) as $q) { $q['questionType'] = 'consistency'; $out[] = $q; }
    return $out;
}


/* ============================================================
   C. SESSION BUILDER (server-side draw — mirrors the original
      static site's buildSession(), ported from JS to PHP so the
      drawn set can be locked server-side against tampering)
   ============================================================ */

function pild_la_sample($arr, $n) {
    if (count($arr) <= $n) { $out = $arr; shuffle($out); return $out; }
    $keys = array_rand($arr, $n);
    if (!is_array($keys)) $keys = [$keys];
    $picked = array_map(function($k) use ($arr) { return $arr[$k]; }, $keys);
    shuffle($picked);
    return $picked;
}

function pild_la_build_session($category_id, $sector_id) {
    $cfg = pild_la_get_config();
    $counts = $cfg['questionCounts'] ?? [
        'general'     => 24,
        'category'    => 4,
        'sector'      => 4,
        'consistency' => 4,
    ];

    $general     = pild_la_sample(pild_la_get_general_questions(), $counts['general']);
    $category    = pild_la_sample(pild_la_get_category_questions($category_id), $counts['category']);
    $sector      = pild_la_sample(pild_la_get_sector_questions($category_id, $sector_id), $counts['sector']);
    $consistency = pild_la_sample(pild_la_get_consistency_questions(), $counts['consistency']);

    $main = array_merge($general, $category, $sector);
    shuffle($main);

    // Interleave consistency-check questions at roughly even intervals
    // through the main set, same spacing logic as the original static site.
    $questions = $main;
    if (!empty($consistency)) {
        $step = max(1, (int) floor(count($main) / (count($consistency) + 1)));
        $offset = 0;
        foreach ($consistency as $i => $cq) {
            $pos = min(count($questions), $step * ($i + 1) + $offset);
            array_splice($questions, $pos, 0, [$cq]);
            $offset++;
        }
    }

    // Re-key ids to guarantee uniqueness even if two sampled questions from
    // different pools happened to reuse the same source id.
    foreach ($questions as $i => &$q) {
        $q['session_id'] = $q['questionType'] . '_' . $i . '_' . ($q['id'] ?? $i);
    }
    unset($q);

    return $questions;
}


/* ============================================================
   D. SCORING ENGINE (ported from score-calculator.js)
   ============================================================ */

function pild_la_calculate($answers, $questions) {
    // $answers: [ session_id => value(1-5) ]
    // $questions: the locked server-side set (from the attempt row)
    $weights = [];
    foreach (pild_la_get_competencies() as $c) $weights[$c['id']] = floatval($c['weight'] ?? 1);

    $raw = []; $counts = [];
    $consistency_vals = [];

    foreach ($questions as $q) {
        $sid = $q['session_id'];
        if (!isset($answers[$sid])) continue;
        $val = max(1, min(5, intval($answers[$sid])));

        if ($q['questionType'] === 'consistency') {
            $consistency_vals[] = $val;
            continue;
        }
        $comp = $q['competency'] ?? '';
        if ($comp === '') continue;
        $raw[$comp]    = ($raw[$comp]    ?? 0) + $val;
        $counts[$comp] = ($counts[$comp] ?? 0) + 1;
    }

    $competency_scores = [];
    foreach (pild_la_get_competencies() as $c) {
        $cid = $c['id'];
        $n = $counts[$cid] ?? 0;
        $sum = $raw[$cid] ?? 0;
        $pct = $n > 0 ? round(($sum / ($n * 5)) * 100) : 0;
        $competency_scores[$cid] = [
            'raw'         => $sum,
            'answerCount' => $n,
            'percentage'  => $pct,
        ];
    }

    // Consistency penalty: lower variance across the consistency-check
    // answers = more consistent = closer to a 1.0 multiplier.
    $penalty = 1.0;
    if (count($consistency_vals) >= 2) {
        $mean = array_sum($consistency_vals) / count($consistency_vals);
        $variance = 0;
        foreach ($consistency_vals as $v) $variance += pow($v - $mean, 2);
        $variance /= count($consistency_vals);
        // variance 0 -> 1.00 ; variance >= 4 (max spread on a 1-5 scale) -> 0.85 floor
        $penalty = max(0.85, 1 - ($variance / 4) * 0.15);
    }

    // Weighted total (0-100)
    $wsum = 0; $wmax = 0;
    foreach ($competency_scores as $cid => $s) {
        $w = $weights[$cid] ?? 1;
        $wsum += $s['percentage'] * $w;
        $wmax += 100 * $w;
    }
    $total_score = $wmax > 0 ? round(($wsum / $wmax) * 100 * $penalty) : 0;

    // Archetype: top 2 competencies by percentage
    $sorted = $competency_scores;
    uasort($sorted, function($a, $b) { return $b['percentage'] <=> $a['percentage']; });
    $ids = array_keys($sorted);
    $top1 = $ids[0] ?? '';
    $top2 = $ids[1] ?? '';

    $archetype = null;
    foreach (pild_la_get_archetypes() as $a) {
        if ($a['dominant1'] === $top1 && $a['dominant2'] === $top2) { $archetype = $a; break; }
    }
    if (!$archetype) {
        foreach (pild_la_get_archetypes() as $a) {
            if ($a['dominant1'] === $top1) { $archetype = $a; break; }
        }
    }
    if (!$archetype) $archetype = (pild_la_get_archetypes()[0] ?? null);

    return [
        'competencyScores'   => $competency_scores,
        'totalScore'         => $total_score,
        'consistencyPenalty' => round($penalty, 2),
        'archetype'          => $archetype,
        'answeredCount'      => array_sum($counts) + count($consistency_vals),
        'totalQuestions'     => count($questions),
    ];
}


/* ============================================================
   E. AJAX HANDLERS
   ============================================================ */

add_action('wp_ajax_pild_la_get_intro', 'pild_la_ajax_get_intro');
function pild_la_ajax_get_intro() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    wp_send_json_success([
        'categories' => pild_la_get_categories(),
        'goals'      => pild_la_get_goals(),
    ]);
}

add_action('wp_ajax_pild_la_start', 'pild_la_ajax_start');
function pild_la_ajax_start() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $user_id = get_current_user_id();

    $category_id = sanitize_text_field($_POST['category_id'] ?? '');
    $sector_id   = sanitize_text_field($_POST['sector_id']   ?? '');
    $goal_id     = sanitize_text_field($_POST['goal_id']     ?? '');

    $cat  = pild_la_find_category($category_id);
    $sec  = pild_la_find_sector($category_id, $sector_id);
    $goal = pild_la_find_goal($goal_id);
    if (!$cat || !$sec || !$goal) wp_send_json_error('Invalid selection');

    $questions = pild_la_build_session($category_id, $sector_id);
    if (empty($questions)) wp_send_json_error('Could not build assessment — please try again');

    global $wpdb;
    // One in-progress attempt per user: replace any stale one.
    $wpdb->delete("{$wpdb->prefix}pild_la_attempts", ['user_id' => $user_id]);
    $wpdb->insert("{$wpdb->prefix}pild_la_attempts", [
        'user_id'          => $user_id,
        'category_id'      => $category_id,
        'category_label'   => $cat['label_ar'] ?? '',
        'sector_id'        => $sector_id,
        'sector_label'     => $sec['label_ar'] ?? '',
        'goal_id'          => $goal_id,
        'goal_label'       => $goal['label_ar'] ?? '',
        'question_payload' => wp_json_encode($questions),
        'created_at'       => current_time('mysql'),
    ]);
    $attempt_id = $wpdb->insert_id;

    // Strip nothing here — there is no "correct answer" field on these
    // questions (self-report Likert scale), so the full option set the
    // client needs to render is safe to send as-is.
    wp_send_json_success([
        'attempt_id' => $attempt_id,
        'questions'  => $questions,
    ]);
}

add_action('wp_ajax_pild_la_submit', 'pild_la_ajax_submit');
function pild_la_ajax_submit() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $user_id = get_current_user_id();

    $attempt_id = intval($_POST['attempt_id'] ?? 0);
    $answers_raw = isset($_POST['answers']) ? wp_unslash($_POST['answers']) : '{}';
    $answers = json_decode(is_array($answers_raw) ? wp_json_encode($answers_raw) : $answers_raw, true);
    if (!is_array($answers)) $answers = [];
    $answers = array_map('intval', $answers);

    global $wpdb;
    $attempt = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_la_attempts WHERE id=%d AND user_id=%d",
        $attempt_id, $user_id
    ));
    if (!$attempt) wp_send_json_error('Assessment session not found or expired — please start again');

    $questions = json_decode($attempt->question_payload, true);
    if (!is_array($questions) || empty($questions)) wp_send_json_error('Assessment data corrupted — please start again');

    $result = pild_la_calculate($answers, $questions);

    $wpdb->insert("{$wpdb->prefix}pild_la_results", [
        'user_id'             => $user_id,
        'category_id'         => $attempt->category_id,
        'category_label'      => $attempt->category_label,
        'sector_id'           => $attempt->sector_id,
        'sector_label'        => $attempt->sector_label,
        'goal_id'             => $attempt->goal_id,
        'goal_label'          => $attempt->goal_label,
        'competency_scores'   => wp_json_encode($result['competencyScores']),
        'total_score'         => $result['totalScore'],
        'archetype_id'        => $result['archetype']['id'] ?? '',
        'consistency_penalty' => $result['consistencyPenalty'],
        'answered_count'      => $result['answeredCount'],
        'total_questions'     => $result['totalQuestions'],
        'completed_at'        => current_time('mysql'),
    ]);
    $result_id = $wpdb->insert_id;

    $wpdb->delete("{$wpdb->prefix}pild_la_attempts", ['id' => $attempt_id]);

    wp_send_json_success([
        'result_id' => $result_id,
        'html'      => pild_la_render_result_card($user_id, true),
    ]);
}

add_action('wp_ajax_pild_la_invite', 'pild_la_ajax_invite');
function pild_la_ajax_invite() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $owner_id = get_current_user_id();
    $email = sanitize_email($_POST['email'] ?? '');
    if (!$email || !is_email($email)) wp_send_json_error('Please enter a valid email address');

    global $wpdb;
    $team_id = pild_la_get_or_create_team($owner_id);

    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_la_team_members WHERE team_id=%d AND email=%s",
        $team_id, $email
    ));
    if ($existing) wp_send_json_error('This email has already been invited');

    $token = wp_generate_password(32, false, false);
    $wpdb->insert("{$wpdb->prefix}pild_la_team_members", [
        'team_id'    => $team_id,
        'user_id'    => 0,
        'email'      => $email,
        'token'      => $token,
        'status'     => 'invited',
        'invited_at' => current_time('mysql'),
    ]);

    pild_la_send_invite_email($owner_id, $email, $token);

    wp_send_json_success([
        'html' => pild_la_render_team_members_table($owner_id),
    ]);
}

add_action('wp_ajax_pild_la_remove_member', 'pild_la_ajax_remove_member');
function pild_la_ajax_remove_member() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $owner_id = get_current_user_id();
    $member_row_id = intval($_POST['member_id'] ?? 0);

    global $wpdb;
    $team = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pild_la_teams WHERE owner_id=%d", $owner_id));
    if (!$team) wp_send_json_error('No team found');

    $wpdb->delete("{$wpdb->prefix}pild_la_team_members", ['id' => $member_row_id, 'team_id' => $team->id]);

    wp_send_json_success(['html' => pild_la_render_team_members_table($owner_id)]);
}

add_action('wp_ajax_pild_la_get_member_report', 'pild_la_ajax_get_member_report');
function pild_la_ajax_get_member_report() {
    check_ajax_referer('pild_la_nonce', 'nonce');
    if (!is_user_logged_in()) wp_send_json_error('Not logged in');
    $owner_id = get_current_user_id();
    $target_user_id = intval($_POST['user_id'] ?? 0);

    global $wpdb;
    $team = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pild_la_teams WHERE owner_id=%d", $owner_id));
    if (!$team) wp_send_json_error('No team found');
    $is_member = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_la_team_members WHERE team_id=%d AND user_id=%d",
        $team->id, $target_user_id
    ));
    if (!$is_member) wp_send_json_error('Not authorized to view this report');

    wp_send_json_success(['html' => pild_la_render_result_card($target_user_id, false)]);
}


/* ============================================================
   F. INVITE ACCEPTANCE (email link -> register/login -> auto-join)
   ============================================================ */

add_action('init', 'pild_la_handle_invite_link');
function pild_la_handle_invite_link() {
    if (empty($_GET['pild_la_join'])) return;
    $token = sanitize_text_field($_GET['pild_la_join']);

    if (!is_user_logged_in()) {
        // Remember the token across the registration/login round trip.
        setcookie('pild_la_pending_join', $token, time() + 3600 * 24, COOKIEPATH ?: '/', COOKIE_DOMAIN);
        $account_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : wp_login_url();

        // If the invite link already points at (or was already redirected
        // to) the account/login page itself, redirecting again would just
        // send the still-logged-out visitor back to the same URL forever
        // (ERR_TOO_MANY_REDIRECTS) — the account page needs to actually
        // render so they can log in or register. The cookie above already
        // carries the token forward; pild_la_handle_pending_join_cookie()
        // picks it up on the next request once they're logged in.
        $current_path = untrailingslashit(strtok(esc_url_raw($_SERVER['REQUEST_URI'] ?? ''), '?'));
        $account_path = $account_url ? untrailingslashit((string) wp_parse_url($account_url, PHP_URL_PATH)) : '';
        if ($account_path !== '' && $current_path === $account_path) {
            return;
        }

        wp_safe_redirect(add_query_arg('pild_la_join', $token, $account_url));
        exit;
    }

    pild_la_consume_join_token($token);
}

// Also catches the case where the cookie survived a login/registration
// that landed the member back on My Account without the token in the URL.
add_action('template_redirect', 'pild_la_handle_pending_join_cookie', 20);
function pild_la_handle_pending_join_cookie() {
    if (!is_user_logged_in() || empty($_COOKIE['pild_la_pending_join'])) return;
    $token = sanitize_text_field($_COOKIE['pild_la_pending_join']);
    setcookie('pild_la_pending_join', '', time() - 3600, COOKIEPATH ?: '/', COOKIE_DOMAIN);
    pild_la_consume_join_token($token);
}

function pild_la_consume_join_token($token) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_la_team_members WHERE token=%s AND status='invited'",
        $token
    ));
    if (!$row) return;
    $wpdb->update("{$wpdb->prefix}pild_la_team_members", [
        'user_id'   => get_current_user_id(),
        'status'    => 'joined',
        'joined_at' => current_time('mysql'),
    ], ['id' => $row->id]);
}


/* ============================================================
   G. TEAM / EMAIL HELPERS
   ============================================================ */

function pild_la_get_or_create_team($owner_id) {
    global $wpdb;
    $team_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}pild_la_teams WHERE owner_id=%d", $owner_id));
    if ($team_id) return (int) $team_id;
    $owner = get_userdata($owner_id);
    $wpdb->insert("{$wpdb->prefix}pild_la_teams", [
        'owner_id'   => $owner_id,
        'name'       => ($owner ? $owner->display_name : '') . ' — Team',
        'created_at' => current_time('mysql'),
    ]);
    return (int) $wpdb->insert_id;
}

function pild_la_get_team_members($owner_id) {
    global $wpdb;
    $team = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pild_la_teams WHERE owner_id=%d", $owner_id));
    if (!$team) return [];
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_la_team_members WHERE team_id=%d ORDER BY invited_at DESC",
        $team->id
    ));
}

function pild_la_send_invite_email($owner_id, $email, $token) {
    $owner = get_userdata($owner_id);
    $join_url = add_query_arg('pild_la_join', $token, home_url('/'));
    $manager_name = $owner ? $owner->display_name : __('A colleague', 'pild-unified');

    $heading = sprintf(__('%s invited you to take the Leadership Assessment', 'pild-unified'), $manager_name);
    $body = '<p>' . sprintf(
        esc_html__('%s has invited you to take PILD\'s free Leadership Assessment — an 8-competency self-assessment that gives you a personalized leadership profile in about 20 minutes.', 'pild-unified'),
        esc_html($manager_name)
    ) . '</p>';

    wp_mail(
        $email,
        $heading,
        pild_email_html($heading, $body, __('Start the Assessment', 'pild-unified'), $join_url),
        pild_email_headers()
    );
}


/* ============================================================
   H. RESULT LOOKUP
   ============================================================ */

function pild_la_get_latest_result($user_id) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}pild_la_results WHERE user_id=%d ORDER BY completed_at DESC LIMIT 1",
        $user_id
    ));
    if (!$row) return null;
    $row->competency_scores = json_decode($row->competency_scores, true) ?: [];
    return $row;
}


/* ============================================================
   H2. LANGUAGE (Polylang-aware — same pattern as includes/17-sector-
       explorer.php's $is_en/$dir). The bundled JSON question bank
       already carries a full _en counterpart for every _ar field
       (label_en, text_en, options_en, description_en, strengths_en,
       activities_en…), so this only has to (a) pick which of the two
       is read at render time, and (b) translate the handful of fixed
       UI-chrome strings that aren't part of the data.
   ============================================================ */

function pild_la_is_en() {
    if (function_exists('pll_current_language')) {
        $lang = pll_current_language();
        if ($lang) return $lang === 'en';
    }
    return false;
}
function pild_la_dir($is_en = null) {
    if ($is_en === null) $is_en = pild_la_is_en();
    return $is_en ? 'ltr' : 'rtl';
}
// Same value 1-5 questions get a different *widget* per position purely
// for variety (see assets/leadership-assessment.js) — the arrow glyph on
// the two "next" buttons just needs to point the way the wizard advances
// for the current text direction.
function pild_la_next_arrow($is_en = null) {
    if ($is_en === null) $is_en = pild_la_is_en();
    return $is_en ? '→' : '←';
}
// label_ar/description_ar/etc. with an _en counterpart -> pick by language,
// always falling back to whichever of the two is actually present.
function pild_la_field($item, $base, $is_en = null) {
    if (!is_array($item)) return '';
    if ($is_en === null) $is_en = pild_la_is_en();
    if ($is_en) return $item[$base . '_en'] ?? $item[$base . '_ar'] ?? '';
    return $item[$base . '_ar'] ?? $item[$base . '_en'] ?? '';
}

function pild_la_strings($is_en = null) {
    if ($is_en === null) $is_en = pild_la_is_en();
    $strings = [
        'ar' => [
            'platform_tag'      => 'Leadership Intelligence Platform',
            'welcome_sub'       => 'منصة التوجيه القيادي الذكي',
            'welcome_title_1'   => 'اكتشف',
            'welcome_title_accent' => 'نمطك القيادي',
            'welcome_title_2'   => 'وابنِ مستقبلك',
            'welcome_desc_1'    => 'تقييم علمي شامل يقيس',
            'welcome_desc_comps'=> '8 كفاءات قيادية',
            'welcome_desc_2'    => 'عبر',
            'welcome_desc_qs'   => '36 سؤالاً',
            'welcome_desc_3'    => 'مُصممة خصيصاً لقطاعك وفئتك المهنية. يستغرق التقييم بين 18 و22 دقيقة فقط.',
            'stat_questions'    => 'سؤالاً مخصصاً',
            'stat_competencies' => 'كفاءات قيادية',
            'stat_sectors'      => 'قطاعاً مهنياً',
            'stat_minutes'      => 'دقيقة متوسطاً',
            'start_btn'         => 'ابدأ التقييم',
            'choose_category'   => 'اختر فئتك المهنية',
            'what_is_your'      => 'ما هو',
            'work_sector'       => 'قطاع عملك',
            'sectors_suffix'    => 'قطاع',
            'back'              => 'رجوع',
            'pin_your_sector'   => 'حدِّد قطاعك بدقة',
            'assessment_goal'   => 'ما هو هدفك من هذا التقييم؟',
            'start_now_btn'     => 'ابدأ التقييم الآن',
            'no_result_yet'     => 'لا توجد نتيجة تقييم بعد.',
            'out_of_100'        => 'من 100',
            'questions_answered'=> 'سؤالاً أجبتَ عليها',
            'assessment_date'   => 'تاريخ التقييم',
            'recommended_track' => 'المسار الموصى به:',
            'retake_btn'        => 'إعادة التقييم',
            'invite_team_title' => 'ادعُ فريقك',
            'invite_team_desc'  => 'ادعُ زملاءك لأخذ التقييم القيادي المجاني وتابع نتائجهم هنا.',
            'send_invite_btn'   => 'إرسال دعوة',
            'no_invites_yet'    => 'لم تُرسل أي دعوة بعد. أضف بريد زميلك الإلكتروني أعلاه لإرسال أول دعوة.',
            'th_email'          => 'الإيميل',
            'th_status'         => 'الحالة',
            'th_result'         => 'النتيجة',
            'status_completed'  => 'أكمل التقييم',
            'status_registered' => 'سجّل، لم يبدأ',
            'status_invited'    => 'مدعو',
            'view_report_btn'   => 'عرض التقرير',
            'please_login_assessment' => 'برجاء تسجيل الدخول لأخذ التقييم القيادي.',
            'please_login'      => 'برجاء تسجيل الدخول.',
            'tab_label'         => 'التقييم القيادي',
            'panel_desc'        => 'ملفك القيادي الشخصي المجاني',
            'team_tab_label'    => 'فريقي',
            'team_panel_desc'   => 'ادعُ زملاءك لأخذ التقييم القيادي المجاني وتابع نتائجهم من هنا',
        ],
        'en' => [
            'platform_tag'      => 'Leadership Intelligence Platform',
            'welcome_sub'       => 'The Smart Leadership Guidance Platform',
            'welcome_title_1'   => 'Discover',
            'welcome_title_accent' => 'your leadership style',
            'welcome_title_2'   => 'and build your future',
            'welcome_desc_1'    => 'A comprehensive scientific assessment measuring',
            'welcome_desc_comps'=> '8 leadership competencies',
            'welcome_desc_2'    => 'across',
            'welcome_desc_qs'   => '36 questions',
            'welcome_desc_3'    => 'tailored to your sector and professional category. The assessment takes only 18–22 minutes.',
            'stat_questions'    => 'tailored questions',
            'stat_competencies' => 'leadership competencies',
            'stat_sectors'      => 'professional sectors',
            'stat_minutes'      => 'minutes on average',
            'start_btn'         => 'Start the Assessment',
            'choose_category'   => 'Choose your professional category',
            'what_is_your'      => 'What is your',
            'work_sector'       => 'work sector',
            'sectors_suffix'    => 'sectors',
            'back'              => 'Back',
            'pin_your_sector'   => 'Pinpoint your sector',
            'assessment_goal'   => 'What is your goal for this assessment?',
            'start_now_btn'     => 'Start the Assessment Now',
            'no_result_yet'     => 'No assessment result yet.',
            'out_of_100'        => 'out of 100',
            'questions_answered'=> 'questions answered',
            'assessment_date'   => 'Assessment date',
            'recommended_track' => 'Recommended track:',
            'retake_btn'        => 'Retake the Assessment',
            'invite_team_title' => 'Invite Your Team',
            'invite_team_desc'  => 'Invite colleagues to take the free leadership assessment and track their results here.',
            'send_invite_btn'   => 'Send Invite',
            'no_invites_yet'    => 'No invites sent yet. Add a colleague\'s email above to send the first one.',
            'th_email'          => 'Email',
            'th_status'         => 'Status',
            'th_result'         => 'Result',
            'status_completed'  => 'Completed',
            'status_registered' => 'Registered, not started',
            'status_invited'    => 'Invited',
            'view_report_btn'   => 'View Report',
            'please_login_assessment' => 'Please log in to take the Leadership Assessment.',
            'please_login'      => 'Please log in.',
            'tab_label'         => 'Leadership Assessment',
            'panel_desc'        => 'Your free personal leadership profile',
            'team_tab_label'    => 'My Team',
            'team_panel_desc'   => 'Invite colleagues to take the free leadership assessment and track their results here',
        ],
    ];
    return $strings[$is_en ? 'en' : 'ar'];
}



/* ============================================================
   H3. ICONS — classic line icons (inline SVG, currentColor) that
       replace the emoji the tool used before. One place to change
       any glyph; the JS side receives the same map via PILD_LA.icons.
   ============================================================ */
function pild_la_icon_paths() {
    return [
        'landmark'  => '<line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="11"/><line x1="10" x2="10" y1="18" y2="11"/><line x1="14" x2="14" y1="18" y2="11"/><line x1="18" x2="18" y1="18" y2="11"/><polygon points="12 2 20 7 4 7"/>',
        'building'  => '<rect x="4" y="2" width="16" height="20" rx="1"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M16 14h.01"/>',
        'briefcase' => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
        'heart'     => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
        'leaf'      => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
        'share'     => '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
        'settings'  => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
        'layers'    => '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
        'globe'     => '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
        'sprout'    => '<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
        'trending'  => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'repeat'    => '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
        'target'    => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
        'users'     => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'award'     => '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
        'compass'   => '<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
        'zap'       => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        'bars'      => '<line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>',
        'shield'    => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
        'rocket'    => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
        'clipboard' => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4M12 16h4M8 11h.01M8 16h.01"/>',
        'bulb'      => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
        'clock'     => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'calendar'  => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'folder'    => '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
        'book'      => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
        'tag'       => '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".6"/>',
        'search'    => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        'sliders'   => '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
        'list'      => '<line x1="10" x2="21" y1="6" y2="6"/><line x1="10" x2="21" y1="12" y2="12"/><line x1="10" x2="21" y1="18" y2="18"/><path d="M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',
        'user'      => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'check'     => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
        'pin'       => '<line x1="12" x2="12" y1="17" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"/>',
        'grip'      => '<circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/>',
    ];
}
function pild_la_svg($name) {
    $p = pild_la_icon_paths();
    $inner = $p[$name] ?? $p['target'];
    return '<svg class="la-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $inner . '</svg>';
}
// data-record id -> icon (the JSON records still carry their old emoji
// in "icon"; that field is simply no longer displayed).
function pild_la_icon_for($kind, $id) {
    static $map = [
        'category'  => ['government'=>'landmark','semi_government'=>'building','private'=>'briefcase','nonprofit'=>'heart','civil_society'=>'leaf','cooperative'=>'share','public_services'=>'settings','infrastructure'=>'layers','international'=>'globe'],
        'goal'      => ['self_development'=>'sprout','promotion'=>'trending','career_change'=>'repeat','candidate_assessment'=>'target','team_development'=>'users','leadership_program'=>'award'],
        'archetype' => ['strategic_leader'=>'compass','executive_leader'=>'zap','human_leader'=>'heart','analytical_leader'=>'bars','crisis_leader'=>'shield','transformational_leader'=>'rocket'],
    ];
    return pild_la_svg($map[$kind][$id] ?? 'target');
}
// Column count that spreads N cards over full, even rows (max 5 per
// row): 6 -> 3+3, 8 -> 4+4, 9 -> 3+3+3, 7 -> 4+3. Same rule as gridCols()
// in leadership-assessment.js, which sizes the sector grid.
function pild_la_grid_cols($n) {
    $n = max(1, (int) $n);
    if ($n <= 5) return $n;
    $best = 5; $best_empty = (5 - $n % 5) % 5;
    for ($k = 4; $k >= 3; $k--) {
        $e = ($k - $n % $k) % $k;
        if ($e < $best_empty) { $best = $k; $best_empty = $e; }
    }
    return $best;
}
function pild_la_icons_for_js() {
    $out = [];
    foreach (['sliders','list','user','check','target','pin','grip'] as $n) $out[$n] = pild_la_svg($n);
    return $out;
}

/* ============================================================
   I. ASSETS
   ============================================================ */
// Deliberately NOT hooked to the site-wide 'wp_enqueue_scripts' action —
// that would load this module's CSS/JS/Google Font on every single
// front-end page for every logged-in visitor, whether or not the
// assessment ever appears there. Instead pild_la_enqueue_assets() is
// called directly, once, from inside each render function below
// (pild_la_render_assessment_tab / pild_la_render_team_tab — the only
// two places this module's markup is ever output), the same pattern
// already used for pildcm-js in 06-dashboard-solo.php. This keeps the
// module fully self-isolated: nothing it loads ever reaches a page
// that doesn't actually contain it.
function pild_la_asset_ver($relative_path) {
    $full = PILD_PATH . $relative_path;
    return file_exists($full) ? (string) filemtime($full) : PILD_LA_DB_VERSION;
}

function pild_la_enqueue_assets() {
    static $done = false;
    if ($done) return; // safe to call from both render functions on the same page
    $done = true;

    if (!is_user_logged_in()) return;
    wp_enqueue_style('pild-la-font', 'https://fonts.googleapis.com/css2?family=El+Messiri:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap', [], null);
    wp_enqueue_style('pild-la', PILD_URL . 'assets/leadership-assessment.css', [], pild_la_asset_ver('assets/leadership-assessment.css'));
    wp_register_script('pild-la', PILD_URL . 'assets/leadership-assessment.js', ['jquery'], pild_la_asset_ver('assets/leadership-assessment.js'), true);
    $is_en = pild_la_is_en();
    wp_localize_script('pild-la', 'PILD_LA', [
        'ajaxUrl'      => admin_url('admin-ajax.php'),
        'nonce'        => wp_create_nonce('pild_la_nonce'),
        'isEn'         => $is_en,
        'cssUrl'       => PILD_URL . 'assets/leadership-assessment.css',
        'icons'        => pild_la_icons_for_js(),
        'dir'          => pild_la_dir($is_en),
        // id/label_ar/label_en/color per competency, so the multi-type
        // question engine (situational/ranking/slider/likert) in
        // leadership-assessment.js can label + color-code the "comp-lbl"
        // chip and slider poles without duplicating this data as a JS
        // constant.
        'competencies' => pild_la_get_competencies(),
        'i18n'    => $is_en ? [
            'next'          => 'Next',
            'prev'          => 'Previous',
            'submit'        => 'Finish Assessment',
            'selectSector'  => 'Please choose your category, sector, and goal',
            'answerAll'     => 'Please answer the question to continue',
            'error'         => 'Something went wrong — please try again',
            'confirmRetake' => 'This will start a new assessment and replace your current result. Continue?',
            'letters'       => ['A', 'B', 'C', 'D', 'E'],
            'likert'        => ['Strongly disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly agree'],
            'rankIntro'     => 'Drag the options and reorder them by leadership importance',
            'qType'         => [
                'situational' => 'Leadership scenario',
                'behavioral'  => 'Behavioral style',
                'ranking'     => 'Priority ranking',
                'slider'      => 'Orientation scale',
                'likert'      => 'Agreement level',
            ],
            'srcMeta'       => [
                'general'     => 'Leadership competency',
                'category'    => 'Category context',
                'sector'      => 'Sector context',
                'consistency' => 'Consistency',
            ],
            'sliderPoles'   => [
                'strategic_thinking'     => ['right' => 'Operational / day-to-day', 'left' => 'Strategic / long-term'],
                'communication'          => ['right' => 'Direct and assertive',      'left' => 'Consultative and collaborative'],
                'emotional_intelligence' => ['right' => 'Logical / analytical',      'left' => 'Emotional / people-focused'],
                'execution'              => ['right' => 'Quality / precision',       'left' => 'Speed / delivery'],
                'crisis_management'      => ['right' => 'Cautious / gradual',        'left' => 'Decisive / fast'],
                'influence'              => ['right' => 'Formal authority',          'left' => 'Persuasion and relationships'],
                'innovation'             => ['right' => 'Conservative / stable',     'left' => 'Innovative / bold'],
                'development'            => ['right' => 'Individual performance',    'left' => 'Developing others'],
            ],
            'rankingItems'  => [
                'strategic_thinking'     => ['Long-term vision', 'Analyzing the environment', 'Setting priorities', 'Risk management'],
                'communication'          => ['Clarity of message', 'Active listening', 'Persuasion and influence', 'Non-verbal communication'],
                'emotional_intelligence' => ['Self-awareness', 'Empathy for others', 'Managing emotions', 'Building trust'],
                'execution'              => ['Planning and organizing', 'Close follow-up', 'Removing obstacles', 'Delivering results'],
                'crisis_management'      => ['Calm under pressure', 'Decision speed', 'Crisis communication', 'Regaining momentum'],
                'influence'              => ['Building alliances', 'Logical persuasion', 'Leading by example', 'Effective negotiation'],
                'innovation'             => ['Thinking outside the box', 'Adopting technology', 'Experimenting with new ideas', 'Leading change'],
                'development'            => ['Identifying talent', 'Continuous coaching', 'Delegating responsibility', 'Building a growth culture'],
            ],
            'rankingFallback' => ['Priority 1', 'Priority 2', 'Priority 3', 'Priority 4'],
            'sliderFallback'  => ['right' => 'Less', 'left' => 'More'],
        ] : [
            'next'          => __('التالي', 'pild-unified'),
            'prev'          => __('السابق', 'pild-unified'),
            'submit'        => __('إنهاء التقييم', 'pild-unified'),
            'selectSector'  => __('برجاء اختيار الفئة والقطاع والهدف', 'pild-unified'),
            'answerAll'     => __('برجاء الإجابة على السؤال للمتابعة', 'pild-unified'),
            'error'         => __('حدث خطأ ما — برجاء المحاولة مرة أخرى', 'pild-unified'),
            'confirmRetake' => __('سيبدأ هذا تقييمًا جديدًا ويستبدل نتيجتك الحالية. متابعة؟', 'pild-unified'),
            'letters'       => ['أ', 'ب', 'ج', 'د', 'هـ'],
            'likert'        => ['لا أتفق إطلاقاً', 'لا أتفق', 'محايد', 'أتفق', 'أتفق تماماً'],
            'rankIntro'     => 'اسحب الخيارات وأعد ترتيبها بحسب أهميتها القيادية',
            'qType'         => [
                'situational' => 'سيناريو قيادي',
                'behavioral'  => 'نمط سلوكي',
                'ranking'     => 'ترتيب الأولويات',
                'slider'      => 'مقياس التوجه',
                'likert'      => 'درجة الاتفاق',
            ],
            'srcMeta'       => [
                'general'     => 'كفاءة قيادية',
                'category'    => 'سياق الفئة',
                'sector'      => 'سياق القطاع',
                'consistency' => 'اتساق',
            ],
            'sliderPoles'   => [
                'strategic_thinking'     => ['right' => 'تشغيلي / يومي',  'left' => 'استراتيجي / بعيد المدى'],
                'communication'          => ['right' => 'مباشر وحازم',     'left' => 'تشاوري وتشاركي'],
                'emotional_intelligence' => ['right' => 'منطقي / تحليلي',  'left' => 'عاطفي / إنساني'],
                'execution'              => ['right' => 'إتقان / جودة',    'left' => 'سرعة / إنجاز'],
                'crisis_management'      => ['right' => 'حذر / تدريجي',    'left' => 'حاسم / سريع'],
                'influence'              => ['right' => 'سلطة رسمية',      'left' => 'إقناع وعلاقات'],
                'innovation'             => ['right' => 'محافظ / مستقر',   'left' => 'مبتكر / جريء'],
                'development'            => ['right' => 'أداء فردي',       'left' => 'تطوير الآخرين'],
            ],
            'rankingItems'  => [
                'strategic_thinking'     => ['الرؤية طويلة المدى', 'تحليل البيئة المحيطة', 'تحديد الأولويات', 'إدارة المخاطر'],
                'communication'          => ['وضوح الرسالة', 'الاستماع الفعّال', 'الإقناع والتأثير', 'التواصل غير اللفظي'],
                'emotional_intelligence' => ['الوعي الذاتي', 'التعاطف مع الآخرين', 'ضبط المشاعر', 'بناء الثقة'],
                'execution'              => ['التخطيط والتنظيم', 'المتابعة الدقيقة', 'حل المعوقات', 'إنجاز النتائج'],
                'crisis_management'      => ['الهدوء تحت الضغط', 'سرعة القرار', 'التواصل في الأزمات', 'استعادة الزخم'],
                'influence'              => ['بناء التحالفات', 'الإقناع المنطقي', 'القدوة الشخصية', 'التفاوض الفعّال'],
                'innovation'             => ['التفكير خارج الصندوق', 'تبني التكنولوجيا', 'تجريب الأفكار الجديدة', 'قيادة التغيير'],
                'development'            => ['تحديد المواهب', 'التوجيه المستمر', 'تفويض المسؤوليات', 'بناء ثقافة النمو'],
            ],
            'rankingFallback' => ['الأولوية الأولى', 'الأولوية الثانية', 'الأولوية الثالثة', 'الأولوية الرابعة'],
            'sliderFallback'  => ['right' => 'أقل', 'left' => 'أكثر'],
        ],
    ]);
    wp_enqueue_script('pild-la');
}

// This module now follows PILD's institutional design system (limestone/
// brass/emerald palette, El Messiri + IBM Plex Sans Arabic — see assets/
// leadership-assessment.css) instead of the original standalone site's
// dark purple/green theme, scoped under .pild-la-site via native CSS
// nesting so it stays isolated from the rest of the dashboard.
function pild_la_inline_css() {
    return ''; // styling now lives in the enqueued stylesheet above.
}

/* ============================================================
   J. RENDER — "My Leadership Assessment" tab (solo dashboard)
   ============================================================ */

function pild_la_render_assessment_tab($user_id) {
    pild_la_enqueue_assets();
    $result = pild_la_get_latest_result($user_id);
    $is_en = pild_la_is_en();
    $dir = pild_la_dir($is_en);
    ob_start();
    ?>
    <div class="pild-la-site" dir="<?php echo esc_attr($dir); ?>" lang="<?php echo esc_attr($is_en ? 'en' : 'ar'); ?>">
      <div class="bg-canvas" aria-hidden="true">
        <div class="bg-grid"></div>
        <div class="bg-orb bg-orb-1"></div>
        <div class="bg-orb bg-orb-2"></div>
      </div>
      <div id="pild-la-root" data-state="<?php echo $result ? 'result' : 'intro'; ?>">
        <div id="pild-la-intro" <?php echo $result ? 'style="display:none"' : ''; ?>>
          <?php echo pild_la_render_intro(); ?>
        </div>
        <div id="pild-la-wizard" style="display:none"></div>
        <div id="pild-la-result">
          <?php if ($result) echo pild_la_render_result_card($user_id, true); ?>
        </div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}

function pild_la_render_intro() {
    $categories = pild_la_get_categories();
    $goals = pild_la_get_goals();
    $tracks = pild_la_get_tracks();
    $is_en = pild_la_is_en();
    $t = pild_la_strings($is_en);
    $arrow = pild_la_next_arrow($is_en);

    // goal-track-badge label: goals.json only stores a trackId, so look
    // the track's own bilingual label up rather than reading a field
    // that was never actually populated on the goal record itself.
    $track_label_by_id = [];
    foreach ($tracks as $tr) $track_label_by_id[$tr['id']] = pild_la_field($tr, 'label', $is_en);

    ob_start();
    ?>
    <section class="screen active" id="pild-la-welcome">
      <div class="logo-badge">
        <div class="logo-badge-dot"></div>
        <span><?php echo esc_html($t['platform_tag']); ?></span>
      </div>
      <div class="welcome-header">
        <div class="welcome-logo">PILD</div>
        <div class="welcome-sub"><?php echo esc_html($t['welcome_sub']); ?></div>
      </div>
      <h1 class="welcome-title">
        <?php echo esc_html($t['welcome_title_1']); ?> <span class="accent"><?php echo esc_html($t['welcome_title_accent']); ?></span><br/><?php echo esc_html($t['welcome_title_2']); ?>
      </h1>
      <p class="welcome-desc">
        <?php echo esc_html($t['welcome_desc_1']); ?> <strong style="color:var(--white)"><?php echo esc_html($t['welcome_desc_comps']); ?></strong>
        <?php echo esc_html($t['welcome_desc_2']); ?> <strong style="color:var(--white)"><?php echo esc_html($t['welcome_desc_qs']); ?></strong>
        <?php echo esc_html($t['welcome_desc_3']); ?>
      </p>
      <div class="stats-row">
        <div class="stat-chip"><span class="stat-chip-icon"><?php echo pild_la_svg('clipboard'); ?></span><span class="stat-chip-num">36</span><span class="stat-chip-text"><?php echo esc_html($t['stat_questions']); ?></span></div>
        <div class="stat-chip"><span class="stat-chip-icon"><?php echo pild_la_svg('bulb'); ?></span><span class="stat-chip-num">8</span><span class="stat-chip-text"><?php echo esc_html($t['stat_competencies']); ?></span></div>
        <div class="stat-chip"><span class="stat-chip-icon"><?php echo pild_la_svg('building'); ?></span><span class="stat-chip-num">88</span><span class="stat-chip-text"><?php echo esc_html($t['stat_sectors']); ?></span></div>
        <div class="stat-chip"><span class="stat-chip-icon"><?php echo pild_la_svg('clock'); ?></span><span class="stat-chip-num">20</span><span class="stat-chip-text"><?php echo esc_html($t['stat_minutes']); ?></span></div>
      </div>
      <button class="btn-primary" id="pild-la-welcome-next-btn" style="margin-top:32px">
        <span><?php echo esc_html($t['start_btn']); ?></span><span class="btn-arrow"><?php echo esc_html($arrow); ?></span>
      </button>
    </section>

    <!-- Slide 2: choose the professional category -->
    <section class="screen" id="pild-la-category-screen">
      <div class="section-header">
        <div class="step-badge"><span class="step-badge-icon"><?php echo pild_la_svg('tag'); ?></span><?php echo esc_html($t['choose_category']); ?></div>
        <h2 class="section-title"><?php echo esc_html($t['what_is_your']); ?> <span class="hl"><?php echo esc_html($t['work_sector']); ?></span><?php echo $is_en ? '?' : '؟'; ?></h2>
      </div>
      <div class="categories-grid" id="pild-la-categories-grid" style="--la-cols:<?php echo (int) pild_la_grid_cols(count($categories)); ?>">
        <?php foreach ($categories as $c): ?>
        <div class="cat-card" data-id="<?php echo esc_attr($c['id']); ?>">
          <div class="cat-card-check">✓</div>
          <div class="cat-card-icon"><?php echo pild_la_icon_for('category', $c['id']); ?></div>
          <div class="cat-card-body">
            <div class="cat-card-name"><?php echo esc_html(pild_la_field($c, 'label', $is_en)); ?></div>
            <div class="cat-card-count"><?php echo intval(count($c['sectors'] ?? [])); ?> <?php echo esc_html($t['sectors_suffix']); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div id="pild-la-categories-data" style="display:none"><?php echo wp_json_encode($categories); ?></div>
    </section>

    <!-- Slide 3: choose the sub-sector (populated from the chosen category) -->
    <section class="screen" id="pild-la-sector-screen">
      <div class="section-header">
        <button type="button" class="btn btn-ghost pild-la-back-nav" data-target="pild-la-category-screen">← <?php echo esc_html($t['back']); ?></button>
        <div class="step-badge" style="margin-top:16px"><span class="step-badge-icon"><?php echo pild_la_svg('search'); ?></span><?php echo esc_html($t['pin_your_sector']); ?></div>
      </div>
      <div class="sectors-grid" id="pild-la-sectors-grid"></div>
    </section>

    <!-- Slide 4: choose the assessment goal, then start -->
    <section class="screen" id="pild-la-goal-screen">
      <div class="section-header">
        <button type="button" class="btn btn-ghost pild-la-back-nav" data-target="pild-la-sector-screen">← <?php echo esc_html($t['back']); ?></button>
        <div class="step-badge" style="margin-top:16px"><span class="step-badge-icon"><?php echo pild_la_svg('target'); ?></span><?php echo esc_html($t['assessment_goal']); ?></div>
      </div>
      <div class="goals-grid" id="pild-la-goal-grid" style="--la-cols:<?php echo (int) pild_la_grid_cols(count($goals)); ?>">
        <?php foreach ($goals as $g): ?>
        <div class="goal-card" data-id="<?php echo esc_attr($g['id']); ?>">
          <div class="goal-check">✓</div>
          <div class="goal-header">
            <div class="goal-icon"><?php echo pild_la_icon_for('goal', $g['id']); ?></div>
            <div class="goal-track-badge"><div class="goal-track-dot"></div><?php echo esc_html($track_label_by_id[$g['trackId'] ?? ''] ?? ''); ?></div>
          </div>
          <div class="goal-body">
            <div class="goal-name"><?php echo esc_html(pild_la_field($g, 'label', $is_en)); ?></div>
            <div class="goal-desc"><?php echo esc_html(pild_la_field($g, 'description', $is_en)); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <button class="btn-primary" id="pild-la-start-btn" style="margin-top:28px" disabled>
        <span><?php echo esc_html($t['start_now_btn']); ?></span><span class="btn-arrow"><?php echo esc_html($arrow); ?></span>
      </button>
    </section>
    <?php
    return ob_get_clean();
}

function pild_la_report_strings($is_en) {
    $s = [
        'ar' => [
            'org'            => 'المعهد المهني للتعلم والتطوير',
            'confidential'   => 'تقرير شخصي — سري',
            'title'          => 'تقرير التقييم القيادي',
            'f_name'         => 'الاسم',
            'f_position'     => 'المسمى الوظيفي',
            'f_category'     => 'الفئة المهنية',
            'f_sector'       => 'القطاع',
            'f_goal'         => 'هدف التقييم',
            'f_date'         => 'تاريخ التقييم',
            'f_report_no'    => 'رقم التقرير',
            'f_answered'     => 'الأسئلة المُجابة',
            'h_summary'      => 'الملخص التنفيذي',
            'overall'        => 'الدرجة الإجمالية',
            'out_of'         => 'من 100',
            'level'          => 'المستوى القيادي',
            'profile'        => 'النمط القيادي',
            'h_competency'   => 'ملف الكفاءات',
            'competency'     => 'الكفاءة',
            'score'          => 'الدرجة',
            'rating'         => 'التقدير',
            'no_data'        => 'لا توجد بيانات كافية',
            'r_strong'       => 'قوي',
            'r_solid'        => 'جيد',
            'r_developing'   => 'قيد التطوير',
            'r_priority'     => 'أولوية تطوير',
            'h_focus'        => 'نقاط القوة وأولويات التطوير',
            'strengths'      => 'أبرز نقاط القوة',
            'priorities'     => 'أولويات التطوير',
            'h_path'         => 'مسار التطوير الموصى به',
            'duration'       => 'المدة',
            'activities'     => 'الأنشطة',
            'for_goal'       => 'مرتبط بهدف',
            'h_method'       => 'المنهجية وموثوقية النتائج',
            'm_answered'     => 'الأسئلة المُجابة',
            'm_consistency'  => 'اتساق الإجابات',
            'c_high'         => 'مرتفع',
            'c_moderate'     => 'متوسط',
            'c_review'       => 'يُنصح بالمراجعة',
            'm_basis'        => 'أساس التقييم',
            'm_basis_v'      => 'تقييم ذاتي موزون عبر 8 كفاءات',
            'note'           => 'يعتمد هذا التقرير على إجابات ذاتية ويعكس تصوّر المشارك عن ممارساته القيادية وقت التقييم، وليس تقييماً لأدائه الفعلي. يُنصح بقراءته مع تغذية راجعة من الزملاء وبيانات الأداء.',
            'footer_conf'    => 'سري — أُعدّ للمشارك المذكور أعلاه',
            'print'          => 'طباعة / حفظ PDF',
            'date_fmt'       => 'j F Y',
        ],
        'en' => [
            'org'            => 'Professional Institute for Learning & Development',
            'confidential'   => 'Personal report — Confidential',
            'title'          => 'Leadership Assessment Report',
            'f_name'         => 'Name',
            'f_position'     => 'Job title',
            'f_category'     => 'Professional category',
            'f_sector'       => 'Sector',
            'f_goal'         => 'Assessment goal',
            'f_date'         => 'Assessment date',
            'f_report_no'    => 'Report no.',
            'f_answered'     => 'Questions answered',
            'h_summary'      => 'Executive Summary',
            'overall'        => 'Overall score',
            'out_of'         => 'out of 100',
            'level'          => 'Leadership level',
            'profile'        => 'Leadership profile',
            'h_competency'   => 'Competency Profile',
            'competency'     => 'Competency',
            'score'          => 'Score',
            'rating'         => 'Rating',
            'no_data'        => 'Not enough data',
            'r_strong'       => 'Strong',
            'r_solid'        => 'Solid',
            'r_developing'   => 'Developing',
            'r_priority'     => 'Development priority',
            'h_focus'        => 'Strengths & Development Priorities',
            'strengths'      => 'Key strengths',
            'priorities'     => 'Development priorities',
            'h_path'         => 'Recommended Development Pathway',
            'duration'       => 'Duration',
            'activities'     => 'Activities',
            'for_goal'       => 'Aligned with goal',
            'h_method'       => 'Methodology & Reliability',
            'm_answered'     => 'Questions answered',
            'm_consistency'  => 'Response consistency',
            'c_high'         => 'High',
            'c_moderate'     => 'Moderate',
            'c_review'       => 'Review advised',
            'm_basis'        => 'Basis of assessment',
            'm_basis_v'      => 'Weighted self-assessment across 8 competencies',
            'note'           => 'This report is based on self-reported responses and reflects the participant\'s own view of their leadership practice at the time of assessment; it is not an evaluation of actual performance. It is best read alongside peer feedback and performance data.',
            'footer_conf'    => 'Confidential — prepared for the participant named above',
            'print'          => 'Print / Save as PDF',
            'date_fmt'       => 'F j, Y',
        ],
    ];
    return $s[$is_en ? 'en' : 'ar'];
}

// Radar (spider) chart: N axes, rings at 25/50/75/100. Axis markers are
// numbered so they match the numbered rows in the competency table
// (avoids cramming long Arabic/English names around the chart).
function pild_la_radar_svg($values) {
    $n = count($values);
    if ($n < 3) return '';
    $cx = 180; $cy = 180; $R = 118;
    $pt = function ($i, $r) use ($n, $cx, $cy) {
        $a = -M_PI / 2 + (2 * M_PI * $i / $n);
        return [round($cx + $r * cos($a), 1), round($cy + $r * sin($a), 1)];
    };
    $o = '<svg class="la-radar" viewBox="0 0 360 360" role="img" aria-hidden="true">';
    foreach ([25, 50, 75, 100] as $ring) {
        $pts = [];
        for ($i = 0; $i < $n; $i++) { $p = $pt($i, $R * $ring / 100); $pts[] = $p[0] . ',' . $p[1]; }
        $o .= '<polygon class="la-radar-ring" points="' . implode(' ', $pts) . '"/>';
    }
    for ($i = 0; $i < $n; $i++) { $p = $pt($i, $R); $o .= '<line class="la-radar-axis" x1="' . $cx . '" y1="' . $cy . '" x2="' . $p[0] . '" y2="' . $p[1] . '"/>'; }
    $poly = [];
    foreach ($values as $i => $v) { $p = $pt($i, $R * max(0, min(100, (float) $v)) / 100); $poly[] = $p[0] . ',' . $p[1]; }
    $o .= '<polygon class="la-radar-area" points="' . implode(' ', $poly) . '"/>';
    foreach ($poly as $xy) { list($x, $y) = explode(',', $xy); $o .= '<circle class="la-radar-dot" cx="' . $x . '" cy="' . $y . '" r="3.6"/>'; }
    for ($i = 0; $i < $n; $i++) {
        $p = $pt($i, $R + 24);
        $o .= '<circle class="la-radar-badge" cx="' . $p[0] . '" cy="' . $p[1] . '" r="11"/><text class="la-radar-num" x="' . $p[0] . '" y="' . ($p[1] + 4) . '" text-anchor="middle">' . ($i + 1) . '</text>';
    }
    return $o . '</svg>';
}

function pild_la_render_result_card($user_id, $with_retake = false) {
    $result = pild_la_get_latest_result($user_id);
    $is_en = pild_la_is_en();
    $t = pild_la_strings($is_en);
    $r = pild_la_report_strings($is_en);
    if (!$result) {
        return '<div class="la-empty">' . esc_html($t['no_result_yet']) . '</div>';
    }

    $archetype = null;
    foreach (pild_la_get_archetypes() as $a) if ($a['id'] === $result->archetype_id) { $archetype = $a; break; }
    $archetype = $archetype ?: (pild_la_get_archetypes()[0] ?? ['id' => '', 'label_ar' => '', 'label_en' => '', 'description_ar' => '', 'description_en' => '', 'strengths_ar' => [], 'strengths_en' => []]);

    $goal = pild_la_find_goal($result->goal_id);
    $track = null;
    if ($goal && !empty($goal['trackId'])) {
        foreach (pild_la_get_tracks() as $tr) if ($tr['id'] === $goal['trackId']) { $track = $tr; break; }
    }
    // Category/sector labels are stored as one (Arabic) snapshot; re-read
    // them from the bundled data so the report follows the site language.
    $cat_fresh = pild_la_find_category($result->category_id);
    $sec_fresh = pild_la_find_sector($result->category_id, $result->sector_id);
    $sector_label   = $sec_fresh ? pild_la_field($sec_fresh, 'label', $is_en) : $result->sector_label;
    $category_label = $cat_fresh ? pild_la_field($cat_fresh, 'label', $is_en) : $result->category_label;
    $goal_label     = $goal ? pild_la_field($goal, 'label', $is_en) : $result->goal_label;

    // Person
    $u = get_userdata($user_id);
    $name = $u ? $u->display_name : '';
    $job  = '';
    if ($is_en) $job = (string) get_user_meta($user_id, 'pild_job_title_en', true);
    if ($job === '') $job = (string) get_user_meta($user_id, 'pild_job_title', true);

    // Overall level (from config.json scoring.levels)
    $score = intval($result->total_score);
    $level_label = '';
    $cfg = pild_la_get_config();
    foreach (($cfg['scoring']['levels'] ?? []) as $lv) {
        if ($score >= ($lv['min'] ?? 0) && $score <= ($lv['max'] ?? 100)) { $level_label = pild_la_field($lv, 'label', $is_en); break; }
    }

    // Competencies
    $rows = []; $radar = [];
    $rate = function ($pct) use ($r) {
        if ($pct >= 80) return $r['r_strong'];
        if ($pct >= 60) return $r['r_solid'];
        if ($pct >= 40) return $r['r_developing'];
        return $r['r_priority'];
    };
    foreach (pild_la_get_competencies() as $comp) {
        $sc = $result->competency_scores[$comp['id']] ?? [];
        $has = intval($sc['answerCount'] ?? 0) > 0;
        $pct = $has ? intval($sc['percentage'] ?? 0) : null;
        $rows[] = [
            'name' => pild_la_field($comp, 'label', $is_en) ?: $comp['id'],
            'desc' => pild_la_field($comp, 'description', $is_en),
            'pct'  => $pct,
            'rate' => $has ? $rate($pct) : $r['no_data'],
        ];
        $radar[] = $pct ?? 0;
    }
    $ranked = [];
    foreach ($rows as $i => $row) if ($row['pct'] !== null) $ranked[] = $i;
    usort($ranked, function ($a, $b) use ($rows) { return $rows[$b]['pct'] <=> $rows[$a]['pct']; });
    $k = max(1, min(3, intdiv(count($ranked), 2)));
    $top = array_slice($ranked, 0, $k);
    $low = array_slice(array_reverse($ranked), 0, $k);

    // Reliability
    $pen = floatval($result->consistency_penalty);
    $cons = $pen >= 0.97 ? $r['c_high'] : ($pen >= 0.92 ? $r['c_moderate'] : $r['c_review']);

    $strengths = (array) ($is_en ? ($archetype['strengths_en'] ?? []) : ($archetype['strengths_ar'] ?? []));
    $date = mysql2date($r['date_fmt'], $result->completed_at);
    $report_no = 'PILD-LA-' . str_pad((string) intval($result->id), 6, '0', STR_PAD_LEFT);
    $circ = 2 * M_PI * 54;
    $offset = round($circ * (1 - $score / 100), 1);
    $fields = [
        [$r['f_name'], $name], [$r['f_position'], $job !== '' ? $job : '—'],
        [$r['f_category'], $category_label], [$r['f_sector'], $sector_label],
        [$r['f_goal'], $goal_label], [$r['f_date'], $date],
        [$r['f_report_no'], $report_no], [$r['f_answered'], intval($result->answered_count) . ' / ' . intval($result->total_questions)],
    ];

    ob_start();
    ?>
    <section class="screen active la-report" id="pild-la-hero-result">
      <article class="la-r-doc">

        <header class="la-r-head">
          <div class="la-r-brand">
            <div class="la-r-logo">PILD</div>
            <div class="la-r-org"><?php echo esc_html($r['org']); ?></div>
          </div>
          <div class="la-r-title">
            <div class="la-r-eyebrow"><?php echo esc_html($r['confidential']); ?></div>
            <h1><?php echo esc_html($r['title']); ?></h1>
          </div>
        </header>

        <div class="la-r-cand">
          <?php foreach ($fields as $f): ?>
          <div class="la-r-field"><span class="la-r-k"><?php echo esc_html($f[0]); ?></span><span class="la-r-v"><?php echo esc_html($f[1]); ?></span></div>
          <?php endforeach; ?>
        </div>

        <section class="la-r-sec">
          <div class="la-r-sec-h"><span class="la-r-num">01</span><h2><?php echo esc_html($r['h_summary']); ?></h2></div>
          <div class="la-r-summary">
            <div class="la-r-scorebox">
              <div class="la-r-ring">
                <svg viewBox="0 0 140 140" aria-hidden="true">
                  <circle class="la-r-ring-bg" cx="70" cy="70" r="54"/>
                  <circle class="la-r-ring-fill" cx="70" cy="70" r="54" stroke-dasharray="<?php echo round($circ, 1); ?>" stroke-dashoffset="<?php echo $offset; ?>" transform="rotate(-90 70 70)"/>
                </svg>
                <div class="la-r-ring-c"><b><?php echo $score; ?></b><span><?php echo esc_html($r['out_of']); ?></span></div>
              </div>
              <div class="la-r-k"><?php echo esc_html($r['level']); ?></div>
              <?php if ($level_label !== ''): ?><div class="la-r-badge"><?php echo esc_html($level_label); ?></div><?php endif; ?>
            </div>
            <div class="la-r-profile">
              <div class="la-r-k"><?php echo esc_html($r['profile']); ?></div>
              <h3><span class="la-r-arch-ico"><?php echo pild_la_icon_for('archetype', $archetype['id'] ?? ''); ?></span><?php echo esc_html(pild_la_field($archetype, 'label', $is_en)); ?></h3>
              <p><?php echo esc_html(pild_la_field($archetype, 'description', $is_en)); ?></p>
              <?php if ($strengths): ?>
              <div class="la-r-chips"><?php foreach ($strengths as $s): ?><span><?php echo esc_html($s); ?></span><?php endforeach; ?></div>
              <?php endif; ?>
            </div>
          </div>
        </section>

        <section class="la-r-sec">
          <div class="la-r-sec-h"><span class="la-r-num">02</span><h2><?php echo esc_html($r['h_competency']); ?></h2></div>
          <div class="la-r-comp">
            <div class="la-r-radar"><?php echo pild_la_radar_svg($radar); ?></div>
            <div class="la-r-table">
              <div class="la-r-row la-r-row-h"><span></span><span><?php echo esc_html($r['competency']); ?></span><span></span><span><?php echo esc_html($r['score']); ?></span><span><?php echo esc_html($r['rating']); ?></span></div>
              <?php foreach ($rows as $i => $row): ?>
              <div class="la-r-row">
                <span class="la-r-idx"><?php echo $i + 1; ?></span>
                <span class="la-r-name"><?php echo esc_html($row['name']); ?></span>
                <span class="la-r-bar"><i style="width:<?php echo (int) ($row['pct'] ?? 0); ?>%"></i></span>
                <span class="la-r-pct"><?php echo $row['pct'] === null ? '—' : $row['pct'] . '%'; ?></span>
                <span class="la-r-rate"><?php echo esc_html($row['rate']); ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </section>

        <section class="la-r-sec">
          <div class="la-r-sec-h"><span class="la-r-num">03</span><h2><?php echo esc_html($r['h_focus']); ?></h2></div>
          <div class="la-r-focus">
            <?php foreach ([['strengths', $top, 'is-strength'], ['priorities', $low, 'is-priority']] as $grp): ?>
            <div class="la-r-focus-col <?php echo $grp[2]; ?>">
              <div class="la-r-focus-h"><?php echo esc_html($r[$grp[0]]); ?></div>
              <?php foreach ($grp[1] as $i): $row = $rows[$i]; ?>
              <div class="la-r-item">
                <div class="la-r-item-top"><span class="la-r-idx"><?php echo $i + 1; ?></span><b><?php echo esc_html($row['name']); ?></b><em><?php echo (int) $row['pct']; ?>%</em></div>
                <?php if ($row['desc'] !== ''): ?><p><?php echo esc_html($row['desc']); ?></p><?php endif; ?>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
          </div>
        </section>

        <?php if ($track): ?>
        <section class="la-r-sec">
          <div class="la-r-sec-h"><span class="la-r-num">04</span><h2><?php echo esc_html($r['h_path']); ?></h2></div>
          <div class="la-r-path">
            <div class="la-r-path-main">
              <div class="la-r-k"><?php echo esc_html($r['for_goal']); ?>: <?php echo esc_html($goal_label); ?></div>
              <h3><?php echo esc_html(pild_la_field($track, 'label', $is_en)); ?></h3>
              <?php $dur = pild_la_field($track, 'duration', $is_en); if ($dur !== ''): ?>
              <div class="la-r-dur"><span class="la-r-k"><?php echo esc_html($r['duration']); ?></span> <b><?php echo esc_html($dur); ?></b></div>
              <?php endif; ?>
            </div>
            <?php $acts = (array) ($is_en ? ($track['activities_en'] ?? []) : ($track['activities_ar'] ?? [])); if ($acts): ?>
            <div class="la-r-path-acts">
              <div class="la-r-k"><?php echo esc_html($r['activities']); ?></div>
              <ul><?php foreach ($acts as $a): ?><li><?php echo esc_html($a); ?></li><?php endforeach; ?></ul>
            </div>
            <?php endif; ?>
          </div>
        </section>
        <?php endif; ?>

        <section class="la-r-sec">
          <div class="la-r-sec-h"><span class="la-r-num"><?php echo $track ? '05' : '04'; ?></span><h2><?php echo esc_html($r['h_method']); ?></h2></div>
          <div class="la-r-method">
            <div><span class="la-r-k"><?php echo esc_html($r['m_answered']); ?></span><b><?php echo intval($result->answered_count); ?> / <?php echo intval($result->total_questions); ?></b></div>
            <div><span class="la-r-k"><?php echo esc_html($r['m_consistency']); ?></span><b><?php echo esc_html($cons); ?></b></div>
            <div><span class="la-r-k"><?php echo esc_html($r['m_basis']); ?></span><b><?php echo esc_html($r['m_basis_v']); ?></b></div>
          </div>
          <p class="la-r-note"><?php echo esc_html($r['note']); ?></p>
        </section>

        <footer class="la-r-foot">
          <span><?php echo esc_html($r['footer_conf']); ?></span>
          <span><?php echo esc_html($report_no); ?> · <?php echo esc_html($date); ?></span>
        </footer>
      </article>

      <div class="la-r-actions la-no-print">
        <button type="button" class="btn-secondary la-r-print"><?php echo esc_html($r['print']); ?></button>
        <?php if ($with_retake): ?>
        <button class="btn-secondary" id="pild-la-retake-btn"><?php echo esc_html($t['retake_btn']); ?></button>
        <?php endif; ?>
      </div>
    </section>
    <?php
    return ob_get_clean();
}


/* ============================================================
   K. RENDER — "My Team" tab (free invite system, solo dashboard)
   ============================================================ */

function pild_la_render_team_tab($user_id) {
    pild_la_enqueue_assets();
    $is_en = pild_la_is_en();
    $dir = pild_la_dir($is_en);
    $t = pild_la_strings($is_en);
    ob_start();
    ?>
    <div class="pild-la-site" dir="<?php echo esc_attr($dir); ?>" lang="<?php echo esc_attr($is_en ? 'en' : 'ar'); ?>">
      <div id="pild-la-team-root">
        <div class="section-header">
          <h2 class="section-title"><?php echo esc_html($t['invite_team_title']); ?></h2>
          <p class="section-desc"><?php echo esc_html($t['invite_team_desc']); ?></p>
        </div>
        <div class="la-invite-box">
          <input type="email" class="form-input" id="pild-la-invite-email" placeholder="colleague@company.com" />
          <button class="btn-primary btn-sm" id="pild-la-invite-btn"><?php echo esc_html($t['send_invite_btn']); ?></button>
        </div>
        <div id="pild-la-team-table"><?php echo pild_la_render_team_members_table($user_id); ?></div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}

function pild_la_render_team_members_table($owner_id) {
    $is_en = pild_la_is_en();
    $t = pild_la_strings($is_en);
    $members = pild_la_get_team_members($owner_id);
    if (empty($members)) {
        return '<div class="la-empty">' . esc_html($t['no_invites_yet']) . '</div>';
    }
    ob_start();
    ?>
    <table class="la-team-table">
      <thead><tr>
        <th><?php echo esc_html($t['th_email']); ?></th>
        <th><?php echo esc_html($t['th_status']); ?></th>
        <th><?php echo esc_html($t['th_result']); ?></th>
        <th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($members as $m):
        $result = $m->user_id ? pild_la_get_latest_result($m->user_id) : null;
        $name = $m->user_id ? get_userdata($m->user_id) : null;
      ?>
      <tr>
        <td><?php echo esc_html($name ? $name->display_name . ' — ' . $m->email : $m->email); ?></td>
        <td>
          <?php if ($m->status === 'joined' && $result): ?>
            <span class="la-status la-status-joined"><?php echo esc_html($t['status_completed']); ?></span>
          <?php elseif ($m->status === 'joined'): ?>
            <span class="la-status la-status-invited"><?php echo esc_html($t['status_registered']); ?></span>
          <?php else: ?>
            <span class="la-status la-status-none"><?php echo esc_html($t['status_invited']); ?></span>
          <?php endif; ?>
        </td>
        <td><?php echo $result ? intval($result->total_score) . '%' : '—'; ?></td>
        <td>
          <?php if ($result): ?>
          <button class="btn-secondary btn-sm pild-la-view-report" data-user="<?php echo esc_attr($m->user_id); ?>"><?php echo esc_html($t['view_report_btn']); ?></button>
          <?php endif; ?>
          <button class="btn-secondary btn-sm pild-la-remove-member" data-id="<?php echo esc_attr($m->id); ?>">✕</button>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php
    return ob_get_clean();
}


/* ============================================================
   L. SHORTCODES (thin wrappers, for standalone-page reuse)
   ============================================================ */

add_shortcode('pild_leadership_assessment', function() {
    $t = pild_la_strings();
    if (!is_user_logged_in()) return '<p>' . esc_html($t['please_login_assessment']) . '</p>';
    return pild_la_render_assessment_tab(get_current_user_id());
});
add_shortcode('pild_leadership_team', function() {
    $t = pild_la_strings();
    if (!is_user_logged_in()) return '<p>' . esc_html($t['please_login']) . '</p>';
    return pild_la_render_team_tab(get_current_user_id());
});
