<?php
/**
 * Plugin Name: PILD Unified
 * Plugin URI:  https://pild.org
 * Description: PILD Learning System + Company Manager — merged into one plugin.
 *              Includes: CPTs, ACF fields, progress tracking, playbook engine,
 *              gamification (points & badges), company dashboards,
 *              certificate generation, quiz integration, and LinkedIn sync.
 * Version:     1.9
 * Author:      PILD
 * Text Domain: pild-unified
 * Domain Path: /languages
 * Requires:    WooCommerce Memberships, Teams for WooCommerce Memberships, ACF
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// CONSTANTS
// ============================================================
define( 'PILD_VERSION',  '1.7' );
define( 'PILD_PATH',     plugin_dir_path( __FILE__ ) );
define( 'PILD_URL',      plugin_dir_url( __FILE__ ) );

// ============================================================
// TRANSLATIONS
// ============================================================
// Loads /languages/pild-unified-{locale}.mo (e.g. pild-unified-ar.mo).
// Polylang automatically serves the correct locale's file based on the
// language the visitor is currently viewing the site in — no extra code
// needed here beyond registering the text domain in the standard way.
add_action( 'plugins_loaded', 'pild_unified_load_textdomain' );
function pild_unified_load_textdomain() {
    load_plugin_textdomain( 'pild-unified', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

// Legacy aliases so included files that still use PILDCM_* constants work.
define( 'PILDCM_VERSION', PILD_VERSION );
define( 'PILDCM_PATH',    PILD_PATH );
define( 'PILDCM_URL',     PILD_URL );

// ============================================================
// ACTIVATION — Create ALL DB tables (merged from both plugins)
// ============================================================
register_activation_hook( __FILE__, 'pild_unified_activate' );
function pild_unified_activate() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();

    // pild_progress (unified — superset of both plugins' schemas)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_progress (
        id           int(11)      NOT NULL AUTO_INCREMENT,
        user_id      int(11)      NOT NULL,
        playbook_id    int(11)      NOT NULL,
        program_id   int(11)      DEFAULT 0,
        track_id     int(11)      DEFAULT 0,
        status       varchar(20)  DEFAULT 'completed',
        completed_at datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY   unique_completion (user_id, playbook_id),
        KEY user_track   (user_id, track_id),
        KEY user_idx     (user_id),
        KEY playbook_idx   (playbook_id)
    ) $c;" );

    // pild_results (superset: includes certificate_url column from company manager)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_results (
        id               int(11)      NOT NULL AUTO_INCREMENT,
        user_id          int(11)      NOT NULL,
        track_id         int(11)      NOT NULL,
        score            int(11)      DEFAULT 0,
        total_questions  int(11)      DEFAULT 0,
        passed           varchar(3)   DEFAULT 'no',
        certificate_code varchar(100) DEFAULT NULL,
        certificate_url  text         DEFAULT NULL,
        completed_at     datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY user_track (user_id, track_id)
    ) $c;" );

    // pild_enrollments (from company manager)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_enrollments (
        id          int(11)     NOT NULL AUTO_INCREMENT,
        user_id     int(11)     NOT NULL,
        track_id    int(11)     NOT NULL,
        program_id  int(11)     DEFAULT 0,
        enrolled_by int(11)     DEFAULT 0,
        enrolled_at datetime    DEFAULT CURRENT_TIMESTAMP,
        deadline    date        DEFAULT NULL,
        status      varchar(20) DEFAULT 'active',
        PRIMARY KEY (id),
        UNIQUE KEY  unique_enrollment (user_id, track_id, program_id),
        KEY user_idx  (user_id),
        KEY track_idx (track_id)
    ) $c;" );

    // pild_points (from company manager)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_points (
        id        int(11)      NOT NULL AUTO_INCREMENT,
        user_id   int(11)      NOT NULL,
        points    int(11)      DEFAULT 0,
        reason    varchar(100) DEFAULT '',
        ref_id    int(11)      DEFAULT 0,
        earned_at datetime     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_idx (user_id)
    ) $c;" );

    // pild_badges (from company manager)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_badges (
        id        int(11)     NOT NULL AUTO_INCREMENT,
        user_id   int(11)     NOT NULL,
        badge_key varchar(50) NOT NULL,
        ref_id    int(11)     DEFAULT 0,
        earned_at datetime    DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY unique_badge (user_id, badge_key, ref_id),
        KEY user_idx (user_id)
    ) $c;" );

    // pild_quiz_attempts (native assessment engine — see includes/28-quiz-engine.php.
    // Replaces the Quiz Maker integration in 10-quiz-certificate.php for tracks that
    // switch over to it; tracks still using an external quiz_url are unaffected.)
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pild_quiz_attempts (
        id             int(11)      NOT NULL AUTO_INCREMENT,
        user_id        int(11)      NOT NULL,
        assessment_id  int(11)      NOT NULL,
        track_id       int(11)      NOT NULL,
        question_ids   longtext     NOT NULL,
        answers        longtext     DEFAULT NULL,
        time_limit     int(11)      DEFAULT 3600,
        started_at     datetime     DEFAULT CURRENT_TIMESTAMP,
        submitted_at   datetime     DEFAULT NULL,
        score          int(11)      DEFAULT NULL,
        passed         varchar(3)   DEFAULT NULL,
        tab_switches   int(11)      DEFAULT 0,
        PRIMARY KEY  (id),
        KEY user_assessment (user_id, assessment_id),
        KEY user_idx (user_id)
    ) $c;" );

    // Add student role (from learning plugin)
    add_role( 'student', 'Student', [ 'read' => true ] );

    // Training Partner role — same base capabilities as a normal
    // logged-in manager/customer ('read'), used only as a flag that
    // includes/14-partner-pricing.php checks to decide which price
    // to show. Does not change Teams/seat permissions in any way.
    add_role( 'pild_training_partner', 'Training Partner', [ 'read' => true ] );
    add_option( 'pild_flush_needed', true );

    pild_migrate_playbook_assessment_rename();
}

// ============================================================
// ONE-TIME DATA MIGRATION
// Renames all existing DB data from the old 'lesson'/'exam' naming
// to the new 'playbook'/'assessment' naming, so existing content
// keeps working under the new code. Safe to run multiple times —
// it exits immediately once the 'pild_migrated_playbook_v1' flag is set.
// Hooked to both plugin activation AND 'init' so it still runs even
// if the plugin files were simply replaced on the server without a
// manual deactivate/reactivate.
// ============================================================
add_action( 'init', 'pild_migrate_playbook_assessment_rename', 5 );
function pild_migrate_playbook_assessment_rename() {
    if ( get_option( 'pild_migrated_playbook_v1' ) ) return;
    global $wpdb;

    // 1) Rename the post types themselves.
    $wpdb->update( $wpdb->posts, [ 'post_type' => 'playbook'   ], [ 'post_type' => 'lesson' ] );
    $wpdb->update( $wpdb->posts, [ 'post_type' => 'assessment' ], [ 'post_type' => 'exam'   ] );

    // 2) Rename postmeta keys.
    $meta_map = [
        'lesson_program'   => 'playbook_program',
        'lesson_type'      => 'playbook_type',
        'lesson_quiz_id'   => 'playbook_quiz_id',
        'lesson_video_url' => 'playbook_video_url',
        'lesson_duration'  => 'playbook_duration',
        'lesson_order'     => 'playbook_order',
        'exam_track'       => 'assessment_track',
        'question_exam'    => 'question_assessment',
    ];
    foreach ( $meta_map as $old_key => $new_key ) {
        $wpdb->update( $wpdb->postmeta, [ 'meta_key' => $new_key ], [ 'meta_key' => $old_key ] );
    }

    // 3) Rename the points/badges history so past records still match
    //    what the new code looks for.
    $wpdb->update( "{$wpdb->prefix}pild_points", [ 'reason'    => 'playbook_complete' ], [ 'reason'    => 'lesson_complete' ] );
    $wpdb->update( "{$wpdb->prefix}pild_badges", [ 'badge_key' => 'first_playbook'    ], [ 'badge_key' => 'first_lesson'    ] );

    // 4) Rename the progress table's lesson_id column to playbook_id
    //    (only if the table exists and still has the old column name).
    $progress_table = "{$wpdb->prefix}pild_progress";
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$progress_table'" ) ) {
        $col_exists = $wpdb->get_var( "SHOW COLUMNS FROM `$progress_table` LIKE 'lesson_id'" );
        if ( $col_exists ) {
            $wpdb->query( "ALTER TABLE `$progress_table` CHANGE COLUMN `lesson_id` `playbook_id` int(11) NOT NULL" );
        }
    }

    flush_rewrite_rules();
    update_option( 'pild_migrated_playbook_v1', 1 );
}

// ============================================================
// FLUSH REWRITE RULES ON FIRST LOAD AFTER ACTIVATION
// ------------------------------------------------------------
// FIX: priority 20 (not the default 10) so this runs AFTER every
// module's `add_action('init', 'add_..._rewrite_rule')` callback
// (verify-certificate, certificate/xxx, cert/xxx — all registered
// at the default priority 10 from includes/12-cert-verify-acf.php).
// Flushing at the same/earlier priority than those registrations
// captured an INCOMPLETE rewrite table on first activation and
// caused /verify-certificate/, /certificate/xxx and /cert/xxx to
// 404 until an admin manually re-saved Settings → Permalinks.
// ============================================================
add_action( 'init', function () {
    if ( get_option( 'pild_flush_needed' ) ) {
        flush_rewrite_rules();
        delete_option( 'pild_flush_needed' );
    }
}, 20 );

// ============================================================
// REGISTER CUSTOM POST TYPES
// (from pild-learning — company manager had none)
// ============================================================
add_action( 'init', 'pild_register_post_types' );
function pild_register_post_types() {
    $cpts = [
        'sector'   => [ 'Sectors',         'Sector',        'dashicons-building',          4 ],
        'domain'   => [ 'Practice Areas', 'Practice Area', 'dashicons-portfolio',        5 ],
        'track'    => [ 'Tracks',          'Track',         'dashicons-chart-line',        6 ],
        'program'  => [ 'Programs',        'Program',       'dashicons-book',              7 ],
        'playbook'   => [ 'Playbooks',       'Playbook',      'dashicons-welcome-learn-more',8 ],
        'assessment'     => [ 'Assessments',           'Assessment',          'dashicons-clock',             9 ],
        'question' => [ 'Questions',       'Question',      'dashicons-editor-help',      10 ],
    ];
    foreach ( $cpts as $slug => [ $plural, $singular, $icon, $pos ] ) {
        $public = ( $slug !== 'question' );
        register_post_type( $slug, [
            'labels'        => [
                'name'          => $plural,
                'singular_name' => $singular,
                'add_new'       => "Add $singular",
                'add_new_item'  => "Add New $singular",
            ],
            'public'        => $public,
            'show_ui'       => true,
            'has_archive'   => false,
            'show_in_rest'  => true,
            'supports'      => [ 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ],
            'menu_icon'     => $icon,
            'menu_position' => $pos,
        ] );
    }
}

// ============================================================
// Redirect old URLs from before the rename to their new equivalents:
//   /lesson/...  -> /playbook/...
//   /exam/...    -> /assessment/...
// (keeps old links, bookmarks, and search-engine results working)
// ============================================================
add_action( 'template_redirect', 'pild_redirect_old_slugs' );
function pild_redirect_old_slugs() {
    if ( ! is_404() ) return;
    $path = trim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );

    $map = [
        'lesson' => 'playbook',
        'exam'   => 'assessment',
    ];

    foreach ( $map as $old_slug => $new_type ) {
        if ( strpos( $path, $old_slug . '/' ) !== 0 ) continue;
        $rest = trim( substr( $path, strlen( $old_slug . '/' ) ), '/' );
        if ( $rest === '' ) continue;
        // Only redirect if a real post of the new type actually exists at that path.
        if ( get_page_by_path( $rest, OBJECT, $new_type ) ) {
            wp_safe_redirect( home_url( '/' . $new_type . '/' . $rest . '/' ), 301 );
            exit;
        }
    }
}

// ============================================================
// PUBLIC ARCHIVE PAGE — /sectors
// (Sector CPT has has_archive=false like the rest of the hierarchy,
// so this virtual page is added the same way /verify-certificate/
// is handled in 12-cert-verify-acf.php: a rewrite rule + query var +
// template_redirect, but rendered INSIDE the active theme's normal
// header/footer so it looks and feels like the rest of the site.)
// ============================================================
add_action( 'init', 'pild_add_sectors_archive_rewrite' );
function pild_add_sectors_archive_rewrite() {
    add_rewrite_rule( '^sectors/?$', 'index.php?pild_sectors_archive=1', 'top' );
}

add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'pild_sectors_archive';
    return $vars;
} );

// One-time flush so /sectors/ works immediately after this update ships,
// without requiring an admin to manually re-save Settings → Permalinks.
add_action( 'init', function () {
    if ( ! get_option( 'pild_sectors_rewrite_flushed' ) ) {
        flush_rewrite_rules();
        update_option( 'pild_sectors_rewrite_flushed', 1 );
    }
}, 21 );

add_action( 'template_redirect', 'pild_render_sectors_archive' );
function pild_render_sectors_archive() {
    if ( ! get_query_var( 'pild_sectors_archive' ) ) return;

    $sectors = get_posts( [ 'post_type' => 'sector', 'posts_per_page' => -1,
        'post_status' => 'publish', 'orderby' => 'menu_order title', 'order' => 'ASC' ] );

    get_header();
    echo pild_global_css();
    ?>
    <div class="pild-wrap">
      <div class="pild-section-tag" style="margin-bottom:2rem"><?php esc_html_e( 'Explore Our Sectors', 'pild-unified' ); ?></div>
      <?php if ( empty( $sectors ) ) : ?>
        <div class="pild-empty-state"><div class="pild-empty-icon">🚀</div><p><?php esc_html_e( 'Expanding our Sectors soon.', 'pild-unified' ); ?></p></div>
      <?php else : ?>
      <div class="pild-tracks-grid">
        <?php foreach ( $sectors as $sector ) :
            $link    = get_permalink( $sector->ID );
            $thumb   = get_the_post_thumbnail_url( $sector->ID, 'medium' );
            $excerpt = wp_trim_words( $sector->post_excerpt ?: $sector->post_content, 18 );
            $domains = get_posts( [ 'post_type' => 'domain', 'posts_per_page' => -1, 'meta_key' => 'domain_sector', 'meta_value' => $sector->ID ] );
            $d_count = count( $domains );
        ?>
        <div class="pild-track-card">
          <?php if ( $thumb ) : ?>
            <div class="pild-track-thumb" style="background-image:url('<?php echo esc_url( $thumb ); ?>')"></div>
          <?php else : ?>
            <div class="pild-track-thumb pild-track-thumb-empty"><svg width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg></div>
          <?php endif; ?>
          <div class="pild-track-card-body">
            <h3 class="pild-track-card-title"><?php echo esc_html( $sector->post_title ); ?></h3>
            <?php if ( $excerpt ) : ?><p class="pild-track-card-desc"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
            <div class="pild-track-meta">
              <span><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg> <b><?php echo $d_count; ?></b> <?php esc_html_e( 'Practice Areas', 'pild-unified' ); ?></span>
            </div>
            <a href="<?php echo esc_url( $link ); ?>" class="pild-btn-primary pild-btn-full"><?php esc_html_e( 'Explore Sector →', 'pild-unified' ); ?></a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php
    get_footer();
    exit;
}

// ============================================================
// ADMIN — Sector filter dropdown + column on the Domain (Practice
// Area) list table in wp-admin, so staff can filter/see which
// Sector each Domain belongs to at a glance.
// ============================================================
add_action( 'restrict_manage_posts', 'pild_domain_sector_filter_dropdown' );
function pild_domain_sector_filter_dropdown( $post_type ) {
    if ( $post_type !== 'domain' ) return;
    $sectors = get_posts( [ 'post_type' => 'sector', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
    if ( empty( $sectors ) ) return;
    $selected = isset( $_GET['pild_sector_filter'] ) ? (int) $_GET['pild_sector_filter'] : 0;
    ?>
    <select name="pild_sector_filter">
        <option value="0">All Sectors</option>
        <?php foreach ( $sectors as $sector ) : ?>
            <option value="<?php echo esc_attr( $sector->ID ); ?>" <?php selected( $selected, $sector->ID ); ?>><?php echo esc_html( $sector->post_title ); ?></option>
        <?php endforeach; ?>
    </select>
    <?php
}

add_filter( 'parse_query', 'pild_filter_domains_by_sector' );
function pild_filter_domains_by_sector( $query ) {
    global $pagenow;
    if ( ! is_admin() || $pagenow !== 'edit.php' || ! $query->is_main_query() ) return $query;
    if ( ( $query->query_vars['post_type'] ?? '' ) !== 'domain' ) return $query;
    if ( empty( $_GET['pild_sector_filter'] ) ) return $query;
    $query->query_vars['meta_key']   = 'domain_sector';
    $query->query_vars['meta_value'] = (int) $_GET['pild_sector_filter'];
    return $query;
}

add_filter( 'manage_domain_posts_columns', 'pild_domain_sector_column' );
function pild_domain_sector_column( $columns ) {
    $new = [];
    foreach ( $columns as $key => $label ) {
        $new[ $key ] = $label;
        if ( $key === 'title' ) $new['pild_sector'] = 'Sector';
    }
    return $new;
}
add_action( 'manage_domain_posts_custom_column', 'pild_domain_sector_column_content', 10, 2 );
function pild_domain_sector_column_content( $column, $post_id ) {
    if ( $column !== 'pild_sector' ) return;
    $sector_id = function_exists( 'get_field' ) ? (int) get_field( 'domain_sector', $post_id ) : 0;
    echo $sector_id ? esc_html( get_the_title( $sector_id ) ) : '—';
}

// ============================================================
// ACF FIELD GROUPS
// (from pild-learning — company manager had none)
// ============================================================
add_action( 'acf/include_fields', function () {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

    $groups = [
        [ 'key' => 'group_program_track', 'title' => 'Program Relationship', 'fields' => [ [ 'key' => 'field_program_track', 'label' => 'Select Track',   'name' => 'program_track',  'type' => 'post_object', 'post_type' => [ 'track' ],   'return_format' => 'id', 'required' => 1 ] ], 'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'program' ] ] ] ],
        [ 'key' => 'group_playbook_program','title' => 'Playbook Relationship', 'fields' => [ [ 'key' => 'field_playbook_program','label' => 'Select Program', 'name' => 'playbook_program', 'type' => 'post_object', 'post_type' => [ 'program' ], 'return_format' => 'id', 'required' => 1 ] ], 'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'playbook'  ] ] ] ],
        // PHASE 15: 'Playbook Type' field group removed — everything is a
        // uniform "Playbook" now (see pild_get_playbook_type_badge()).
        [ 'key' => 'group_domain_sector', 'title' => 'Domain Relationship',  'fields' => [ [ 'key' => 'field_domain_sector', 'label' => 'Sector',         'name' => 'domain_sector',  'type' => 'post_object', 'post_type' => [ 'sector' ],  'return_format' => 'id', 'required' => 1 ] ], 'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'domain'  ] ] ] ],
        [ 'key' => 'group_track_domain',  'title' => 'Track Relationship',   'fields' => [ [ 'key' => 'field_track_domain',  'label' => 'Practice Area',  'name' => 'track_domain',   'type' => 'post_object', 'post_type' => [ 'domain' ],  'return_format' => 'id', 'required' => 1 ] ], 'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'track'   ] ] ] ],
        [ 'key' => 'group_assessment_track',    'title' => 'Assessment Relationship',    'fields' => [ [ 'key' => 'field_assessment_track',    'label' => 'Select Track',   'name' => 'assessment_track',     'type' => 'post_object', 'post_type' => [ 'track' ],   'return_format' => 'id' ] ],             'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'assessment'    ] ] ] ],
        [ 'key' => 'group_question_assessment', 'title' => 'Question Relationship','fields' => [ [ 'key' => 'field_question_assessment', 'label' => 'Select Assessment',    'name' => 'question_assessment',  'type' => 'post_object', 'post_type' => [ 'assessment' ],    'return_format' => 'id', 'required' => 1 ] ], 'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'question'] ] ] ],
        // PHASE 22 replaced this per-Sector field with a per-Identity
        // system instead (client decision, Sep 2026) — see "Certificate
        // Backgrounds" admin page in includes/12-cert-verify-acf.php.
    ];
    foreach ( $groups as $g ) acf_add_local_field_group( $g );

    acf_add_local_field_group( [
        'key'    => 'group_track_settings',
        'title'  => 'Track Settings',
        'fields' => [
            [ 'key' => 'field_track_quiz_url','label' => 'Quiz Page URL',    'name' => 'quiz_url',     'type' => 'url' ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'track' ] ] ],
    ] );

    // NEW: rich content shown in the "Program Details" popup on the public
    // sector-explorer page (includes/17-sector-explorer.php) — overview
    // (post_excerpt / النبذة, already existed) + goals + outcomes. Both are
    // plain textareas, one line per goal/outcome — the front-end splits on
    // newlines to render a bullet list. Filled either by hand in wp-admin
    // or via the "Import from Excel" tool (كود_البرنامج → الأهداف / المخرجات).
    acf_add_local_field_group( [
        'key'    => 'group_program_details',
        'title'  => 'Program Details (Popup)',
        'fields' => [
            [
                'key'          => 'field_program_goals',
                'label'        => 'الأهداف (Goals)',
                'name'         => 'program_goals',
                'type'         => 'textarea',
                'instructions' => 'سطر واحد لكل هدف — كل سطر بيتحول لنقطة (bullet) في نافذة تفاصيل البرنامج.',
                'rows'         => 5,
                'new_lines'    => '',
            ],
            [
                'key'          => 'field_program_outcomes',
                'label'        => 'المخرجات (Outcomes)',
                'name'         => 'program_outcomes',
                'type'         => 'textarea',
                'instructions' => 'سطر واحد لكل مخرج — كل سطر بيتحول لنقطة (bullet) في نافذة تفاصيل البرنامج.',
                'rows'         => 5,
                'new_lines'    => '',
            ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'program' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'    => 'group_product_book_url',
        'title'  => 'Book Access',
        'fields' => [
            [
                'key'          => 'field_product_book_url',
                'label'        => 'Book Post URL',
                'name'         => 'product_book_url',
                'type'         => 'url',
                'instructions' => 'The URL of the post containing the book — shown to the customer in their dashboard after purchase',
                'required'     => 0,
            ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'product' ] ] ],
    ] );

    // NEW: direct product → track link. Independent of WooCommerce Memberships
    // plan configuration — used by pild_auto_enroll_tracks_from_purchase() so a
    // customer/manager gets access to exactly the track(s) tied to whatever they
    // bought, the moment the order completes, with zero Memberships setup required.
    acf_add_local_field_group( [
        'key'    => 'group_product_tracks',
        'title'  => 'Track Access (Auto-Enroll)',
        'fields' => [
            [
                'key'          => 'field_product_tracks',
                'label'        => 'Track(s) unlocked by this product',
                'name'         => 'product_tracks',
                'type'         => 'post_object',
                'post_type'    => [ 'track' ],
                'multiple'     => 1,
                'return_format'=> 'id',
                'instructions' => 'Whoever completes an order containing this product is automatically enrolled in the selected track(s) — no WooCommerce Memberships plan needed.',
                'required'     => 0,
            ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'product' ] ] ],
    ] );
} );

// ============================================================
// ENQUEUE SCRIPTS
// (unified — uses pild_nonce for the learning playbook JS)
// ============================================================
add_action( 'wp_enqueue_scripts', 'pild_enqueue_scripts' );
function pild_enqueue_scripts() {
    $cpts    = [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment' ];
    $js_path = PILD_PATH . 'assets/playbook.js';
    if ( ( is_singular( $cpts ) || is_page_template( 'page-track-landing.php' ) ) && file_exists( $js_path ) ) {
        wp_enqueue_script( 'pild-playbook', PILD_URL . 'assets/playbook.js', [ 'jquery' ], PILD_VERSION, true );
        wp_localize_script( 'pild-playbook', 'pild_ajax', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'pild_nonce' ),
        ] );
    }
}

// ============================================================
// LEARNING HELPERS
// (from pild-learning — used by playbook pages, track/program views)
// ============================================================

function pild_get_next_playbook( $program_id, $current_playbook_id ) {
    $playbooks = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1,
        'meta_key' => 'playbook_program', 'meta_value' => $program_id,
        'orderby' => 'menu_order', 'order' => 'ASC' ] );
    foreach ( $playbooks as $idx => $l ) {
        if ( $l->ID == $current_playbook_id && isset( $playbooks[ $idx + 1 ] ) ) return $playbooks[ $idx + 1 ];
    }
    return null;
}

function pild_playbook_completed( $user_id, $playbook_id ) {
    global $wpdb;
    // Bilingual: a step finished on the Arabic edition of a playbook must
    // already show as done on its English translation (and vice versa) —
    // see pild_bilingual_post_ids() in includes/02-helpers.php.
    $ids = function_exists( 'pild_bilingual_post_ids' ) ? pild_bilingual_post_ids( $playbook_id ) : [ (int) $playbook_id ];
    $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
    return (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND playbook_id IN ($placeholders)",
        array_merge( [ $user_id ], $ids )
    ) );
}

// PHASE 15: "Playbook Type" (Book/Activity/Exercise) has been removed —
// everything is uniformly a "Playbook" now. These two functions are kept
// (still called from a few places) but simplified to always return the
// unified label/badge, ignoring any 'playbook_type' meta a post might
// still have stored from before this change (removing the ACF field
// definition doesn't retroactively clear old postmeta on existing posts).
function pild_get_playbook_type_label( $playbook_id ) {
    return __('Playbook', 'pild-unified');
}

function pild_get_playbook_type_badge( $playbook_id ) {
    $icon = '<svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>';
    return '<span class="pild-playbook-type pild-type-book">' . $icon . ' ' . esc_html__('Playbook', 'pild-unified') . '</span>';
}

// ============================================================
// PHASE: native track-enrollment gate — replaces the old WC
// Memberships / Paid Memberships Pro dependent version of this
// function, which "fail-opened" (returned true, i.e. unlocked)
// whenever neither of those plugins was active. That meant any
// Playbook opened directly by its URL was fully readable by
// anyone, logged in or not, with zero enrollment check, the
// moment WC Memberships stopped running.
//
// This version is fail-closed and depends on nothing but this
// plugin's own data: for a Playbook, it resolves the Playbook's
// Track (playbook_program -> program_track) and checks the same
// pild_enrollments-based pildcm_is_enrolled() used everywhere
// else access is already enforced correctly (progress saving,
// native quiz engine). A Playbook that isn't linked to any Track
// at all (no program, or a program with no track set) is treated
// as intentionally free/public content and stays open — that is
// the one case where "open by default" is still correct, because
// there is no track to be enrolled in.
//
// Any post type OTHER than 'playbook' keeps the previous
// behaviour untouched (this function has never been called for
// anything but playbooks in this plugin, but the fallback is left
// in place rather than removed, so nothing else that might rely
// on it silently changes behaviour).
// ============================================================
function pild_user_can_access( $post_id ) {
    if ( current_user_can( 'manage_options' ) ) return true;

    if ( get_post_type( $post_id ) === 'playbook' ) {
        $track_id = function_exists( 'pildcm_get_playbook_track_id' ) ? pildcm_get_playbook_track_id( $post_id ) : 0;

        // No Track relationship at all -> intentionally free/public Playbook.
        if ( ! $track_id ) return true;

        if ( ! is_user_logged_in() ) return false;

        return function_exists( 'pildcm_is_enrolled' ) && pildcm_is_enrolled( get_current_user_id(), $track_id );
    }

    if ( function_exists( 'wc_memberships_is_post_content_restricted' ) ) {
        if ( ! wc_memberships_is_post_content_restricted( $post_id ) ) return true;
        if ( ! is_user_logged_in() ) return false;
        if ( function_exists( 'wc_memberships_user_can' ) ) {
            return wc_memberships_user_can( get_current_user_id(), 'view', [ 'post' => $post_id ] );
        }
        return false;
    }
    if ( function_exists( 'pmpro_hasMembershipLevel' ) ) {
        $levels = function_exists( 'pmpro_getMembershipLevelsForPost' ) ? pmpro_getMembershipLevelsForPost( $post_id ) : [];
        if ( empty( $levels ) ) return true;
        if ( ! is_user_logged_in() ) return false;
        return pmpro_hasMembershipLevel( $levels );
    }
    return true;
}

// Whether a logged-out visitor, or a logged-in but not-enrolled member,
// is looking at a locked Playbook right now — used by pild_add_complete_button()
// below to pick the right locked-state message/CTA.
function pild_playbook_restricted_type( $post_id ) {
    if ( ! is_user_logged_in() ) return 'login';

    $track_id = function_exists( 'pildcm_get_playbook_track_id' ) ? pildcm_get_playbook_track_id( $post_id ) : 0;
    if ( $track_id && function_exists( 'pildcm_enrollment_expired' ) && pildcm_enrollment_expired( get_current_user_id(), $track_id ) ) {
        return 'expired';
    }
    return 'track';
}

// ============================================================
// AJAX — COMPLETE PLAYBOOK (unified handler)
//
// Replaces BOTH:
//   pild_complete_playbook    (pild-learning   — basic progress save)
//   pildcm_mark_playbook_complete (pild-company-manager — progress + points + badges)
//
// The unified handler accepts EITHER nonce ('pild_nonce' or 'pildcm_nonce')
// so existing JS on both themes/pages keeps working.
// ============================================================
add_action( 'wp_ajax_pild_complete_playbook',         'pild_unified_complete_playbook' );
add_action( 'wp_ajax_pildcm_mark_playbook_complete',  'pild_unified_complete_playbook' );

function pild_unified_complete_playbook() {
    // Accept either nonce
    $nonce_ok = false;
    if ( ! empty( $_POST['nonce'] ) ) {
        if ( wp_verify_nonce( $_POST['nonce'], 'pild_nonce'   ) ) $nonce_ok = true;
        if ( wp_verify_nonce( $_POST['nonce'], 'pildcm_nonce' ) ) $nonce_ok = true;
    }
    if ( ! $nonce_ok ) wp_send_json_error( 'Invalid nonce' );
    if ( ! is_user_logged_in() ) wp_send_json_error( 'Not logged in' );

    global $wpdb;
    $user_id    = get_current_user_id();
    $playbook_id  = (int) ( $_POST['playbook_id']  ?? 0 );
    $program_id = (int) ( $_POST['program_id'] ?? 0 );
    $track_id   = (int) ( $_POST['track_id']   ?? 0 );

    if ( ! $playbook_id ) wp_send_json_error( 'Invalid playbook' );

    // Resolve program / track from meta if not passed
    if ( ! $program_id ) $program_id = (int) get_post_meta( $playbook_id, 'playbook_program', true );
    if ( ! $track_id && $program_id ) $track_id = (int) get_post_meta( $program_id, 'program_track', true );

    // Enrollment / access check (solo membership bypass)
    if ( $track_id && ! pildcm_is_enrolled( $user_id, $track_id ) ) {
        $has_access = false;
        if ( function_exists( 'wc_memberships_user_can' ) ) {
            $has_access = wc_memberships_user_can( $user_id, 'view', [ 'post' => $track_id ] );
        }
        if ( ! $has_access ) wp_send_json_error( 'Not enrolled in this track' );
    }

    // Prevent duplicate — check BOTH language editions of this playbook, so
    // completing it in Arabic and then opening the English translation
    // never inserts a second row or re-fires points/badges.
    $playbook_ids_bi = function_exists( 'pild_bilingual_post_ids' ) ? pild_bilingual_post_ids( $playbook_id ) : [ $playbook_id ];
    $pb_ph = implode( ',', array_fill( 0, count( $playbook_ids_bi ), '%d' ) );
    $exists = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND playbook_id IN ($pb_ph) LIMIT 1",
        array_merge( [ $user_id ], $playbook_ids_bi )
    ) );
    if ( $exists ) {
        // Return navigation URLs for the learning plugin's JS
        $next_playbook  = pild_get_next_playbook( $program_id, $playbook_id );
        $next_program = null;
        if ( ! $next_playbook && $track_id ) {
            $all_progs = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1,
                'meta_key' => 'program_track', 'meta_value' => $track_id,
                'orderby' => 'menu_order', 'order' => 'ASC' ] );
            foreach ( $all_progs as $idx => $p ) {
                if ( $p->ID == $program_id && isset( $all_progs[ $idx + 1 ] ) ) { $next_program = $all_progs[ $idx + 1 ]; break; }
            }
        }
        wp_send_json_success( [
            'message'            => 'Already completed',
            'completed'          => true,
            'next_playbook_url'    => $next_playbook  ? get_permalink( $next_playbook->ID )   : null,
            'next_playbook_title'  => $next_playbook  ? $next_playbook->post_title            : null,
            'program_completed'  => false,
            'next_program_url'   => $next_program ? get_permalink( $next_program->ID )  : null,
            'next_program_title' => $next_program ? $next_program->post_title           : null,
            'track_url'          => $track_id ? get_permalink( $track_id ) : '',
        ] );
    }

    // ── 1. Record progress ─────────────────────────────────────
    $wpdb->insert( "{$wpdb->prefix}pild_progress", [
        'user_id'      => $user_id,
        'playbook_id'    => $playbook_id,
        'program_id'   => $program_id,
        'track_id'     => $track_id,
        'status'       => 'completed',
        'completed_at' => current_time( 'mysql' ),
    ] );

    // ── 2. Points for playbook ───────────────────────────────────
    $pts_cfg = pildcm_points_config();
    $wpdb->insert( "{$wpdb->prefix}pild_points", [
        'user_id'   => $user_id,
        'points'    => $pts_cfg['playbook_complete'],
        'reason'    => 'playbook_complete',
        'ref_id'    => $playbook_id,
        'earned_at' => current_time( 'mysql' ),
    ] );
    $message = '+' . $pts_cfg['playbook_complete'] . ' points';

    // Helper: insert badge once
    $award_badge = function ( $key, $ref = 0 ) use ( $wpdb, $user_id ) {
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pild_badges WHERE user_id=%d AND badge_key=%s AND ref_id=%d LIMIT 1",
            $user_id, $key, $ref
        ) );
        if ( ! $exists ) {
            $wpdb->insert( "{$wpdb->prefix}pild_badges", [
                'user_id'   => $user_id,
                'badge_key' => $key,
                'ref_id'    => $ref,
                'earned_at' => current_time( 'mysql' ),
            ] );
            return true;
        }
        return false;
    };

    // ── 3. first_playbook badge ──────────────────────────────────
    $total_done = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d", $user_id
    ) );
    if ( $total_done === 1 && $award_badge( 'first_playbook' ) ) $message .= ' · 🌱 Badge: First Step!';

    // ── 4. fast_learner badge (5 playbooks today) ────────────────
    $today = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND DATE(completed_at)=CURDATE()", $user_id
    ) );
    if ( $today >= 5 && $award_badge( 'fast_learner' ) ) $message .= ' · ⚡ Badge: Fast Learner!';

    // ── 5. early_bird badge (before 08:00) ─────────────────────
    if ( (int) date( 'G' ) < 8 && $award_badge( 'early_bird' ) ) $message .= ' · 🌅 Badge: Early Bird!';

    // ── 6. streak badges ───────────────────────────────────────
    $streak = pildcm_get_streak( $user_id );
    if ( $streak >= 7  && $award_badge( 'streak_7'  ) ) $message .= ' · 🔥 7-Day Streak!';
    if ( $streak >= 30 && $award_badge( 'streak_30' ) ) $message .= ' · ⚡ 30-Day Streak!';

    // ── 7. program_complete check ──────────────────────────────
    $prog_complete = false;
    $next_program  = null;
    if ( $program_id ) {
        $all_prog_playbooks = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1,
            'meta_key' => 'playbook_program', 'meta_value' => $program_id ] );
        $prog_done = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND program_id=%d", $user_id, $program_id
        ) );
        if ( $prog_done >= count( $all_prog_playbooks ) ) {
            $prog_complete = true;
            // Program points bonus
            $prog_pts_exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_points WHERE user_id=%d AND reason='program_complete' AND ref_id=%d LIMIT 1",
                $user_id, $program_id
            ) );
            if ( ! $prog_pts_exists ) {
                $wpdb->insert( "{$wpdb->prefix}pild_points", [
                    'user_id'   => $user_id,
                    'points'    => $pts_cfg['program_complete'],
                    'reason'    => 'program_complete',
                    'ref_id'    => $program_id,
                    'earned_at' => current_time( 'mysql' ),
                ] );
                $message .= ' · Program complete! +' . $pts_cfg['program_complete'] . ' pts';
            }
            // Find next program
            if ( $track_id ) {
                $all_progs = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1,
                    'meta_key' => 'program_track', 'meta_value' => $track_id,
                    'orderby' => 'menu_order', 'order' => 'ASC' ] );
                foreach ( $all_progs as $idx => $p ) {
                    if ( $p->ID == $program_id && isset( $all_progs[ $idx + 1 ] ) ) { $next_program = $all_progs[ $idx + 1 ]; break; }
                }
            }
        }
    }

    // ── 8. track_finisher badge + bonus points + auto-cert ────
    if ( $track_id ) {
        $prog = pildcm_get_track_progress( $user_id, $track_id );
        // Points/badge/certificate keyed to the bilingual GROUP of $track_id,
        // not this one request's specific language ID — so finishing the
        // track (in any mix of AR/EN steps) awards them exactly once.
        $track_ids_bi   = function_exists( 'pild_bilingual_post_ids' ) ? pild_bilingual_post_ids( $track_id ) : [ $track_id ];
        $track_ph       = implode( ',', array_fill( 0, count( $track_ids_bi ), '%d' ) );
        $track_group_id = function_exists( 'pild_bilingual_group_key' ) ? pild_bilingual_group_key( $track_id ) : $track_id;
        if ( $prog['pct'] >= 100 ) {
            // Bonus points (once)
            $track_pts_exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_points WHERE user_id=%d AND reason='track_complete' AND ref_id IN ($track_ph) LIMIT 1",
                array_merge( [ $user_id ], $track_ids_bi )
            ) );
            if ( ! $track_pts_exists ) {
                $wpdb->insert( "{$wpdb->prefix}pild_points", [
                    'user_id'   => $user_id,
                    'points'    => $pts_cfg['track_complete'],
                    'reason'    => 'track_complete',
                    'ref_id'    => $track_id,
                    'earned_at' => current_time( 'mysql' ),
                ] );
                $message .= ' · Track complete! +' . $pts_cfg['track_complete'] . ' bonus pts';
            }
            if ( $award_badge( 'track_finisher', $track_group_id ) ) $message .= ' · 🏁 Badge: Track Finisher!';

            // Auto-certificate if no quiz-based cert exists yet (for this
            // track or its translation).
            $existing_cert = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_results WHERE user_id=%d AND track_id IN ($track_ph) AND passed='yes' LIMIT 1",
                array_merge( [ $user_id ], $track_ids_bi )
            ) );
            if ( ! $existing_cert && ! get_post_meta( $track_id, 'track_quiz_id', true ) ) {
                $cert_code = strtoupper( wp_generate_password( 12, false ) );
                $user_obj  = get_userdata( $user_id );
                $cert_data = [
                    'user_name'   => $user_obj ? $user_obj->display_name : '',
                    'track_title' => get_the_title( $track_id ),
                    'score'       => 100,
                ];
                $cert_url = '';
                if ( function_exists( 'pildcm_generate_branded_certificate' ) ) {
                    $cert_url = pildcm_generate_branded_certificate( $user_id, $track_id, 0, 100, $cert_code, $cert_data );
                }
                $wpdb->insert( "{$wpdb->prefix}pild_results", [
                    'user_id'          => $user_id,
                    'track_id'         => $track_id,
                    'score'            => 100,
                    'total_questions'  => 0,
                    'passed'           => 'yes',
                    'certificate_code' => $cert_code,
                    'certificate_url'  => $cert_url ?: home_url( '/certificate/' . $cert_code ),
                    'completed_at'     => current_time( 'mysql' ),
                ] );
                $award_badge( 'certified' );
                $message .= ' · 🏅 Certificate issued!';
            }
        }
    }

    // ── 9. Navigation links (for pild-learning floating footer JS) ─
    $next_playbook = pild_get_next_playbook( $program_id, $playbook_id );

    wp_send_json_success( [
        'message'            => $message,
        'completed'          => true,
        'next_playbook_url'    => $next_playbook  ? get_permalink( $next_playbook->ID )   : null,
        'next_playbook_title'  => $next_playbook  ? $next_playbook->post_title            : null,
        'program_completed'  => $prog_complete,
        'next_program_url'   => $next_program ? get_permalink( $next_program->ID )  : null,
        'next_program_title' => $next_program ? $next_program->post_title           : null,
        'track_url'          => $track_id ? get_permalink( $track_id ) : '',
    ] );
}

// ============================================================
// CONTENT FILTERS — Domain, Track, Program, Playbook pages
// (from pild-learning, unchanged)
// ============================================================
add_shortcode( 'pild_dashboard', 'pild_dashboard_shortcode' );
function pild_dashboard_shortcode() {
    if ( ! is_user_logged_in() ) return pild_restricted_html( 'login', get_permalink() );

    global $wpdb;
    $uid  = get_current_user_id();
    $done = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d", $uid ) );
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT track_id, COUNT(*) as completed FROM {$wpdb->prefix}pild_progress WHERE user_id=%d GROUP BY track_id", $uid ) );

    ob_start();
    echo pild_global_css();
    ?>
    <div class="pild-wrap">
      <div class="pild-dash-hero">
        <div class="pild-dash-hero-left">
          <div class="pild-section-tag"><?php esc_html_e( 'My Development Dashboard', 'pild-unified' ); ?></div>
          <h1 class="pild-dash-title"><?php echo esc_html( wp_get_current_user()->display_name ); ?></h1>
          <p class="pild-dash-subtitle"><?php esc_html_e( 'Welcome back. Keep building your leadership capability.', 'pild-unified' ); ?></p>
        </div>
        <div class="pild-dash-stat-box">
          <span class="pild-stat-num"><?php echo $done; ?></span>
          <span class="pild-stat-label"><?php esc_html_e( 'Sections Completed', 'pild-unified' ); ?></span>
        </div>
      </div>
      <div class="pild-section-tag" style="margin-bottom:1.5rem"><?php esc_html_e( 'Your Active Tracks', 'pild-unified' ); ?></div>
      <?php if ( $rows ) : ?>
        <div class="pild-dash-track-grid">
          <?php foreach ( $rows as $row ) :
              $title = get_the_title( $row->track_id );
              $link  = get_permalink( $row->track_id );
              $total = count( get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1, 'meta_key' => 'program_track', 'meta_value' => $row->track_id ] ) );
          ?>
          <div class="pild-dash-track-card">
            <h3 class="pild-dash-track-title"><?php echo esc_html( $title ); ?></h3>
            <p class="pild-dash-track-meta"><?php printf( esc_html__( '%1$d Playbooks completed · %2$d programs', 'pild-unified' ), intval( $row->completed ), $total ); ?></p>
            <div class="pild-progress-wrap" style="margin:1rem 0 1.25rem">
              <div class="pild-progress-bar" style="width:<?php echo min( 100, round( ( intval( $row->completed ) / max( 1, $total * 3 ) ) * 100 ) ); ?>%"></div>
            </div>
            <a href="<?php echo esc_url( $link ); ?>" class="pild-btn-primary"><?php esc_html_e( 'Continue →', 'pild-unified' ); ?></a>
          </div>
          <?php endforeach; ?>
        </div>
      <?php else : ?>
        <div class="pild-empty-state">
          <div class="pild-empty-icon"><svg width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg></div>
          <p><?php esc_html_e( "You haven't started any tracks yet.", 'pild-unified' ); ?></p>
          <a href="/sectors" class="pild-btn-primary"><?php esc_html_e( 'Explore Our Sectors →', 'pild-unified' ); ?></a>
        </div>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

add_filter( 'the_content', 'pild_display_domains_on_sector', 20 );
function pild_display_domains_on_sector( $content ) {
    if ( ! is_singular( 'sector' ) ) return $content;
    global $post;
    $domains = get_posts( [ 'post_type' => 'domain', 'posts_per_page' => -1,
        'meta_key' => 'domain_sector', 'meta_value' => $post->ID, 'post_status' => 'publish' ] );
    ob_start();
    echo pild_global_css();
    if ( empty( $domains ) ) {
        echo '<div class="pild-empty-state"><div class="pild-empty-icon">🚀</div><p>' . esc_html__('Expanding this Sector soon.', 'pild-unified') . '</p></div>';
        return $content . ob_get_clean();
    }
    ?>
    <div class="pild-wrap">
      <div class="pild-section-tag" style="margin-bottom:2rem"><?php esc_html_e( 'Explore Practice Areas in this Sector', 'pild-unified' ); ?></div>
      <div class="pild-tracks-grid">
        <?php foreach ( $domains as $domain ) :
            $link     = get_permalink( $domain->ID );
            $thumb    = get_the_post_thumbnail_url( $domain->ID, 'medium' );
            $excerpt  = wp_trim_words( $domain->post_excerpt ?: $domain->post_content, 18 );
            $tracks   = get_posts( [ 'post_type' => 'track', 'posts_per_page' => -1, 'meta_key' => 'track_domain', 'meta_value' => $domain->ID ] );
            $t_count  = count( $tracks );
        ?>
        <div class="pild-track-card">
          <?php if ( $thumb ) : ?>
            <div class="pild-track-thumb" style="background-image:url('<?php echo esc_url( $thumb ); ?>')"></div>
          <?php else : ?>
            <div class="pild-track-thumb pild-track-thumb-empty"><svg width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg></div>
          <?php endif; ?>
          <div class="pild-track-card-body">
            <h3 class="pild-track-card-title"><?php echo esc_html( $domain->post_title ); ?></h3>
            <?php if ( $excerpt ) : ?><p class="pild-track-card-desc"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
            <div class="pild-track-meta">
              <span><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg> <b><?php echo $t_count; ?></b> <?php esc_html_e( 'Tracks', 'pild-unified' ); ?></span>
            </div>
            <a href="<?php echo esc_url( $link ); ?>" class="pild-btn-primary pild-btn-full"><?php esc_html_e( 'Explore Practice Area →', 'pild-unified' ); ?></a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php
    return $content . ob_get_clean();
}

add_filter( 'the_content', 'pild_display_tracks_on_domain', 20 );
function pild_display_tracks_on_domain( $content ) {
    if ( ! is_singular( 'domain' ) ) return $content;
    global $post;
    $tracks = get_posts( [ 'post_type' => 'track', 'posts_per_page' => -1,
        'meta_key' => 'track_domain', 'meta_value' => $post->ID, 'post_status' => 'publish' ] );
    ob_start();
    echo pild_global_css();
    if ( empty( $tracks ) ) {
        echo '<div class="pild-empty-state"><div class="pild-empty-icon">🚀</div><p>' . esc_html__('Expanding our Practice Areas soon.', 'pild-unified') . '</p></div>';
        return $content . ob_get_clean();
    }
    ?>
    <div class="pild-wrap">
      <div class="pild-section-tag" style="margin-bottom:2rem"><?php esc_html_e( 'Explore Tracks in this Practice Area', 'pild-unified' ); ?></div>
      <div class="pild-tracks-grid">
        <?php foreach ( $tracks as $track ) :
            $link     = get_permalink( $track->ID );
            $thumb    = get_the_post_thumbnail_url( $track->ID, 'medium' );
            $excerpt  = wp_trim_words( $track->post_excerpt ?: $track->post_content, 18 );
            $programs = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1, 'meta_key' => 'program_track', 'meta_value' => $track->ID ] );
            $p_count  = count( $programs );
            $l_count  = 0;
            foreach ( $programs as $p ) $l_count += count( get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1, 'meta_key' => 'playbook_program', 'meta_value' => $p->ID ] ) );
        ?>
        <div class="pild-track-card">
          <?php if ( $thumb ) : ?>
            <div class="pild-track-thumb" style="background-image:url('<?php echo esc_url( $thumb ); ?>')"></div>
          <?php else : ?>
            <div class="pild-track-thumb pild-track-thumb-empty"><svg width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.2" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg></div>
          <?php endif; ?>
          <div class="pild-track-card-body">
            <h3 class="pild-track-card-title"><?php echo esc_html( $track->post_title ); ?></h3>
            <?php if ( $excerpt ) : ?><p class="pild-track-card-desc"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
            <div class="pild-track-meta">
              <span><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg> <b><?php echo $p_count; ?></b> <?php esc_html_e( 'Programs', 'pild-unified' ); ?></span>
              <span><svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> <b><?php echo $l_count; ?></b> <?php esc_html_e( 'Playbooks', 'pild-unified' ); ?></span>
            </div>
            <a href="<?php echo esc_url( $link ); ?>" class="pild-btn-primary pild-btn-full"><?php esc_html_e( 'Explore Track →', 'pild-unified' ); ?></a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php
    return $content . ob_get_clean();
}

add_filter( 'the_content', 'pild_display_programs_on_track', 20 );
function pild_display_programs_on_track( $content ) {
    if ( ! is_singular( 'track' ) ) return $content;
    global $post;
    $track_id    = $post->ID;
    $programs    = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1,
        'meta_key' => 'program_track', 'meta_value' => $track_id,
        'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ] );
    if ( empty( $programs ) ) return $content . '<div class="pild-empty-state"><div class="pild-empty-icon">🚧</div><p>' . esc_html__('No programs added yet.', 'pild-unified') . '</p></div>';

    $total_playbooks = 0;
    foreach ( $programs as $p ) $total_playbooks += count( get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1, 'meta_key' => 'playbook_program', 'meta_value' => $p->ID ] ) );

    $completed_playbooks = 0;
    if ( is_user_logged_in() ) {
        global $wpdb;
        $completed_playbooks = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}pild_progress WHERE user_id=%d AND track_id=%d",
            get_current_user_id(), $track_id
        ) );
    }
    $progress_pct = $total_playbooks > 0 ? round( ( $completed_playbooks / $total_playbooks ) * 100 ) : 0;

    ob_start();
    echo pild_global_css();
    ?>
    <div class="pild-wrap">
      <div class="pild-track-hero">
        <div class="pild-track-hero-left">
          <h2 class="pild-track-hero-title"><?php echo esc_html( get_the_title( $track_id ) ); ?></h2>
          <div class="pild-track-hero-meta"><?php printf( esc_html__( '%1$d / %2$d Playbooks completed', 'pild-unified' ), $completed_playbooks, $total_playbooks ); ?></div>
        </div>
        <div class="pild-track-hero-right"><span class="pild-hero-pct"><?php echo $progress_pct; ?>%</span></div>
        <div class="pild-progress-wrap" style="grid-column:1/-1;margin-top:.5rem">
          <div class="pild-progress-bar" style="width:<?php echo $progress_pct; ?>%"></div>
        </div>
      </div>
      <div class="pild-programs-list">
        <?php foreach ( $programs as $prog_idx => $program ) :
            global $wpdb;
            $playbooks  = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1,
                'meta_key' => 'playbook_program', 'meta_value' => $program->ID,
                'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ] );
            $prog_done = 0; $done_ids = [];
            if ( is_user_logged_in() ) {
                foreach ( $playbooks as $l ) {
                    if ( pild_playbook_completed( get_current_user_id(), $l->ID ) ) { $prog_done++; $done_ids[] = $l->ID; }
                }
            }
            $prog_pct      = count( $playbooks ) > 0 ? round( ( $prog_done / count( $playbooks ) ) * 100 ) : 0;
            $prog_complete = ( $prog_pct >= 100 && count( $playbooks ) > 0 );
            $is_unlocked   = true;
            if ( $prog_idx > 0 && is_user_logged_in() ) {
                $prev    = $programs[ $prog_idx - 1 ];
                $prev_ls = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1, 'meta_key' => 'playbook_program', 'meta_value' => $prev->ID ] );
                $prev_done = 0;
                foreach ( $prev_ls as $pl ) { if ( pild_playbook_completed( get_current_user_id(), $pl->ID ) ) $prev_done++; }
                if ( $prev_done < count( $prev_ls ) ) $is_unlocked = false;
            }
        ?>
        <div class="pild-program-card <?php echo $is_unlocked ? '' : 'pild-locked'; ?>">
          <div class="pild-program-header" onclick="pildToggle(this)" role="button" aria-expanded="false">
            <div class="pild-program-header-left">
              <span class="pild-toggle-icon"><svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg></span>
              <div>
                <div class="pild-program-title">
                  <?php echo esc_html( $program->post_title ); ?>
                  <?php if ( ! $is_unlocked ) : ?><span class="pild-badge-locked">🔒 <?php esc_html_e( 'Locked', 'pild-unified' ); ?></span>
                  <?php elseif ( $prog_complete ) : ?><span class="pild-badge-done">✓ <?php esc_html_e( 'Complete', 'pild-unified' ); ?></span>
                  <?php endif; ?>
                </div>
                <div class="pild-program-meta"><?php printf( esc_html__( '%1$d Playbooks · %2$d%% complete', 'pild-unified' ), count( $playbooks ), $prog_pct ); ?></div>
              </div>
            </div>
            <div class="pild-program-header-right">
              <div class="pild-mini-prog-wrap"><div class="pild-mini-prog-bar" style="width:<?php echo $prog_pct; ?>%"></div></div>
              <span class="pild-prog-pct"><?php echo $prog_pct; ?>%</span>
            </div>
          </div>
          <div class="pild-program-body" id="prog-<?php echo $program->ID; ?>">
            <?php if ( ! $is_unlocked && $prog_idx > 0 ) : ?>
              <div class="pild-locked-notice">
                <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                <div>
                  <strong><?php esc_html_e( 'Program Locked', 'pild-unified' ); ?></strong>
                  <p><?php printf( wp_kses( __( 'Complete "%s" to unlock this program.', 'pild-unified' ), ['strong'=>[]] ), '<strong>' . esc_html( $programs[ $prog_idx - 1 ]->post_title ) . '</strong>' ); ?></p>
                </div>
              </div>
            <?php else : ?>
              <?php foreach ( $playbooks as $playbook ) :
                  $l_done     = in_array( $playbook->ID, $done_ids );
                  $l_link     = get_permalink( $playbook->ID );
                  $has_access = pild_user_can_access( $playbook->ID );
              ?>
              <div class="pild-playbook-row <?php echo $l_done ? 'pild-done' : ''; ?>">
                <div class="pild-playbook-row-left">
                  <span class="pild-playbook-dot <?php echo $l_done ? 'pild-dot-done' : ''; ?>">
                    <?php if ( $l_done ) : ?><svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg><?php endif; ?>
                  </span>
                  <?php echo pild_get_playbook_type_badge( $playbook->ID ); ?>
                  <span class="pild-playbook-name"><?php echo esc_html( $playbook->post_title ); ?></span>
                </div>
                <div class="pild-playbook-row-right">
                  <?php if ( ! $has_access ) : ?><span class="pild-badge-members">🔐 <?php esc_html_e( 'Members Only', 'pild-unified' ); ?></span>
                  <?php elseif ( $l_done ) : ?><span class="pild-badge-done">✓ <?php esc_html_e( 'Done', 'pild-unified' ); ?></a><a href="<?php echo esc_url( $l_link ); ?>" class="pild-btn-ghost"><?php esc_html_e( 'Re-read', 'pild-unified' ); ?></a>
                  <?php else : ?><a href="<?php echo esc_url( $l_link ); ?>" class="pild-btn-primary pild-btn-sm"><?php esc_html_e( 'Start →', 'pild-unified' ); ?></a>
                  <?php endif; ?>
                </div>
              </div>
              <?php endforeach; ?>
              <?php if ( empty( $playbooks ) ) : ?><div class="pild-empty-state pild-empty-sm"><p><?php esc_html_e( 'No Playbooks in this program yet.', 'pild-unified' ); ?></p></div><?php endif; ?>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php
      $quiz_url = get_field( 'quiz_url', $track_id );
      // Native quiz engine fallback: if no external Quiz Maker URL is set
      // on this track, but a native Assessment (includes/28-quiz-engine.php)
      // is linked to it, use that instead — same "Take the Assessment"
      // button, just pointed at the assessment's own page.
      $native_assessment_id = $quiz_url ? 0 : ( function_exists( 'pild_quiz_get_assessment_for_track' ) ? pild_quiz_get_assessment_for_track( $track_id ) : 0 );
      $assessment_link      = $quiz_url ? $quiz_url : ( $native_assessment_id ? get_permalink( $native_assessment_id ) : '' );
      if ( $assessment_link && is_user_logged_in() ) :
          // Assessment unlocks only when every program (in order) is 100% complete
          $all_done = false;
          if ( $total_playbooks > 0 ) {
              $all_programs_done = true;
              foreach ( $programs as $_prog ) {
                  $_prog_playbooks = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1,
                      'meta_key' => 'playbook_program', 'meta_value' => $_prog->ID,
                      'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC', 'fields' => 'ids' ] );
                  if ( empty( $_prog_playbooks ) ) continue;
                  foreach ( $_prog_playbooks as $_lid ) {
                      if ( ! pild_playbook_completed( get_current_user_id(), $_lid ) ) {
                          $all_programs_done = false;
                          break 2;
                      }
                  }
              }
              $all_done = $all_programs_done;
          }
      ?>
      <div class="pild-assessment-section <?php echo $all_done ? 'pild-assessment-ready' : ''; ?>">
        <div class="pild-assessment-icon"><svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg></div>
        <div class="pild-assessment-body">
          <div class="pild-section-tag" style="margin-bottom:.5rem"><?php esc_html_e( 'Final Assessment', 'pild-unified' ); ?></div>
          <h3 class="pild-assessment-title"><?php printf( esc_html__( '%s — Final Assessment', 'pild-unified' ), esc_html( get_the_title( $track_id ) ) ); ?></h3>
          <?php if ( $all_done ) : ?>
            <p class="pild-assessment-desc"><?php esc_html_e( "You've completed all Playbooks. You're ready to take the final assessment.", 'pild-unified' ); ?></p>
            <a href="<?php echo esc_url( $assessment_link ); ?>" class="pild-btn-primary"><?php esc_html_e( 'Take the Assessment →', 'pild-unified' ); ?></a>
          <?php else : ?>
            <p class="pild-assessment-desc"><?php printf( esc_html( _n( 'Complete %d more Playbook to unlock the final assessment.', 'Complete %d more Playbooks to unlock the final assessment.', ( $total_playbooks - $completed_playbooks ), 'pild-unified' ) ), ( $total_playbooks - $completed_playbooks ) ); ?></p>
            <span class="pild-assessment-locked-label"><?php esc_html_e( 'Assessment Locked', 'pild-unified' ); ?></span>
          <?php endif; ?>
        </div>
      </div>

      <?php
      // PHASE 20: Certificate card, right after Assessment — mirrors the
      // same is-it-unlocked logic. 3 states:
      //   1. Playbooks not all done yet -> locked, same reason as Assessment.
      //   2. Playbooks done but no passing result yet -> "pass the assessment first".
      //   3. Certificate already earned (pildcm_get_certificate_url() in
      //      includes/02-helpers.php) -> View/Download button.
      $cert_url = function_exists( 'pildcm_get_certificate_url' ) ? pildcm_get_certificate_url( get_current_user_id(), $track_id ) : '';
      ?>
      <div class="pild-assessment-section <?php echo $cert_url ? 'pild-assessment-ready' : ''; ?>" style="margin-top:1rem;">
        <div class="pild-assessment-icon"><svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 15a6 6 0 100-12 6 6 0 000 12z"/><path d="M8.5 13.5L7 22l5-3 5 3-1.5-8.5"/></svg></div>
        <div class="pild-assessment-body">
          <div class="pild-section-tag" style="margin-bottom:.5rem"><?php esc_html_e( 'Certificate', 'pild-unified' ); ?></div>
          <h3 class="pild-assessment-title"><?php printf( esc_html__( '%s — Certificate', 'pild-unified' ), esc_html( get_the_title( $track_id ) ) ); ?></h3>
          <?php if ( $cert_url ) : ?>
            <p class="pild-assessment-desc"><?php esc_html_e( 'Congratulations — you earned this certificate.', 'pild-unified' ); ?></p>
            <a href="<?php echo esc_url( $cert_url ); ?>" class="pild-btn-primary" target="_blank"><?php esc_html_e( 'View / Download Certificate →', 'pild-unified' ); ?></a>
          <?php elseif ( $all_done ) : ?>
            <p class="pild-assessment-desc"><?php esc_html_e( 'Pass the final assessment above to earn your certificate.', 'pild-unified' ); ?></p>
            <span class="pild-assessment-locked-label"><?php esc_html_e( 'Certificate Locked', 'pild-unified' ); ?></span>
          <?php else : ?>
            <p class="pild-assessment-desc"><?php esc_html_e( 'Complete all Playbooks and pass the final assessment to earn your certificate.', 'pild-unified' ); ?></p>
            <span class="pild-assessment-locked-label"><?php esc_html_e( 'Certificate Locked', 'pild-unified' ); ?></span>
          <?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
      <?php if ( function_exists( 'pild_get_user_dashboard_url' ) ) : ?>
        <div style="margin-top:2.5rem;text-align:center;">
          <a href="<?php echo esc_url( pild_get_user_dashboard_url( get_current_user_id() ) ); ?>" class="pild-back-link" style="display:inline-flex;">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
            <?php esc_html_e( 'Back to Dashboard', 'pild-unified' ); ?>
          </a>
        </div>
      <?php endif; ?>
    </div>
    <script>
    function pildToggle(header) {
        var body=header.nextElementSibling,icon=header.querySelector('.pild-toggle-icon'),isOpen=body.classList.contains('pild-open');
        body.classList.toggle('pild-open',!isOpen);header.setAttribute('aria-expanded',!isOpen);
        icon.style.transform=isOpen?'':'rotate(90deg)';
    }
    document.addEventListener('DOMContentLoaded',function(){
        var cards=document.querySelectorAll('.pild-program-card:not(.pild-locked)');
        for(var i=0;i<cards.length;i++){
            var bar=cards[i].querySelector('.pild-mini-prog-bar');
            if(bar&&bar.style.width!=='100%'){var hdr=cards[i].querySelector('.pild-program-header');if(hdr)pildToggle(hdr);break;}
        }
    });
    </script>
    <?php
    return ob_get_clean();
}

add_filter( 'the_content', 'pild_display_program_page', 20 );
function pild_display_program_page( $content ) {
    if ( ! is_singular( 'program' ) ) return $content;
    global $post;
    $program_id = $post->ID;
    $track_id   = get_field( 'program_track', $program_id );
    if ( ! $track_id ) return $content . '<div class="pild-empty-state"><p>⚠️ ' . esc_html__('Program not linked to a track.', 'pild-unified') . '</p></div>';

    $playbooks  = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1,
        'meta_key' => 'playbook_program', 'meta_value' => $program_id,
        'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ] );
    $programs = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1,
        'meta_key' => 'program_track', 'meta_value' => $track_id,
        'orderby' => 'menu_order', 'order' => 'ASC' ] );

    $current_idx = -1;
    foreach ( $programs as $idx => $p ) { if ( $p->ID == $program_id ) { $current_idx = $idx; break; } }

    $is_unlocked  = true;
    $prev_program = null;
    if ( $current_idx > 0 && is_user_logged_in() ) {
        $prev_program = $programs[ $current_idx - 1 ];
        $prev_ls      = get_posts( [ 'post_type' => 'playbook', 'posts_per_page' => -1, 'meta_key' => 'playbook_program', 'meta_value' => $prev_program->ID ] );
        $prev_done    = 0;
        foreach ( $prev_ls as $pl ) { if ( pild_playbook_completed( get_current_user_id(), $pl->ID ) ) $prev_done++; }
        if ( $prev_done < count( $prev_ls ) ) $is_unlocked = false;
    }

    $done_ids  = []; $prog_done = 0;
    if ( is_user_logged_in() && $is_unlocked ) {
        foreach ( $playbooks as $l ) {
            if ( pild_playbook_completed( get_current_user_id(), $l->ID ) ) { $done_ids[] = $l->ID; $prog_done++; }
        }
    }
    $prog_pct      = count( $playbooks ) > 0 ? round( ( $prog_done / count( $playbooks ) ) * 100 ) : 0;
    $prog_complete = ( $prog_pct >= 100 && count( $playbooks ) > 0 );
    $next_program  = isset( $programs[ $current_idx + 1 ] ) ? $programs[ $current_idx + 1 ] : null;

    ob_start();
    echo pild_global_css();
    ?>
    <div class="pild-wrap">
      <a href="<?php echo get_permalink( $track_id ); ?>" class="pild-back-link"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg> <?php esc_html_e( 'Back to Track', 'pild-unified' ); ?></a>
      <?php if ( ! $is_unlocked && $prev_program ) : ?>
        <div class="pild-locked-page">
          <svg width="40" height="40" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
          <h3><?php esc_html_e( 'Program Locked', 'pild-unified' ); ?></h3>
          <p><?php printf( wp_kses( __( 'Complete all Playbooks in %s to unlock this program.', 'pild-unified' ), ['strong'=>[]] ), '<strong>"' . esc_html( $prev_program->post_title ) . '"</strong>' ); ?></p>
        </div>
      <?php else : ?>
        <div class="pild-track-hero">
          <div class="pild-track-hero-left">
            <div class="pild-track-tag"><?php esc_html_e( 'Program', 'pild-unified' ); ?></div>
            <h2 class="pild-track-hero-title"><?php echo esc_html( get_the_title( $program_id ) ); ?></h2>
            <div class="pild-track-hero-meta"><?php printf( esc_html__( '%1$d / %2$d Playbooks completed', 'pild-unified' ), $prog_done, count( $playbooks ) ); ?></div>
          </div>
          <div class="pild-track-hero-right"><span class="pild-hero-pct"><?php echo $prog_pct; ?>%</span></div>
          <div class="pild-progress-wrap" style="grid-column:1/-1;margin-top:.5rem"><div class="pild-progress-bar" style="width:<?php echo $prog_pct; ?>%"></div></div>
        </div>
        <?php $raw = get_the_content( null, false, $post ); if ( $raw ) : ?>
          <div class="pild-program-description"><?php echo wpautop( $raw ); ?></div>
        <?php endif; ?>
        <div class="pild-section-tag" style="margin-bottom:1.5rem"><?php esc_html_e( 'Playbooks in this Program', 'pild-unified' ); ?></div>
        <?php if ( empty( $playbooks ) ) : ?>
          <div class="pild-empty-state"><div class="pild-empty-icon">📖</div><p><?php esc_html_e( 'No Playbooks added yet.', 'pild-unified' ); ?></p></div>
        <?php else : ?>
          <div class="pild-playbooks-list">
            <?php foreach ( $playbooks as $i => $playbook ) :
                $l_done     = in_array( $playbook->ID, $done_ids );
                $l_link     = get_permalink( $playbook->ID );
                $has_access = pild_user_can_access( $playbook->ID );
            ?>
            <div class="pild-playbook-full-row <?php echo $l_done ? 'pild-done' : ''; ?>">
              <div class="pild-playbook-full-num"><?php printf( '%02d', $i + 1 ); ?></div>
              <div class="pild-playbook-full-info">
                <?php echo pild_get_playbook_type_badge( $playbook->ID ); ?>
                <span class="pild-playbook-full-title"><?php echo esc_html( $playbook->post_title ); ?></span>
              </div>
              <div class="pild-playbook-full-actions">
                <?php if ( ! $has_access ) : ?><span class="pild-badge-members">🔐 <?php esc_html_e( 'Members Only', 'pild-unified' ); ?></span>
                <?php elseif ( $l_done ) : ?><span class="pild-badge-done">✓ <?php esc_html_e( 'Done', 'pild-unified' ); ?></a><a href="<?php echo esc_url( $l_link ); ?>" class="pild-btn-ghost"><?php esc_html_e( 'Re-read', 'pild-unified' ); ?></a>
                <?php else : ?><a href="<?php echo esc_url( $l_link ); ?>" class="pild-btn-primary pild-btn-sm"><?php esc_html_e( 'Open →', 'pild-unified' ); ?></a>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php if ( $prog_complete ) : ?>
          <div class="pild-completion-banner">
            <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>
            <div>
              <strong><?php esc_html_e( 'Program Complete!', 'pild-unified' ); ?></strong>
              <?php if ( $next_program ) : ?><a href="<?php echo get_permalink( $next_program->ID ); ?>" class="pild-btn-primary" style="margin-left:1rem"><?php printf( esc_html__( 'Next: %s →', 'pild-unified' ), esc_html( $next_program->post_title ) ); ?></a>
              <?php else : ?><a href="<?php echo get_permalink( $track_id ); ?>" class="pild-btn-primary" style="margin-left:1rem"><?php esc_html_e( 'Back to Development Track 🏆', 'pild-unified' ); ?></a><?php endif; ?>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// ── Playbook page content wrap ──
add_filter( 'the_content', 'pild_add_complete_button', 20 );
function pild_add_complete_button( $content ) {
    if ( ! is_singular( 'playbook' ) ) return $content;
    global $post;
    if ( ! pild_user_can_access( $post->ID ) ) {
        $track_id = function_exists( 'pildcm_get_playbook_track_id' ) ? pildcm_get_playbook_track_id( $post->ID ) : 0;
        return pild_restricted_html( pild_playbook_restricted_type( $post->ID ), get_permalink(), $track_id );
    }
    // PHASE 15: "Playbook Type" removed — every playbook uses the same
    // (previously "book") wrap style, no per-post type badge header.
    ob_start();
    echo pild_global_css();
    ?>
    <div class="pild-wrap pild-wrap-book">
      <div class="pild-playbook-content"><?php
        // PHASE 15: playbook content is now a link to an external book/reader,
        // embedded in an iframe, instead of raw WordPress editor content. A
        // post whose content is just one URL (no other HTML/text) gets
        // rendered as a frame; anything else falls back to normal rendering
        // (backward compatible with existing playbooks that still have real
        // written content instead of a link).
        $trimmed_content = trim( wp_strip_all_tags( $content ) );
        if ( filter_var( $trimmed_content, FILTER_VALIDATE_URL ) ) {
            echo '<iframe src="' . esc_url( $trimmed_content ) . '" class="pild-playbook-frame" style="width:100%;min-height:80vh;border:none;border-radius:var(--r);" loading="lazy" allowfullscreen></iframe>';
        } else {
            echo $content;
        }
      ?></div>
    </div>
    <?php
    return ob_get_clean();
}

// ── Playbook floating footer (the Mark as Complete bar) ──
add_action( 'wp_footer', 'pild_inject_playbook_footer', 5 );
function pild_inject_playbook_footer() {
    if ( ! is_singular( 'playbook' ) ) return;
    global $post;
    if ( ! pild_user_can_access( $post->ID ) ) return;

    $program_id = get_field( 'playbook_program', $post->ID );
    $track_id   = $program_id ? get_field( 'program_track', $program_id ) : null;
    $completed  = is_user_logged_in() ? pild_playbook_completed( get_current_user_id(), $post->ID ) : false;
    $next_l     = pild_get_next_playbook( $program_id, $post->ID );
    $next_p     = null;
    if ( ! $next_l && $track_id ) {
        $all_progs = get_posts( [ 'post_type' => 'program', 'posts_per_page' => -1,
            'meta_key' => 'program_track', 'meta_value' => $track_id,
            'orderby' => 'menu_order', 'order' => 'ASC' ] );
        foreach ( $all_progs as $idx => $p ) {
            if ( $p->ID == $program_id && isset( $all_progs[ $idx + 1 ] ) ) { $next_p = $all_progs[ $idx + 1 ]; break; }
        }
    }
    ?>
    <style>
    #pild-floating-footer{position:fixed!important;bottom:0!important;left:0!important;right:0!important;z-index:999999!important;background:#fff;border-top:1px solid rgba(13,17,23,.12);box-shadow:0 -4px 20px rgba(13,17,23,.10);padding:1rem 1.25rem;display:flex!important;align-items:center;justify-content:center;gap:.75rem;flex-wrap:wrap;box-sizing:border-box;visibility:visible!important;opacity:1!important;transform:none!important;}
    #pild-floating-footer .pild-btn-complete{font-family:"DM Sans",sans-serif;font-size:.92rem;font-weight:500;color:#fff;background:#0E6655;border:none;cursor:pointer;padding:.85rem 2rem;border-radius:8px;display:inline-flex;align-items:center;gap:.65rem;transition:all .2s ease;white-space:nowrap;}
    #pild-floating-footer .pild-btn-complete:hover{background:#148F77;}
    #pild-floating-footer .pild-btn-complete:disabled{opacity:.5;cursor:not-allowed;}
    #pild-floating-footer .pild-btn-login{font-family:"DM Sans",sans-serif;font-size:.82rem;font-weight:500;color:#fff;background:#0E6655;padding:.75rem 1.75rem;border-radius:8px;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem;}
    #pild-floating-footer .pild-btn-primary{font-family:"DM Sans",sans-serif;font-size:.82rem;font-weight:500;color:#fff;background:#0D1117;padding:.55rem 1.35rem;border-radius:8px;text-decoration:none;display:inline-flex;align-items:center;gap:.4rem;}
    #pild-floating-footer .pild-btn-ghost{font-family:"DM Sans",sans-serif;font-size:.78rem;color:#3A3F4A;background:transparent;border:1px solid rgba(13,17,23,.18);padding:.4rem 1rem;border-radius:8px;text-decoration:none;display:inline-flex;align-items:center;}
    #pild-floating-footer .pild-done-msg{display:flex;align-items:center;gap:.65rem;font-size:.9rem;color:#0E6655;font-weight:500;}
    #pild-floating-footer .pild-login-msg{font-size:.82rem;color:#7A8090;}
    #pild-floating-footer .pild-msg-success{font-size:.88rem;color:#0E6655;font-weight:500;}
    #pild-floating-footer .pild-msg-error{font-size:.88rem;color:#c0392b;}
    @keyframes pild-rotate2{to{transform:rotate(360deg);}}
    #pild-floating-footer .pild-spin{display:inline-block;animation:pild-rotate2 .8s linear infinite;}
    body.single-playbook{padding-bottom:80px!important;}
    </style>
    <div id="pild-floating-footer">
    <?php if ( ! is_user_logged_in() ) : ?>
      <span class="pild-login-msg"><?php esc_html_e( 'Log in to track your progress', 'pild-unified' ); ?></span>
      <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="pild-btn-login">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg><?php esc_html_e( 'Login to Track Progress', 'pild-unified' ); ?></a>
    <?php elseif ( $completed ) : ?>
      <div class="pild-done-msg"><svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg><?php esc_html_e( "You've completed this Playbook", 'pild-unified' ); ?></div>
      <a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" class="pild-btn-ghost"><?php esc_html_e( 'Re-read', 'pild-unified' ); ?></a>
      <?php if ( $next_l ) : ?><a href="<?php echo esc_url( get_permalink( $next_l->ID ) ); ?>" class="pild-btn-primary"><?php esc_html_e( 'Next Playbook →', 'pild-unified' ); ?></a>
      <?php elseif ( $next_p ) : ?><a href="<?php echo esc_url( get_permalink( $next_p->ID ) ); ?>" class="pild-btn-primary"><?php esc_html_e( 'Next Program →', 'pild-unified' ); ?></a>
      <?php else : ?><a href="<?php echo esc_url( get_permalink( $track_id ) ); ?>" class="pild-btn-primary"><?php esc_html_e( 'Back to Development Track 🏆', 'pild-unified' ); ?></a>
      <?php endif; ?>
    <?php else : ?>
      <button id="pild-complete-btn" class="pild-btn-complete"
          data-playbook="<?php echo intval( $post->ID ); ?>"
          data-program="<?php echo intval( $program_id ); ?>"
          data-track="<?php echo intval( $track_id ); ?>">
        <svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg><?php esc_html_e( 'Mark as Complete', 'pild-unified' ); ?>
      </button>
      <span id="pild-msg"></span>
      <div id="pild-nav" style="display:flex;gap:.75rem;flex-wrap:wrap;align-items:center;"></div>
    <?php endif; ?>
    </div>
    <script>
    (function(){
        var pildI18n = {
            saving: <?php echo wp_json_encode( __( 'Saving…', 'pild-unified' ) ); ?>,
            nextPlaybook: <?php echo wp_json_encode( __( 'Next Playbook →', 'pild-unified' ) ); ?>,
            nextProgram: <?php echo wp_json_encode( __( 'Next Program →', 'pild-unified' ) ); ?>,
            backToTrack: <?php echo wp_json_encode( __( 'Back to Development Track 🏆', 'pild-unified' ) ); ?>,
            reread: <?php echo wp_json_encode( __( 'Re-read', 'pild-unified' ) ); ?>,
            errorRetry: <?php echo wp_json_encode( __( 'Error. Please try again.', 'pild-unified' ) ); ?>,
            networkError: <?php echo wp_json_encode( __( 'Network error. Please try again.', 'pild-unified' ) ); ?>,
            markAsComplete: <?php echo wp_json_encode( __( 'Mark as Complete', 'pild-unified' ) ); ?>
        };
        var btn=document.getElementById('pild-complete-btn');
        if(!btn)return;
        btn.addEventListener('click',function(){
            var playbook=btn.dataset.playbook,program=btn.dataset.program,track=btn.dataset.track;
            var msg=document.getElementById('pild-msg'),nav=document.getElementById('pild-nav');
            btn.disabled=true;btn.innerHTML='<span class="pild-spin">⟳</span> '+pildI18n.saving;
            var body=new URLSearchParams();
            body.append('action','pild_complete_playbook');
            body.append('playbook_id',playbook);body.append('program_id',program);body.append('track_id',track);
            body.append('nonce',(typeof pild_ajax!=='undefined')?pild_ajax.nonce:'<?php echo wp_create_nonce('pild_nonce'); ?>');
            fetch((typeof pild_ajax!=='undefined')?pild_ajax.ajax_url:'<?php echo esc_js(admin_url('admin-ajax.php')); ?>',
                {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()})
            .then(function(r){return r.json();})
            .then(function(data){
                if(data.success){
                    btn.remove();msg.className='pild-msg-success';msg.innerHTML='✓ '+data.data.message;
                    var d=data.data,html='';
                    if(d.next_playbook_url) html+='<a href="'+d.next_playbook_url+'" class="pild-btn-primary">'+pildI18n.nextPlaybook+'</a>';
                    if(d.next_program_url) html+='<a href="'+d.next_program_url+'" class="pild-btn-primary">'+pildI18n.nextProgram+'</a>';
                    if(!d.next_playbook_url&&!d.next_program_url) html+='<a href="'+d.track_url+'" class="pild-btn-primary">'+pildI18n.backToTrack+'</a>';
                    html+='<a href="'+window.location.href+'" class="pild-btn-ghost">'+pildI18n.reread+'</a>';
                    nav.innerHTML=html;
                }else{
                    msg.className='pild-msg-error';msg.innerHTML='✕ '+(data.data||pildI18n.errorRetry);
                    btn.disabled=false;btn.innerHTML='<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> '+pildI18n.markAsComplete;
                }
            })
            .catch(function(){
                msg.className='pild-msg-error';msg.innerHTML='✕ '+pildI18n.networkError;
                btn.disabled=false;btn.innerHTML='<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> '+pildI18n.markAsComplete;
            });
        });
    })();
    </script>
    <?php
}

// ============================================================
// MEMBERSHIP PROTECTION & META BOXES
// (from pild-learning)
// ============================================================

// FIX (2026-07): resolve the track_id that governs access for ANY of the
// gated post types, so pild_enrollments (manager-assigned or auto-enrolled
// tracks) can be checked directly — not just WooCommerce Memberships plans.
// - track      → its own ID
// - program    → program_track meta
// - playbook   → playbook_program → program_track (two hops)
// - assessment → assessment_track meta
// - domain     → no single track applies; returns 0 (falls back to WC Memberships only)
function pild_resolve_gate_track_id( $post_id, $post_type ) {
    switch ( $post_type ) {
        case 'track':
            return (int) $post_id;
        case 'program':
            return (int) get_post_meta( $post_id, 'program_track', true );
        case 'playbook':
            $program_id = (int) get_post_meta( $post_id, 'playbook_program', true );
            return $program_id ? (int) get_post_meta( $program_id, 'program_track', true ) : 0;
        case 'assessment':
            return (int) get_post_meta( $post_id, 'assessment_track', true );
        default:
            return 0;
    }
}

// FIX (2026-07, root-cause): wc_memberships_user_can() is called directly
// from MANY places across this plugin (page templates, quiz gate, dashboards,
// pild_membership_protection() below) — not only through the `the_content`
// filter. Patching pild_membership_protection() alone (as done first) only
// covered the one the_content path; every other direct call — including the
// track page TEMPLATE's own access check, and WooCommerce Memberships' own
// native the_content restriction handler, which also calls this same
// function internally — still said "no access" for anyone who only has a
// pild_enrollments row (manager-assigned or auto-enrolled) without a real
// WC Memberships/Teams membership behind it.
//
// Filtering wc_memberships_user_can() itself fixes every one of those call
// sites at once, and is immune to any the_content hook-priority ordering
// between us and WooCommerce Memberships' own restriction filter.
add_filter( 'wc_memberships_user_can', 'pild_grant_view_access_via_enrollment', 20, 4 );
function pild_grant_view_access_via_enrollment( $can_user, $action, $args, $user_id ) {
    if ( $can_user ) return $can_user; // already allowed — nothing to add
    if ( $action !== 'view' || empty( $args['post'] ) ) return $can_user;

    $post    = $args['post'];
    $post_id = is_object( $post ) ? (int) $post->ID : (int) $post;
    if ( ! $post_id ) return $can_user;

    $track_id = pild_resolve_gate_track_id( $post_id, get_post_type( $post_id ) );
    if ( $track_id && function_exists( 'pildcm_is_enrolled' ) && pildcm_is_enrolled( (int) $user_id, $track_id ) ) {
        return true;
    }
    return $can_user;
}

add_filter( 'the_content', 'pild_membership_protection', 5 );
function pild_membership_protection( $content ) {
    $cpts = [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment' ];
    if ( ! is_singular( $cpts ) ) return $content;
    if ( current_user_can( 'manage_options' ) ) return $content;
    global $post;

    // FIX: pild_enrollments is the plugin's own source of truth (auto-enroll
    // on purchase via ACF product_tracks, AND manager "Assign Track"). A user
    // enrolled this way must get access regardless of whether WooCommerce
    // Memberships/Teams happens to also cover this specific post — this was
    // the missing link that caused "assigned but still asked to purchase".
    if ( is_user_logged_in() ) {
        $gate_track_id = pild_resolve_gate_track_id( $post->ID, get_post_type( $post ) );
        if ( $gate_track_id ) {
            if ( function_exists( 'pildcm_is_enrolled' ) && pildcm_is_enrolled( get_current_user_id(), $gate_track_id ) ) {
                return $content;
            }
            // PHASE 6: distinguish "had access, it lapsed after 1 year" from
            // "never had access" — different message, different call to action.
            if ( function_exists( 'pildcm_enrollment_expired' ) && pildcm_enrollment_expired( get_current_user_id(), $gate_track_id ) ) {
                return pild_restricted_html( 'expired', get_permalink(), $gate_track_id );
            }
        }
    }

    if ( function_exists( 'wc_memberships_is_post_content_restricted' ) ) {
        if ( wc_memberships_is_post_content_restricted( $post->ID ) ) {
            if ( ! is_user_logged_in() ) return pild_restricted_html( 'login', get_permalink() );
            if ( function_exists( 'wc_memberships_user_can' ) &&
                 ! wc_memberships_user_can( get_current_user_id(), 'view', [ 'post' => $post->ID ] ) )
                return pild_restricted_html( 'membership', get_permalink() );
        }
        return $content;
    }
    if ( function_exists( 'pmpro_getMembershipLevelsForPost' ) ) {
        $levels = pmpro_getMembershipLevelsForPost( $post->ID );
        if ( ! empty( $levels ) ) {
            if ( ! is_user_logged_in() ) return pild_restricted_html( 'login', get_permalink() );
            if ( ! pmpro_hasMembershipLevel( $levels ) ) return pild_restricted_html( 'membership', get_permalink() );
        }
    }
    return $content;
}

add_action( 'add_meta_boxes', 'pild_add_membership_meta_boxes' );
function pild_add_membership_meta_boxes() {
    if ( function_exists( 'pmpro_page_meta' ) && ! function_exists( 'wc_memberships' ) ) {
        foreach ( [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment' ] as $cpt )
            add_meta_box( 'pmpro_page_meta', 'Require Membership', 'pmpro_page_meta', $cpt, 'side', 'high' );
    }
}

// ============================================================
// CLEAN THEME CHROME
// (from pild-learning)
// ============================================================
add_action( 'wp_head', 'pild_clean_display', 999 );
function pild_clean_display() {
    if ( ! is_singular( [ 'sector', 'domain', 'track', 'program', 'playbook', 'assessment' ] ) ) return;
    ?>
    <style>
    html,body{background:#F9F7F2 !important;}
    .entry-meta,.post-meta,.post-info,.byline,.posted-on,.entry-date,.updated,.published,
    .author,.post-author,.single .entry-footer,.post-footer,.cat-links,.tags-links,
    .comments-link,.entry-header .entry-meta,footer.entry-meta,.post-date,.date,.time,.meta,.author-name{display:none !important;}
    .single-sector .entry-title,.single-domain .entry-title,.single-track .entry-title,.single-program .entry-title,.single-playbook .entry-title,.single-assessment .entry-title{display:none !important;}
    .entry-content,#content,#primary,#main,.site-main,.content-area,main{background:#F9F7F2 !important;width:100% !important;max-width:100% !important;margin:0 !important;padding:0 !important;float:none !important;}
    .hentry,.post,.page,.type-sector,.type-domain,.type-track,.type-program,.type-playbook,.type-assessment{background:#F9F7F2 !important;margin:0 !important;padding:0 !important;}
    .container,.wrap,.wrapper,.site-content,.page-content,.content-wrap{max-width:100% !important;width:100% !important;margin:0 !important;padding:0 !important;}
    .entry-content{margin-top:0 !important;padding-top:0 !important;}
    .hentry::before,.hentry::after{display:none !important;}
    .pild-wrap{width:100% !important;max-width:100% !important;margin:0 !important;box-sizing:border-box !important;}
    </style>
    <?php
}

// ============================================================
// GLOBAL CSS + RESTRICTED HTML HELPERS
// (from pild-learning — unchanged)
// ============================================================
function pild_global_css() {
    // PHASE 19 FIX: this used to have a `static $printed` guard to avoid
    // duplicate <style> output if called twice in one page load. In
    // practice it did the opposite of what was intended — WordPress (or an
    // SEO plugin generating a meta description) sometimes runs the_content
    // once "invisibly" before the real page render, e.g. to build a
    // fallback excerpt when a post has none. That invisible call alone was
    // enough to flip the guard, so the REAL page render got an empty
    // string back — full HTML structure, zero CSS. This is exactly what
    // made the symptom disappear the moment any Excerpt text was typed in
    // (no more fallback-excerpt-from-content call needed, so the guard
    // never got consumed early). Removing the guard: in the rare case this
    // does run twice on one real page, the only cost is one small
    // duplicate <style> block — harmless — versus the previous failure
    // mode of silently losing all styling.
    // 11-css.php is loaded at plugin init (before modules), so pildcm_css() is always defined.
    // Call it here to bundle dashboard CSS together with playbook CSS in one output.
    $dashboard_css = pildcm_css(); // static guard inside ensures it outputs only once

    return '
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root{--ink:#0D1117;--ink2:#3A3F4A;--ink3:#7A8090;--parchment:#F9F7F2;--cream:#EEE9DD;--gold:#B8960C;--gold2:#D4AC0D;--gold-light:#F5E98A;--teal:#0E6655;--teal2:#148F77;--border:rgba(13,17,23,0.12);--border-med:rgba(13,17,23,0.18);--r:8px;--r-lg:14px;--shadow-sm:0 1px 4px rgba(13,17,23,0.08);--shadow-md:0 4px 20px rgba(13,17,23,0.10);--transition:all .2s cubic-bezier(.4,0,.2,1);}
.pild-wrap{font-family:"DM Sans",sans-serif;font-weight:400;color:var(--ink);background:var(--parchment);min-height:100vh;padding:2.5rem 3rem 5rem;max-width:100%;margin:0;line-height:1.65;box-sizing:border-box;}
.pild-back-link{display:inline-flex;align-items:center;gap:.45rem;font-size:.92rem;font-weight:600;color:var(--teal);text-decoration:none;margin-bottom:2rem;padding:.35rem .7rem;border-radius:6px;background:rgba(30,111,92,.08);transition:var(--transition);}
.pild-back-link:hover{color:#fff;background:var(--teal);}
.pild-section-tag{font-size:.7rem;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--teal);margin-bottom:1rem;display:inline-block;}
.pild-track-tag{font-size:.62rem;font-weight:500;letter-spacing:.12em;text-transform:uppercase;color:var(--gold2);margin-bottom:.65rem;display:block;}
.pild-playbook-type{font-size:.62rem;font-weight:500;letter-spacing:.08em;text-transform:uppercase;padding:.18rem .65rem;border-radius:99px;border:1px solid;display:inline-flex;align-items:center;gap:.3rem;margin-right:.5rem;}
.pild-type-book{border-color:rgba(14,102,85,.3);color:var(--teal);background:rgba(14,102,85,.07);}
.pild-type-activity{border-color:rgba(184,150,12,.3);color:var(--gold);background:rgba(184,150,12,.07);}
.pild-type-exercise{border-color:rgba(20,143,119,.3);color:var(--teal2);background:rgba(20,143,119,.07);}
.pild-dash-hero{background:var(--ink);border-radius:var(--r-lg);padding:2.5rem 2.75rem;margin-bottom:2.5rem;display:flex;align-items:center;justify-content:space-between;gap:2rem;flex-wrap:wrap;position:relative;overflow:hidden;}
.pild-dash-hero::before{content:"";position:absolute;top:-60px;right:-80px;width:340px;height:340px;border-radius:50%;background:radial-gradient(circle,rgba(184,150,12,.1) 0%,transparent 70%);pointer-events:none;}
.pild-dash-hero .pild-section-tag{color:var(--gold2);margin-bottom:.5rem;}
.pild-dash-title{font-family:"Playfair Display",serif;font-size:1.8rem;font-weight:700;color:#fff;margin-bottom:.25rem;}
.pild-dash-subtitle{font-size:.88rem;color:rgba(255,255,255,.5);font-weight:300;}
.pild-dash-stat-box{display:flex;flex-direction:column;align-items:center;gap:.25rem;}
.pild-stat-num{font-family:"Playfair Display",serif;font-size:3.2rem;font-weight:700;color:var(--gold2);line-height:1;}
.pild-stat-label{font-size:.65rem;font-weight:500;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.4);}
.pild-dash-track-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1rem;margin-top:1rem;}
.pild-dash-track-card{background:#fff;border:1px solid var(--border);border-radius:var(--r-lg);padding:1.5rem;transition:var(--transition);}
.pild-dash-track-card:hover{border-color:var(--teal2);box-shadow:var(--shadow-md);}
.pild-dash-track-title{font-family:"Playfair Display",serif;font-size:1rem;font-weight:700;color:var(--ink);margin:.4rem 0 .2rem;}
.pild-dash-track-meta{font-size:.75rem;color:var(--ink3);margin-bottom:.5rem;}
.pild-track-hero{position:sticky;top:0;z-index:50;background:#fff;border-bottom:1px solid var(--border);padding:1.25rem 2.5rem;margin:-2.5rem -3rem 2.5rem;display:grid;grid-template-columns:1fr auto;gap:.5rem 2rem;align-items:center;box-shadow:0 2px 16px rgba(13,17,23,.08);}
.pild-track-hero-title{font-family:"Playfair Display",serif;font-size:1.15rem;font-weight:700;color:var(--ink);margin:.2rem 0 .1rem;}
.pild-track-hero-meta{font-size:.72rem;color:var(--ink3);}
.pild-hero-pct{font-family:"Playfair Display",serif;font-size:1.6rem;font-weight:700;color:var(--teal);}
.pild-progress-wrap{height:5px;background:var(--cream);border-radius:99px;overflow:hidden;}
.pild-progress-bar{height:100%;background:linear-gradient(90deg,var(--teal),var(--teal2));border-radius:99px;transition:width .8s cubic-bezier(.4,0,.2,1);}
.pild-programs-list{display:flex;flex-direction:column;gap:2px;margin-bottom:2rem;}
.pild-program-card{background:#fff;border:1px solid var(--border);border-radius:0;overflow:hidden;transition:var(--transition);}
.pild-program-card:first-child{border-radius:var(--r) var(--r) 0 0;}
.pild-program-card:last-child{border-radius:0 0 var(--r) var(--r);}
.pild-program-card:only-child{border-radius:var(--r);}
.pild-program-card.pild-locked{opacity:.6;filter:saturate(.3);}
.pild-program-header{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1.15rem 1.5rem;cursor:pointer;user-select:none;transition:background .15s;}
.pild-program-header:hover{background:var(--parchment);}
.pild-program-header-left{display:flex;align-items:center;gap:.85rem;flex:1;min-width:0;}
.pild-program-header-right{display:flex;align-items:center;gap:.75rem;flex-shrink:0;}
.pild-toggle-icon{color:var(--ink3);flex-shrink:0;transition:transform .25s ease;}
.pild-program-title{font-size:.92rem;font-weight:500;color:var(--ink);}
.pild-program-meta{font-size:.7rem;color:var(--ink3);margin-top:.2rem;}
.pild-badge-locked{font-size:.58rem;font-weight:500;text-transform:uppercase;background:rgba(184,150,12,.1);color:var(--gold);padding:.14rem .5rem;border-radius:99px;border:1px solid rgba(184,150,12,.25);margin-left:.5rem;}
.pild-badge-done{font-size:.58rem;font-weight:500;text-transform:uppercase;background:rgba(14,102,85,.1);color:var(--teal);padding:.14rem .5rem;border-radius:99px;border:1px solid rgba(14,102,85,.25);margin-left:.5rem;}
.pild-mini-prog-wrap{width:64px;height:4px;background:var(--cream);border-radius:99px;overflow:hidden;}
.pild-mini-prog-bar{height:100%;background:var(--teal);border-radius:99px;}
.pild-prog-pct{font-size:.67rem;font-weight:500;color:var(--ink3);min-width:26px;text-align:right;}
.pild-program-body{max-height:0;overflow:hidden;contain:layout;will-change:max-height;transition:max-height .35s cubic-bezier(.4,0,.2,1);border-top:1px solid transparent;}
.pild-program-body.pild-open{contain:none;}
.pild-program-body.pild-open{max-height:2400px;border-top-color:var(--border);}
.pild-playbook-row{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.85rem 1.5rem;border-bottom:1px solid var(--border);transition:background .15s;}
.pild-playbook-row:last-child{border-bottom:none;}
.pild-playbook-row:hover{background:var(--parchment);}
.pild-playbook-row.pild-done{opacity:.7;}
.pild-playbook-row-left{display:flex;align-items:center;gap:.7rem;flex:1;min-width:0;}
.pild-playbook-row-right{display:flex;align-items:center;gap:.5rem;flex-shrink:0;}
.pild-playbook-dot{width:16px;height:16px;border-radius:50%;border:1.5px solid var(--border-med);background:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.pild-dot-done{background:var(--teal);border-color:var(--teal);color:#fff;}
.pild-playbook-name{font-size:.85rem;color:var(--ink3);}
.pild-playbooks-list{display:flex;flex-direction:column;gap:6px;margin-bottom:2rem;}
.pild-playbook-full-row{display:flex;align-items:center;gap:1.25rem;padding:.95rem 1.25rem;border:1px solid var(--border);border-radius:var(--r);background:#fff;transition:var(--transition);}
.pild-playbook-full-row:hover{border-color:var(--teal2);box-shadow:var(--shadow-sm);transform:translateX(3px);}
.pild-playbook-full-row.pild-done{opacity:.7;}
.pild-playbook-full-num{font-size:.62rem;font-weight:500;color:var(--ink3);flex-shrink:0;width:20px;}
.pild-playbook-full-info{flex:1;min-width:0;display:flex;align-items:center;flex-wrap:wrap;gap:.4rem;}
.pild-playbook-full-title{font-size:.88rem;color:var(--ink2);}
.pild-playbook-full-actions{display:flex;align-items:center;gap:.5rem;flex-shrink:0;}
.pild-playbook-content{font-size:1.05rem;line-height:1.85;color:var(--ink2);font-family:"DM Sans",sans-serif;font-weight:300;}
.pild-playbook-content h1,.pild-playbook-content h2,.pild-playbook-content h3{font-family:"Playfair Display",serif;font-weight:700;color:var(--ink);margin-top:2.5rem;}
.pild-playbook-content p{margin-bottom:1.4rem;}
.pild-playbook-content img{max-width:100%;border-radius:var(--r);margin:1.5rem 0;}
.pild-wrap-book{padding:0!important;margin:0!important;}
.pild-tracks-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1px;background:var(--border);margin-top:2rem;}
.pild-track-card{background:var(--parchment);transition:var(--transition);overflow:hidden;}
.pild-track-card:hover{background:#fff;box-shadow:var(--shadow-md);}
.pild-track-thumb{height:140px;background-size:cover;background-position:center;background-color:var(--cream);}
.pild-track-thumb-empty{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--cream),var(--parchment));color:var(--ink3);opacity:.4;}
.pild-track-card-body{padding:1.5rem;}
.pild-track-card-title{font-family:"Playfair Display",serif;font-size:1rem;font-weight:700;color:var(--ink);margin:.5rem 0;line-height:1.3;}
.pild-track-card-desc{font-size:.82rem;color:var(--ink3);line-height:1.6;margin-bottom:.75rem;font-weight:300;}
.pild-track-meta{display:flex;gap:1.25rem;margin-bottom:1rem;}
.pild-track-meta span{font-size:.7rem;color:var(--ink3);display:flex;align-items:center;gap:.3rem;}
.pild-track-meta span b{color:var(--ink2);font-weight:500;}
.pild-btn-primary{font-family:"DM Sans",sans-serif;font-size:.82rem;font-weight:500;color:#fff;background:var(--ink);padding:.55rem 1.35rem;border-radius:var(--r);text-decoration:none;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:.4rem;transition:var(--transition);white-space:nowrap;}
.pild-btn-primary:hover{background:var(--teal);transform:translateY(-1px);color:#fff;}
.pild-btn-primary.pild-btn-sm{font-size:.72rem;padding:.38rem .85rem;}
.pild-btn-primary.pild-btn-full{display:block;text-align:center;margin-top:1rem;width:100%;box-sizing:border-box;}
.pild-btn-ghost{font-family:"DM Sans",sans-serif;font-size:.78rem;color:var(--ink2);background:transparent;border:1px solid var(--border-med);padding:.4rem 1rem;border-radius:var(--r);text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:.4rem;transition:var(--transition);}
.pild-btn-ghost:hover{border-color:var(--ink);color:var(--ink);}
.pild-btn-outline{font-family:"DM Sans",sans-serif;font-size:.8rem;font-weight:500;color:var(--teal);background:rgba(14,102,85,.08);border:1px solid rgba(14,102,85,.2);padding:.6rem 1.4rem;border-radius:var(--r);text-decoration:none;display:inline-block;}
.pild-btn-complete{font-family:"DM Sans",sans-serif;font-size:.92rem;font-weight:500;color:#fff;background:var(--teal);border:none;cursor:pointer;padding:.9rem 2.4rem;border-radius:var(--r);display:inline-flex;align-items:center;gap:.65rem;}
.pild-badge-members{font-size:.6rem;font-weight:500;padding:.18rem .6rem;border-radius:99px;background:rgba(184,150,12,.1);color:var(--gold);border:1px solid rgba(184,150,12,.25);}
.pild-locked-notice{display:flex;align-items:flex-start;gap:1rem;padding:1.25rem 1.5rem;background:rgba(184,150,12,.06);border-left:3px solid var(--gold2);}
.pild-locked-notice strong{font-size:.88rem;color:var(--ink);display:block;margin-bottom:.3rem;}
.pild-locked-notice p{font-size:.82rem;color:var(--ink3);margin-bottom:.75rem;font-weight:300;}
.pild-locked-page{display:flex;flex-direction:column;align-items:center;gap:1rem;padding:4rem 2rem;text-align:center;border:1px solid rgba(184,150,12,.2);border-radius:var(--r-lg);background:rgba(184,150,12,.05);}
.pild-locked-page h3{font-family:"Playfair Display",serif;font-size:1.35rem;font-weight:700;color:var(--ink);}
.pild-locked-page p{font-size:.88rem;color:var(--ink3);max-width:400px;font-weight:300;}
.pild-assessment-section{display:flex;align-items:flex-start;gap:1.5rem;padding:1.75rem;border:1px solid rgba(184,150,12,.2);border-radius:var(--r-lg);background:#fff;margin-top:2rem;}
.pild-assessment-section.pild-assessment-ready{border-color:rgba(184,150,12,.45);background:rgba(184,150,12,.04);}
.pild-assessment-icon{color:var(--gold2);flex-shrink:0;margin-top:.2rem;}
.pild-assessment-title{font-family:"Playfair Display",serif;font-size:1.05rem;font-weight:700;color:var(--ink);margin-bottom:.4rem;}
.pild-assessment-desc{font-size:.84rem;color:var(--ink3);margin-bottom:.85rem;font-weight:300;}
.pild-assessment-locked-label{font-size:.72rem;font-weight:500;padding:.4rem 1rem;border-radius:var(--r);background:var(--cream);color:var(--ink3);border:1px solid var(--border);display:inline-block;}
.pild-completion-banner{display:flex;align-items:center;gap:1rem;padding:1.25rem 1.5rem;background:rgba(14,102,85,.07);border:1px solid rgba(14,102,85,.2);border-radius:var(--r-lg);margin-top:1.5rem;flex-wrap:wrap;}
.pild-completion-banner strong{font-size:.9rem;color:var(--teal);font-weight:600;}
.pild-program-description{padding:1.25rem 1.5rem;border:1px solid var(--border);border-radius:var(--r);background:#fff;margin-bottom:1.5rem;font-size:.9rem;color:var(--ink3);line-height:1.8;font-weight:300;}
.pild-empty-state{display:flex;flex-direction:column;align-items:center;gap:.75rem;padding:3.5rem 2rem;text-align:center;border:1px dashed var(--border);border-radius:var(--r-lg);}
.pild-empty-sm{padding:2rem;}
.pild-empty-icon{font-size:2rem;opacity:.4;color:var(--ink3);}
.pild-empty-state p{font-size:.88rem;color:var(--ink3);font-weight:300;}
.pild-restricted{max-width:460px;margin:4rem auto;padding:2.5rem;text-align:center;background:#fff;border:1px solid var(--border);border-radius:var(--r-lg);box-shadow:var(--shadow-md);}
.pild-restricted-icon{font-size:2.5rem;margin-bottom:1.25rem;display:block;}
.pild-restricted h2{font-family:"Playfair Display",serif;font-size:1.4rem;font-weight:700;color:var(--ink);margin-bottom:.5rem;}
.pild-restricted p{font-size:.88rem;color:var(--ink3);margin-bottom:1.5rem;font-weight:300;}
@keyframes pild-fade-up{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
.pild-program-body.pild-open .pild-playbook-row{animation:pild-fade-up .2s ease both;}
@media(max-width:768px){.pild-wrap{padding:1.25rem 1rem 5rem;}.pild-track-hero{padding:1rem;margin:-1.25rem -1rem 1.5rem;}.pild-tracks-grid{grid-template-columns:1fr;}.pild-dash-track-grid{grid-template-columns:1fr;}.pild-dash-hero{padding:1.5rem;}}
</style>' . $dashboard_css;
}

function pild_restricted_html( $type, $redirect = '', $track_id = 0 ) {
    $css      = pild_global_css();

    // PHASE 6: a lapsed 1-year access window is a distinct case from
    // "never purchased" — different icon/copy, and the call to action
    // depends on WHO would need to act: a team member can't renew their
    // own seat (their manager owns the purchase), so they're told to ask
    // their manager instead of being shown a "buy" button they can't
    // meaningfully use.
    if ( $type === 'expired' ) {
        $manager_id = function_exists( 'pildcm_get_member_manager' ) ? pildcm_get_member_manager( get_current_user_id() ) : null;

        if ( $manager_id ) {
            $manager = get_userdata( $manager_id );
            $desc = $manager
                ? sprintf( esc_html__( 'Your one-year access to this track has ended. Ask %s (your manager) to renew your team\'s access to continue.', 'pild-unified' ), esc_html( $manager->display_name ) )
                : esc_html__( 'Your one-year access to this track has ended. Ask your manager to renew your team\'s access to continue.', 'pild-unified' );
            return $css . '
            <div class="pild-wrap">
              <div class="pild-restricted">
                <span class="pild-restricted-icon">⏳</span>
                <h2>' . esc_html__( 'Access Expired', 'pild-unified' ) . '</h2>
                <p>' . $desc . '</p>
              </div>
            </div>';
        }

        // Individual buyer: point them straight at the same track's product.
        $renew_url = '#';
        if ( $track_id && function_exists( 'get_field' ) ) {
            $product = get_field( 'pild_product_individual', $track_id );
            $product_id = is_object( $product ) ? $product->ID : ( is_array( $product ) ? ( $product['ID'] ?? 0 ) : (int) $product );
            if ( $product_id ) $renew_url = get_permalink( $product_id );
        }
        return $css . '
        <div class="pild-wrap">
          <div class="pild-restricted">
            <span class="pild-restricted-icon">⏳</span>
            <h2>' . esc_html__( 'Access Expired', 'pild-unified' ) . '</h2>
            <p>' . esc_html__( 'Your one-year access to this track has ended. Renew now to keep learning.', 'pild-unified' ) . '</p>
            <a href="' . esc_url( $renew_url ) . '" class="pild-btn-primary">' . esc_html__( 'Renew Access →', 'pild-unified' ) . '</a>
          </div>
        </div>';
    }

    // PHASE: "not enrolled in this Playbook's Track yet" — replaces the old
    // generic 'membership' type (which pointed at WooCommerce My Account /
    // PMPro's levels page, neither of which means anything for a Track-based
    // sale). Points straight at the Track's own individual-purchase product
    // when one is set, falling back to the Track's own landing page (where
    // team/company purchase options are also visible) otherwise.
    if ( $type === 'track' ) {
        $buy_url = $track_id ? get_permalink( $track_id ) : '#';
        if ( $track_id && function_exists( 'get_field' ) ) {
            $product    = get_field( 'pild_product_individual', $track_id );
            $product_id = is_object( $product ) ? $product->ID : ( is_array( $product ) ? ( $product['ID'] ?? 0 ) : (int) $product );
            if ( $product_id ) $buy_url = get_permalink( $product_id );
        }
        return $css . '
        <div class="pild-wrap">
          <div class="pild-restricted">
            <span class="pild-restricted-icon">🔐</span>
            <h2>' . esc_html__( 'Track Enrollment Required', 'pild-unified' ) . '</h2>
            <p>' . esc_html__( 'This Playbook is part of a Development Track. Enroll in the track to unlock it.', 'pild-unified' ) . '</p>
            <a href="' . esc_url( $buy_url ) . '" class="pild-btn-primary">' . esc_html__( 'View the Track →', 'pild-unified' ) . '</a>
          </div>
        </div>';
    }

    $icon     = $type === 'login' ? '🔐' : '⭐';
    $title    = $type === 'login' ? __('Login Required', 'pild-unified') : __('Members Only', 'pild-unified');
    $desc     = $type === 'login'
        ? __('Please log in to access this content.', 'pild-unified')
        : __('This content is available to members only. Upgrade your plan to get full access.', 'pild-unified');
    $btn_text = $type === 'login' ? __('Login →', 'pild-unified') : __('View Membership Plans →', 'pild-unified');
    $btn_href = $type === 'login'
        ? wp_login_url( $redirect )
        : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : ( function_exists( 'pmpro_url' ) ? pmpro_url( 'levels' ) : '#' ) );
    return $css . '
    <div class="pild-wrap">
      <div class="pild-restricted">
        <span class="pild-restricted-icon">' . $icon . '</span>
        <h2>' . esc_html( $title ) . '</h2>
        <p>' . esc_html( $desc ) . '</p>
        <a href="' . esc_url( $btn_href ) . '" class="pild-btn-primary">' . esc_html( $btn_text ) . '</a>
      </div>
    </div>';
}

// ============================================================
// ADMIN SETTINGS PAGE (merged from both plugins)
// ============================================================
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'pild_settings_link' );
function pild_settings_link( $links ) {
    array_unshift( $links, '<a href="' . admin_url( 'admin.php?page=pild-settings' ) . '">Settings</a>' );
    return $links;
}

add_action( 'admin_menu', 'pild_add_admin_menu' );
function pild_add_admin_menu() {
    add_menu_page( 'PILD Unified', 'PILD Unified', 'manage_options', 'pild-settings', 'pild_settings_page', 'dashicons-welcome-learn-more', 25 );
}

// Handle Team Player badge backfill for existing members
add_action('admin_init', function() {
    if ( isset($_POST['pild_backfill_team_player'])
        && check_admin_referer('pild_backfill_nonce')
        && current_user_can('manage_options')
    ) {
        global $wpdb;
        $count = 0;

        // Get all users from pild_team_members (PHASE 4: was wc_memberships_team_members
        // — covers both members and managers, same as before, new table).
        $member_ids = $wpdb->get_col("
            SELECT DISTINCT user_id
            FROM {$wpdb->prefix}pild_team_members
            WHERE user_id IS NOT NULL AND user_id > 0
        ");

        foreach ( $member_ids as $uid ) {
            $uid = (int) $uid;
            if ( ! $uid ) continue;
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}pild_badges WHERE user_id=%d AND badge_key='team_player' LIMIT 1",
                $uid
            ));
            if ( ! $exists ) {
                $wpdb->insert( "{$wpdb->prefix}pild_badges", [
                    'user_id'   => $uid,
                    'badge_key' => 'team_player',
                    'ref_id'    => 0,
                    'earned_at' => current_time('mysql'),
                ]);
                $count++;
            }
        }
        set_transient('pild_backfill_result', "Done — {$count} badge(s) awarded.", 30);
        wp_redirect( admin_url('admin.php?page=pild-settings') );
        exit;
    }
});

function pild_settings_page() {
    $msg = get_transient('pild_backfill_result');
    if ($msg) delete_transient('pild_backfill_result');
    ?>
<div class="wrap">
  <h1>PILD Unified Plugin v1.0</h1>
  <p>Learning System + Company Manager — Active ✅</p>
  <?php if ($msg): ?>
    <div class="notice notice-success"><p>✅ <?php echo esc_html($msg); ?></p></div>
  <?php endif; ?>
  <hr>
  <h2>🔧 Tools</h2>
  <form method="post">
    <?php wp_nonce_field('pild_backfill_nonce'); ?>
    <p>
      <strong>Award "Team Player" badge to all existing active members</strong><br>
      <span style="color:#666;font-size:13px;">Runs once safely — skips members who already have the badge.</span>
    </p>
    <button type="submit" name="pild_backfill_team_player" class="button button-primary">
      Run Backfill
    </button>
  </form>
  <hr>
  <h2>Shortcodes</h2>
  <ul>
    <li><code>[pild_dashboard]</code> — Basic user development dashboard</li>
    <li><code>[pild_company_dashboard]</code> — Company/Manager dashboard</li>
    <li><code>[pild_member_dashboard]</code> — Team member dashboard</li>
    <li><code>[pild_solo_dashboard]</code> — Independent member dashboard (any registered/purchasing customer — packages, books, or assessments)</li>
    <li><code>[pild_my_badges]</code> — Standalone gamification widget (points/streak/badges)</li>
  </ul>
  <hr>
  <h2>Content Hierarchy</h2>
  <ol>
    <li><strong>Sector</strong> (sector) → top-level category</li>
    <li><strong>Practice Area</strong> (domain) → linked via <code>domain_sector</code></li>
    <li><strong>Track</strong> → linked via <code>track_domain</code></li>
    <li><strong>Program</strong> → linked via <code>program_track</code></li>
    <li><strong>Playbook</strong> → linked via <code>playbook_program</code></li>
    <li><strong>Assessment</strong> → linked to Track via <code>assessment_track</code>, and to the Practice Area (Domain) certification exam configured in <code>15-domain-certification.php</code></li>
  </ol>
  <hr>
  <h2>Gamification</h2>
  <p>Points: Playbook (+10), Program (+50), Track (+200), Assessment Pass (+100), First Login (+5), 3-Day Streak (+30)</p>
  <p>Badges: First Step, Track Finisher, 7-Day Streak, 30-Day Streak, Top Scorer, Early Bird, Fast Learner, Certified, Team Player</p>
  <hr>
  <h2>Smart Login Redirect</h2>
  <p>Manager → /company-dashboard/ · Team Member → /member-dashboard/ · Anyone who registers or purchases anything (free package, paid package, book, or assessment) → /solo-dashboard/</p>
</div>
<?php }

// ============================================================
// Load CSS module first — defines pildcm_css() used by all dashboard shortcodes below.
require_once PILD_PATH . 'includes/11-css.php';

// LOAD COMPANY MANAGER MODULES (unchanged files from the plugin)
// ============================================================
$pild_modules = [
    '01-config',             // Points & badges config
    '02-helpers',            // Core helper functions (pildcm_*)
    '03-ajax',               // AJAX: team sync, assign track, invite, login redirect
    '04-dashboard-company',  // [pild_company_dashboard]
    '05-dashboard-member',   // [pild_member_dashboard]
    '06-dashboard-solo',     // [pild_solo_dashboard]
    '07-dashboard-customer', // [pild_my_badges] (standalone customer dashboard removed — folded into solo dashboard)
    '09-admin',              // Admin enrollment report
    '10-quiz-certificate',   // Quiz Maker + certificate generation
    '12-cert-verify-acf',    // Certificate verification + ACF fields
    '13-polylang',           // Polylang integration (multilingual EN/AR support)
    '14-partner-pricing',    // Training Partner role + hidden partner pricing
    '15-domain-certification', // Practice Area professional certificate
    '16-public-profile',     // [Public Professional Profile] /profile/{username} + Make Public toggle
    '17-sector-explorer',    // [pild_sector_explorer] Sector -> Practice Area -> Track -> Program drill-down
    '28-quiz-engine',        // Native assessment engine: question bank, session-locked random draw, server-side timer/scoring, anti-cheat, certificate/badge hookup (opt-in per track — see includes/28-quiz-engine.php header)
    '29-quiz-admin',         // Native assessment engine admin tools: bulk question import, item-exposure report
    '18-excel-importer',     // Admin -> Import Sector: bulk Sectors/Domains/Tracks/Programs/Books
    // NOTE: 26-products-importer.php (Admin -> Import Products, one WooCommerce
    //   product per track) is REMOVED per client decision — superseded entirely
    //   by the level-based pricing model (see 31-pricing-importer.php: Import
    //   Track Pricing), which creates a small fixed set of shared level
    //   products and links every track to one of them by its track_pricing_level.
    //   The file is left on disk, unloaded, rather than deleted, in case
    //   anything still needs its history.
    '27-canvas-template',    // Forces Track/Program/Playbook singular pages onto a bare template (templates/canvas.php) — no theme header/footer/nav, matches an "Elementor Canvas"-style full-width distraction-free page without depending on Elementor.
    // NOTE: 30-team-checkout.php ([pild_team_multi_checkout], the standalone
    //   "register more than one track" page) is REMOVED per client decision —
    //   registering for several tracks now happens inline from the Sector
    //   Explorer itself (register a track -> stays on the page -> "register
    //   another track" -> pick the next one -> everything accumulates in the
    //   same cart), so a separate page for it is no longer needed. The file
    //   is left on disk, unloaded, rather than deleted, in case anything
    //   still needs its history.
    '21-excel-exporter',     // Admin -> Export to Excel: same sheets/columns as the importer, from live data
    '19-sector-delete',      // Admin -> Delete a Sector: cascade-delete a sector + everything under it
    '20-admin-filters',      // Admin list screens -> Sector/Domain/Track/Program filter dropdowns
    '22-registration-routing', // "Register" button routing: individual vs team product, by real role or guest audience-tab session
    '23-teams-core',         // PHASE 1 of Teams-extension replacement: own pild_teams/pild_team_members/pild_team_tracks/pild_invites tables + core functions.
    '24-team-purchase',      // PHASE 2: Team-product detection (pild_product_team), minimum-seats=5 enforcement, Individual qty locked to 1, purchase hook creates a team instead of a plain enrollment for Team products.
    '25-access-reminders',   // PHASE 7: daily cron — 7-day and 1-day email reminders before a member's 1-year access window ends (individual buyers get a renewal link; team members are told to contact their manager; managers get one aggregated summary email per batch).
    '31-pricing-importer',   // Admin -> Import Track Pricing: reads a per-sector pricing worksheet (كود التراك/المستوى/prices), auto-creates the 6 shared level products, tags each track's track_pricing_level by code
    '32-catalog-health',     // Admin -> Catalog & Pricing Health: read-only report of tracks missing/mismatched pricing levels and the configured level products
    '33-profile-cv',         // Member/solo dashboard "Resume" tab (experience, education, skills) + public-profile display of the same
    '34-book-store',         // Book Store: Sector -> Domain -> Book CPT, each linked to a WooCommerce product; [pild_book_store] shortcode + Admin -> Import Bookstore (creates Sectors/Domains/Books/Products from one Excel file)
    '35-purchase-category',  // Sep 2026: Training-Partner "pending application" purchase lock + Organization quick-registration (org name/responsible/phone) collected inline from the card-level category selector, before add-to-cart
    '36-sar-symbol',         // Replaces WooCommerce's plain-text "ر.س" SAR symbol with the official SAMA riyal symbol (SVG, self-hosted via a one-time server-side download) — same graphic in Arabic and English since it isn't text
    '37-track-articles',     // Links a WP Category to a Domain (ACF field on the category edit screen) and gates that Category's articles behind Track enrollment in that Domain (native pild_enrollments check, fail-closed) — free articles (unlinked category) are untouched
    '42-leadership-assessment', // Free, self-report Leadership Assessment (36-question, 8-competency, sector-aware) + an independent free invite system (own pild_la_teams tables — not tied to any purchase). Fully self-contained module: own DB tables/data/JS. Only other touch point is two new tabs added to 06-dashboard-solo.php (search "LEADERSHIP ASSESSMENT" there).
    // NOTE: 08-playbook-engine.php is NOT loaded —
    //   its playbook-complete button is superseded by pild_inject_playbook_footer()
    //   and its AJAX handler by pild_unified_complete_playbook() above.
    // NOTE: 11-css.php is loaded separately BEFORE this list (defines pildcm_css()).
];
foreach ( $pild_modules as $file ) {
    require_once PILD_PATH . 'includes/' . $file . '.php';
}

// ============================================================
// BLOCK WP-LOGIN / WP-ADMIN / REGISTRATION FOR NON-ADMINS
//
// Rules:
//  1. /wp-login.php — redirect everyone to /my-account/
//     (WooCommerce My Account page handles login, registration, lost password)
//  2. /wp-admin/    — non-admins & non-editors get sent to their dashboard
//  3. wp-login.php?action=register — disabled; redirect to /my-account/
//
// Admins/editors (anyone with 'edit_posts' cap) are never blocked.
// REST API and AJAX requests from /wp-admin/ are never blocked.
// ============================================================

/**
 * 1. Block direct access to /wp-login.php
 *
 * Fires on 'init' — early enough to redirect before wp-login outputs anything.
 * We allow the internal WordPress AJAX calls that legitimately POST to wp-login
 * (e.g. interim login dialog). Those come with specific interim-login params.
 */
add_action( 'init', 'pild_block_wp_login_page', 1 );
function pild_block_wp_login_page() {
    // Only act when WordPress itself is loading the login page
    if ( ! isset( $GLOBALS['pagenow'] ) || $GLOBALS['pagenow'] !== 'wp-login.php' ) {
        return;
    }

    $action = $_REQUEST['action'] ?? '';

    // Allow: interim login popup (used by wp-admin session-expired dialog)
    if ( $action === 'interim-login' ) {
        return;
    }

    // Allow: logout action so users can actually log out
    if ( $action === 'logout' ) {
        return;
    }

    // Allow: postpass (password-protected posts)
    if ( $action === 'postpass' ) {
        return;
    }

    // Block registration via wp-login.php?action=register → send to My Account
    if ( $action === 'register' ) {
        wp_redirect( home_url( '/my-account/' ) );
        exit;
    }

    // Block lost-password via wp-login.php?action=lostpassword → send to My Account
    // WooCommerce My Account has its own lost-password form at /my-account/lost-password/
    if ( $action === 'lostpassword' || $action === 'retrievepassword' ) {
        wp_redirect( home_url( '/my-account/lost-password/' ) );
        exit;
    }

    // Allow: rp / resetpass links (the email reset links must work)
    if ( $action === 'rp' || $action === 'resetpass' ) {
        return;
    }

    // Block: default login page (GET request, no special action)
    // If the user is already logged in → send them to their dashboard
    if ( is_user_logged_in() ) {
        wp_redirect( pild_get_user_dashboard_url( get_current_user_id() ) );
        exit;
    }

    // Not logged in → send to WooCommerce My Account login form
    wp_redirect( home_url( '/my-account/' ) );
    exit;
}

/**
 * 2. Block /wp-admin/ for non-admins
 *
 * 'admin_init' runs before any wp-admin page renders.
 * We skip AJAX requests (admin-ajax.php) and REST requests.
 */
add_action( 'admin_init', 'pild_block_wp_admin_for_non_admins' );
function pild_block_wp_admin_for_non_admins() {
    // Never block AJAX requests — they go through admin-ajax.php and are needed by the front-end
    if ( wp_doing_ajax() ) {
        return;
    }

    // Never block REST API requests routed through wp-admin
    if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
        return;
    }

    // Allow admins and editors through
    if ( current_user_can( 'edit_posts' ) ) {
        return;
    }

    // Everyone else: redirect to their appropriate dashboard
    wp_redirect( pild_get_user_dashboard_url( get_current_user_id() ) );
    exit;
}

/**
 * Helper: resolve the correct front-end dashboard URL for a given user.
 * Mirrors the logic in pildcm_smart_login_redirect() from 03-ajax.php.
 */
function pild_get_user_dashboard_url( $user_id ) {
    if ( ! $user_id ) {
        return home_url( '/my-account/' );
    }

    global $wpdb;

    // Approved Training Partner: checked FIRST, same priority given to
    // this role everywhere else in the plugin (includes/22-registration-
    // routing.php's pild_get_registration_context()) — a partner should
    // never be routed to the plain individual/company dashboard just
    // because they also happen to have completed an order or own a team.
    // Points at a page with the slug "partner-dashboard" IF one exists;
    // until that page is built this silently falls through to the normal
    // chain below, so nothing breaks in the meantime.
    if ( function_exists( 'pild_is_approved_partner' ) && pild_is_approved_partner( $user_id ) ) {
        $partner_page = get_page_by_path( 'partner-dashboard' );
        if ( $partner_page ) {
            return get_permalink( $partner_page );
        }
    }

    // Manager: owns a team
    // PHASE 4: was wc_memberships_teams — now pild_teams (includes/23-teams-core.php).
    $is_owner = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_teams WHERE owner_id = %d LIMIT 1", $user_id
    ) );
    if ( $is_owner ) {
        return pild_dashboard_url('company-dashboard');
    }

    // Team Member
    $in_team = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}pild_team_members WHERE user_id=%d AND role='member' LIMIT 1", $user_id
    ) );
    if ( $in_team ) {
        return pild_dashboard_url('member-dashboard');
    }

    // Solo member (active WC membership not via a team)
    if ( function_exists( 'wc_memberships_get_user_memberships' ) ) {
        $memberships = wc_memberships_get_user_memberships( $user_id, [ 'status' => 'active' ] );
        if ( ! empty( $memberships ) ) {
            return pild_dashboard_url('solo-dashboard');
        }
    }

    // Any customer who registered/purchased anything (free package, paid
    // package, book, or assessment) becomes a member and goes to the
    // unified Independent Member ("solo") Dashboard — same as an active
    // WC membership above. In practice pild_auto_enroll_buyer_in_free_plan()
    // already grants an active free-plan membership on any completed order,
    // so this is mostly a safety net for orders processed before that hook ran.
    if ( function_exists( 'wc_get_orders' ) ) {
        $orders = wc_get_orders( [
            'customer' => $user_id,
            'limit'    => 1,
            'status'   => [ 'completed', 'processing' ],
        ] );
        if ( ! empty( $orders ) ) {
            return pild_dashboard_url('solo-dashboard');
        }
    }

    // Fallback: My Account
    return home_url( '/my-account/' );
}

// ============================================================
// SAFETY STUBS — 08-playbook-engine.php is intentionally NOT loaded.
// These stubs prevent fatal errors if any theme/plugin calls the old functions.
// ============================================================
if ( ! function_exists( 'pildcm_show_enrollment_count' ) ) {
    function pildcm_show_enrollment_count( $content ) { return $content; }
}
if ( ! function_exists( 'pildcm_inject_playbook_complete_button' ) ) {
    function pildcm_inject_playbook_complete_button( $content ) { return $content; }
}
if ( ! function_exists( 'pildcm_ajax_mark_playbook_complete' ) ) {
    function pildcm_ajax_mark_playbook_complete() {
        // Superseded by pild_unified_complete_playbook() registered on wp_ajax_pildcm_mark_playbook_complete
        wp_send_json_error( 'Handler moved to pild_unified_complete_playbook.' );
    }
}

// ============================================================
// AUTO-ENROLL IN FREE PLAN ON PURCHASE
// When a customer completes any WooCommerce order (book, assessment,
// or any product), automatically enroll them in the Free membership
// plan so they get the solo dashboard and free articles.
//
// To configure: go to WooCommerce → Memberships → Plans and note
// the slug (or ID) of your free plan. Set it in the constant below,
// or add a filter: add_filter('pild_free_plan_slug', fn() => 'my-free-plan');
// ============================================================

if ( ! defined( 'PILD_FREE_PLAN_SLUG' ) ) {
    define( 'PILD_FREE_PLAN_SLUG', 'free' ); // ← Change to your free plan's slug
}

/**
 * Fire on order completion and payment to catch both paid and free products.
 */
add_action( 'woocommerce_order_status_completed', 'pild_auto_enroll_buyer_in_free_plan', 20 );
add_action( 'woocommerce_payment_complete',       'pild_auto_enroll_buyer_in_free_plan', 20 );

function pild_auto_enroll_buyer_in_free_plan( $order_id ) {
    // Don't run if WC Memberships isn't active
    if ( ! function_exists( 'wc_memberships_get_user_memberships' ) ) {
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    $user_id = $order->get_user_id();
    if ( ! $user_id ) {
        // Guest checkout — no user account to enrol
        return;
    }

    // Allow the free plan slug to be overridden via filter
    $free_plan_slug = apply_filters( 'pild_free_plan_slug', PILD_FREE_PLAN_SLUG );

    // Resolve plan by slug; try ID if slug isn't found
    $free_plan = wc_memberships_get_membership_plan( $free_plan_slug );

    // Fallback: if slug lookup fails, iterate all plans and find by slug
    if ( ! $free_plan && function_exists( 'wc_memberships_get_membership_plans' ) ) {
        foreach ( wc_memberships_get_membership_plans() as $plan ) {
            if ( $plan->get_slug() === $free_plan_slug ) {
                $free_plan = $plan;
                break;
            }
        }
    }

    if ( ! $free_plan ) {
        // Free plan not found — log and exit
        error_log( 'PILD: Free plan "' . $free_plan_slug . '" not found. Create it in WooCommerce → Memberships → Plans.' );
        return;
    }

    $plan_id = $free_plan->get_id();

    // Check if user already has this membership (any status)
    $existing = wc_memberships_get_user_memberships( $user_id, [
        'plan_id' => $plan_id,
    ] );

    if ( ! empty( $existing ) ) {
        // Already enrolled — nothing to do
        return;
    }

    // Enrol the user in the free plan
    wc_memberships_create_user_membership( [
        'user_id' => $user_id,
        'plan_id' => $plan_id,
        'order_id' => $order_id,
    ] );

    error_log( 'PILD: User #' . $user_id . ' enrolled in free plan "' . $free_plan_slug . '" after order #' . $order_id );
}

// ============================================================
// AUTO-ENROLL IN THE SPECIFIC TRACK(S) A PRODUCT UNLOCKS
// ------------------------------------------------------------
// Root-cause fix for: "customer/manager buys a track's product but it
// never shows up in the dashboard." Previously the ONLY thing that
// happened automatically on purchase was enrollment in the free
// WooCommerce Memberships plan (above) — nothing tied the specific
// product purchased to the specific track it was supposed to unlock.
// Everything else depended on WooCommerce Memberships being manually
// configured per-product (Plan → Purchase tab → Content Restriction
// rule on the track), which is fragile and easy to forget when adding
// new tracks/products.
//
// This hook reads the new ACF field `product_tracks` on each purchased
// product (see acf/include_fields above) and inserts a row directly
// into pild_enrollments — completely independent of whether WooCommerce
// Memberships is even configured for that product. It also busts the
// dashboard's 5-minute track cache so the track shows up immediately.
// ============================================================
add_action( 'woocommerce_order_status_completed', 'pild_auto_enroll_tracks_from_purchase', 20 );
add_action( 'woocommerce_payment_complete',       'pild_auto_enroll_tracks_from_purchase', 20 );

// PHASE 8: ACF being deactivated (accidentally, or a failed update) used to
// mean every completed order silently enrolled nobody — the customer paid,
// got nothing, and no one found out until they complained. Now: (1) a
// persistent red notice in wp-admin as long as ACF is missing, and (2) a
// real-time email to the site admin naming the specific order that just
// failed to auto-enroll, rate-limited to at most one email per 30 minutes
// so a prolonged outage doesn't flood the inbox — every occurrence is still
// logged to error_log regardless of the email rate limit.
function pild_alert_acf_missing( $order_id ) {
    error_log( "PILD ALERT: Advanced Custom Fields (ACF) is not active — order #{$order_id} completed without auto-enrollment running." );

    if ( get_transient( 'pild_acf_missing_alert_sent' ) ) return; // rate limit
    set_transient( 'pild_acf_missing_alert_sent', 1, 30 * MINUTE_IN_SECONDS );

    $admin_email = get_option( 'admin_email' );
    $subject     = '🚨 PILD: Orders are NOT being enrolled (ACF inactive)';
    $message  = "Advanced Custom Fields (ACF) is not active on your site.\n\n";
    $message .= "Order #{$order_id} (and possibly others while this persists) just completed WITHOUT any track enrollment happening — the plugin's purchase-to-access automation depends entirely on ACF.\n\n";
    $message .= "To fix: reactivate the ACF plugin, then manually check order #{$order_id} and enroll the customer if needed from the Enrollment Report in wp-admin.\n\n";
    $message .= "This is a rate-limited alert — you won't be emailed again for 30 minutes even if more orders are affected in the meantime, but every occurrence is being logged.";

    wp_mail( $admin_email, $subject, $message );
}

add_action( 'admin_notices', function () {
    if ( function_exists( 'get_field' ) ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;
    echo '<div class="notice notice-error"><p><strong>PILD:</strong> ' .
        esc_html__( 'Advanced Custom Fields (ACF) is not active. Course purchases will NOT auto-enroll customers until this is fixed.', 'pild-unified' ) .
        '</p></div>';
} );

function pild_auto_enroll_tracks_from_purchase( $order_id ) {
    if ( ! function_exists( 'get_field' ) ) {
        pild_alert_acf_missing( $order_id ); // PHASE 8: was a silent `return` — see function below.
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    $user_id = $order->get_user_id();
    if ( ! $user_id ) {
        return; // guest checkout — no account to enroll
    }

    $enrolled_any = false;

    foreach ( $order->get_items() as $item ) {
        $product_id = $item->get_product_id();
        if ( ! $product_id ) {
            continue;
        }

        // Prefer the track tagged on this specific order LINE (see
        // includes/22-registration-routing.php, 26.11) — required once a
        // product is one of the 6 shared pricing-level products, since
        // product_tracks on the product itself can't identify a single
        // track anymore. Falls back to the legacy field for any order
        // still going through a dedicated per-track product.
        $item_track_id = (int) $item->get_meta( '_pild_track_id', true );
        $track_ids = $item_track_id ? [ $item_track_id ] : (array) get_field( 'product_tracks', $product_id );
        if ( empty( $track_ids ) ) {
            continue;
        }

        // Team products are handled entirely by pild_team_create_from_purchase()
        // in includes/24-team-purchase.php (runs first, at priority 5) — a team
        // gets created with seats, not a plain per-buyer enrollment. Skip here
        // to avoid doing both.
        if ( apply_filters( 'pild_skip_individual_enroll_for_item_' . $order_id . '_' . $product_id, false ) ) {
            continue;
        }

        foreach ( (array) $track_ids as $track_id ) {
            $track_id = (int) $track_id;
            if ( ! $track_id || get_post_status( $track_id ) !== 'publish' ) {
                continue;
            }

            // Resolve the track's program (if any) so progress/points logic
            // that expects a program_id keeps working.
            $program_id = 0;
            $programs   = get_posts( [
                'post_type'      => 'program',
                'posts_per_page' => 1,
                'meta_key'       => 'program_track',
                'meta_value'     => $track_id,
                'fields'         => 'ids',
            ] );
            if ( ! empty( $programs ) ) {
                $program_id = (int) $programs[0];
            }

            $inserted = pildcm_enroll_user( $user_id, $track_id, $program_id, $user_id, null );
            if ( $inserted ) {
                $enrolled_any = true;
                error_log( "PILD: User #$user_id auto-enrolled in track #$track_id from product #$product_id (order #$order_id)." );
            }
        }
    }

    if ( $enrolled_any && function_exists( 'pild_bust_track_cache' ) ) {
        pild_bust_track_cache( $user_id );
    }
}

