<?php
if (!defined('ABSPATH')) exit;
// PHASE 17: bare "canvas" template — no theme header.php/footer.php, no
// nav bar, no site chrome. Used for Track/Program/Playbook single pages
// (see includes/27-canvas-template.php) so those pages show only the
// plugin's own generated content (hero, progress bar, program list, etc.
// via the_content() below), full-width and distraction-free.
// wp_head()/wp_footer() still run — required for enqueued CSS/JS
// (including Elementor's own assets, if used elsewhere on the site) and
// for any analytics/tracking scripts hooked into those actions.
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('pild-canvas-page'); ?>>
<?php while (have_posts()) : the_post(); ?>
  <?php the_content(); ?>
<?php endwhile; ?>
<?php wp_footer(); ?>
</body>
</html>
